# Contract transfer: PhysioNet/CinC 2019 sepsis (patient-hour records)

Status: internally frozen; `prereg_hashes.json` (binding this plan,
`frozen_design.json`, and `code/run_sepsis.py`) is RFC 3161-timestamped before
any data file is retrieved. Not an OSF/Zenodo preregistration. The labels are
public (Reyna et al. 2019); the authors have not downloaded any record file.

## Data

Training sets A and B (40,336 patient files, one row per ICU hour), downloaded
once by the runner from physionet.org, packed into a deterministic zip, and
hashed before parsing. Endpoint: `SepsisLabel` (already shifted six hours early
by the challenge). Dependence unit: patient (file).

## Features and preprocessing

Allowlist: HR, O2Sat, Temp, SBP, MAP, DBP, Resp, Age, Gender, HospAdmTime,
ICULOS. Within-patient last-observation-carried-forward (past values only);
remaining gaps imputed with construction-set medians.
Value gate on construction rows after LOCF: missing fraction ≤ 0.5 and ≥ 2
distinct values per field.

## Split

Patient-hash holdout, salt 20260927, fraction 0.25. Construction = the rest.
Tuning: GroupKFold (3) by patient on a 30% patient subsample of construction;
refit on all construction rows.

## Candidates

- B0: construction prevalence.
- B1: logistic regression on HR, Resp, Temp.
- B2: logistic regression on the allowlist.
- B4: random forest (100 trees, max_samples 0.1).
- B5: histogram gradient boosting.
- C_rowsplit (literature protocol, not an author-designed leak): B5 with its
  tuned parameters trained on a row-random 75% of all rows, the "leaky random
  split" contrasted in Jin & Lee (2026). Its training rows include holdout
  patients' rows; the role audit (patient) and a row-identity check both
  refuse it.

## Decision

Name, value, role gates; then CR1 patient-cluster paired Brier, Holm over the
ten admissible pairs (α = 0.05).

- H1: B1, B2, B4, B5 each beat B0 and are Holm-rejected.
- H2: B2, B4, B5 each beat B1 and are Holm-rejected.
- E1: the contract refuses C_rowsplit.
- E2: a score-only workflow admits all six and selects C_rowsplit.

## Overlap inflation (primary for the overlap question)

B5 (same tuned parameters) is also fitted on a row-random 75% of all rows and
scored on the remaining row-random 25%. Compare AUROC and Brier with B5 on the
patient-disjoint holdout. Inflation is declared if the patient-cluster bootstrap
(1,000 draws) 95% intervals of the two AUROCs do not overlap and the row-random
AUROC is higher. Report the share of row-random test patients present in its
training rows.

## Evaluability floors

≥ 1,000 holdout patients, ≥ 100 septic holdout patients, ≥ 100 positive rows.
Otherwise `non_evaluable`, no Holm labels.

## One-shot

The runner refuses to overwrite results or to run on a prereg hash mismatch.
