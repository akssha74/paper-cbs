#!/usr/bin/env python3
"""One-shot contract transfer on PhysioNet/CinC 2019 sepsis patient-hour records.

Refuses to run on a prereg hash mismatch or if results exist. Record files are
downloaded once, packed into a deterministic zip, and hashed before parsing.
`--synthetic-dry-run DIR` exercises the full pipeline on generated records in
DIR (no network, no results written) and is used only to test the code.
"""
from __future__ import annotations

import concurrent.futures as cf
import hashlib
import io
import itertools
import json
import os
import platform
import re
import sys
import time
import urllib.request
import zipfile

import numpy as np
import scipy
import sklearn
from scipy.stats import t as student_t
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PREREG = os.path.join(ROOT, "prereg")


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha(path):
    return sha_bytes(open(path, "rb").read())


def get(url, tries=6):
    last = None
    for a in range(tries):
        try:
            return urllib.request.urlopen(url, timeout=120).read()
        except Exception as exc:  # noqa: BLE001
            last = exc
            time.sleep(min(30, 2 ** a))
    raise RuntimeError(f"retrieval failed {url}: {last}")


def retrieve(design):
    names = []
    for sub in design["subsets"]:
        idx = get(design["base_url"] + sub + "/").decode("utf-8")
        for f in sorted(set(re.findall(r'href="(p\d+\.psv)"', idx))):
            names.append(f"{sub}/{f}")
    if len(names) != design["expected_files"]:
        raise SystemExit(f"expected {design['expected_files']} files, listing has {len(names)}")
    blobs = {}
    with cf.ThreadPoolExecutor(max_workers=32) as ex:
        futs = {ex.submit(get, design["base_url"] + n): n for n in names}
        for fut in cf.as_completed(futs):
            blobs[futs[fut]] = fut.result()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for n in sorted(blobs):
            zi = zipfile.ZipInfo(n, date_time=(1980, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(zi, blobs[n])
    return buf.getvalue(), names


def parse(zip_bytes, design):
    """Return arrays: X (allowlist after LOCF, NaN kept), y, patient ids, hospital."""
    allow = design["allowlist"]
    zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    Xs, ys, pids, hosp, raw_obs = [], [], [], [], []
    for n in sorted(zf.namelist()):
        lines = zf.read(n).decode("utf-8").strip().split("\n")
        head = lines[0].split("|")
        col = {h: i for i, h in enumerate(head)}
        m = np.array([[np.nan if v == "NaN" else float(v) for v in ln.split("|")] for ln in lines[1:]], dtype=float)
        x = m[:, [col[f] for f in allow]]
        raw_obs.append(~np.isnan(x))
        for j in range(x.shape[1]):
            v = x[:, j]
            last = np.nan
            for i in range(v.size):
                if np.isnan(v[i]):
                    v[i] = last
                else:
                    last = v[i]
        Xs.append(x)
        ys.append(m[:, col[design["endpoint"]]])
        pid = n.split("/")[-1][:-4]
        pids.extend([pid] * x.shape[0])
        hosp.extend([n.split("/")[0][-1]] * x.shape[0])
    return (np.vstack(Xs), np.concatenate(ys).astype(float), np.asarray(pids), np.asarray(hosp),
            np.vstack(raw_obs))


def hash_frac(key, salt):
    return int(hashlib.sha256(f"{salt}:{key}".encode()).hexdigest()[:8], 16) / 2 ** 32


def cr1(d, groups):
    point = float(np.mean(d))
    uniq, inv = np.unique(groups, return_inverse=True)
    G = uniq.size
    infl = np.bincount(inv, weights=d - point, minlength=G)
    se = float(np.sqrt(G / (G - 1.0) * np.sum(infl ** 2)) / d.size)
    if se == 0.0:
        return point, 0.0, 1.0
    return point, se, float(2 * student_t.sf(abs(point / se), G - 1))


def holm(p, alpha):
    order = sorted(range(len(p)), key=lambda i: p[i])
    rej = [False] * len(p)
    for k, i in enumerate(order):
        if p[i] <= alpha / (len(p) - k):
            rej[i] = True
        else:
            break
    return rej


def build(cid, params, rs):
    if cid.startswith("B1") or cid.startswith("B2"):
        return make_pipeline(StandardScaler(), LogisticRegression(C=params["C"], max_iter=2000))
    if cid.startswith("B4"):
        return RandomForestClassifier(n_estimators=100, max_samples=0.1, n_jobs=-1, random_state=rs,
                                      min_samples_leaf=params["min_samples_leaf"])
    if cid.startswith("B5"):
        return HistGradientBoostingClassifier(max_iter=200, learning_rate=params["learning_rate"],
                                              max_leaf_nodes=params["max_leaf_nodes"], early_stopping=False,
                                              random_state=rs)
    raise KeyError(cid)


def grid(g):
    keys = sorted(g)
    return [dict(zip(keys, v)) for v in itertools.product(*(g[k] for k in keys))]


def cols_for(cid, design):
    allow = design["allowlist"]
    if cid.startswith("B1"):
        return [allow.index(f) for f in design["b1_fields"]]
    return list(range(len(allow)))


def boot_auc(y, p, g, draws, seed):
    uniq, inv = np.unique(g, return_inverse=True)
    idx_by = [[] for _ in range(uniq.size)]
    for i, k in enumerate(inv):
        idx_by[k].append(i)
    idx_by = [np.asarray(v) for v in idx_by]
    rng = np.random.default_rng(seed)
    out = []
    for _ in range(draws):
        pick = rng.integers(0, uniq.size, uniq.size)
        ii = np.concatenate([idx_by[k] for k in pick])
        if np.unique(y[ii]).size < 2:
            continue
        out.append(roc_auc_score(y[ii], p[ii]))
    return [float(np.quantile(out, 0.025)), float(np.quantile(out, 0.975))]


def analyse(X, y, pid, hosp, raw_obs, design, fast=False):
    rs = design["random_state"]
    allow = design["allowlist"]
    hold = np.asarray([hash_frac(p, design["split"]["salt"]) < design["split"]["holdout_fraction"] for p in pid])
    cons = ~hold
    ev = design["evaluability"]
    hp = np.unique(pid[hold])
    septic = np.unique(pid[hold & (y == 1)])
    cohort = {"n_rows": int(y.size), "n_patients": int(np.unique(pid).size),
              "n_holdout_rows": int(hold.sum()), "n_holdout_patients": int(hp.size),
              "n_septic_holdout_patients": int(septic.size), "n_positive_holdout_rows": int(y[hold].sum()),
              "holdout_row_prevalence": float(y[hold].mean()),
              "holdout_rows_by_hospital": {h: int((hold & (hosp == h)).sum()) for h in sorted(set(hosp.tolist()))}}
    out = {"cohort": cohort}
    gate = {}
    for j, f in enumerate(allow):
        v = X[cons, j]
        miss = float(np.isnan(v).mean())
        dist = int(np.unique(v[~np.isnan(v)]).size)
        gate[f] = {"missing_after_locf": miss, "raw_observed_fraction": float(raw_obs[cons, j].mean()),
                   "distinct": dist, "passed": miss <= design["value_gate"]["max_missing_fraction"]
                   and dist >= design["value_gate"]["min_distinct"]}
    out["value_gate"] = gate
    if not all(g["passed"] for g in gate.values()):
        out["status"] = "refused_value_gate"
        return out
    if hp.size < ev["min_holdout_patients"] or septic.size < ev["min_septic_patients"] or y[hold].sum() < ev["min_positive_rows"]:
        out["status"] = "non_evaluable"
        return out
    med = np.nanmedian(X[cons], axis=0)
    Xi = np.where(np.isnan(X), med, X)
    Xc, yc, gc = Xi[cons], y[cons], pid[cons]
    Xh, yh, gh = Xi[hold], y[hold], pid[hold]
    cp = np.unique(gc)
    sub_p = set(cp[np.asarray([hash_frac(p, "tune") < design["tuning"]["patient_subsample"] for p in cp])].tolist())
    sub = np.asarray([p in sub_p for p in gc])
    preds, fits = {}, {}
    for cid in design["candidates"]:
        if cid.startswith("B0"):
            preds[cid] = np.full(yh.size, float(yc.mean()))
            fits[cid] = {"prevalence": float(yc.mean())}
            continue
        cols = cols_for(cid, design)
        g = grid(design["grids"][cid])
        if fast:
            g = g[:1]
        cv = []
        folds = list(GroupKFold(n_splits=design["tuning"]["cv_folds"]).split(Xc[sub], yc[sub], gc[sub]))
        for params in g:
            sc = []
            for tr, va in folds:
                m = build(cid, params, rs).fit(Xc[sub][tr][:, cols], yc[sub][tr])
                sc.append(float(np.mean((m.predict_proba(Xc[sub][va][:, cols])[:, 1] - yc[sub][va]) ** 2)))
            cv.append({"params": params, "mean_brier": float(np.mean(sc))})
        best = min(cv, key=lambda c: (c["mean_brier"], str(c["params"])))
        m = build(cid, best["params"], rs).fit(Xc[:, cols], yc)
        preds[cid] = m.predict_proba(Xh[:, cols])[:, 1]
        fits[cid] = {"best_params": best["params"], "cv": cv}
    b5p = fits["B5_hist_gbm"]["best_params"]
    rowtest = np.asarray([hash_frac(f"{p}:{i}", design["row_split"]["salt"]) < design["row_split"]["test_fraction"]
                          for i, p in enumerate(pid)])
    mrow = build("B5_hist_gbm", b5p, rs).fit(Xi[~rowtest], y[~rowtest])
    preds["C_rowsplit"] = mrow.predict_proba(Xh)[:, 1]
    p_row = mrow.predict_proba(Xi[rowtest])[:, 1]
    y_row, g_row = y[rowtest], pid[rowtest]
    train_row_patients = set(np.unique(pid[~rowtest]).tolist())
    bs = design["bootstrap"]
    infl = {
        "patient_disjoint": {"n_rows": int(yh.size), "auroc": float(roc_auc_score(yh, preds["B5_hist_gbm"])),
                             "brier": float(np.mean((preds["B5_hist_gbm"] - yh) ** 2)),
                             "auroc_ci": boot_auc(yh, preds["B5_hist_gbm"], gh, bs["draws"], bs["seed"])},
        "row_random": {"n_rows": int(y_row.size), "auroc": float(roc_auc_score(y_row, p_row)),
                       "brier": float(np.mean((p_row - y_row) ** 2)),
                       "auroc_ci": boot_auc(y_row, p_row, g_row, bs["draws"], bs["seed"]),
                       "share_test_patients_in_training": float(np.mean([p in train_row_patients for p in np.unique(g_row)]))},
    }
    pd_, rr = infl["patient_disjoint"], infl["row_random"]
    infl["auroc_gain_row_minus_patient"] = rr["auroc"] - pd_["auroc"]
    infl["brier_gain_patient_minus_row"] = pd_["brier"] - rr["brier"]
    infl["inflation_declared"] = bool(rr["auroc"] > pd_["auroc"] and rr["auroc_ci"][0] > pd_["auroc_ci"][1])
    out["overlap_inflation"] = infl
    per = {c: {"brier": float(np.mean((p - yh) ** 2)),
               "auroc": None if np.unique(p).size < 2 else float(roc_auc_score(yh, p))} for c, p in preds.items()}
    adm = list(design["candidates"])
    pairs = list(itertools.combinations(adm, 2))
    prow = []
    for a, b in pairs:
        d = (yh - preds[a]) ** 2 - (yh - preds[b]) ** 2
        pt, se, p1 = cr1(d, gh)
        _, _, pe = cr1(d, np.arange(d.size))
        prow.append({"a": a, "b": b, "mean_diff_a_minus_b": pt, "cr1_se": se, "cr1_p": p1, "row_level_p": pe})
    for key, name in (("cr1_p", "holm_cr1"), ("row_level_p", "holm_row_level")):
        for r, x in zip(prow, holm([r[key] for r in prow], design["family_alpha"])):
            r[name] = bool(x)
    look = {(r["a"], r["b"]): r for r in prow}
    hyp = {}
    for h, prs in design["hypotheses"].items():
        items = []
        for a, b in prs:
            r = look.get((a, b)) or look.get((b, a))
            diff = r["mean_diff_a_minus_b"] if (a, b) in look else -r["mean_diff_a_minus_b"]
            items.append({"better": a, "worse": b, "diff": diff, "holm_cr1": r["holm_cr1"], "cr1_p": r["cr1_p"]})
        hyp[h] = {"pairs": items, "supported": all(i["diff"] < 0 and i["holm_cr1"] for i in items)}
    role = {c: {"training_includes_holdout_patients": False, "training_rows_that_are_holdout_rows": 0} for c in adm}
    role["C_rowsplit"] = {"training_includes_holdout_patients": bool(np.any(hold & ~rowtest)),
                          "training_rows_that_are_holdout_rows": int(np.sum(hold & ~rowtest))}
    allc = adm + ["C_rowsplit"]
    contract_adm = [c for c in allc if not role[c]["training_includes_holdout_patients"]]
    best = lambda cs: min(cs, key=lambda c: per[c]["brier"])
    wf = {"W1_score_only": {"admitted": allc, "selected": best(allc)},
          "W5_contract": {"admitted": contract_adm, "selected": best(contract_adm),
                          "claimed_pairs": [f"{r['a']}-{r['b']}" for r in prow if r["holm_cr1"]]}}
    out.update({"status": "evaluated", "fits": fits, "per_candidate": per, "pairs": prow,
                "n_holm_rejections_cr1": sum(r["holm_cr1"] for r in prow),
                "n_holm_rejections_row_level": sum(r["holm_row_level"] for r in prow),
                "hypotheses": hyp, "role_audit": role, "workflows": wf,
                "expectations": {"E1_contract_refuses_C_rowsplit": "C_rowsplit" not in contract_adm,
                                 "E2_score_only_selects_C_rowsplit": wf["W1_score_only"]["selected"] == "C_rowsplit"},
                "holdout_predictions_digest": sha_bytes(json.dumps(
                    {k: [round(float(v), 10) for v in p] for k, p in preds.items()}, sort_keys=True).encode())})
    return out


def synthetic_zip(n_pat, design, seed=0):
    rng = np.random.default_rng(seed)
    head = design["allowlist"] + ["Lactate", "Unit1", design["endpoint"]]
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for k in range(n_pat):
            T = int(rng.integers(8, 60))
            sep = rng.random() < 0.08
            base = rng.normal(0, 1)
            rows = []
            for t in range(T):
                lab = int(sep and t > T - 10)
                vals = [90 + 10 * base + 15 * lab + rng.normal(0, 5), 97 + rng.normal(0, 1), 37 + 0.5 * lab + rng.normal(0, .3),
                        120 + rng.normal(0, 10), 80 + rng.normal(0, 8), 60 + rng.normal(0, 6), 18 + 4 * lab + rng.normal(0, 2),
                        60 + 10 * base, float(k % 2), -rng.random() * 10, t + 1]
                vals = [("NaN" if (i in (2,) and rng.random() < 0.6) else f"{v:.2f}") for i, v in enumerate(vals)]
                rows.append("|".join(vals + ["NaN", "1", str(lab)]))
            sub = "training_setA" if k % 2 else "training_setB"
            zf.writestr(f"{sub}/p{k:06d}.psv", "|".join(head) + "\n" + "\n".join(rows) + "\n")
    return buf.getvalue()


def main():
    design = json.load(open(os.path.join(PREREG, "frozen_design.json")))
    if len(sys.argv) == 3 and sys.argv[1] == "--synthetic-dry-run":
        z = synthetic_zip(6000, design)
        res = analyse(*parse(z, design), design, fast=True)
        print(json.dumps({k: res.get(k) for k in ("status", "cohort", "overlap_inflation", "expectations",
                                                    "n_holm_rejections_cr1", "hypotheses")}, indent=1, default=str)[:4000])
        return
    rec = json.load(open(os.path.join(PREREG, "prereg_hashes.json")))
    for k, rel in (("analysis_plan.md", "prereg/analysis_plan.md"), ("frozen_design.json", "prereg/frozen_design.json"),
                   ("run_sepsis.py", "code/run_sepsis.py")):
        if sha(os.path.join(ROOT, rel)) != rec[k]:
            raise SystemExit(f"prereg hash mismatch: {k}")
    res_dir = os.path.join(ROOT, "results")
    out_path = os.path.join(res_dir, "results.json")
    if os.path.exists(out_path):
        raise SystemExit("results exist; refusing to overwrite")
    os.makedirs(res_dir, exist_ok=True)
    t0 = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    z, names = retrieve(design)
    zpath = os.path.join(res_dir, "raw_data.zip")
    open(zpath, "wb").write(z)
    prov = {"access_start_utc": t0, "access_end_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "n_files": len(names), "raw_zip_sha256": sha_bytes(z), "listing_sha256": sha_bytes("\n".join(names).encode())}
    res = analyse(*parse(z, design), design)
    res.update({"study": design["study"], "prereg_hashes": rec, "provenance": prov,
                "environment": {"python": platform.python_version(), "numpy": np.__version__,
                                "scipy": scipy.__version__, "sklearn": sklearn.__version__,
                                "platform": platform.platform()}})
    json.dump(res, open(out_path, "w"), indent=2, default=str)
    json.dump({"results.json": sha(out_path), "raw_data.zip": prov["raw_zip_sha256"],
               "run_sepsis.py": sha(os.path.abspath(__file__))},
              open(os.path.join(res_dir, "hash_manifest.json"), "w"), indent=2)
    print(json.dumps({k: res.get(k) for k in ("status", "provenance", "cohort", "value_gate", "overlap_inflation",
                                                "expectations", "n_holm_rejections_cr1", "hypotheses", "per_candidate")},
                     indent=1, default=str))


if __name__ == "__main__":
    main()
