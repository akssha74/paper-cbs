# Magnitude-shift DYFI arm: M4.0–4.99, 2025-01-01 to 2026-09-01

Status: internally frozen plan; an RFC 3161 timestamp of `prereg_hashes.json`
(which binds this plan, `frozen_design.json`, and `code/run_prospective.py`) is
obtained before any outcome-bearing FDSN retrieval. Not an OSF/Zenodo
preregistration. DYFI labels for this envelope are public; the authors have not
retrieved them. Only an FDSN `/count` (2,018 features, no outcomes) was made.

## Why this arm

The previous timestamped window (2026-07-02 to 2026-09-01, M≥5) was predictably
too small (42 eligible). This envelope was never retrieved by the authors, is
disjoint in magnitude from all training and holdout rows (M≥5), and is forecast
to be evaluable.

## Evaluability forecast (frozen before retrieval)

About 750 eligible events (eligible fraction 353/959 in the 2025–26 M≥5 run) and
35–75 severe events (prevalence 0.143 at M5.0–5.2 in the frozen table,
extrapolated to 0.05–0.10). Floors unchanged: ≥100 events and ≥20 per class.

## Contract (unchanged, version 2)

Training: frozen 2015–2024 M≥5 table. Allowlist magnitude, depth; value gate;
100 km / 30 day joint declustering; straddler exclusion; B0–B2, B4, B5; seeded
C_F1, C_F2, C_F2_ren, C_year, C_geo; CR1 Holm over ten admissible pairs, α=0.05.
Count drift tolerance 25 features.

## Hypotheses

- H1: B1, B2, B4, B5 each beat B0 (Brier) and are Holm-rejected.
- H2: B2, B4, B5 each beat B1 and are Holm-rejected.

This is a covariate-shift transfer: models trained on M≥5 are scored on M4–5.
B0's training prevalence will not match, so H1 is expected to be easy; H2 is the
informative test. No result from this arm changes any earlier frozen verdict.
