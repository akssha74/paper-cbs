#!/usr/bin/env python3
"""Apply deterministic CBS review-layout wrappers to wide generated tables."""
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
TABLES = HERE / "tables"
WIDE = {
    "cohort_roles.tex",
    "baseline_performance.tex",
    "pairwise_matrix.tex",
    "endpoint_threshold_sensitivity.tex",
}
CAPTIONS = {
    "cohort_roles.tex": "Cohort accounting and outcome-independent role assignment",
    "endpoint_threshold_sensitivity.tex": "Relabeled threshold probe of the primary fitted model",
    "baseline_performance.tex": "Temporal-holdout performance of fixed baseline models",
    "leakage_gap.tex": "Split-assignment performance of the fixed diagnostic",
    "pairwise_matrix.tex": "Paired Brier-score comparisons among admissible baselines",
    "exclusions_deviations.tex": "Protocol exclusions, deviations, and interpretation boundaries",
    "slices.tex": "Temporal and geographic summaries within the temporal holdout",
}


def wrap(path: Path) -> None:
    text = path.read_text()
    caption = CAPTIONS.get(path.name)
    if caption:
        text = re.sub(
            r"\\caption\{.*?\}\s*\\label",
            rf"\\caption{{{caption}}}\n\\label",
            text,
            count=1,
            flags=re.S,
        )
    if path.name == "exclusions_deviations.tex":
        text = text.replace(
            "Includes event year, which reveals the temporal evaluation period.",
            "Origin year is available at prediction time but is outside the prespecified SOURCE\\_ONLY schema; no label-leakage claim is made.",
        )
    if path.name == "endpoint_threshold_sensitivity.tex":
        text = text.replace(
            r"Maximum CDI cutoff & Severe rate & Brier score & AUROC \\",
            r"Maximum CDI cutoff & Severe rate & Brier (6.0-fitted, relabeled) & AUROC (6.0-fitted, relabeled) \\",
        )
    if path.name == "leakage_gap.tex":
        text = text.replace("Event-grouped (control)", "Event-grouped (second allocation)")
        text = text.replace("Sequence-grouped (primary)", "Sequence-grouped")
        text = text.replace(
            "The frozen internal protocol required uncertainty but did not define the "
            "paired interval estimator; the executed report retained point estimates "
            "only. This deviation is disclosed, and no post-hoc interval or equivalence "
            "claim is added.",
            "The frozen internal protocol required uncertainty but the executed report "
            "retained no interval. Post-hoc paired sequence-cluster "
            "intervals were subsequently added (main text, Section 5.3); all include "
            "zero, and no equivalence claim is made.",
        )
    if path.name == "exclusions_deviations.tex":
        text = text.replace(
            r"Equivalence interpretation & Descriptive only & No numerical margin was specified; intervals are reported without equivalence labels. \\",
            r"Headline-result designation & Post-protocol disclosure & The frozen internal protocol named the split-assignment contrast the primary quantitative result. This manuscript reports it as a secondary diagnostic because the executed run retained no paired interval. B2 versus B0 is a post-hoc learned-versus-reference comparison and was not designated in that protocol. \\"
            "\n"
            r"Split-contrast intervals & Post-hoc addition & Paired sequence-cluster bootstrap over 1530 construction sequences after the nine frozen per-scheme scores were reproduced exactly; every Brier, AUROC, and log-loss interval includes zero. \\"
            "\n"
            r"Multiple-comparison inference & Post-hoc addition & Sequence-cluster-robust paired Brier-loss tests with Holm step-down over all ten pairs; large-$G$ $t$ approximation with 354 clusters, no refit. Seven pairs are rejected; B2--B4, B2--B5, and B4--B5 remain unresolved. \\"
            "\n"
            r"Decision sensitivity & Post-hoc addition & The seven-pair reference-only family, log-loss family, exploratory AUROC family, 50/100/200 km sequence windows, CR3 jackknife, wild-cluster bootstrap, event-level $t$, and 5/10 degree regional clusters produce the same seven decisions; with 10 degree cells the wild-cluster B1--B4 decision is borderline within Monte Carlo precision. B1--B4 becomes unresolved in the 15-pair seeded family (Supplementary Table~S6). \\"
            "\n"
            r"Seeded candidates & Post-hoc illustration & Five candidates (F1, F2, renamed F2, year, latitude/longitude) fit on construction rows with B2's frozen regularization after the admission audit; all five are rejected. Scores are shown only to expose what an ungated workflow would conclude. \\"
            "\n"
            r"Equivalence interpretation & Descriptive only & No numerical margin was specified; intervals are reported without equivalence labels. \\",
        )
        text = text.replace(
            "These decisions were recorded before, or disclosed with, the analysis. No result, subset, cutoff, or comparison was omitted because of its observed outcome.",
            "These decisions were recorded before, or disclosed with, the analysis, including the post-protocol reclassification of the split diagnostic. No result, subset, cutoff, or comparison was omitted because of its observed outcome.",
        )
    if path.name == "cohort_roles.tex":
        text = text.replace(
            "Thus the 2360 role-assigned events contain 702 severe events.",
            "Thus the 2360 role-assigned events contain 702 severe events. The straddle severe rate is omitted because $n=2$.",
        )
    if path.name == "pairwise_matrix.tex" and "Bonferroni" not in text:
        fw = json.loads((HERE / "frozen_inputs" / "family_wise_sensitivity.json").read_text())
        text = text.replace(r"\begin{tabular}{llccc l}", r"\begin{tabular}{llccc l c c}")
        text = text.replace(
            r"CI relation \\",
            r"CI relation & Bonferroni 99.5\% $t$ CI & Holm (cluster-robust $p$) \\",
        )
        text = text.replace(
            r"Model A & Model B & A $-$ B & 95\% CI & $P$(A better) & CI relation & Bonferroni 99.5\% $t$ CI & Holm (cluster-robust $p$) \\",
            r"A & B & A $-$ B & 95\% CI & \shortstack{$P$(A\\better)} & \shortstack{CI\\relation} & \shortstack{Bonferroni\\99.5\% $t$ CI} & \shortstack{Holm decision\\(cluster-robust $p$)} \\",
        )
        for pair in fw["pairs"]:
            a, b = pair["baseline_a"][:2], pair["baseline_b"][:2]
            lo, hi = pair["bonferroni_ci"]
            p = pair["cluster_robust_p_two_sided"]
            verdict = "reject" if pair["holm_rejects_zero"] else "unresolved"
            p_text = "$<0.0001$" if p < 0.0001 else f"{p:.4f}"
            holm = f"{verdict} ({p_text})"
            text = re.sub(
                rf"^({a} & {b} & .*?)( \\\\)$",
                lambda m, lo=lo, hi=hi, holm=holm: f"{m.group(1)} & [{lo:.4f}, {hi:.4f}] & {holm}{m.group(2)}",
                text,
                count=1,
                flags=re.M,
            )
        text = re.sub(
            r"^B[0-9].*\\\\$",
            lambda m: re.sub(r"(?<![A-Za-z])-(?=\d)", r"$-$", m.group(0)),
            text,
            flags=re.M,
        )
        text = text.replace(
            "B0 is the no-skill reference;",
            "$P$(A better) is the descriptive share of bootstrap replicates in which A has the lower Brier score; it is not a $p$-value. The last two columns use post-hoc paired Brier-loss tests with sequence-cluster-robust variance, a $t(G-1)$ reference with $G=354$, and Holm step-down over all ten pairs (family $\\alpha=0.05$). The 95\\% percentile intervals remain descriptive and were reproduced exactly before this analysis; no model was refit. Percentile intervals and cluster-robust tests are different procedures and can disagree near the boundary (B2--B4); only the tests decide, with direction taken from the sign of A $-$ B. B0 is the no-skill reference;",
        )
        text = text.replace(r"\begin{table*}[t]", r"\begin{table*}[!htbp]", 1)
        text = text.replace(r"\resizebox{\textwidth}{!}{%" + "\n", "")
        text = text.replace("\\end{tabular}\n}%\n", "\\end{tabular}\n")
        text = text.replace("\\centering\n\\small", "\\centering\n\\footnotesize\n\\setlength{\\tabcolsep}{3pt}", 1)
        text = text.replace(
            "\\par\\vspace{2pt}\\footnotesize\\emph{Note.}",
            "\\par\\vspace{2pt}\\begin{minipage}{\\textwidth}\\raggedright\\footnotesize\\emph{Note.}",
        )
        text = text.replace("\n\\end{table*}", "\n\\end{minipage}\n\\end{table*}")
    if path.name == "exclusions_deviations.tex":
        text = text.replace(
            "\\begin{table*}[t]\n\\centering\n\\small",
            "\\small",
        )
        text = re.sub(
            r"\\caption\{([^}]*)\}\s*\\label\{([^}]*)\}\s*"
            r"\\begin\{tabular\}\{([^\n]+)\}",
            lambda m: (
                f"\\begin{{longtable}}{{{m.group(3)}}}\n"
                f"\\caption{{{m.group(1)}}}\\label{{{m.group(2)}}}\\\\"
            ),
            text,
            count=1,
        )
        text = text.replace(r"\end{tabular}", r"\end{longtable}")
        text = text.replace(r"\end{table*}", "")
        header = "Decision & Treatment & Rationale \\\\\n\\midrule"
        text = text.replace(
            header,
            header
            + "\n\\endfirsthead\n\\toprule\n"
            + header
            + "\n\\endhead",
            1,
        )
        if "Italian CPTI15" not in text:
            text = text.replace(
                "\\bottomrule\n\\end{longtable}",
                "Italian CPTI15/DBMI15 transfer & Internally frozen; fail-closed & Local hash-bound plan. Unchanged field audit and declustering ran; candidate grids and Holm tests were not reached. Provenance filter and 100-event floor are plan additions, not version-1 contract fields. Hash manifest written after the non-evaluable return. Gate-skipped: S1 illustration, B2-versus-B2 control, threshold rescoring. \\\\\n\\bottomrule\n\\end{longtable}",
            )
        if "Prospective DYFI 2025" not in text:
            text = text.replace(
                "\\bottomrule\n\\end{longtable}",
                "Prospective DYFI 2025--2026 evaluation & Internally Git-frozen; evaluated once & Plan, hypotheses, value gate, and synthetic ablations committed locally before the recorded outcome-bearing retrieval; no external timestamp. Raw payload retained. H1 supported; H2 not supported. No amendment after retrieval. \\\\\n\\bottomrule\n\\end{longtable}",
            )
        if "ShakeMap MMI" not in text:
            text = text.replace(
                "\\bottomrule\n\\end{longtable}",
                "ShakeMap MMI transfer & Corrective; evaluable & ID-disjoint vs 2{,}362 DYFI events, which conditions on post-event participation. v1 admitted an entirely missing \\texttt{properties.depth}, scored the holdout, and returned Holm 0/10. The v2 binding amendment was frozen after v1 outcomes and before v2 scoring; geometry depth returned 6/10. A retrospective value gate rejects v1 and passes v2. A later retrieval plus 4{,}666 frozen rows reconstructs v2 (floating-point tolerance across environments; identical Holm decisions), but the original payload bytes were not retained. ShakeMap MMI is partly model-derived. \\\\\n\\bottomrule\n\\end{longtable}",
            )
    if path.name == "baseline_performance.tex":
        text = text.replace(
            r"Table~\ref{tab:exclusions}",
            r"Supplementary Table~S2",
        )
    if path.name == "cohort_roles.tex" and r"\begin{minipage}" not in text:
        text = text.replace(
            r"\par\vspace{2pt}\footnotesize\emph{Note.}",
            r"\par\vspace{2pt}\begin{minipage}{\textwidth}\raggedright\footnotesize\emph{Note.}",
        )
        text = text.replace("\n\\end{table*}", "\n\\end{minipage}\n\\end{table*}")
    if path.name not in WIDE or path.name == "pairwise_matrix.tex":
        path.write_text(text)
        return
    if r"\resizebox{\textwidth}{!}{%" in text:
        path.write_text(text)
        return
    start = text.index(r"\begin{tabular}")
    end_token = r"\end{tabular}"
    end = text.index(end_token, start) + len(end_token)
    text = (
        text[:start]
        + r"\resizebox{\textwidth}{!}{%"
        + "\n"
        + text[start:end]
        + "\n}%\n"
        + text[end:]
    )
    path.write_text(text)


def write_decision_sensitivity() -> None:
    fw = json.loads((HERE / "frozen_inputs" / "family_wise_sensitivity.json").read_text())
    rob = json.loads((HERE / "frozen_inputs" / "robustness_post_hoc.json").read_text())
    seeded = json.loads((HERE / "frozen_inputs" / "seeded_candidate_demo.json").read_text())
    short = lambda a, b: f"{a[:2]}-{b[:2]}"
    pairs = [short(p["baseline_a"], p["baseline_b"]) for p in fw["pairs"]]
    default = {short(p["baseline_a"], p["baseline_b"]) for p in fw["pairs"] if p["holm_rejects_zero"]}
    seq = rob["sequence_definition_sensitivity"]
    ve = rob["variance_estimator_sensitivity"]["holm_rejected_pairs"]
    cells = rob["region_block_sensitivity"]["cells"]
    ext = seeded["extended_holm_family"]["admissible_pair_decisions"]
    ext_set = {short(*k.split("_vs_")) for k, v in ext.items() if v}
    columns = [
        ("Default", default),
        ("\\shortstack{50\\\\km}", set(seq["50km_15d"]["holm_rejected_pairs"])),
        ("\\shortstack{200\\\\km}", set(seq["200km_60d"]["holm_rejected_pairs"])),
        ("CR3", set(ve["cr3_jackknife_p"])),
        ("Wild", set(ve["wild_cluster_rademacher_p"])),
        ("\\shortstack{Event\\\\$t$}", set(ve["event_level_iid_p"])),
        ("\\shortstack{5\\textdegree{}\\\\CR1}", set(cells["5deg_cells"]["holm_rejected_pairs"]["cr1_p"])),
        ("\\shortstack{5\\textdegree{}\\\\wild}", set(cells["5deg_cells"]["holm_rejected_pairs"]["wild_cluster_rademacher_p"])),
        ("\\shortstack{10\\textdegree{}\\\\CR1}", set(cells["10deg_cells"]["holm_rejected_pairs"]["cr1_p"])),
        ("\\shortstack{10\\textdegree{}\\\\wild}", set(cells["10deg_cells"]["holm_rejected_pairs"]["wild_cluster_rademacher_p"])),
        ("\\shortstack{Log-\\\\loss}", {short(r["a"], r["b"]) for r in rob["secondary_metric_holm"]["log_loss"] if r["holm_reject"]}),
        ("AUROC", {short(r["a"], r["b"]) for r in rob["secondary_metric_holm"]["auroc"] if r["holm_reject"]}),
        ("\\shortstack{15-\\\\pair}", ext_set),
    ]
    def borderline(rows):
        order = sorted(rows, key=lambda r: r["wild_cluster_rademacher_p"])
        flagged = set()
        for rank, r in enumerate(order):
            threshold = 0.05 / (len(order) - rank)
            if abs(r["wild_cluster_rademacher_p"] - threshold) < 2.0 * r["wild_cluster_mc_se"]:
                flagged.add(short(r["a"], r["b"]))
        return flagged
    wild_flags = {
        4: borderline(rob["variance_estimator_sensitivity"]["pairs"]),
        7: borderline(cells["5deg_cells"]["pairs"]),
        9: borderline(cells["10deg_cells"]["pairs"]),
    }
    header = "Pair & " + " & ".join(c[0] for c in columns) + r" \\"
    body = []
    for pair in pairs:
        marks = [("R$^{b}$" if pair in wild_flags.get(i, set()) else "R") if pair in s else "--"
                 for i, (_, s) in enumerate(columns)]
        body.append(pair.replace("-", "--") + " & " + " & ".join(marks) + r" \\")
    totals = "Rejected & " + " & ".join(str(len(s)) for _, s in columns) + r" \\"
    cs = rob["cluster_structure"]
    lines = [
        "% GENERATED by format_cbs_tables.py from frozen_inputs -- do not edit.",
        r"\begin{table*}[!htbp]",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{4pt}",
        r"\caption{Holm decisions across post-hoc sensitivity analyses}",
        r"\label{tab:decision-sensitivity}",
        r"\begin{tabular}{l" + "c" * len(columns) + "}",
        r"\toprule",
        header,
        r"\midrule",
        *body,
        r"\midrule",
        totals,
        r"\bottomrule",
        r"\end{tabular}",
        r"\par\vspace{2pt}\begin{minipage}{\textwidth}\footnotesize\emph{Note.} R, rejected under Holm "
        r"(family $\alpha=0.05$); R$^{b}$, rejected but within two Monte Carlo standard errors of its Holm threshold; --, unresolved. Default: Brier, cluster-robust (CR1) $t$ on the "
        f"{cs['n_clusters']} default 100 km/30 d sequences ({cs['n_singletons']} singletons, largest "
        f"{cs['largest_cluster_sizes'][0]} events). 50 km and 200 km: alternative sequence windows. CR3: "
        r"leave-one-cluster-out jackknife variance. Wild: null-imposed wild-cluster Rademacher bootstrap-$t$ "
        f"({rob['variance_estimator_sensitivity']['wild_draws']:,} draws). Event $t$: event-level paired $t$ ignoring clustering, for contrast. "
        f"5\\textdegree{{}} and 10\\textdegree{{}}: holdout re-clustered by latitude--longitude cell "
        f"({cells['5deg_cells']['cluster_structure']['n_clusters']} and "
        f"{cells['10deg_cells']['cluster_structure']['n_clusters']} clusters). Log-loss uses the "
        r"cluster-robust $t$; AUROC uses a null-centred paired cluster bootstrap and is exploratory. "
        r"15-pair: the admissible pairs within the family that adds the seeded candidate C\textsubscript{F2}. "
        r"A disclosed random partition of the same 430 losses into 86 clusters (mean size 5) yields six Holm "
        r"rejections (B1--B4 CR1 $p=0.0138$); 54- and 43-cluster partitions keep seven. "
        r"All analyses are post hoc, keep roles and fitted models fixed, and change no frozen number."
        r"\end{minipage}",
        r"\end{table*}",
        "",
    ]
    (TABLES / "decision_sensitivity.tex").write_text("\n".join(lines))


SHORT = {"B0_no_skill": "B0", "B1_magnitude_only_logit": "B1", "B2_source_only_logit": "B2",
         "B4_random_forest": "B4", "B5_xgboost": "B5", "C_F1": r"C\textsubscript{F1}",
         "C_F2": r"C\textsubscript{F2}", "C_F2_ren": r"C\textsubscript{F2}$'$",
         "C_year": r"C\textsubscript{year}", "C_geo": r"C\textsubscript{geo}"}
GENERATED = "% GENERATED by format_cbs_tables.py from frozen_inputs/{src}; do not edit.\n"


def fmt_p(p: float) -> str:
    return f"{p:.4f}" if p >= 0.001 else f"{p:.1e}".replace("e-0", "e-")


def write_shakemap_table() -> None:
    v1 = json.loads((HERE / "frozen_inputs" / "contract_transfer_shakemap_v1.json").read_text())
    v2 = json.loads((HERE / "frozen_inputs" / "contract_transfer_shakemap_v2.json").read_text())
    auc = lambda r: "--" if r["auroc"] is None else f"{r['auroc']:.3f}"
    lines = [GENERATED.format(src="contract_transfer_shakemap_v1.json and _v2.json").rstrip("\n"),
             r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{4pt}",
             r"\caption{ShakeMap corrective transfer: v1 and v2 outcomes}", r"\label{tab:shakemap-v1-v2}",
             r"\begin{tabular}{lrrrr}", r"\toprule",
             r"Candidate & v1 Brier & v1 AUROC & v2 Brier & v2 AUROC \\", r"\midrule"]
    for c in v2["per_candidate"]:
        a, b = v1["per_candidate"][c], v2["per_candidate"][c]
        lines.append(f"{SHORT[c]} & {a['brier']:.4f} & {auc(a)} & {b['brier']:.4f} & {auc(b)} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", "", r"\vspace{8pt}", r"\begin{tabular}{lrrrr}", r"\toprule",
              r"Pair & v1 CR1 $p$ & v1 Holm & v2 CR1 $p$ & v2 Holm \\", r"\midrule"]
    for a, b in zip(v1["pairs"], v2["pairs"]):
        if (a["a"], a["b"]) != (b["a"], b["b"]):
            raise SystemExit("ShakeMap v1/v2 pair order mismatch")
        lines.append(f"{SHORT[a['a']]}--{SHORT[a['b']]} & {fmt_p(a['cr1_p'])} & {'R' if a['holm_cr1'] else '--'}"
                     f" & {fmt_p(b['cr1_p'])} & {'R' if b['holm_cr1'] else '--'} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}",
              r"\par\vspace{2pt}\footnotesize\emph{Note.} R, rejected under the ten-pair Holm",
              r"family at $\alpha=0.05$; --, unresolved. V1 imputed an entirely missing",
              r"\texttt{properties.depth} field to a constant. The v2 binding amendment was",
              r"hashed after v1 outcomes were known and before v2 scoring; v2 is therefore a",
              r"corrective rerun rather than untouched prospective confirmation. V1 and v2 used",
              r"different retrievals (different whole-payload hashes) of the same envelope.",
              r"\end{table}", ""]
    (TABLES / "shakemap_v1_v2.tex").write_text("\n".join(lines))


def write_prospective_tables() -> None:
    r = json.loads((HERE / "frozen_inputs" / "prospective_dyfi_2025.json").read_text())
    per, wf = r["per_candidate"], r["workflows"]
    ph = json.loads((HERE / "frozen_inputs" / "prospective_dyfi_2025_post_hoc_winners.json").read_text())["rules"]
    exact_schema = list(r["fits"])
    win = lambda c: SHORT[c] if c else "none"  # noqa: E731
    po = lambda adm: ", ".join(SHORT[c] for c in adm if c in ("C_F1", "C_F2", "C_F2_ren")) or "none"  # noqa: E731
    rows = [
        ("A1 point-score only", wf["W1_score_only"], "--", "--", 10),
        ("A2 permissive field validation", wf["W2_schema_validation"], "--", "--", None),
        ("A2b exact schema$^\\dagger$", {"admitted": exact_schema, "selected":
                                          min(exact_schema, key=lambda c: per[c]["brier"])}, "--", "--", None),
        ("A3 unpaired intervals", wf["W3_unpaired_intervals"],
         str(len(ph["A3_unpaired_intervals"]["admissible_pair_labels"])), win(ph["A3_unpaired_intervals"]["winner"]), 36),
        ("A4 event-level Holm", wf["W4_event_paired_holm"],
         str(len(ph["A4_event_paired_holm"]["admissible_pair_labels"])), win(ph["A4_event_paired_holm"]["winner"]), 36),
        ("A2b + event-level Holm$^\\dagger$", {"admitted": exact_schema, "selected":
                                                min(exact_schema, key=lambda c: per[c]["brier"])},
         str(len(ph["A2b_exact_schema_event_holm"]["admissible_pair_labels"])),
         win(ph["A2b_exact_schema_event_holm"]["winner"]), 10),
        ("Contract (sequence Holm)", wf["W5_contract"],
         str(len(ph["Contract"]["admissible_pair_labels"])), win(ph["Contract"]["winner"]), 10),
    ]
    lines = [GENERATED.format(src="prospective_dyfi_2025.json and _post_hoc_winners.json").rstrip("\n"),
             r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{3pt}",
             r"\caption{Prospective 2025--2026 DYFI holdout: synthetic decision-rule ablations.}",
             r"\label{tab:prospective}",
             r"\begin{tabular}{>{\raggedright\arraybackslash}p{0.27\textwidth}r>{\raggedright\arraybackslash}p{0.19\textwidth}lrl}",
             r"\toprule",
             r"Rule & Admitted & Post-outcome admitted & Min.\ Brier & Pairs & Winner$^\dagger$ \\", r"\midrule"]
    for lab, w, labels, winner_cell, _ in rows:
        lines.append(f"{lab} & {len(w['admitted'])} & {po(w['admitted'])} & {SHORT[w['selected']]} & "
                     f"{labels} & {winner_cell} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}",
              r"\par\vspace{2pt}\begin{minipage}{\textwidth}\raggedright\footnotesize\emph{Note.} Ten candidates were submitted",
              r"(five admissible, five seeded). A1--A4 are synthetic ablations of isolated capabilities, not executions",
              r"or faithful system comparisons. The frozen plan defined each rule's output as the minimum-Brier admitted",
              r"candidate (Min.\ Brier); A1--A4 therefore select C\textsubscript{F1}, the outcome itself, and the contract's",
              r"recorded minimum is B5. Frozen plan labels: W1$=$A1, W2$=$A2 (called TFDV-style there),",
              r"W3$=$A3 (TFMA-style), W4$=$A4, W5$=$contract. $^\dagger$Post hoc: the A2b rows and the Winner column, defined as the unique admitted",
              r"candidate supported against every other admitted candidate by the rule's own test. Pairwise decisions are -- for A1/A2",
              r"(score-order only); A3 unpaired-interval labels; A4/contract Holm labels. A3 and A4 both evaluate nine admitted candidates; only A4 uses a",
              r"36-pair Holm family, while A3's three labels are disjoint unpaired intervals. Frozen W4 versus the contract",
              r"disagrees on one admissible pair (B1--B2).",
              f"Holdout: {r['cohort']['n_holdout']} events, {r['cohort']['n_sequences']} sequences, "
              f"{r['cohort']['positives']} severe. Brier: B5 {per['B5_xgboost']['brier']:.3f}, "
              f"B2 {per['B2_source_only_logit']['brier']:.3f}, B0 {per['B0_no_skill']['brier']:.3f}, "
              f"C\\textsubscript{{F1}} {per['C_F1']['brier']:.3f}, C\\textsubscript{{F2}} {per['C_F2']['brier']:.3f}.",
              r"\end{minipage}", r"\end{table}", ""]
    (TABLES / "prospective_decisions.tex").write_text("\n".join(lines))

    auc = lambda x: "--" if x["auroc"] is None else f"{x['auroc']:.3f}"
    s = [GENERATED.format(src="prospective_dyfi_2025.json").rstrip("\n"),
         r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{4pt}",
         r"\caption{Prospective 2025--2026 DYFI holdout: scores and the ten pre-declared pairs}",
         r"\label{tab:prospective-pairs}", r"\begin{tabular}{lrrrr}", r"\toprule",
         r"Candidate & Brier & Log-loss & AUROC & Brier (CDI$\geq$5.5 / 6.5) \\", r"\midrule"]
    for c, x in per.items():
        t = x["brier_by_threshold"]
        s.append(f"{SHORT[c]} & {x['brier']:.4f} & {x['log_loss']:.3f} & {auc(x)} & "
                 f"{t['5.5']:.3f} / {t['6.5']:.3f} \\\\")
    s += [r"\bottomrule", r"\end{tabular}", "", r"\vspace{8pt}", r"\begin{tabular}{lrrrrrr}", r"\toprule",
          r"Pair & $\Delta$Brier & CR1 $p$ & Holm & CR3 Holm & Event Holm & Hypothesis \\", r"\midrule"]
    hyp = {}
    for h, v in r["hypotheses"].items():
        for it in v["pairs"]:
            hyp[frozenset((it["better"], it["worse"]))] = h
    for p in r["pairs"]:
        yn = lambda b: "R" if b else "--"
        s.append(f"{SHORT[p['a']]}--{SHORT[p['b']]} & {p['mean_diff_a_minus_b']:.4f} & {fmt_p(p['cr1_p'])} & "
                 f"{yn(p['holm_cr1'])} & {yn(p['holm_cr3'])} & {yn(p['holm_event_level'])} & "
                 f"{hyp.get(frozenset((p['a'], p['b'])), 'descriptive')} \\\\")
    s += [r"\bottomrule", r"\end{tabular}",
          r"\par\vspace{2pt}\footnotesize\emph{Note.} $\Delta$Brier is first minus second candidate; R, rejected under",
          r"the ten-pair Holm family at $\alpha=0.05$; --, unresolved. H1 (primary) is "
          + ("supported" if r["hypotheses"]["H1"]["supported"] else "not supported")
          + "; H2 is " + ("supported" if r["hypotheses"]["H2"]["supported"] else "not supported")
          + ". The pre-specified family includes all ten pairs. Holm stops at descriptive B4--B5; "
          + "in a post-hoc seven-pair H1+H2-only family all seven directional pairs reject, and the "
          + "event-level sensitivity test also rejects all three H2 pairs, "
          + "but the pre-specified H2 verdict remains unchanged.",
          r"\end{table}", ""]
    (TABLES / "prospective_pairs.tex").write_text("\n".join(s))


DSHORT = {"B0_no_skill": "B0", "B1_inpatient_logit": "B1", "B2_core_logit": "B2", "B4_random_forest": "B4",
          "B5_hist_gbm": "B5", "C_label": r"C\textsubscript{label}", "C_id": r"C\textsubscript{id}",
          "C_weight": r"C\textsubscript{weight}", "C_overlap": r"C\textsubscript{overlap}"}


def write_diabetes_tables() -> None:
    base = HERE / "frozen_inputs" / "diabetes_transfer" / "results"
    r = json.loads((base / "results.json").read_text())
    ph = json.loads((base / "post_hoc_gate_ablations.json").read_text())["variants"]
    nc = json.loads((base / "post_hoc_null_calibration.json").read_text())["arms"]
    per, wf, co = r["per_candidate"], r["workflows"], r["cohort"]
    adm_pairs = {f"{p['a']}-{p['b']}" for p in r["pairs"]}
    seeded = lambda a: ", ".join(DSHORT[c] for c in a if c.startswith("C_")) or "none"  # noqa: E731
    win = lambda c: DSHORT[c] if c else "none"  # noqa: E731
    rows = [("A1 point-score only", wf["A1_point_score_only"], "--", "--"),
            ("A2 permissive field validation", wf["A2_permissive_validation"], "--", "--"),
            ("A2b exact schema (names)", wf["A2b_exact_schema"], "--", "--"),
            ("A3 unpaired intervals", wf["A3_unpaired_intervals"], None, None),
            ("A4 encounter-level Holm", wf["A4_encounter_paired_holm"], None, None),
            ("Contract (patient Holm)", wf["Contract"], None, None)]
    lines = [GENERATED.format(src="diabetes_transfer/results").rstrip("\n"),
             r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{3pt}",
             r"\caption{Non-seismic transfer (30-day readmission, patient-dependent encounters): gates and decision rules.}",
             r"\label{tab:diabetes}",
             r"\begin{tabular}{>{\raggedright\arraybackslash}p{0.30\textwidth}r>{\raggedright\arraybackslash}p{0.25\textwidth}lrl}",
             r"\toprule", r"Rule & Admitted & Seeded admitted & Min.\ Brier & Pairs & Winner \\", r"\midrule"]
    for lab, w, labels, winner_cell in rows:
        lines.append(f"{lab} & {len(w['admitted'])} & {seeded(w['seeded_admitted'])} & {DSHORT[w['lowest_point']]} & "
                     f"{labels if labels else len(w['pair_labels'])} & {winner_cell if winner_cell else win(w['winner'])} \\\\")
    lines.append(r"\midrule")
    for key, lab in (("without_name_gate", "Contract without name gate$^\\dagger$"),
                     ("without_value_gate", "Contract without value gate$^\\dagger$"),
                     ("without_role_audit", "Contract without role audit$^\\dagger$")):
        v = ph[key]
        n_lab = sum(1 for s in v["supported_pairs"] if s in adm_pairs)
        lines.append(f"{lab} & {len(v['admitted'])} & {seeded(v['seeded_admitted'])} & {DSHORT[v['lowest_point']]} & "
                     f"{n_lab} & {win(v['winner'])} \\\\")
    ri = json.loads((base / "post_hoc_row_identity_ablation.json").read_text())["variants"]
    for key, lab in (("exact_schema_plus_row_identity", "Names + row identity$^\\dagger$"),
                     ("name_value_plus_row_identity", "Names + values + row identity$^\\dagger$")):
        v = ri[key]
        n_lab = sum(1 for s in v["supported_pairs"] if s in adm_pairs)
        lines.append(f"{lab} & {len(v['admitted'])} & {seeded(v['seeded_admitted'])} & {DSHORT[v['lowest_point']]} & "
                     f"{n_lab} & {win(v['winner'])} \\\\")
    et = json.loads((HERE / "frozen_inputs" / "toolchain_comparison" / "evaltoolkit_comparison.json").read_text())
    lines.append(r"\midrule")
    for key, lab in (("T1_evaltoolkit", "eval-toolkit as shipped$^\\ddagger$"),
                     ("T2_evaltoolkit_plus_name_gate", "eval-toolkit + name gate$^\\ddagger$")):
        v = et["stacks"][key]
        n_lab = sum(1 for k, s in v["pairs"].items() if s["resolved"] and k in adm_pairs)
        lines.append(f"{lab} & {len(v['admitted'])} & {seeded(v['seeded_admitted'])} & {DSHORT[v['lowest_point']]} & "
                     f"{n_lab} & {win(v['named_winner'])} \\\\")
    g = r["gates"]
    wv = g["C_weight"]["value_detail"]["weight"]["missing_fraction"]
    ov = r["fits"]["C_overlap"]
    arm = {a["arm"]: a for a in nc}["diabetes_readmission"]
    lines += [r"\bottomrule", r"\end{tabular}",
              r"\par\vspace{2pt}\begin{minipage}{\textwidth}\raggedright\footnotesize\emph{Note.} Nine candidates (five admissible,",
              r"four seeded). The name gate rejects C\textsubscript{label} (post-outcome \texttt{readmitted}) and",
              r"C\textsubscript{id} (\texttt{patient\_nbr}); the value gate rejects C\textsubscript{weight}",
              f"(\\texttt{{weight}} {100 * wv:.1f}\\% missing, although allowlisted by name); the role audit rejects",
              f"C\\textsubscript{{overlap}} ({ov['n_train_holdout_patient_rows']:,} of its {ov['n_train']:,} training rows are scored holdout encounters,",
              r"75.0\% of the holdout; zero other encounters of those patients is definitional under the role rule).",
              r"Pairwise decisions are -- for A1/A2/A2b (score-order or names-only); A3 unpaired-interval labels; A4/contract Holm labels.",
              r"Winner is the unique admitted candidate",
              r"supported against every other admitted candidate by the rule's own test. $^\dagger$Post hoc gate removals",
              r"and substitutions; the row-identity check refuses a candidate whose training rows include a scored holdout",
              r"encounter. $^\ddagger$Post hoc executed comparison: eval-toolkit 1.12.0 group and exact cross-split",
              r"leakage checks, then its row-level paired bootstrap (95\% interval excludes zero; no multiplicity correction).",
              r"Pairs counts labelled pairs among the ten pre-declared admissible pairs.",
              f"Holdout: {co['n_holdout']:,} encounters, {co['n_holdout_patients']:,} patients, {co['positives']:,} readmitted within 30 days.",
              f"Brier: B5 {per['B5_hist_gbm']['brier']:.4f}, B0 {per['B0_no_skill']['brier']:.4f}, "
              f"C\\textsubscript{{overlap}} {per['C_overlap']['brier']:.4f}, C\\textsubscript{{label}} {per['C_label']['brier']:.4f}.",
              r"\end{minipage}", r"\end{table}", ""]
    (TABLES / "diabetes_decisions.tex").write_text("\n".join(lines))

    auc = lambda x: "--" if x["auroc"] is None else f"{x['auroc']:.3f}"  # noqa: E731
    s = [GENERATED.format(src="diabetes_transfer/results/results.json").rstrip("\n"),
         r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{4pt}",
         r"\caption{Non-seismic transfer: scores, gates, and the ten pre-declared pairs.}",
         r"\label{tab:diabetes-pairs}", r"\begin{tabular}{lrrrl}", r"\toprule",
         r"Candidate & Brier & Log-loss & AUROC & Gate outcome \\", r"\midrule"]
    for c, x in per.items():
        gg = g[c]
        out = "admitted" if gg["admitted"] else ("name" if not gg["name_passed"] else
                                                   "value" if not gg["value_passed"] else "role") + " rejected"
        s.append(f"{DSHORT[c]} & {x['brier']:.5f} & {x['log_loss']:.4f} & {auc(x)} & {out} \\\\")
    s += [r"\bottomrule", r"\end{tabular}", "", r"\vspace{8pt}", r"\begin{tabular}{lrrrrrr}", r"\toprule",
          r"Pair & $\Delta$Brier & Patient CR1 $p$ & Holm & Encounter $p$ & Holm & SE ratio \\", r"\midrule"]
    for p in r["pairs"]:
        yn = lambda b: "R" if b else "--"  # noqa: E731
        s.append(f"{DSHORT[p['a']]}--{DSHORT[p['b']]} & {p['mean_diff_a_minus_b']:.5f} & {fmt_p(p['cr1_p'])} & "
                 f"{yn(p['holm_cr1'])} & {fmt_p(p['event_level_p'])} & {yn(p['holm_event_level'])} & "
                 f"{p['cr1_se'] / p['event_level_se']:.2f} \\\\")
    s += [r"\bottomrule", r"\end{tabular}",
          r"\par\vspace{2pt}\footnotesize\emph{Note.} $\Delta$Brier is first minus second candidate; R, rejected under the",
          r"ten-pair Holm family at $\alpha=0.05$. SE ratio is patient-cluster over encounter-level standard error. H1 is "
          + ("supported" if r["hypotheses"]["H1"]["supported"] else "not supported") + " and H2 is "
          + ("supported" if r["hypotheses"]["H2"]["supported"] else "not supported") + ".",
          r"\end{table}", ""]
    (TABLES / "diabetes_pairs.tex").write_text("\n".join(s))

    names = {"dyfi_prospective_2025": "DYFI 2025--2026 (sequence)", "diabetes_readmission": "Readmission (patient)"}
    t = [GENERATED.format(src="diabetes_transfer/results/post_hoc_null_calibration.json").rstrip("\n"),
         r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{4pt}",
         r"\caption{Post hoc error-rate calibration under a cluster sign-flip null.}",
         r"\label{tab:null-calibration}", r"\begin{tabular}{lrrrrrr}", r"\toprule",
         r"Arm & Rows & Units & Multi-row & Largest & FWER event & FWER cluster \\", r"\midrule"]
    for a in nc:
        pe, pc = a["fwer_event_level_holm"], a["fwer_cluster_holm"]
        n = a["draws"]
        se_e = (pe * (1 - pe) / n) ** 0.5
        se_c = (pc * (1 - pc) / n) ** 0.5
        t.append(f"{names[a['arm']]} & {a['n']:,} & {a['units']:,} & {a['multi_member_units']:,} & {a['largest_unit']} & "
                 f"{pe:.3f} ({se_e:.3f}) & {pc:.3f} ({se_c:.3f}) \\\\")
    mu = json.loads((HERE / "frozen_inputs" / "misspecified_unit_null" / "misspecified_unit_null.json").read_text())
    fw, ms = mu["fwer_holm"], mu["monte_carlo_se"]
    t.append(r"\midrule")
    t.append(f"DYFI 2025--2026, regional null$^\\ddagger$ & {mu['n']:,} & {mu['regions']:,} & {mu['multi_member_regions']:,} & "
             f"{mu['largest_region']} & {fw['event_level']:.3f} ({ms['event_level']:.3f}) & "
             f"{fw['declared_sequence_cluster']:.3f} ({ms['declared_sequence_cluster']:.3f}) \\\\")
    t += [r"\bottomrule", r"\end{tabular}",
          r"\par\vspace{2pt}\footnotesize\emph{Note.} Each arm's ten admissible pairwise Brier loss differences were",
          r"centred and multiplied by one Rademacher sign per dependence unit, shared across pairs, so all ten nulls",
          f"are true and observed within-unit dependence is kept ({arm['draws']:,} draws, seed {arm['seed']}). Signs are",
          r"drawn at the declared unit, so the cluster test is expected to stay nearer the nominal rate. FWER is the",
          r"fraction of draws with any Holm rejection at $\alpha=0.05$; MC SE is the binomial Monte Carlo standard error.",
          r"Largest single-pair unadjusted rejection rate:",
          f"readmission {max(p['unadjusted_rate_event'] for p in arm['per_pair']):.3f} event-level versus "
          f"{max(p['unadjusted_rate_cluster'] for p in arm['per_pair']):.3f} cluster.",
          r"$^\ddagger$Misspecified-unit null: signs drawn per catalogue region, coarser than the declared",
          f"sequence ({mu['draws']:,} draws, seed {mu['seed']}); Units and Multi-row count regions, and FWER cluster is the",
          f"declared sequence-cluster test. Region-cluster Holm gave {fw['region_cluster']:.3f} ({ms['region_cluster']:.3f}).",
          r"Whether real DYFI loss differences depend at the regional level was not tested.",
          r"\end{table}", ""]
    (TABLES / "null_calibration.tex").write_text("\n".join(t))

    uo = json.loads((HERE / "frozen_inputs" / "unit_overlap_diabetes" / "results" / "results.json").read_text())
    sc, st, ck, pr = uo["scores_on_E_R"], uo["sets"], uo["checks"], uo["primary"]
    ushort = dict(DSHORT, C_unit=r"C\textsubscript{unit}")
    rv = uo["row_check_variant"]
    u = [GENERATED.format(src="unit_overlap_diabetes/results/results.json").rstrip("\n"),
         r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{4pt}",
         r"\caption{Post hoc unit-overlap seed (readmission): scores on the repeat patients' last encounters.}",
         r"\label{tab:unit-overlap}", r"\begin{tabular}{lrrrr}", r"\toprule",
         r"Candidate & Brier & Log-loss & AUROC & Point rank \\", r"\midrule"]
    for i, c in enumerate(uo["point_rank_on_E_R"], 1):
        x = sc[c]
        u.append(f"{ushort[c]} & {x['brier']:.5f} & {x['log_loss']:.4f} & {auc(x)} & {i} \\\\")
    u += [r"\bottomrule", r"\end{tabular}",
          r"\par\vspace{2pt}\begin{minipage}{0.9\textwidth}\raggedright\footnotesize\emph{Note.} Evaluation rows are the last",
          f"encounters of the {st['n_repeat_patients']:,} repeat holdout patients ({st['eval_positives']:,} readmitted);",
          f"C\\textsubscript{{unit}} adds their {st['n_donor_rows']:,} earlier encounters to a size-matched B4 training set",
          f"({ck['C_unit']['n_train']:,} rows), passes the row-identity check, and fails the patient-level role audit.",
          r"$\Delta=\mathrm{Brier}_{\mathrm{control}}-\mathrm{Brier}_{\mathrm{C_{unit}}}$"
          f"$={pr['delta_brier_ctrl_minus_unit']:.5f}$ (SE {pr['se']:.5f}); negative means C\\textsubscript{{unit}} is worse.",
          f"Row-check variant (patient-cluster Holm over all {len(rv['pairs'])} pairs): {rv['n_holm']} rejected, unique winner",
          f"{ushort[rv['winner']]}. No-skill ranks first because evaluation rows are less often positive than",
          r"construction rows (ordering confound), so this seed cannot isolate optimism from patient overlap.",
          r"\end{minipage}", r"\end{table}", ""]
    (TABLES / "unit_overlap.tex").write_text("\n".join(u))

    rh = json.loads((HERE / "frozen_inputs" / "misspecified_unit_null" / "prospective_region_holm.json").read_text())
    pshort = {"B0_no_skill": "B0", "B1_magnitude_only_logit": "B1", "B2_source_only_logit": "B2",
              "B4_random_forest": "B4", "B5_xgboost": "B5"}
    yn = lambda v: "Yes" if v else "No"  # noqa: E731
    g = [GENERATED.format(src="misspecified_unit_null/prospective_region_holm.json").rstrip("\n"),
         r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{5pt}",
         r"\caption{Post hoc prospective DYFI pair decisions under declared-sequence and region clustering.}",
         r"\label{tab:region-holm}", r"\begin{tabular}{lrrcrc}", r"\toprule",
         r"Pair & Mean A$-$B & $p$ (sequence) & Holm & $p$ (region) & Holm \\", r"\midrule"]
    for k, s in rh["pairs"]["sequence"].items():
        a, b = k.split("-")
        r_ = rh["pairs"]["region"][k]
        g.append(f"{pshort[a]}--{pshort[b]} & ${s['mean_diff']:+.4f}$ & {s['p']:.2g} & {yn(s['holm'])} "
                 f"& {r_['p']:.2g} & {yn(r_['holm'])} \\\\")
    g += [r"\bottomrule", r"\end{tabular}",
          r"\par\vspace{2pt}\begin{minipage}{0.9\textwidth}\raggedright\footnotesize\emph{Note.} Mean A$-$B is the",
          r"Brier-loss difference; positive values favour B. CR1 paired Brier",
          f"tests clustered by {rh['sequences']} declared sequences or {rh['regions']} catalogue regions over",
          f"{rh['n']} events, Holm over ten pairs ($\\alpha={rh['alpha']}$). Sequence decisions reproduce the frozen",
          f"labels ({rh['n_holm']['sequence']} rejected); region clustering rejects {rh['n_holm']['region']}.",
          f"H1 {'holds' if rh['hypotheses']['region']['H1'] else 'fails'} and H2",
          f"{'holds' if rh['hypotheses']['region']['H2'] else 'fails'} under both. Post hoc; the frozen verdicts are unchanged.",
          r"\end{minipage}", r"\end{table}", ""]
    (TABLES / "region_holm.tex").write_text("\n".join(g))

    tw = [GENERATED.format(src="prospective_dyfi_2026q3/, magshift_dyfi/").rstrip("\n"),
          r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{4pt}",
          r"\caption{RFC~3161-timestamped DYFI windows: timestamp, retrieval, and evaluability.}",
          r"\label{tab:timestamped}", r"\begin{tabular}{llllrrrl}", r"\toprule",
          r"Window & Envelope & Stamp & Retrieved & Feat. & Elig. & Severe & Status \\",
          r"\midrule"]
    for d, lab, env in (("prospective_dyfi_2026q3", "2026 Q3", r"$M\geq5$, 2026-07-02/09-01"),
                        ("magshift_dyfi", "Mag.\\ shift", r"$M$4.0--4.99, 2025-01/2026-08")):
        r = json.loads((HERE / "frozen_inputs" / d / "results.json").read_text())
        t = json.loads((HERE / "frozen_inputs" / d / "timestamp_record.json").read_text())
        c, p = r["cohort"], r["provenance"]
        tw.append(f"{lab} & {env} & {t['tst_time_gmt'][11:19]} & {p['access_utc'][11:19]} & "
                  f"{p['payload_features']:,} & {c['n_holdout']:,} & {c['positives']} & {r['status'].replace('_', '-')} \\\\")
    tw += [r"\bottomrule", r"\end{tabular}",
           r"\par\vspace{2pt}\begin{minipage}{0.95\textwidth}\raggedright\footnotesize\emph{Note.} Times are UTC on 2026-09-27;",
           r"FreeTSA tokens verified with OpenSSL. Floors: 100 eligible events and 20 per class. The magnitude-shift",
           r"plan froze a forecast of about 750 eligible and 35--75 severe events; it missed. No Holm labels were issued.",
           r"\end{minipage}", r"\end{table}", ""]
    (TABLES / "timestamped_windows.tex").write_text("\n".join(tw))

    sp_path = HERE / "frozen_inputs" / "sepsis_transfer" / "results.json"
    if sp_path.exists():
        sp = json.loads(sp_path.read_text())
        names = {"B0_no_skill": "B0 no-skill", "B1_vitals_logit": "B1 HR, Resp, Temp logit",
                 "B2_allowlist_logit": "B2 allowlist logit", "B4_random_forest": "B4 random forest",
                 "B5_hist_gbm": "B5 hist. gradient boosting", "C_rowsplit": r"C\textsubscript{rowsplit} (B5, row-random training)"}
        adm = sp["workflows"]["W5_contract"]["admitted"]
        s = [GENERATED.format(src="sepsis_transfer/results.json").rstrip("\n"),
             r"\begin{table}[!htbp]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{5pt}",
             r"\caption{Externally timestamped sepsis transfer: patient-disjoint holdout scores and contract admission.}",
             r"\label{tab:sepsis}", r"\begin{tabular}{lrrl}", r"\toprule",
             r"Candidate & Brier & AUROC & Contract \\", r"\midrule"]
        for c, v in sp["per_candidate"].items():
            au = "--" if v["auroc"] is None else f"{v['auroc']:.3f}"
            s.append(f"{names[c]} & {v['brier']:.5f} & {au} & {'admitted' if c in adm else 'refused (role)'} \\\\")
        oi = sp["overlap_inflation"]
        pd_, rr = oi["patient_disjoint"], oi["row_random"]
        s += [r"\bottomrule", r"\end{tabular}",
              r"\par\vspace{2pt}\begin{minipage}{0.92\textwidth}\raggedright\footnotesize\emph{Note.}",
              f"{sp['cohort']['n_holdout_rows']:,} holdout rows from {sp['cohort']['n_holdout_patients']:,} patients "
              f"({sp['cohort']['n_septic_holdout_patients']} septic). Patient-cluster Holm rejects "
              f"{sp['n_holm_rejections_cr1']}/10 admissible pairs. B5 scored on a row-random test split: AUROC "
              f"{rr['auroc']:.3f} [{rr['auroc_ci'][0]:.3f}, {rr['auroc_ci'][1]:.3f}] versus {pd_['auroc']:.3f} "
              f"[{pd_['auroc_ci'][0]:.3f}, {pd_['auroc_ci'][1]:.3f}] on the patient-disjoint holdout "
              f"(patient-cluster bootstrap, {sp.get('bootstrap_draws', 1000)} draws).",
              r"\end{minipage}", r"\end{table}", ""]
        (TABLES / "sepsis_transfer.tex").write_text("\n".join(s))


def main() -> None:
    for name in sorted(set(CAPTIONS) | WIDE):
        wrap(TABLES / name)
        print(f"formatted {name}")
    write_decision_sensitivity()
    print("wrote decision_sensitivity.tex")
    write_shakemap_table()
    write_prospective_tables()
    write_diabetes_tables()
    print("wrote shakemap_v1_v2.tex, prospective_decisions.tex, prospective_pairs.tex, diabetes_*.tex, null_calibration.tex")


if __name__ == "__main__":
    main()
