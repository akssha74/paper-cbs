#!/usr/bin/env python3
"""Post hoc (not in any frozen plan): Strack et al. 2014 published-spec candidate on the frozen holdout.

Trains a logistic regression on construction patients using the Strack 2014
covariate list that exists in the UCI table (race, gender, age, admission type,
discharge disposition, admission source, time in hospital, lab procedures,
procedures, medications, outpatient/emergency/inpatient visits, primary ICD
group, number of diagnoses, change, diabetesMed), after dropping expired and
hospice discharges as in that paper. Scores the frozen patient-hash holdout
without using any author-seeded leak field. Does not overwrite frozen results.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ARM = os.path.join(os.path.dirname(ROOT), "contract-transfer-diabetes")
sys.path.insert(0, os.path.join(ARM, "code"))
import contract_diabetes as cd  # noqa: E402

EXPIRED_HOSPICE = {"11", "13", "14", "19", "20", "21"}
STRACK_FIELDS = ["race", "gender", "age", "admission_type_id", "discharge_disposition_id",
                 "admission_source_id", "time_in_hospital", "num_lab_procedures", "num_procedures",
                 "num_medications", "number_outpatient", "number_emergency", "number_inpatient",
                 "diag_1", "number_diagnoses", "change", "diabetesMed"]


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def main():
    out = os.path.join(ROOT, "results", "strack2014_candidate.json")
    if os.path.exists(out):
        sys.exit("results exist; refusing to overwrite")
    design = json.load(open(os.path.join(ARM, "prereg", "frozen_design.json")))
    rec = json.load(open(os.path.join(ARM, "results", "results.json")))
    raw_path = os.path.join(ARM, "results", "raw_data.zip")
    man = json.load(open(os.path.join(ARM, "results", "hash_manifest.json")))
    assert sha(raw_path) == man["raw_data.zip"]
    rows, _ = cd.read_rows(open(raw_path, "rb").read(), design["data_member_suffix"])
    unit = design["unit"]
    keep = [r for r in rows if r.get("discharge_disposition_id", "") not in EXPIRED_HOSPICE]
    train = [r for r in keep if not cd.is_holdout_unit(r[unit], design)]
    hold = [r for r in keep if cd.is_holdout_unit(r[unit], design)]
    ytr = np.asarray([cd.label(r, design) for r in train], dtype=float)
    yh = np.asarray([cd.label(r, design) for r in hold], dtype=float)
    enc = cd.Encoder(STRACK_FIELDS, design).fit(train)
    xtr = enc.transform(train)
    xh = enc.transform(hold)
    m = LogisticRegression(C=1.0, max_iter=5000).fit(xtr, ytr)
    p = m.predict_proba(xh)[:, 1]
    brier = float(np.mean((p - yh) ** 2))
    name_ok = all(f in design["allowlist"] for f in STRACK_FIELDS)
    val_ok = all(cd.value_gate_field(train, f, design)["passed"] for f in STRACK_FIELDS)
    role_ok = not any(cd.is_holdout_unit(r[unit], design) for r in train)
    frozen_b5 = rec["per_candidate"]["B5_hist_gbm"]["brier"]
    out_d = {"status": "post_hoc", "design": __doc__.strip(), "citation": "strack2014impact",
             "n_train": len(train), "n_hold": len(hold), "dropped_expired_hospice": len(rows) - len(keep),
             "brier": brier, "auroc": float(roc_auc_score(yh, p)),
             "frozen_b5_brier_on_full_holdout": frozen_b5,
             "brier_minus_frozen_b5": brier - frozen_b5,
             "gates": {"name_passed": name_ok, "value_passed": val_ok, "role_passed": role_ok},
             "admitted_by_contract_v2": bool(name_ok and val_ok and role_ok),
             "sources": {"raw_data.zip": man["raw_data.zip"]}}
    os.makedirs(os.path.dirname(out), exist_ok=True)
    json.dump(out_d, open(out, "w"), indent=2)
    print(json.dumps({k: out_d[k] for k in ("n_train", "n_hold", "brier", "auroc", "brier_minus_frozen_b5",
                                            "admitted_by_contract_v2")}, indent=2))


if __name__ == "__main__":
    main()
