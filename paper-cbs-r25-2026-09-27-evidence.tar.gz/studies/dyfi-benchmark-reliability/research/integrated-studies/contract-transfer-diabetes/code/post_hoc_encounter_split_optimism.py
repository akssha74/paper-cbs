#!/usr/bin/env python3
"""Post hoc (not in any frozen plan): encounter-random vs patient-disjoint split on the frozen diabetes table.

Fits B5 (histogram gradient boosting, frozen grid) under two split rules of the
same table and seed: (i) the frozen patient-hash holdout, (ii) an encounter-hash
holdout at the same fraction. Reports Brier/AUROC and, on the encounter split,
the share of test patients who also appear in training, plus Brier among test
encounters whose patient is vs is not in the training set. Refits B5 only; does
not overwrite frozen transfer results.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys

import numpy as np
from sklearn.metrics import roc_auc_score

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ARM = os.path.join(os.path.dirname(ROOT), "contract-transfer-diabetes")
sys.path.insert(0, os.path.join(ARM, "code"))
import contract_diabetes as cd  # noqa: E402


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def encounter_holdout(enc_id, salt, frac):
    h = int(hashlib.sha256(f"{salt}:{enc_id}".encode()).hexdigest()[:8], 16)
    return h < frac * 2 ** 32


def main():
    out = os.path.join(ROOT, "results", "encounter_split_optimism.json")
    if os.path.exists(out):
        sys.exit("results exist; refusing to overwrite")
    design = json.load(open(os.path.join(ARM, "prereg", "frozen_design.json")))
    rec = json.load(open(os.path.join(ARM, "results", "results.json")))
    raw_path = os.path.join(ARM, "results", "raw_data.zip")
    man = json.load(open(os.path.join(ARM, "results", "hash_manifest.json")))
    assert sha(raw_path) == man["raw_data.zip"]
    rows, _ = cd.read_rows(open(raw_path, "rb").read(), design["data_member_suffix"])
    unit = design["unit"]
    frac = design["split"]["holdout_fraction"]
    cid = "B5_hist_gbm"

    def eval_split(hold, train, label):
        y = np.asarray([cd.label(r, design) for r in hold], dtype=float)
        fitted, meta = cd.tune_and_fit(cid, train, design)
        p = cd.predict(fitted, hold)
        hold_u = {r[unit] for r in hold}
        train_u = {r[unit] for r in train}
        overlap_u = hold_u & train_u
        y_ov = np.asarray([cd.label(r, design) for r in hold if r[unit] in overlap_u], dtype=float)
        p_ov = np.asarray([pi for r, pi in zip(hold, p) if r[unit] in overlap_u])
        y_dis = np.asarray([cd.label(r, design) for r in hold if r[unit] not in overlap_u], dtype=float)
        p_dis = np.asarray([pi for r, pi in zip(hold, p) if r[unit] not in overlap_u])
        def pack(yy, pp):
            if yy.size == 0:
                return None
            return {"n": int(yy.size), "brier": float(np.mean((pp - yy) ** 2)),
                    "auroc": None if np.unique(yy).size < 2 else float(roc_auc_score(yy, pp))}
        return {"label": label, "n_train": len(train), "n_hold": len(hold),
                "n_hold_patients": len(hold_u), "n_train_patients": len(train_u),
                "n_overlapping_patients": len(overlap_u),
                "frac_hold_patients_in_train": len(overlap_u) / len(hold_u),
                "overall": pack(y, p), "hold_encounters_patient_in_train": pack(y_ov, p_ov),
                "hold_encounters_patient_not_in_train": pack(y_dis, p_dis),
                "best_params": meta.get("best_params")}

    hold_p = [r for r in rows if cd.is_holdout_unit(r[unit], design)]
    train_p = [r for r in rows if not cd.is_holdout_unit(r[unit], design)]
    salt_e = design["split"]["salt"] + ":encounter"
    hold_e = [r for r in rows if encounter_holdout(r["encounter_id"], salt_e, frac)]
    train_e = [r for r in rows if not encounter_holdout(r["encounter_id"], salt_e, frac)]
    out_d = {"status": "post_hoc", "design": __doc__.strip(), "frozen_b5_brier": rec["per_candidate"][cid]["brier"],
             "sources": {"raw_data.zip": man["raw_data.zip"]},
             "patient_disjoint": eval_split(hold_p, train_p, "patient_hash"),
             "encounter_random": eval_split(hold_e, train_e, "encounter_hash")}
    os.makedirs(os.path.dirname(out), exist_ok=True)
    json.dump(out_d, open(out, "w"), indent=2)
    print(json.dumps({k: {kk: out_d[k][kk] for kk in ("n_hold", "n_overlapping_patients",
                                                      "frac_hold_patients_in_train", "overall") if kk in out_d[k]}
                      for k in ("patient_disjoint", "encounter_random")}, indent=2))


if __name__ == "__main__":
    main()
