#!/usr/bin/env python3
"""Post hoc (not in any frozen plan): residual dependence vs 100 km / 30 day sequences.

On the frozen prospective 2025-26 holdout, takes Brier-loss residuals of B5 vs
the event mean, and reports (i) intra-class correlation at sequence, region, and
event (ICC=1 by definition at event), (ii) mean product of residual pairs in
distance/time bins, (iii) ratio of within-sequence to between-sequence pair
products. Does not change frozen Holm verdicts.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os

import numpy as np
from scipy.stats import t as student_t

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PRO = os.path.join(os.path.dirname(ROOT), "prospective-dyfi-2025", "results")


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def hav_km(lat1, lon1, lat2, lon2):
    r = np.radians
    dlat, dlon = r(lat2 - lat1), r(lon2 - lon1)
    a = np.sin(dlat / 2) ** 2 + np.cos(r(lat1)) * np.cos(r(lat2)) * np.sin(dlon / 2) ** 2
    return 6371.0 * 2 * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def icc(resid, groups):
    g, inv = np.unique(groups, return_inverse=True)
    G = g.size
    n = resid.size
    means = np.bincount(inv, weights=resid, minlength=G) / np.bincount(inv, minlength=G)
    ssb = float(np.sum(np.bincount(inv, minlength=G) * (means - resid.mean()) ** 2))
    ssw = float(np.sum((resid - means[inv]) ** 2))
    msb = ssb / (G - 1) if G > 1 else 0.0
    msw = ssw / (n - G) if n > G else 0.0
    nbar = n / G
    den = msb + (nbar - 1) * msw
    return None if den == 0 else float((msb - msw) / den)


def main():
    outp = os.path.join(ROOT, "results", "sequence_residual_dependence.json")
    if os.path.exists(outp):
        raise SystemExit("results exist; refusing to overwrite")
    rec = json.load(open(os.path.join(PRO, "results.json")))
    rows = [json.loads(l) for l in gzip.open(os.path.join(PRO, "holdout_rows.jsonl.gz"))]
    y = np.asarray([r["severe_label"] for r in rows], dtype=float)
    p = np.asarray(rec["holdout_predictions"]["B5_xgboost"], dtype=float)
    resid = (y - p) ** 2 - ((y - p) ** 2).mean()
    seq = np.asarray([r["sequence_id"] for r in rows])
    reg = np.asarray([r.get("region_code") or r.get("place") or "NA" for r in rows])
    if "region_code" not in rows[0]:
        # prospective rows may store region elsewhere; fall back to 2-letter from place
        reg = np.asarray([(r.get("region_code") or str(r.get("place", "NA")).split(",")[-1].strip()) for r in rows])
    lat = np.asarray([float(r["latitude"]) for r in rows])
    lon = np.asarray([float(r["longitude"]) for r in rows])
    t = np.asarray([np.datetime64(r["origin_time"][:19]) for r in rows]).astype("datetime64[s]").astype(float)
    n = resid.size
    # pair subsample if large: n=342 is fine (~58k pairs)
    i, j = np.triu_indices(n, k=1)
    prod = resid[i] * resid[j]
    dkm = hav_km(lat[i], lon[i], lat[j], lon[j])
    dt_d = np.abs(t[i] - t[j]) / 86400.0
    same_seq = seq[i] == seq[j]
    within = float(prod[same_seq].mean()) if same_seq.any() else None
    between = float(prod[~same_seq].mean())
    bins = [(0, 100, 0, 30), (0, 100, 30, np.inf), (100, 500, 0, 30), (500, np.inf, 0, np.inf)]
    bin_stats = []
    for d0, d1, t0, t1 in bins:
        m = (dkm >= d0) & (dkm < d1) & (dt_d >= t0) & (dt_d < t1)
        bin_stats.append({"d_km": [d0, None if np.isinf(d1) else d1], "dt_days": [t0, None if np.isinf(t1) else t1],
                          "n_pairs": int(m.sum()), "mean_residual_product": None if not m.any() else float(prod[m].mean())})
    out = {"status": "post_hoc", "design": __doc__.strip(), "n": int(n),
           "icc": {"sequence": icc(resid, seq), "region": icc(resid, reg)},
           "n_sequences": int(np.unique(seq).size), "n_regions": int(np.unique(reg).size),
           "mean_pair_product_same_sequence": within, "mean_pair_product_different_sequence": between,
           "ratio_within_over_between": None if not between else (None if within is None else within / between),
           "distance_time_bins": bin_stats,
           "sources": {"results.json": sha(os.path.join(PRO, "results.json")),
                       "holdout_rows.jsonl.gz": sha(os.path.join(PRO, "holdout_rows.jsonl.gz"))}}
    os.makedirs(os.path.dirname(outp), exist_ok=True)
    json.dump(out, open(outp, "w"), indent=2)
    print(json.dumps({k: out[k] for k in ("n", "icc", "mean_pair_product_same_sequence",
                                          "mean_pair_product_different_sequence", "distance_time_bins")}, indent=2))


if __name__ == "__main__":
    main()
