#!/usr/bin/env python3
"""One-shot confirmatory DYFI window 2026-07-02 to 2026-09-01 (internally frozen; RFC 3161 timestamped before retrieval).

Refuses to run if the pre-registration hashes mismatch or results exist. The raw
FDSN bytes are written and hashed before any parsing.
"""
from __future__ import annotations

import csv
import datetime as dt
import gzip
import hashlib
import itertools
import json
import os
import platform
import sys
import time
import urllib.parse
import urllib.request

import numpy as np
import scipy
import sklearn
from scipy.stats import t as student_t
from sklearn.metrics import roc_auc_score

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RESEARCH = os.path.dirname(os.path.dirname(ROOT))
BENCH = os.path.join(RESEARCH, "benchmark-resource", "code")
sys.path.insert(0, BENCH)

import baselines  # noqa: E402
import common  # noqa: E402
import decluster  # noqa: E402
import ingest_eligibility  # noqa: E402
import leakage_audit  # noqa: E402

PREREG = os.path.join(ROOT, "prereg")
RESULTS = os.path.join(ROOT, "results")
FDSN = "https://earthquake.usgs.gov/fdsnws/event/1"


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha(path):
    return sha_bytes(open(path, "rb").read())


def check_prereg():
    rec = json.load(open(os.path.join(PREREG, "prereg_hashes.json")))
    for f in ("analysis_plan.md", "frozen_design.json"):
        if sha(os.path.join(PREREG, f)) != rec[f]:
            raise SystemExit(f"prereg hash mismatch: {f}")
    return rec


def cr1(d, groups):
    point = float(np.mean(d))
    g = np.asarray(groups, dtype=object)
    uniq = sorted(set(g.tolist()), key=str)
    infl = np.asarray([np.sum(d[g == u] - point) for u in uniq])
    G = len(uniq)
    se = float(np.sqrt(G / (G - 1.0) * np.sum(infl ** 2)) / d.size)
    if se == 0.0:
        return point, 0.0, 1.0, G - 1
    return point, se, float(2 * student_t.sf(abs(point / se), G - 1)), G - 1


def cr3(d, groups):
    g = np.asarray(groups, dtype=object)
    uniq = sorted(set(g.tolist()), key=str)
    G = len(uniq)
    loo = np.asarray([float(np.mean(d[g != u])) for u in uniq])
    se = float(np.sqrt((G - 1.0) / G * np.sum((loo - loo.mean()) ** 2)))
    point = float(np.mean(d))
    if se == 0.0:
        return 1.0
    return float(2 * student_t.sf(abs(point / se), G - 1))


def holm(pvals, alpha):
    order = sorted(range(len(pvals)), key=lambda i: pvals[i])
    rej = [False] * len(pvals)
    m = len(pvals)
    for k, i in enumerate(order):
        if pvals[i] <= alpha / (m - k):
            rej[i] = True
        else:
            break
    return rej


def logloss(y, p):
    p = np.clip(p, 1e-15, 1 - 1e-15)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def get(url):
    last = None
    for attempt in range(1, 6):
        try:
            return urllib.request.urlopen(url, timeout=300).read()
        except Exception as exc:  # noqa: BLE001
            last = exc
            time.sleep(min(60, 2 ** attempt))
    raise SystemExit(f"retrieval failed: {last}")


def load_training(design):
    path = os.path.join(RESEARCH, design["training_table"])
    rows = []
    for r in csv.DictReader(open(path)):
        if r["role"] in design["training_exclude_roles"]:
            continue
        rows.append({
            "event_id": r["event_id"], "origin_time": r["origin_time"],
            "origin_year": int(r["origin_year"]), "magnitude": float(r["magnitude"]),
            "depth_km": float(r["depth_km"]), "latitude": float(r["latitude"]),
            "longitude": float(r["longitude"]), "num_responses": int(r["num_responses"]),
            "max_cdi": float(r["max_cdi"]), "severe_label": int(r["severe_label"]),
            "sequence_id": r["sequence_id"],
        })
    return rows, sha(path)


def value_gate(payload, design):
    """Missingness and variance of each allowlisted field among CDI & felt>=10 features."""
    vals = {"magnitude": [], "depth_km": []}
    n = 0
    for feat in payload.get("features", []):
        p = feat.get("properties") or {}
        if p.get("cdi") is None or p.get("felt") is None or float(p["felt"]) < ingest_eligibility.MIN_RESPONSES:
            continue
        n += 1
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        vals["magnitude"].append(p.get("mag"))
        vals["depth_km"].append(coords[2] if len(coords) > 2 else None)
    out = {"n_features_with_cdi_and_felt10": n, "fields": {}}
    ok = n > 0
    for f, v in vals.items():
        present = [float(x) for x in v if x is not None]
        miss = 1.0 - len(present) / n if n else 1.0
        var = float(np.var(present)) if present else 0.0
        passed = miss <= design["value_gate"]["max_missing_fraction"] and var > 0.0
        out["fields"][f] = {"source": design["value_binding"][f], "missing_fraction": miss,
                            "variance": var, "passed": passed}
        ok = ok and passed
    out["passed"] = ok
    return out


def seeded_matrix(rows, cols):
    base = baselines.extract_features(rows, common.SOURCE_ONLY_SCHEMA)
    extra = []
    for field, tr in cols:
        v = np.asarray([float(r[field]) for r in rows], dtype=np.float64)
        extra.append(np.log1p(v) if tr == "log1p" else v)
    return np.column_stack([base] + extra)


def main():
    prereg = check_prereg()
    design = json.load(open(os.path.join(PREREG, "frozen_design.json")))
    os.makedirs(RESULTS, exist_ok=True)
    out_path = os.path.join(RESULTS, "results.json")
    raw_path = os.path.join(RESULTS, "raw_payload.geojson.gz")
    if os.path.exists(out_path) or os.path.exists(raw_path):
        raise SystemExit("results already exist; one-shot refuses to overwrite")

    q = design["fdsn_query"]
    count_params = {k: v for k, v in q.items() if k not in ("orderby", "limit")}
    count_url = f"{FDSN}/count?{urllib.parse.urlencode(count_params)}"
    query_url = f"{FDSN}/query?{urllib.parse.urlencode(q)}"
    pre_count = json.loads(get(count_url).decode("utf-8"))["count"]
    t_access = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    raw = get(query_url)
    payload_sha = sha_bytes(raw)
    with gzip.GzipFile(raw_path, "wb", mtime=0) as fh:
        fh.write(raw)
    payload = json.loads(raw.decode("utf-8"))
    n_feat = len(payload.get("features", []))
    provenance = {"access_utc": t_access, "query_url": query_url, "count_url": count_url,
                  "count_preflight_immediate": pre_count,
                  "count_preflight_before_freeze": design.get("count_preflight_before_freeze"),
                  "payload_features": n_feat, "payload_sha256": payload_sha,
                  "raw_payload_gz_sha256": sha(raw_path)}
    env = {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
           "sklearn": sklearn.__version__, "platform": platform.platform()}
    try:
        import xgboost
        env["xgboost"] = xgboost.__version__
    except Exception:  # noqa: BLE001
        env["xgboost"] = None
    result = {"study": design["study"], "prereg_hashes": prereg, "provenance": provenance,
              "environment": env}

    def finish(status):
        result["status"] = status
        json.dump(result, open(out_path, "w"), indent=2, default=str)
        man = {"results.json": sha(out_path), "raw_payload.geojson.gz": sha(raw_path),
               "run_prospective.py": sha(os.path.abspath(__file__)),
               "analysis_plan.md": prereg["analysis_plan.md"], "frozen_design.json": prereg["frozen_design.json"]}
        for f in ("baselines.py", "leakage_audit.py", "decluster.py", "ingest_eligibility.py", "common.py"):
            man[f] = sha(os.path.join(BENCH, f))
        hp = os.path.join(RESULTS, "holdout_rows.jsonl.gz")
        if os.path.exists(hp):
            man["holdout_rows.jsonl.gz"] = sha(hp)
        json.dump(man, open(os.path.join(RESULTS, "hash_manifest.json"), "w"), indent=2)
        print(json.dumps({k: result.get(k) for k in ("status", "provenance", "cohort", "n_holm_rejections_cr1",
                                                      "hypotheses", "workflows_summary")}, indent=2, default=str))

    if abs(n_feat - pre_count) > design["max_count_drift"]:
        return finish("refused_count_drift")

    gate = value_gate(payload, design)
    result["value_gate"] = gate
    names = {"admissible": leakage_audit.audit_feature_names(list(design["allowlist"]))}
    for cid, c in design["seeded"].items():
        declared = list(design["allowlist"]) + c["declared"]
        fa = leakage_audit.audit_feature_names(declared, common.SOURCE_ONLY_SCHEMA)
        aa = leakage_audit.audit_features_against_axis(declared, axis="temporal")
        names[cid] = {"passed": bool(fa["passed"]) and bool(aa.get("passed", True)),
                      "field_rejections": fa["rejected"], "axis_passed": bool(aa.get("passed", True))}
    result["name_role_gate"] = names
    if not gate["passed"]:
        return finish("refused_value_gate")

    parsed = ingest_eligibility.parse_geojson(payload)
    train, train_sha = load_training(design)
    train_ids = {r["event_id"] for r in train}
    pros = [dict(r) for r in parsed["rows"] if r["event_id"] not in train_ids]
    n_overlap = len(parsed["rows"]) - len(pros)
    for r in pros:
        r["severe_label"] = int(r["max_cdi"] >= design["severe_threshold"])
    joint = [{"event_id": r["event_id"], "origin_time": r["origin_time"], "latitude": r["latitude"],
              "longitude": r["longitude"], "_src": "train"} for r in train]
    joint += [{"event_id": r["event_id"], "origin_time": r["origin_time"], "latitude": r["latitude"],
               "longitude": r["longitude"], "_src": "pros"} for r in pros]
    joint = decluster.assign_sequences(joint, design["space_km"], design["time_days"])
    seq_src = {}
    for r in joint:
        seq_src.setdefault(r["sequence_id"], set()).add(r["_src"])
    seq_of = {r["event_id"]: r["sequence_id"] for r in joint if r["_src"] == "pros"}
    hold, straddle = [], []
    for r in pros:
        r["sequence_id"] = seq_of[r["event_id"]]
        (straddle if "train" in seq_src[r["sequence_id"]] else hold).append(r)
    y = np.asarray([r["severe_label"] for r in hold], dtype=float)
    seqs = {}
    for r in hold:
        seqs[r["sequence_id"]] = seqs.get(r["sequence_id"], 0) + 1
    cohort = {"eligibility": parsed["stats"], "n_overlap_with_training_ids": n_overlap,
              "n_training_events": len(train), "training_table_sha256": train_sha,
              "n_straddle_excluded": len(straddle), "n_holdout": len(hold),
              "n_sequences": len(seqs), "n_multi_event_sequences": sum(1 for v in seqs.values() if v > 1),
              "largest_sequence": max(seqs.values()) if seqs else 0,
              "positives": int(y.sum()), "negatives": int(len(y) - y.sum()),
              "prevalence": float(y.mean()) if len(y) else None,
              "first_origin": hold[0]["origin_time"] if hold else None,
              "last_origin": hold[-1]["origin_time"] if hold else None}
    with gzip.GzipFile(os.path.join(RESULTS, "holdout_rows.jsonl.gz"), "wb", mtime=0) as fh:
        for r in hold:
            fh.write((json.dumps(r, sort_keys=True) + "\n").encode("utf-8"))
    result["cohort"] = cohort
    ev = design["evaluability"]
    if len(hold) < ev["min_holdout_events"] or min(cohort["positives"], cohort["negatives"]) < ev["min_per_class"]:
        return finish("non_evaluable")

    specs = {s.id: s for s in baselines.registry()}
    ledger = baselines.FitLedger()
    groups_c = [r["sequence_id"] for r in train]
    preds, fits = {}, {}
    for cid in design["candidates"]:
        fitted = baselines.tune_and_fit(specs[cid], train, groups_c, ledger, axis="temporal")
        preds[cid] = baselines.predict_proba(fitted, hold)
        fits[cid] = {"best_params": fitted["best_params"], "cv_scores": fitted["cv_scores"]}
    y_c = baselines.extract_labels(train)
    b2 = specs["B2_source_only_logit"]
    b2_params = dict(fits["B2_source_only_logit"]["best_params"])
    for cid, c in design["seeded"].items():
        m = b2.build(dict(b2_params))
        m.fit(seeded_matrix(train, c["cols"]), y_c)
        preds[cid] = np.asarray(m.predict_proba(seeded_matrix(hold, c["cols"]))[:, 1], dtype=np.float64)

    per = {}
    for cid, p in preds.items():
        per[cid] = {"brier": float(np.mean((p - y) ** 2)), "log_loss": logloss(y, p),
                    "auroc": float(roc_auc_score(y, p)) if np.unique(p).size > 1 else None,
                    "brier_by_threshold": {str(t): float(np.mean((p - np.asarray(
                        [float(r["max_cdi"] >= t) for r in hold])) ** 2)) for t in design["threshold_sensitivity"]}}
    g_h = [r["sequence_id"] for r in hold]
    e_h = [r["event_id"] for r in hold]
    adm = list(design["candidates"])
    pairs = list(itertools.combinations(adm, 2))
    prow = []
    for a, b in pairs:
        d = (y - preds[a]) ** 2 - (y - preds[b]) ** 2
        pt, se, p1, df = cr1(d, g_h)
        _, _, pe, _ = cr1(d, e_h)
        prow.append({"a": a, "b": b, "mean_diff_a_minus_b": pt, "cr1_se": se, "cr1_p": p1, "df": df,
                     "event_level_p": pe, "cr3_p": cr3(d, g_h)})
    for key, name in (("cr1_p", "holm_cr1"), ("event_level_p", "holm_event_level"), ("cr3_p", "holm_cr3")):
        for r, x in zip(prow, holm([r[key] for r in prow], design["family_alpha"])):
            r[name] = bool(x)
    lookup = {(r["a"], r["b"]): r for r in prow}

    def pair_rec(a, b):
        r = lookup.get((a, b)) or lookup.get((b, a))
        diff = r["mean_diff_a_minus_b"] if (a, b) in lookup else -r["mean_diff_a_minus_b"]
        return r, diff

    hyp = {}
    for h, spec in design["hypotheses"].items():
        items = []
        for a, b in spec["pairs"]:
            r, diff = pair_rec(a, b)
            items.append({"better": a, "worse": b, "brier_diff_better_minus_worse": diff,
                          "direction_ok": diff < 0, "holm_cr1": r["holm_cr1"], "cr1_p": r["cr1_p"]})
        hyp[h] = {"pairs": items, "supported": all(i["direction_ok"] and i["holm_cr1"] for i in items)}

    # Comparator workflows.
    all_c = adm + list(design["seeded"])
    declared = {c: list(design["allowlist"]) for c in adm}
    for cid, c in design["seeded"].items():
        declared[cid] = list(design["allowlist"]) + c["declared"]
    row_keys = set(hold[0].keys())

    def schema_ok(c):
        for f in declared[c]:
            if f not in row_keys:
                return False
            v = [r.get(f) for r in hold]
            present = [float(x) for x in v if x is not None]
            if 1.0 - len(present) / len(v) > design["value_gate"]["max_missing_fraction"] or np.var(present) <= 0:
                return False
        return True

    post_outcome = {"C_F1", "C_F2", "C_F2_ren"}
    adm_pairs = set(pairs)

    def best(cands):
        return min(cands, key=lambda c: per[c]["brier"])

    wf = {}
    wf["W1_score_only"] = {"admitted": all_c, "selected": best(all_c),
                           "claims_admissible_pairs": sum(1 for a, b in pairs if per[a]["brier"] != per[b]["brier"])}
    w2_adm = [c for c in all_c if schema_ok(c)]
    wf["W2_schema_validation"] = {"admitted": w2_adm, "selected": best(w2_adm),
                                  "claims_admissible_pairs": sum(1 for a, b in pairs
                                                                 if a in w2_adm and b in w2_adm and per[a]["brier"] != per[b]["brier"])}
    bs = design["w3_bootstrap"]
    rng = np.random.default_rng(bs["seed"])
    idx = rng.integers(0, len(y), size=(bs["draws"], len(y)))
    ci = {}
    for c in w2_adm:
        sq = (preds[c] - y) ** 2
        draws = sq[idx].mean(axis=1)
        ci[c] = [float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))]
    w3_claims = [(a, b) for a, b in pairs if a in ci and b in ci and (ci[a][1] < ci[b][0] or ci[b][1] < ci[a][0])]
    wf["W3_unpaired_intervals"] = {"admitted": w2_adm, "selected": best(w2_adm), "intervals": ci,
                                   "claims_admissible_pairs": len(w3_claims),
                                   "claimed_pairs": [f"{a}-{b}" for a, b in w3_claims]}
    w4_pairs = list(itertools.combinations(w2_adm, 2))
    w4_p = []
    for a, b in w4_pairs:
        d = (y - preds[a]) ** 2 - (y - preds[b]) ** 2
        w4_p.append(cr1(d, e_h)[2])
    w4_rej = holm(w4_p, design["family_alpha"])
    w4_dec = {(a, b): r for (a, b), r in zip(w4_pairs, w4_rej)}
    w4_claims = [(a, b) for (a, b) in pairs if w4_dec.get((a, b), False)]
    wf["W4_event_paired_holm"] = {"admitted": w2_adm, "selected": best(w2_adm), "family_size": len(w4_pairs),
                                  "claims_admissible_pairs": len(w4_claims),
                                  "claimed_pairs": [f"{a}-{b}" for a, b in w4_claims]}
    w5_adm = [c for c in all_c if c in adm or names[c]["passed"]]
    w5_claims = [(r["a"], r["b"]) for r in prow if r["holm_cr1"]]
    wf["W5_contract"] = {"admitted": w5_adm, "selected": best(w5_adm), "family_size": len(pairs),
                         "claims_admissible_pairs": len(w5_claims),
                         "claimed_pairs": [f"{a}-{b}" for a, b in w5_claims]}
    for k, w in wf.items():
        w["post_outcome_admitted"] = sorted(set(w["admitted"]) & post_outcome)
        w["post_outcome_selected"] = w["selected"] in post_outcome
    wf["W4_vs_W5_admissible_pair_disagreements"] = sorted(
        f"{a}-{b}" for (a, b) in adm_pairs if bool(w4_dec.get((a, b), False)) != bool(lookup[(a, b)]["holm_cr1"]))
    expect = {
        "W1_W4_admit_all_seeded": all(set(design["seeded"]) <= set(wf[k]["admitted"])
                                      for k in ("W1_score_only", "W2_schema_validation", "W3_unpaired_intervals", "W4_event_paired_holm")),
        "W1_W4_select_C_F1": all(wf[k]["selected"] == "C_F1"
                                 for k in ("W1_score_only", "W2_schema_validation", "W3_unpaired_intervals", "W4_event_paired_holm")),
        "W5_rejects_all_seeded": not (set(design["seeded"]) & set(w5_adm)),
        "W5_selects_no_post_outcome": not wf["W5_contract"]["post_outcome_selected"],
    }
    d0 = np.zeros(len(y))
    result.update({
        "fit_count": ledger.count, "fits": fits, "per_candidate": per, "pairs": prow,
        "n_holm_rejections_cr1": sum(r["holm_cr1"] for r in prow),
        "n_holm_rejections_event_level": sum(r["holm_event_level"] for r in prow),
        "n_holm_rejections_cr3": sum(r["holm_cr3"] for r in prow),
        "hypotheses": hyp, "workflows": wf, "expectations": expect,
        "workflows_summary": {k: {"selected": v["selected"], "n_admitted": len(v["admitted"]),
                                  "post_outcome_admitted": v["post_outcome_admitted"],
                                  "claims": v["claims_admissible_pairs"]}
                              for k, v in wf.items() if isinstance(v, dict)},
        "negative_control_B2_vs_B2_p": cr1(d0, g_h)[2],
        "holdout_predictions_digest": sha_bytes(json.dumps(
            {k: [round(float(x), 12) for x in v] for k, v in preds.items()}, sort_keys=True).encode()),
        "holdout_predictions": {k: [float(x) for x in v] for k, v in preds.items()},
    })
    finish("evaluated")


if __name__ == "__main__":
    main()
