# Confirmatory DYFI window 2026-07-02 to 2026-09-01

Status: internally frozen plan. An RFC 3161 timestamp of this plan, `frozen_design.json`,
and `code/run_prospective.py` will be obtained **before** any outcome-bearing FDSN
retrieval. This is not an OSF/Zenodo preregistration.

## Window (calendar-declared, no outcome peek)

- Envelope: USGS ComCat DYFI, `M≥5`, `eventtype=earthquake`, `producttype=dyfi`.
- `starttime=2026-07-02` (day after the previous prospective `endtime=2026-07-01`).
- `endtime=2026-09-01` (calendar cut; retrieval is planned ≥3 weeks later so late
  reports can accumulate; shorter buffer than the 12-week gap used in 2025–26).
- No pre-freeze count is recorded. Immediate FDSN `/count` and `/query` occur only
  after the timestamp token is stored.

## Contract (same as prospective 2025–26 / contract version 2)

Allowlist magnitude and depth; value gate (missingness ≤20%, nonzero variance);
100 km / 30 day sequences; joint declustering with the frozen 2015–2024 training
table; exclude sequence straddlers; B0–B2, B4, B5; seeded C_F1, C_F2, C_F2_ren,
C_year, C_geo; CR1 Holm over the ten admissible pairs (α=0.05).

## Hypotheses (same directional claims)

- H1: each of B1, B2, B4, B5 has lower Brier than B0 and the pair is Holm-rejected.
- H2: each of B2, B4, B5 has lower Brier than B1 and the pair is Holm-rejected.

## Evaluability floors

At least 100 holdout events and 20 per class after eligibility and straddle
exclusion. If unmet, the run stops as `non_evaluable` and issues no Holm labels.

## One-shot

`code/run_prospective.py` refuses to overwrite results. Training uses the frozen
2015–2024 role-assigned table; candidates are retuned with the existing grids.
