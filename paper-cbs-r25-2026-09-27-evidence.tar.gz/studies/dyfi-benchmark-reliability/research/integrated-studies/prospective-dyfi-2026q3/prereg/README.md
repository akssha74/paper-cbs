This directory holds an internal freeze plus an RFC 3161 timestamp obtained
before retrieval. It is not an OSF, ClinicalTrials, or journal preregistration.
