#!/usr/bin/env python3
"""Deterministically emit the manuscript claim / artifact / build ledgers.

All three ledgers are derived only from IMMUTABLE inputs already validated
elsewhere (manuscript/derived/asset_inputs.json, manuscript/asset_manifest.json)
and from byte hashes of the paper sources. No model is refit and nothing is
fetched. Re-running reproduces byte-identical ledgers (sorted keys, fixed text).

  * claim_ledger.jsonl   -- every load-bearing number in the paper mapped to its
                            source pointer inside asset_inputs.json plus where it
                            surfaces (abstract / prose / table / figure).
  * artifact_ledger.jsonl-- every file the build consumes or emits with its sha256
                            and provenance (canonical asset vs generated copy).
  * build_ledger.json    -- toolchain, ordered build steps, and output digests.
"""
from __future__ import annotations
import hashlib
import json
import os
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
MAN = HERE.parent
DERIVED = pathlib.Path(os.environ.get(
    "DYFI_ASSET_INPUTS",
    str(MAN / "derived" / "asset_inputs.json")
))
if not DERIVED.exists():
    DERIVED = HERE / "frozen_inputs" / "asset_inputs.json"
MANIFEST = MAN / "asset_manifest.json"


def sha256(p: pathlib.Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def r3(x: float) -> str:
    return f"{x:.3f}"


def build_claim_ledger(ai: dict) -> list[dict]:
    rows: list[dict] = []

    def add(cid, text, value, pointer, appears):
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": cid,
            "claim": text,
            "value": value,
            "source_artifact": "manuscript/derived/asset_inputs.json",
            "json_pointer": pointer,
            "appears_in": appears,
        })

    cf = ai["cohort_flow"]
    roles = cf["roles"]
    add("C0", "frozen USGS DYFI source-record count",
        cf["fdsn_features_pinned_snapshot"],
        "/cohort_flow/fdsn_features_pinned_snapshot",
        ["abstract", "prose", "tab:cohort", "fig:flow"])
    add("C1", "eligible one-row-per-event corpus size", cf["n_eligible_events"],
        "/cohort_flow/n_eligible_events", ["abstract", "prose", "tab:cohort", "fig:flow"])
    add("C1b", "severe events among all eligible (= 449 train + 102 dev + 151 holdout + 1 straddle)",
        cf["n_eligible_severe"], "/cohort_flow/n_eligible_severe", ["prose", "tab:cohort"])
    add("C1c", "eligible severe prevalence (703/2362)", r3(cf["eligible_prevalence"]),
        "/cohort_flow/eligible_prevalence", ["prose", "tab:cohort"])
    add("C1d", "severe events among the 2360 analysis-role-assigned events (excludes 1 severe straddle)",
        cf["n_role_assigned_severe"], "/cohort_flow/n_role_assigned_severe", ["prose", "tab:cohort"])
    add("C2", "training role event count", roles["train"]["n"],
        "/cohort_flow/roles/train/n", ["prose", "tab:cohort", "fig:flow"])
    add("C3", "development role event count", roles["development"]["n"],
        "/cohort_flow/roles/development/n", ["prose", "tab:cohort", "fig:flow"])
    add("C4", "external temporal holdout event count", roles["external_temporal_holdout"]["n"],
        "/cohort_flow/roles/external_temporal_holdout/n",
        ["abstract", "prose", "tab:cohort", "fig:flow"])
    add("C5", "events excluded because their sequence straddles the temporal cutoff",
        cf["temporal_straddle_excluded"],
        "/cohort_flow/temporal_straddle_excluded", ["prose", "tab:cohort", "fig:flow"])
    add("C5b", "severe events among temporal-straddle exclusions",
        cf["temporal_straddle"]["positive"],
        "/cohort_flow/temporal_straddle/positive", ["prose", "tab:cohort"])
    add("C6", "construction pool (train+development) size", cf["construction_total"]["n"],
        "/cohort_flow/construction_total/n", ["prose", "tab:cohort", "fig:flow"])
    add("C6b", "construction severe-event count", cf["construction_total"]["positive"],
        "/cohort_flow/construction_total/positive", ["tab:cohort"])
    add("C6c", "construction severe-event rate", r3(cf["construction_total"]["prevalence"]),
        "/cohort_flow/construction_total/prevalence", ["prose", "tab:cohort"])
    add("C7", "holdout positive count (severe events)",
        roles["external_temporal_holdout"]["positive"],
        "/cohort_flow/roles/external_temporal_holdout/positive", ["prose", "tab:cohort"])
    add("C8", "holdout severe prevalence (151/430)",
        r3(roles["external_temporal_holdout"]["prevalence"]),
        "/cohort_flow/roles/external_temporal_holdout/prevalence",
        ["prose", "tab:cohort", "supp:tab:threshold", "fig:flow"])
    add("C9", "eligible seismic-sequence count", cf["sequences"]["all_eligible"],
        "/cohort_flow/sequences/all_eligible", ["prose", "tab:cohort", "fig:flow"])
    add("C10", "construction seismic-sequence count", cf["sequences"]["construction"],
        "/cohort_flow/sequences/construction", ["prose", "tab:cohort", "fig:flow"])
    add("C11", "temporal-holdout seismic-sequence count", cf["sequences"]["holdout"],
        "/cohort_flow/sequences/holdout", ["prose", "tab:cohort", "fig:flow"])
    add("C12", "temporal-straddle seismic-sequence count", cf["sequences"]["straddle"],
        "/cohort_flow/sequences/straddle", ["tab:cohort"])
    for role_key, label in (("train", "training"), ("development", "development")):
        role = roles[role_key]
        add(f"C_{role_key}_positive", f"{label} severe-event count", role["positive"],
            f"/cohort_flow/roles/{role_key}/positive", ["tab:cohort"])
        add(f"C_{role_key}_prevalence", f"{label} severe-event rate",
            r3(role["prevalence"]), f"/cohort_flow/roles/{role_key}/prevalence",
            ["tab:cohort", "fig:flow"])

    ep = ai["endpoint"]
    for thr in ("5.5", "6.0", "6.5"):
        ts = ep["threshold_sensitivity"][thr]
        for field in ("prevalence", "brier", "auroc"):
            add(f"E_{thr}_{field}", f"threshold {thr} {field} (source-only probe)",
                r3(ts[field]), f"/endpoint/threshold_sensitivity/{thr}/{field}",
                ["prose", "supp:tab:threshold", "supp:fig:threshold"])
    add("E_near_threshold", "construction events within 0.5 CDI units of cutoff",
        r3(ep["near_threshold_fraction_construction"]),
        "/endpoint/near_threshold_fraction_construction", ["prose", "supp:tab:threshold"])
    add("E_no_skill", "construction no-skill Brier score",
        r3(ep["no_skill_brier_floor_construction"]),
        "/endpoint/no_skill_brier_floor_construction", ["prose", "supp:tab:threshold"])

    lh = ai["leakage_inflation_headline"]
    add("L1", "Brier split contrast (sequence minus random), reported descriptively",
        r3(lh["brier_inflation_seq_minus_random"]),
        "/leakage_inflation_headline/brier_inflation_seq_minus_random",
        ["prose", "supp:tab:leakage", "supp:fig:S1"])
    add("L2", "AUROC under sequence grouping is higher than under random folds; reported descriptively (the source field stores random minus sequence)",
        r3(-lh["auroc_inflation_random_minus_seq"]),
        "/leakage_inflation_headline/auroc_inflation_random_minus_seq",
        ["prose", "supp:tab:leakage", "supp:fig:S1"])
    add("L1_4dp", "Brier split contrast magnitude printed to 4 dp (sequence lower than random)",
        f"{abs(lh['brier_inflation_seq_minus_random']):.4f}",
        "/leakage_inflation_headline/brier_inflation_seq_minus_random",
        ["prose", "supp:fig:S1"])
    add("L2_4dp", "AUROC split contrast printed to 4 dp (sequence higher than random)",
        f"{-lh['auroc_inflation_random_minus_seq']:.4f}",
        "/leakage_inflation_headline/auroc_inflation_random_minus_seq",
        ["prose", "supp:fig:S1"])
    eg, rnd = lh["per_scheme"]["event_grouped"], lh["per_scheme"]["random_event"]
    add("L_event_gap_4dp", "event-grouped vs random-event Brier gap from unrounded scores",
        f"{abs(rnd['brier'] - eg['brier']):.4f}",
        "derived: per_scheme/random_event/brier minus per_scheme/event_grouped/brier",
        ["prose"])
    for scheme in ("random_event", "event_grouped", "sequence_grouped"):
        ps = lh["per_scheme"][scheme]
        for metric in ("brier", "auroc", "log_loss"):
            add(f"L_{scheme}_{metric}_4dp", f"{scheme} {metric} printed to 4 dp", f"{ps[metric]:.4f}",
                f"/leakage_inflation_headline/per_scheme/{scheme}/{metric}",
                ["prose", "supp:tab:leakage"])
    for scheme in ("random_event", "event_grouped", "sequence_grouped"):
        ps = lh["per_scheme"][scheme]
        add(f"L_{scheme}_brier", f"{scheme} mean Brier", r3(ps["brier"]),
            f"/leakage_inflation_headline/per_scheme/{scheme}/brier",
            ["supp:tab:leakage", "supp:fig:S1"])
        add(f"L_{scheme}_auroc", f"{scheme} mean AUROC", r3(ps["auroc"]),
            f"/leakage_inflation_headline/per_scheme/{scheme}/auroc",
            ["supp:tab:leakage", "supp:fig:S1"])
        add(f"L_{scheme}_logloss", f"{scheme} mean log-loss", r3(ps["log_loss"]),
            f"/leakage_inflation_headline/per_scheme/{scheme}/log_loss",
            ["supp:tab:leakage"])

    pb = ai["per_baseline"]
    for bid in ("B0_no_skill", "B1_magnitude_only_logit", "B2_source_only_logit",
                "B4_random_forest", "B5_xgboost"):
        b = pb[bid]
        add(f"{bid}_brier", f"{bid} holdout Brier", r3(b["brier"]),
            f"/per_baseline/{bid}/brier",
            ["prose", "tab:baselines", "fig:baselines", "tab:qualification"])
        lo, hi = b["brier_ci"]
        add(f"{bid}_brier_ci", f"{bid} holdout Brier 95% cluster-bootstrap CI",
            [r3(lo), r3(hi)], f"/per_baseline/{bid}/brier_ci",
            ["tab:baselines", "fig:baselines", "tab:qualification"])
        add(f"{bid}_auroc", f"{bid} holdout AUROC", r3(b["auroc"]),
            f"/per_baseline/{bid}/auroc", ["tab:baselines"])
        add(f"{bid}_logloss", f"{bid} holdout log-loss", r3(b["log_loss"]),
            f"/per_baseline/{bid}/log_loss", ["tab:baselines"])
        add(f"{bid}_accuracy", f"{bid} holdout accuracy at the fixed threshold",
            f"{b['confusion_at_threshold']['accuracy']:.2f}",
            f"/per_baseline/{bid}/confusion_at_threshold/accuracy", ["tab:baselines"])
        if b["calibration_status"] == "OK":
            add(f"{bid}_calibration", f"{bid} calibration intercept and slope",
                [f"{b['calibration_intercept']:.2f}", f"{b['calibration_slope']:.2f}"],
                f"/per_baseline/{bid}", ["tab:baselines"])
        else:
            add(f"{bid}_calibration", f"{bid} calibration unavailable for constant predictions",
                b["calibration_status"], f"/per_baseline/{bid}/calibration_status",
                ["tab:baselines"])

    pm = ai["pairwise_ranking_stability"]["pairwise_matrix"]
    for pk, cell in pm.items():
        appears = ["supp:tab:pairwise"]
        if pk == "B2_source_only_logit_vs_B5_xgboost":
            appears.append("tab:qualification")
        add(f"P_{pk}", f"pairwise Brier comparison ({pk})",
            {
                "point_diff_a_minus_b": f"{cell['point_diff_a_minus_b']:.4f}",
                "ci": [f"{cell['ci'][0]:.4f}", f"{cell['ci'][1]:.4f}"],
                "prob_a_better": r3(cell["prob_a_better"]),
                "resolved": cell["resolved"],
            },
            f"/pairwise_ranking_stability/pairwise_matrix/{pk}",
            appears)
    add("P_unresolved_unadjusted_95",
        "legacy unadjusted 95% percentile intervals include zero for two learned-baseline pairs (B2 vs B4; B2 vs B5); "
        "superseded for decisions by H_unresolved",
        ["B2_source_only_logit_vs_B4_random_forest",
         "B2_source_only_logit_vs_B5_xgboost"],
        "/pairwise_ranking_stability/pairwise_matrix", ["supp:tab:pairwise"])

    sl = ai["slices"]
    for yr in ("2023", "2024"):
        add(f"S_temporal_{yr}_brier", f"temporal slice {yr} Brier", r3(sl["temporal"][yr]["brier"]),
            f"/slices/temporal/{yr}/brier", ["prose", "supp:tab:slices", "supp:fig:threshold"])
        add(f"S_temporal_{yr}_auroc", f"temporal slice {yr} AUROC", r3(sl["temporal"][yr]["auroc"]),
            f"/slices/temporal/{yr}/auroc", ["prose", "supp:tab:slices", "supp:fig:threshold"])
        add(f"S_temporal_{yr}_n", f"temporal slice {yr} n", sl["temporal"][yr]["n"],
            f"/slices/temporal/{yr}/n", ["prose", "supp:tab:slices", "supp:fig:threshold"])
    gs = sl["geographic_summary"]
    add("S_geo_cells", "occupied 10-degree geographic cells within temporal holdout", gs["n_cells"],
        "/slices/geographic_summary/n_cells", ["prose", "supp:tab:slices"])
    add("S_geo_sum_n", "temporal-holdout events included in geographic subgroup summary", gs["sum_n"],
        "/slices/geographic_summary/sum_n", ["supp:tab:slices"])
    add("S_geo_median", "median cell-level Brier score in geographic subgroup summary",
        r3(gs["brier_median"]), "/slices/geographic_summary/brier_median",
        ["prose", "supp:tab:slices"])
    add("S_geo_range", "range of cell-level Brier scores in geographic subgroup summary",
        [r3(gs["brier_min"]), r3(gs["brier_max"])],
        "/slices/geographic_summary", ["prose", "supp:tab:slices"])

    rm = ai["reproducibility_manifest"]
    add("R_fit_count", "fit count consumed", rm["fit_count"],
        "/reproducibility_manifest/fit_count", ["prose"])
    add("R_fit_cap", "preregistered fit cap", rm["fit_cap"],
        "/reproducibility_manifest/fit_cap", ["prose"])
    add("R_run_token", "one-shot run tokens consumed", rm["run_token_consumed_count"],
        "/reproducibility_manifest/run_token_consumed_count", ["prose"])
    add("F1_stale", "self-referential expected-stale manifest entries (F1)",
        rm["n_self_referential_stale"],
        "/reproducibility_manifest/n_self_referential_stale", ["prose"])

    em = ai["pairwise_ranking_stability"]["equivalence_margin_status"]
    add("W4_margin", "preregistered numeric equivalence margin (none; W4 deviation)",
        em["preregistered_numeric_equivalence_margin"],
        "/pairwise_ranking_stability/equivalence_margin_status/preregistered_numeric_equivalence_margin",
        ["prose"])
    add("W4_floor", "genuinely registered resolution floor", em["genuinely_registered_resolution_floor"],
        "/pairwise_ranking_stability/equivalence_margin_status/genuinely_registered_resolution_floor",
        ["prose"])
    add("NW", "no winning-model claim asserted", ai["no_winning_model_claim"],
        "/no_winning_model_claim", ["abstract", "prose"])
    add("Q_B3", "B3 is outside the declared source-only contract because expanded metadata includes event year; this is not asserted as label leakage",
        ai["exclusions_and_deviations"]["B3_axis_excluded"],
        "/exclusions_and_deviations/B3_axis_excluded",
        ["prose", "tab:qualification", "supp:tab:exclusions"])
    loc = HERE / "frozen_inputs" / "source_locator_manifest.json"
    if loc.exists():
        sl = json.loads(loc.read_text())
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "P_access_instant",
            "claim": "frozen snapshot access instant",
            "value": sl["access_instant"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/source_locator_manifest.json",
            "json_pointer": "/access_instant",
            "appears_in": ["prose"],
        })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "P_count_min",
            "claim": "preliminary live count (first observation)",
            "value": sl["drift_receipt"]["count_min"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/source_locator_manifest.json",
            "json_pointer": "/drift_receipt/count_min",
            "appears_in": ["prose"],
        })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "P_count_max",
            "claim": "preliminary live count (second observation)",
            "value": sl["drift_receipt"]["count_max"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/source_locator_manifest.json",
            "json_pointer": "/drift_receipt/count_max",
            "appears_in": ["prose"],
        })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "P_costamped",
            "claim": "costamped frozen payload count",
            "value": sl["costamped_count"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/source_locator_manifest.json",
            "json_pointer": "/costamped_count",
            "appears_in": ["prose"],
        })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "P_recount_lag_s",
            "claim": "seconds between payload access instant and costamped count",
            "value": 50,
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/source_locator_manifest.json",
            "json_pointer": "derived: count_access_instant minus access_instant",
            "appears_in": ["prose"],
            "note": "2026-09-01T06:34:20Z minus 2026-09-01T06:33:30Z",
        })
    fw_path = HERE / "frozen_inputs" / "family_wise_sensitivity.json"
    if fw_path.exists():
        fw = json.loads(fw_path.read_text())
        for i, p in enumerate(fw["pairs"]):
            rows.append({
                "record_type": "claim_ledger_entry",
                "claim_id": f"H_{p['baseline_a'][:2]}_{p['baseline_b'][:2]}",
                "claim": "post-hoc sequence-cluster-robust paired Brier test, Holm decision, and Bonferroni 99.5% t interval (no refit)",
                "value": {
                    "bonferroni_ci": [f"{p['bonferroni_ci'][0]:.4f}", f"{p['bonferroni_ci'][1]:.4f}"],
                    "cluster_robust_p_two_sided": p["cluster_robust_p_two_sided"],
                    "holm_rejects_zero": p["holm_rejects_zero"],
                },
                "source_artifact": "manuscript/paper-cbs/frozen_inputs/family_wise_sensitivity.json",
                "json_pointer": f"/pairs/{i}",
                "appears_in": ["prose", "supp:tab:pairwise"]
                + (["tab:qualification"] if p["baseline_a"][:2] in ("B0", "B1") else []),
            })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "H_unresolved",
            "claim": "admissible pairs not rejected under the ten-pair cluster-robust Holm family (authoritative decision rule)",
            "value": [f"{p['baseline_a']}_vs_{p['baseline_b']}" for p in fw["pairs"] if not p["holm_rejects_zero"]],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/family_wise_sensitivity.json",
            "json_pointer": "/pairs",
            "appears_in": ["abstract", "prose", "supp:tab:pairwise", "tab:qualification"],
        })
    rob_path = HERE / "frozen_inputs" / "robustness_post_hoc.json"
    if rob_path.exists():
        rob = json.loads(rob_path.read_text())
        cs = rob["cluster_structure"]
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "R_cluster_structure",
            "claim": "holdout sequence cluster structure",
            "value": {"n_clusters": cs["n_clusters"], "n_singletons": cs["n_singletons"],
                      "largest": cs["largest_cluster_sizes"][0], "cr1_factor": f"{cs['cr1_small_sample_factor']:.3f}"},
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/robustness_post_hoc.json",
            "json_pointer": "/cluster_structure",
            "appears_in": ["prose", "supp:tab:decision-sensitivity"],
        })
        for cell, rec in rob["region_block_sensitivity"]["cells"].items():
            b14 = next(r for r in rec["pairs"] if r["a"].startswith("B1") and r["b"].startswith("B4"))
            rows.append({
                "record_type": "claim_ledger_entry",
                "claim_id": f"R_region_{cell}",
                "claim": f"region-block ({cell}) Holm decisions and B1-B4 p-values",
                "value": {"n_clusters": rec["cluster_structure"]["n_clusters"],
                          "n_holm_reject": {k: len(v) for k, v in rec["holm_rejected_pairs"].items()},
                          "B1_B4_p": {k: b14[k] for k in ("cr1_p", "cr3_jackknife_p", "wild_cluster_rademacher_p")},
                          "B1_B4_wild_mc_se": b14.get("wild_cluster_mc_se")},
                "source_artifact": "manuscript/paper-cbs/frozen_inputs/robustness_post_hoc.json",
                "json_pointer": f"/region_block_sensitivity/cells/{cell}",
                "appears_in": ["prose", "supp:tab:decision-sensitivity"],
            })
        synth = rob.get("synthetic_larger_cluster_sensitivity", {}).get("cells", {})
        if "86_clusters" in synth:
            rec86 = synth["86_clusters"]
            rows.append({
                "record_type": "claim_ledger_entry",
                "claim_id": "R_synthetic_86_clusters",
                "claim": "disclosed random 86-cluster partition of the same 430 holdout losses",
                "value": {"n_holm_reject": rec86["n_holm_reject"],
                          "B1_B4_cr1_p": rec86["B1_B4"]["cr1_p"]},
                "source_artifact": "manuscript/paper-cbs/frozen_inputs/robustness_post_hoc.json",
                "json_pointer": "/synthetic_larger_cluster_sensitivity/cells/86_clusters",
                "appears_in": ["prose", "supp:tab:decision-sensitivity"],
            })
    for key in ("B1_magnitude_only_logit", "B2_source_only_logit", "B4_random_forest", "B5_xgboost"):
        add(f"RECALL_{key[:2]}", f"{key} recall at the 0.5 cutoff",
            f"{ai['per_baseline'][key]['confusion_at_threshold']['recall']:.2f}",
            f"/per_baseline/{key}/confusion_at_threshold/recall", ["prose"])
    hp = ai["endpoint"]["holdout_prevalence"]
    rows.append({
        "record_type": "claim_ledger_entry",
        "claim_id": "B0_oracle_constant",
        "claim": "Brier of a holdout-prevalence constant p(1-p) and its gap to B0",
        "value": {"oracle_brier": r3(hp * (1 - hp)),
                  "gap_to_B0": f"{ai['per_baseline']['B0_no_skill']['brier'] - hp * (1 - hp):.3f}"},
        "source_artifact": "manuscript/paper-cbs/frozen_inputs/asset_inputs.json",
        "json_pointer": "derived: /endpoint/holdout_prevalence, /per_baseline/B0_no_skill/brier",
        "appears_in": ["prose"],
    })
    add("JOINT_B5_best", "joint-ordering probability B5 uniquely best",
        ai["pairwise_ranking_stability"]["tie_aware_joint_ordering"]["prob_best"]["B5_xgboost"],
        "/pairwise_ranking_stability/tie_aware_joint_ordering/prob_best/B5_xgboost", ["prose"])
    rb_path = HERE / "frozen_inputs" / "robustness_post_hoc.json"
    if rb_path.exists():
        rb = json.loads(rb_path.read_text())
        rb_src = "manuscript/paper-cbs/frozen_inputs/robustness_post_hoc.json"
        for k, v in rb["split_contrast_paired"].items():
            rows.append({
                "record_type": "claim_ledger_entry",
                "claim_id": f"ROB_split_{k}",
                "claim": f"post-hoc paired split-contrast interval ({k})",
                "value": {"point": v["point"], "ci95": v["ci95"], "excludes_zero": v["excludes_zero"]},
                "source_artifact": rb_src,
                "json_pointer": f"/split_contrast_paired/{k}",
                "appears_in": ["prose", "supp:tab:exclusions"],
            })
        for k, v in rb["sequence_definition_sensitivity"].items():
            rows.append({
                "record_type": "claim_ledger_entry",
                "claim_id": f"ROB_seqdef_{k}",
                "claim": f"post-hoc sequence-definition sensitivity ({k}): clusters and Holm rejections",
                "value": {"n_holdout_clusters": v["n_holdout_clusters"], "n_holm_reject": v["n_holm_reject"]},
                "source_artifact": rb_src,
                "json_pointer": f"/sequence_definition_sensitivity/{k}",
                "appears_in": ["prose", "supp:tab:exclusions"],
            })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "ROB_reference_only_family",
            "claim": "Holm rejections under the reference-only family",
            "value": len(rb["reference_only_family"]["holm_rejected_pairs"]),
            "source_artifact": rb_src,
            "json_pointer": "/reference_only_family/holm_rejected_pairs",
            "appears_in": ["prose", "supp:tab:exclusions"],
        })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "ROB_n_holm_reject_log_loss",
            "claim": "Holm rejections under the log-loss family",
            "value": rb["n_holm_reject_log_loss"],
            "source_artifact": rb_src,
            "json_pointer": "/n_holm_reject_log_loss",
            "appears_in": ["prose", "supp:tab:exclusions"],
        })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "ROB_n_holm_reject_auroc",
            "claim": "Holm rejections under the AUROC family",
            "value": rb["n_holm_reject_auroc"],
            "source_artifact": rb_src,
            "json_pointer": "/n_holm_reject_auroc",
            "appears_in": ["prose", "supp:tab:exclusions"],
        })
    tr_path = HERE / "frozen_inputs" / "contract_transfer_dbmi.json"
    if tr_path.exists():
        tr = json.loads(tr_path.read_text())
        tr_src = "manuscript/paper-cbs/frozen_inputs/contract_transfer_dbmi.json"
        s3, co = tr["S3_provenance"], tr["cohort"]
        n_lab = s3["n_non_instrumental_with_label"] + s3["n_instrumental"]
        for cid, claim, value, ptr in (
            ("TR_provenance_fraction", "labelled CPTI15 events with intensity-derived or mixed magnitude",
             {"n": s3["n_non_instrumental_with_label"], "of": n_lab,
              "pct": f"{100 * s3['n_non_instrumental_with_label'] / n_lab:.1f}"}, "/S3_provenance"),
            ("TR_spearman", "Spearman(MwDef, ImaxNum) on purely macroseismic vs instrumental events",
             {"n_macroseismic": s3["n_macroseismic"],
              "rho_macroseismic": f"{s3['spearman_mw_imax_macroseismic']:.3f}",
              "n_instrumental": s3["n_instrumental"],
              "rho_instrumental": f"{s3['spearman_mw_imax_instrumental']:.3f}"},
             "/S3_provenance"),
            ("TR_cohort", "instrumental transfer cohort, cutoff, construction and holdout sizes",
             {"n": co["n_instrumental_labelled"], "cutoff": co["cutoff_year"],
              "construction": co["construction"]["n_events"], "holdout": co["holdout"]["n_events"],
              "holdout_pos": co["holdout_positives"], "holdout_neg": co["holdout_negatives"]}, "/cohort"),
            ("TR_evaluable", "transfer holdout passes preregistered evaluability floor", co["evaluable"],
             "/cohort/evaluable"),
            ("TR_raw_names_rejected", "unchanged audit rejects raw CPTI names", tr["audits"]["raw_catalogue_names"]["passed"],
             "/audits/raw_catalogue_names/passed"),
        ):
            rows.append({"record_type": "claim_ledger_entry", "claim_id": cid, "claim": claim, "value": value,
                         "source_artifact": tr_src, "json_pointer": ptr, "appears_in": ["abstract", "prose"]})
    sm_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_v2.json"
    if sm_path.exists():
        sm = json.loads(sm_path.read_text())
        sm_src = "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_v2.json"
        co = sm["cohort"]
        sc = sm["per_candidate"]
        for cid, claim, value, ptr in (
            ("SM_cohort", "disjoint ShakeMap labelled cohort and holdout sizes",
             {"n_labelled": co["n_labelled"], "holdout": co["holdout"]["n_events"],
              "holdout_sequences": co["holdout"]["n_sequences"],
              "holdout_multi": co["holdout"]["n_multi_event_sequences"],
              "largest": co["holdout"]["largest"], "holdout_pos": co["holdout_positives"]},
             "/cohort"),
            ("SM_holm_cr1", "ShakeMap CR1 Holm rejections of ten pairs",
             sm["n_holm_rejections_cr1"], "/n_holm_rejections_cr1"),
            ("SM_B2_vs_B1", "ShakeMap holdout Brier and AUROC for B2 versus B1",
             {"B1_brier": r3(sc["B1_magnitude_only_logit"]["brier"]),
              "B1_auroc": r3(sc["B1_magnitude_only_logit"]["auroc"]),
              "B2_brier": r3(sc["B2_source_only_logit"]["brier"]),
              "B2_auroc": r3(sc["B2_source_only_logit"]["auroc"])},
             "/per_candidate"),
            ("SM_evaluable", "ShakeMap holdout passes evaluability floor", co["evaluable"],
             "/cohort/evaluable"),
            ("SM_S1_mmi", "declaring mmi as a feature fails F1", sm["audits"]["S1_mmi"]["passed"],
             "/audits/S1_mmi/passed"),
        ):
            rows.append({"record_type": "claim_ledger_entry", "claim_id": cid, "claim": claim, "value": value,
                         "source_artifact": sm_src, "json_pointer": ptr, "appears_in": ["abstract", "prose"]})
    sm_v1_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_v1.json"
    if sm_v1_path.exists():
        sm_v1 = json.loads(sm_v1_path.read_text())
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "SM_v1_holm_cr1",
            "claim": "ShakeMap v1 CR1 Holm rejections with all-missing depth binding",
            "value": sm_v1["n_holm_rejections_cr1"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_v1.json",
            "json_pointer": "/n_holm_rejections_cr1",
            "appears_in": ["abstract", "prose", "supp:tab:shakemap-v1-v2"],
        })
    sm_rec_v1_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_reconstruction_v1.json"
    if sm_rec_v1_path.exists():
        sm_rec_v1 = json.loads(sm_rec_v1_path.read_text())
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "SM_v1_row_reconstruction",
            "claim": "offline v1 row release reproduces digest, fits, scores, ten pairs, and 0/10 Holm",
            "value": sm_rec_v1["exact_matches"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_reconstruction_v1.json",
            "json_pointer": "/exact_matches",
            "appears_in": ["prose", "supp:tab:shakemap-v1-v2"],
        })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "SM_v1_depth_missing",
            "claim": "ShakeMap v1 construction and holdout depth values missing",
            "value": {
                "construction": sm_v1["cohort"]["depth_missing_construction"],
                "holdout": sm_v1["cohort"]["depth_missing_holdout"],
            },
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_v1.json",
            "json_pointer": "/cohort",
            "appears_in": ["abstract", "prose", "supp:tab:shakemap-v1-v2"],
        })
    sm_rec_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_reconstruction_v2.json"
    if sm_rec_path.exists():
        sm_rec = json.loads(sm_rec_path.read_text())
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "SM_v2_reconstruction",
            "claim": "later retrieval exactly reconstructs all v2 scientific outputs",
            "value": sm_rec["exact_matches"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_reconstruction_v2.json",
            "json_pointer": "/exact_matches",
            "appears_in": ["prose", "supp:tab:exclusions"],
        })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "SM_binding_audit",
            "claim": "retrospective value-level binding audit rejects v1 and passes v2",
            "value": sm_rec["binding_audit"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_reconstruction_v2.json",
            "json_pointer": "/binding_audit",
            "appears_in": ["prose", "supp:tab:exclusions"],
        })
    pro_path = HERE / "frozen_inputs" / "prospective_dyfi_2025.json"
    if pro_path.exists():
        pro = json.loads(pro_path.read_text())
        pro_src = "manuscript/paper-cbs/frozen_inputs/prospective_dyfi_2025.json"
        pc = pro["cohort"]
        pp = pro["per_candidate"]
        for cid, claim, value, ptr, where in (
            ("PRO_cohort", "prospective 2025-2026 DYFI payload, eligible, holdout, sequences, severe",
             {"payload": pro["provenance"]["payload_features"], "eligible": pc["eligibility"]["n_eligible"],
              "straddle": pc["n_straddle_excluded"], "holdout": pc["n_holdout"],
              "sequences": pc["n_sequences"], "positives": pc["positives"]},
             "/cohort", ["abstract", "prose", "tab:prospective"]),
            ("PRO_H1", "primary hypothesis H1 outcome (true if every learned candidate beats no-skill under Holm)",
             pro["hypotheses"]["H1"]["supported"], "/hypotheses/H1/supported", ["abstract", "prose"]),
            ("PRO_H2", "secondary hypothesis H2 outcome (true if B2, B4, and B5 each beat magnitude-only B1 under Holm); false = not supported",
             pro["hypotheses"]["H2"]["supported"], "/hypotheses/H2/supported", ["abstract", "prose"]),
            ("PRO_holm_cr1", "prospective CR1 Holm rejections of ten pairs",
             pro["n_holm_rejections_cr1"], "/n_holm_rejections_cr1", ["prose", "supp:tab:prospective-pairs"]),
            ("PRO_scores", "prospective Brier B0, B2, B5, C_F1, C_F2",
             {k: r3(pp[k]["brier"]) for k in ("B0_no_skill", "B2_source_only_logit", "B5_xgboost", "C_F1", "C_F2")},
             "/per_candidate", ["prose", "tab:prospective"]),
            ("PRO_workflows", "frozen-plan output of each rule: minimum-Brier admitted candidate",
             {k: v["selected"] for k, v in pro["workflows"].items() if isinstance(v, dict)},
             "/workflows", ["abstract", "prose", "tab:prospective"]),
            ("PRO_value_gate", "prospective value-binding gate passed", pro["value_gate"]["passed"],
             "/value_gate/passed", ["prose"]),
            ("PRO_expectations", "pre-declared comparator expectations met or not met", pro["expectations"],
             "/expectations", ["prose"]),
        ):
            rows.append({"record_type": "claim_ledger_entry", "claim_id": cid, "claim": claim, "value": value,
                         "source_artifact": pro_src, "json_pointer": ptr, "appears_in": where})
        b5 = {f"{p['a']}-{p['b']}": {"cr1_p": p["cr1_p"], "holm_cr1": p["holm_cr1"]}
              for p in pro["pairs"] if "B5_xgboost" in (p["a"], p["b"]) and not p["a"].startswith("B0")}
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "PRO_B5_pairs",
                     "claim": "abstract: B5 Holm-supported over B1 but unresolved against source-only B2 and random forest B4",
                     "value": b5, "source_artifact": pro_src, "json_pointer": "/pairs",
                     "appears_in": ["abstract", "prose", "supp:tab:prospective-pairs"]})
    phw_path = HERE / "frozen_inputs" / "prospective_dyfi_2025_post_hoc_winners.json"
    if phw_path.exists():
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "PRO_post_hoc_winners",
                     "claim": "post hoc winner and admissible pair labels under each rule's own test",
                     "value": json.loads(phw_path.read_text()),
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/prospective_dyfi_2025_post_hoc_winners.json",
                     "json_pointer": "", "appears_in": ["prose", "tab:prospective"]})
    dia = HERE / "frozen_inputs" / "diabetes_transfer" / "results"
    if (dia / "results.json").exists():
        dr = json.loads((dia / "results.json").read_text())
        dsrc = "manuscript/paper-cbs/frozen_inputs/diabetes_transfer/results/results.json"
        dpc = dr["per_candidate"]
        for cid, claim, value, ptr, where in (
            ("DIA_cohort", "readmission holdout encounters, patients, repeat patients, largest cluster, positives",
             {k: dr["cohort"][k] for k in ("n_rows", "n_holdout", "n_holdout_patients", "n_multi_encounter_patients",
                                           "largest_patient_cluster", "positives")},
             "/cohort", ["abstract", "prose", "tab:diabetes"]),
            ("DIA_hypotheses", "readmission H1 and H2 outcomes (true = supported)",
             {h: dr["hypotheses"][h]["supported"] for h in ("H1", "H2")}, "/hypotheses", ["prose", "supp:tab:diabetes-pairs"]),
            ("DIA_expectations", "readmission pre-declared expectations met", dr["expectations"], "/expectations", ["prose"]),
            ("DIA_scores", "readmission holdout Brier by candidate",
             {k: round(v["brier"], 4) for k, v in dpc.items()}, "/per_candidate", ["prose", "tab:diabetes", "supp:tab:diabetes-pairs"]),
            ("DIA_gates", "readmission gate outcome per candidate",
             {k: v["admitted"] for k, v in dr["gates"].items()}, "/gates", ["abstract", "prose", "tab:diabetes"]),
            ("DIA_rules", "readmission rule outputs: admitted count, lowest point Brier, winner",
             {k: {"n_admitted": len(v["admitted"]), "lowest": v["lowest_point"], "winner": v["winner"]}
              for k, v in dr["workflows"].items()}, "/workflows", ["abstract", "prose", "tab:diabetes"]),
            ("DIA_dependence", "readmission encounter vs patient-cluster decision differences and SE ratios",
             dr["dependence"], "/dependence", ["prose", "supp:tab:diabetes-pairs"]),
        ):
            rows.append({"record_type": "claim_ledger_entry", "claim_id": cid, "claim": claim, "value": value,
                         "source_artifact": dsrc, "json_pointer": ptr, "appears_in": where})
        ph = json.loads((dia / "post_hoc_gate_ablations.json").read_text())["variants"]
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "DIA_gate_removal",
                     "claim": "post hoc gate removal: winner without each gate",
                     "value": {k: v["winner"] for k, v in ph.items()},
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/diabetes_transfer/results/post_hoc_gate_ablations.json",
                     "json_pointer": "/variants", "appears_in": ["abstract", "prose", "tab:diabetes"]})
        nc = json.loads((dia / "post_hoc_null_calibration.json").read_text())["arms"]
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "NULL_fwer",
                     "claim": "post hoc cluster sign-flip null: Holm family-wise error, event-level vs cluster",
                     "value": {a["arm"]: {"event": round(a["fwer_event_level_holm"], 3),
                                          "cluster": round(a["fwer_cluster_holm"], 3)} for a in nc},
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/diabetes_transfer/results/post_hoc_null_calibration.json",
                     "json_pointer": "/arms", "appears_in": ["prose", "supp:tab:null-calibration"]})
        ri = json.loads((dia / "post_hoc_row_identity_ablation.json").read_text())
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "DIA_row_identity",
                     "claim": "post hoc row-identity substitution for the role audit: refused candidates and winner",
                     "value": {"training_rows_that_are_holdout_encounters": ri["training_rows_that_are_holdout_encounters"],
                               **{k: {"admitted": v["admitted"], "winner": v["winner"]} for k, v in ri["variants"].items()}},
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/diabetes_transfer/results/post_hoc_row_identity_ablation.json",
                     "json_pointer": "/variants", "appears_in": ["abstract", "prose", "tab:diabetes"]})
        rec = json.loads((dia / "post_hoc_overlap_recount.json").read_text())
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "DIA_overlap_reuse",
                     "claim": "C_overlap training rows that are exact scored holdout encounters",
                     "value": {"n_train_exact_holdout_encounters": rec["n_train_exact_holdout_encounters"],
                               "fraction_of_holdout_in_training": rec["fraction_of_holdout_in_training"],
                               "n_train_other_encounters_of_holdout_patients": rec["n_train_other_encounters_of_holdout_patients"]},
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/diabetes_transfer/results/post_hoc_overlap_recount.json",
                     "json_pointer": "/n_train_exact_holdout_encounters",
                     "appears_in": ["abstract", "prose", "tab:diabetes"]})
    uo_path = HERE / "frozen_inputs" / "unit_overlap_diabetes" / "results" / "results.json"
    if uo_path.exists():
        uo = json.loads(uo_path.read_text())
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "UNIT_overlap",
                     "claim": "post hoc row-disjoint patient-overlap seed: checks and Brier delta",
                     "value": {"n_eval": uo["sets"]["n_eval_rows"],
                               "row_identity_passed": uo["checks"]["C_unit"]["row_identity_passed"],
                               "role_audit_passed": uo["checks"]["C_unit"]["role_audit_passed"],
                               "delta_brier_ctrl_minus_unit": uo["primary"]["delta_brier_ctrl_minus_unit"],
                               "p": uo["primary"]["p_two_sided"]},
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/unit_overlap_diabetes/results/results.json",
                     "json_pointer": "/primary", "appears_in": ["prose", "supp:tab:unit-overlap"]})
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "UNIT_secondary",
                     "claim": "post hoc unit-overlap seed pre-declared secondary outputs: point rank and row-check winner",
                     "value": {"point_rank_on_E_R": uo["point_rank_on_E_R"],
                               "row_check_winner": uo["row_check_variant"]["winner"],
                               "row_check_n_holm": uo["row_check_variant"]["n_holm"]},
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/unit_overlap_diabetes/results/results.json",
                     "json_pointer": "/row_check_variant", "appears_in": ["prose", "supp:tab:unit-overlap"]})
    mu_path = HERE / "frozen_inputs" / "misspecified_unit_null" / "misspecified_unit_null.json"
    if mu_path.exists():
        mu = json.loads(mu_path.read_text())
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "NULL_misspecified_unit",
                     "claim": "post hoc regional sign-flip null on prospective DYFI: Holm family-wise error by test unit",
                     "value": {k: round(v, 3) for k, v in mu["fwer_holm"].items()},
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/misspecified_unit_null/misspecified_unit_null.json",
                     "json_pointer": "/fwer_holm", "appears_in": ["prose", "supp:tab:null-calibration"]})
    sd_path = HERE / "frozen_inputs" / "seeded_candidate_demo.json"
    if sd_path.exists():
        sd = json.loads(sd_path.read_text())
        s = sd["holdout_scores"]["C_F2"]
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "SEED_scores",
            "claim": "post-hoc seeded F2 candidate holdout scores (Brier, AUROC, log-loss)",
            "value": [r3(s["brier"]), r3(s["auroc"]), r3(s["log_loss"])],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/seeded_candidate_demo.json",
            "json_pointer": "/holdout_scores/C_F2",
            "appears_in": ["abstract", "prose", "tab:qualification"],
        })
        for ref in ("B2_source_only_logit", "B5_xgboost"):
            c = sd["paired_brier_vs_admissible"][ref]
            rows.append({
                "record_type": "claim_ledger_entry",
                "claim_id": f"SEED_vs_{ref[:2]}",
                "claim": f"seeded candidate minus {ref} paired Brier difference and 95% CI",
                "value": {"diff": f"{c['point_diff_leak_minus_ref']:.4f}",
                          "ci": [f"{c['ci95'][0]:.4f}", f"{c['ci95'][1]:.4f}"]},
                "source_artifact": "manuscript/paper-cbs/frozen_inputs/seeded_candidate_demo.json",
                "json_pointer": f"/paired_brier_vs_admissible/{ref}",
                "appears_in": ["prose"],
            })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "SEED_admission",
            "claim": "admission audit rejects the seeded candidate (F2 response count)",
            "value": sd["admission_audit"]["passed"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/seeded_candidate_demo.json",
            "json_pointer": "/admission_audit/passed",
            "appears_in": ["abstract", "prose", "tab:qualification"],
        })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "SEED_prob_better_B2",
            "claim": "bootstrap probability seeded C_F2 beats B2",
            "value": sd["paired_brier_vs_admissible"]["B2_source_only_logit"].get("prob_leak_better"),
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/seeded_candidate_demo.json",
            "json_pointer": "/paired_brier_vs_admissible/B2_source_only_logit/prob_leak_better",
            "appears_in": ["prose"],
        })
        for name, c in sd.get("candidates", {}).items():
            hs = c["holdout_scores"]
            rows.append({
                "record_type": "claim_ledger_entry",
                "claim_id": f"SEED_cand_{name}",
                "claim": f"seeded candidate {name}: admission decision, holdout scores, paired Brier vs B2",
                "value": {"admitted": c["admission_audit"]["passed"],
                          "brier": r3(hs["brier"]), "auroc": r3(hs["auroc"]),
                          "vs_B2": {"diff": f"{c['vs_B2_brier']['diff']:.4f}",
                                    "ci95": [f"{x:.4f}" for x in c["vs_B2_brier"]["ci95"]]}},
                "source_artifact": "manuscript/paper-cbs/frozen_inputs/seeded_candidate_demo.json",
                "json_pointer": f"/candidates/{name}",
                "appears_in": ["prose"],
            })
        rows.append({
            "record_type": "claim_ledger_entry",
            "claim_id": "SEED_extended_holm",
            "claim": "extended 15-pair Holm family: admissible baselines C_F2 is Holm-supported against",
            "value": sd["extended_holm_family"]["C_F2_holm_supported_against"],
            "source_artifact": "manuscript/paper-cbs/frozen_inputs/seeded_candidate_demo.json",
            "json_pointer": "/extended_holm_family",
            "appears_in": ["prose", "tab:qualification"],
        })
    rows.append({
        "record_type": "claim_ledger_entry",
        "claim_id": "P_unit_tests",
        "claim": "unit tests exercising the schema and split audits",
        "value": 110,
        "source_artifact": "manuscript/paper-cbs/frozen_inputs/unit_tests/unittest_inventory.json",
        "json_pointer": "/passed",
        "appears_in": ["prose"],
        "note": "four suites (31+35+20+24), exit code 0; log in frozen_inputs/unit_tests/unittest_run.log",
    })
    et_path = HERE / "frozen_inputs" / "toolchain_comparison" / "evaltoolkit_comparison.json"
    if et_path.exists():
        et = json.loads(et_path.read_text())
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "DIA_evaltoolkit",
                     "claim": "post hoc executed eval-toolkit 1.12.0 comparison on frozen readmission candidates: refusals and named winners",
                     "value": {"refused": {c: a["refused_by"] for c, a in et["audit"].items() if a["refused_by"]},
                               "T1_winner": et["stacks"]["T1_evaltoolkit"]["named_winner"],
                               "T2_winner": et["stacks"]["T2_evaltoolkit_plus_name_gate"]["named_winner"],
                               "T2_seeded_admitted": et["stacks"]["T2_evaltoolkit_plus_name_gate"]["seeded_admitted"]},
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/toolchain_comparison/evaltoolkit_comparison.json",
                     "json_pointer": "/stacks", "appears_in": ["abstract", "prose", "tab:diabetes"]})
    rh_path = HERE / "frozen_inputs" / "misspecified_unit_null" / "prospective_region_holm.json"
    if rh_path.exists():
        rh = json.loads(rh_path.read_text())
        rows.append({"record_type": "claim_ledger_entry", "claim_id": "PRO_region_holm",
                     "claim": "post hoc prospective pair decisions under region clustering: Holm rejections and B1-B2/B1-B5 p",
                     "value": {"n_holm": rh["n_holm"],
                               "B1_B2_region_p": round(rh["pairs"]["region"]["B1_magnitude_only_logit-B2_source_only_logit"]["p"], 3),
                               "B1_B5_region_p": round(rh["pairs"]["region"]["B1_magnitude_only_logit-B5_xgboost"]["p"], 3),
                               "hypotheses": rh["hypotheses"]["region"]},
                     "source_artifact": "manuscript/paper-cbs/frozen_inputs/misspecified_unit_null/prospective_region_holm.json",
                     "json_pointer": "/pairs/region", "appears_in": ["prose", "supp:tab:region-holm"]})
    return rows


def build_artifact_ledger() -> list[dict]:
    manifest = (
        json.loads(MANIFEST.read_text()).get("artifacts", {})
        if MANIFEST.exists() else {}
    )
    rows: list[dict] = []

    def add(rel, role, provenance, canonical_match=None):
        p = HERE / rel
        entry = {
            "record_type": "artifact_ledger_entry",
            "path": f"manuscript/paper-cbs/{rel}",
            "role": role,
            "sha256": sha256(p) if p.exists() else None,
            "exists": p.exists(),
            "provenance": provenance,
        }
        if canonical_match is not None:
            entry["canonical_asset"] = canonical_match
            cp = MAN / canonical_match
            entry["canonical_sha256"] = sha256(cp) if cp.exists() else None
            entry["byte_identical_to_canonical"] = (
                cp.exists() and p.exists() and sha256(cp) == sha256(p))
        rows.append(entry)

    add("main.tex", "manuscript source", "hand-authored from validated assets")
    add("supplement.tex", "supplementary manuscript source",
        "hand-authored wrapper around generated frozen-result tables")
    add("supplement.pdf", "supplementary review PDF",
        "compiled deterministically from supplement.tex and generated tables")
    add("references.bib", "bibliography", "verified per citation_ledger.jsonl")
    add("title_page.tex", "unblinded title page source", "hand-authored; author identities kept out of main.tex")
    add("title_page.pdf", "unblinded title page PDF", "compiled from title_page.tex")
    for fig in sorted((HERE / "figures").glob("*.pdf")):
        if fig.name in {"fig_candidate_workflow.pdf", "fig_split_diagnostic.pdf", "fig_baseline_scores.pdf", "fig_threshold_slice.pdf"}:
            add(f"figures/{fig.name}", "figure",
                "CBS decision-support figure generated by build_utility_assets.py")
        else:
            add(f"figures/{fig.name}", "figure",
                "byte-copy of validated vector manuscript figure",
                canonical_match=f"figures/{fig.name}")
    for t in sorted((HERE / "tables").glob("*.tex")):
        if t.name in {"engineering_failure_modes.tex", "candidate_qualification.tex"}:
            add(f"tables/{t.name}", "decision-support table",
                "CBS table generated from frozen inputs by build_utility_assets.py")
        elif t.read_text().startswith("% GENERATED by format_cbs_tables.py"):
            add(f"tables/{t.name}", "result table",
                "generated from frozen_inputs by format_cbs_tables.py")
        elif t.name == "capability_comparison.tex":
            add(f"tables/{t.name}", "static comparison table", "hand-maintained; no result cells")
        else:
            add(f"tables/{t.name}", "venue-formatted table input",
                "layout-only transform of canonical table via format_tables.py",
                canonical_match=f"tables/{t.name}")
    for aux in ("citation_ledger.jsonl", "claim_ledger.jsonl", "artifact_ledger.jsonl",
                "format_tables.py", "generate_ledgers.py",
                "build.sh", "build_utility_assets.py", "format_cbs_tables.py",
                "validate_cbs.py", "utility_asset_manifest.json",
                "cbs_validation_report.json"):
        if (HERE / aux).exists():
            add(aux, "build/ledger tool or record", "generated in manuscript/paper")
    # note the canonical manifest linkage
    for row in rows:
        cm = row.get("canonical_asset")
        if cm and f"manuscript/{cm}" in manifest:
            row["recorded_manifest_sha256"] = manifest[f"manuscript/{cm}"]
    return rows


def build_build_ledger() -> dict:
    pdf = HERE / "main.pdf"
    return {
        "record_type": "manuscript_build_ledger",
        "resource_id": "DYFI_USGS_SINGLE_SOURCE_SEVERE_FELT_INTENSITY_V1",
        "engine": "Tectonic 0.17.0 (auto BibTeX + reruns)",
        "engine_reference_binary_sha256": "568dea0a81f4ceed859e33734bbbea85d54a25f14b12665a48c98b536a887986",
        "pdf_determinism_scope": (
            "Byte-identical under Tectonic 0.17.0 with the same cached resource "
            "bundle and SOURCE_DATE_EPOCH. Other Tectonic versions may serialize "
            "different PDF bytes while preserving identical text and pixels."
        ),
        "entrypoint": "manuscript/paper-cbs/build.sh",
        "ordered_steps": [
            "python3 build_utility_assets.py  (decision-support assets)",
            "python3 format_tables.py  (layout-only venue table copies)",
            "python3 format_cbs_tables.py  (fit wide tables to review layout)",
            "cp ../figures/*.pdf figures/  (byte-identical vector figures)",
            "tectonic --keep-logs main.tex  (compile -> main.pdf)",
            "tectonic --keep-logs supplement.tex  (compile -> supplement.pdf)",
            "tectonic --keep-logs title_page.tex  (compile -> title_page.pdf)",
        ],
        "inputs_are_immutable": True,
        "network_writes": False,
        "public_repository": "withheld for double-anonymous review; see separate title page",
        "public_release_tag": "withheld for double-anonymous review; see separate title page",
        "doi": None,
        "submitted": False,
        "main_tex_sha256": sha256(HERE / "main.tex"),
        "references_bib_sha256": sha256(HERE / "references.bib"),
        "main_pdf_sha256": sha256(pdf) if pdf.exists() else None,
        "main_pdf_bytes": pdf.stat().st_size if pdf.exists() else None,
        "supplement_tex_sha256": sha256(HERE / "supplement.tex"),
        "supplement_pdf_sha256": sha256(HERE / "supplement.pdf") if (HERE / "supplement.pdf").exists() else None,
        "supplement_pdf_bytes": (HERE / "supplement.pdf").stat().st_size if (HERE / "supplement.pdf").exists() else None,
        "utility_figure_matplotlib_pin": "3.11.1",
        "utility_figure_verification": (
            "CBS-local figures in utility_asset_manifest.json are SHA-256 pinned. "
            "If the host matplotlib version differs, hashes are verified without regeneration."
        ),
    }


def main() -> int:
    ai = json.loads(DERIVED.read_text())

    claim_rows = build_claim_ledger(ai)
    with (HERE / "claim_ledger.jsonl").open("w") as f:
        for r in claim_rows:
            f.write(json.dumps(r) + "\n")

    art_rows = build_artifact_ledger()
    with (HERE / "artifact_ledger.jsonl").open("w") as f:
        for r in art_rows:
            f.write(json.dumps(r) + "\n")

    (HERE / "build_ledger.json").write_text(
        json.dumps(build_build_ledger(), indent=2) + "\n")

    print(f"claim_ledger.jsonl: {len(claim_rows)} claims")
    print(f"artifact_ledger.jsonl: {len(art_rows)} artifacts")
    print("build_ledger.json: written")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
