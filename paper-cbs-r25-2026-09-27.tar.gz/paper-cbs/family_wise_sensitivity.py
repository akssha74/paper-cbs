"""Post-hoc family-wise sensitivity for the ten pairwise Brier comparisons.

Reconstructs the frozen holdout predictions (digest-verified), reproduces the
frozen 95% paired sequence-cluster bootstrap intervals exactly as a gate, and
then applies paired Brier-loss tests with sequence-cluster-robust variance,
t(G-1) reference, Bonferroni simultaneous intervals, and Holm step-down. The
ordinary-bootstrap tail fractions are retained only as a descriptive legacy
sensitivity because the empirical bootstrap distribution is not a null
distribution. No model is refit, tuned, or recalibrated.

Output: frozen_inputs/family_wise_sensitivity.json
"""
from __future__ import annotations

import itertools
import json
import math
import os
import sys

import numpy as np
from scipy.stats import t as student_t

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "code"))

import asset_common as ac  # noqa: E402
import metrics  # noqa: E402

FAMILY_ALPHA = 0.05
FROZEN_PAIRWISE = os.path.join(os.path.dirname(HERE), "derived", "pairwise_ranking_stability.json")
OUT = os.path.join(HERE, "frozen_inputs", "family_wise_sensitivity.json")


def paired_replicates(y, pa, pb, groups, n_boot, seed):
    g = np.asarray(groups, dtype=object)
    uniq = np.array(sorted({v for v in g.tolist()}, key=lambda v: str(v)), dtype=object)
    idx_by_group = {u: np.where(g == u)[0] for u in uniq}
    rng = np.random.default_rng(seed)
    diffs = []
    for _ in range(n_boot):
        chosen = rng.integers(0, uniq.shape[0], size=uniq.shape[0])
        idx = np.concatenate([idx_by_group[uniq[c]] for c in chosen])
        va = metrics._metric_scalar("brier", y[idx], pa[idx])
        vb = metrics._metric_scalar("brier", y[idx], pb[idx])
        if va is None or vb is None or not (math.isfinite(va) and math.isfinite(vb)):
            continue
        diffs.append(va - vb)
    return np.sort(np.asarray(diffs, dtype=np.float64))


def cluster_robust_paired_brier(y, pa, pb, groups):
    """Large-G paired test with sequence-cluster-robust variance.

    The estimand is the event-weighted mean paired Brier-loss difference.
    Cluster influence totals account for arbitrary dependence within a sequence;
    the small-sample variance correction is G/(G-1), and inference uses t(G-1).
    """
    d = (np.asarray(y) - np.asarray(pa)) ** 2 - (np.asarray(y) - np.asarray(pb)) ** 2
    point = float(np.mean(d))
    g = np.asarray(groups, dtype=object)
    uniq = np.array(sorted({v for v in g.tolist()}, key=lambda v: str(v)), dtype=object)
    influence = np.asarray([np.sum(d[g == u] - point) for u in uniq], dtype=np.float64)
    n, n_clusters = d.size, uniq.size
    se = float(np.sqrt(n_clusters / (n_clusters - 1.0) * np.sum(influence ** 2)) / n)
    statistic = point / se
    p_two = float(2.0 * student_t.sf(abs(statistic), df=n_clusters - 1))
    return point, se, statistic, p_two, int(n_clusters - 1)


def main() -> None:
    recon = ac.reconstruct_frozen_predictions()
    ver = ac.verify_reconstruction(recon)
    if not ver["all_match"] or recon["predictions_digest"] != recon["recorded_predictions_digest"]:
        raise SystemExit("reconstruction verification failed; refusing to emit")

    y = np.asarray(recon["y_hold"], dtype=np.float64)
    groups = recon["groups"]
    preds = {b: np.asarray(v, dtype=np.float64) for b, v in recon["predictions"].items()}
    frozen = json.load(open(FROZEN_PAIRWISE))["pairwise_matrix"]

    pairs = list(itertools.combinations(sorted(preds), 2))
    m = len(pairs)
    rows = []
    for a, b in pairs:
        arr = paired_replicates(y, preds[a], preds[b], groups, ac.BOOTSTRAP_DRAWS, ac.BOOTSTRAP_SEED)
        lo95, hi95 = (float(np.quantile(arr, q, method="linear")) for q in (0.025, 0.975))
        ref = frozen[f"{a}_vs_{b}"]["ci"]
        if abs(ac._round12(lo95) - ref[0]) > 1e-12 or abs(ac._round12(hi95) - ref[1]) > 1e-12:
            raise SystemExit(f"95% interval for {a} vs {b} does not reproduce the frozen matrix")
        q = FAMILY_ALPHA / m / 2.0
        percentile_lob, percentile_hib = (
            float(np.quantile(arr, x, method="linear")) for x in (q, 1.0 - q)
        )
        n = arr.size
        tail_p = min(
            1.0,
            2.0
            * min(
                (np.sum(arr <= 0.0) + 1) / (n + 1),
                (np.sum(arr >= 0.0) + 1) / (n + 1),
            ),
        )
        point, se, statistic, p_two, df = cluster_robust_paired_brier(
            y, preds[a], preds[b], groups
        )
        critical = float(student_t.ppf(1.0 - FAMILY_ALPHA / (2.0 * m), df=df))
        lob, hib = point - critical * se, point + critical * se
        rows.append({
            "baseline_a": a, "baseline_b": b,
            "point_diff_a_minus_b": ac._round12(frozen[f"{a}_vs_{b}"]["point_diff_a_minus_b"]),
            "ci95_reproduced": [ac._round12(lo95), ac._round12(hi95)],
            "ci95_excludes_zero": bool(lo95 > 0 or hi95 < 0),
            "bonferroni_ci": [ac._round12(lob), ac._round12(hib)],
            "bonferroni_excludes_zero": bool(lob > 0 or hib < 0),
            "cluster_robust_se": ac._round12(se),
            "cluster_robust_t": ac._round12(statistic),
            "cluster_robust_df": df,
            "cluster_robust_p_two_sided": ac._round12(p_two),
            "bootstrap_tail_area_p_descriptive": ac._round12(tail_p),
            "bootstrap_percentile_bonferroni_ci_descriptive": [
                ac._round12(percentile_lob), ac._round12(percentile_hib)
            ],
            "n_valid": int(n),
        })

    order = sorted(range(m), key=lambda i: rows[i]["cluster_robust_p_two_sided"])
    stop = False
    for rank, i in enumerate(order):
        thresh = FAMILY_ALPHA / (m - rank)
        rows[i]["holm_threshold"] = ac._round12(thresh)
        if not stop and rows[i]["cluster_robust_p_two_sided"] <= thresh:
            rows[i]["holm_rejects_zero"] = True
        else:
            stop = True
            rows[i]["holm_rejects_zero"] = False

    out = {
        "record_type": "post_hoc_family_wise_sensitivity",
        "status": "post-hoc sensitivity; not pre-specified; no refit",
        "family": "ten pairwise holdout Brier differences over B0,B1,B2,B4,B5",
        "family_alpha": FAMILY_ALPHA,
        "inference": {
            "primary": "paired Brier-loss mean with sequence-cluster-robust variance, G/(G-1) correction, t(G-1), Holm step-down",
            "assumption": "independent sequences with arbitrary within-sequence dependence; large-G approximation",
            "n_clusters": len(set(groups)),
        },
        "bootstrap": {
            "kind": "paired_sequence_cluster_percentile_intervals_descriptive",
            "n_boot": ac.BOOTSTRAP_DRAWS,
            "seed": ac.BOOTSTRAP_SEED,
        },
        "gate": {"predictions_digest_match": True, "frozen_95_intervals_reproduced": True,
                 "n_verification_checks": ver["n_checks"]},
        "n_ci95_exclude_zero": sum(r["ci95_excludes_zero"] for r in rows),
        "n_bonferroni_exclude_zero": sum(r["bonferroni_excludes_zero"] for r in rows),
        "n_holm_reject": sum(r["holm_rejects_zero"] for r in rows),
        "pairs": rows,
    }
    with open(OUT, "w") as fh:
        json.dump(out, fh, indent=2, sort_keys=True)
        fh.write("\n")
    print(json.dumps({k: out[k] for k in ("n_ci95_exclude_zero", "n_bonferroni_exclude_zero", "n_holm_reject")}))
    for r in rows:
        print(r["baseline_a"][:2], r["baseline_b"][:2], r["point_diff_a_minus_b"], r["bonferroni_ci"],
              r["cluster_robust_p_two_sided"], r["holm_rejects_zero"])


if __name__ == "__main__":
    main()
