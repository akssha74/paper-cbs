#!/usr/bin/env python3
"""Check the pinned prospective DYFI inputs against the run's hash manifest before verification.

Run before frozen_inputs/prospective_dyfi_2025_verify.py; exits non-zero on any mismatch.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

FI = Path(__file__).resolve().parent / "frozen_inputs"
PINNED = {"results.json": "prospective_dyfi_2025.json",
          "raw_payload.geojson.gz": "prospective_dyfi_2025_raw_payload.geojson.gz",
          "holdout_rows.jsonl.gz": "prospective_dyfi_2025_holdout_rows.jsonl.gz",
          "run_prospective.py": "prospective_dyfi_2025_run.py",
          "analysis_plan.md": "prospective_dyfi_2025_analysis_plan.md",
          "frozen_design.json": "prospective_dyfi_2025_frozen_design.json"}


def main():
    manifest = json.loads((FI / "prospective_dyfi_2025_hash_manifest.json").read_text())
    bad = []
    for key, name in PINNED.items():
        got = hashlib.sha256((FI / name).read_bytes()).hexdigest()
        ok = got == manifest[key]
        bad += [] if ok else [name]
        print(f"{'OK ' if ok else 'BAD'} {name} {got[:12]}")
    if bad:
        sys.exit(f"hash mismatch: {bad}")
    print("prospective inputs match the run manifest")


if __name__ == "__main__":
    main()
