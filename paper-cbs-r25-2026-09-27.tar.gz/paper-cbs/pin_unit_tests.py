#!/usr/bin/env python3
"""Run the four contract unittest suites and pin the inventory, log and exit code."""
from __future__ import annotations

import hashlib
import json
import platform
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CODE = HERE.parents[1] / "code"
SUITES = ["test_benchmark_modules", "test_analytics_stack", "test_runner_report", "test_acquisition_reconstruction"]
OUT = HERE / "frozen_inputs" / "unit_tests"


def main():
    py = sys.argv[1] if len(sys.argv) > 1 else str(CODE / ".venv" / "bin" / "python")
    proc = subprocess.run([py, "-m", "unittest", "-v", *SUITES], cwd=CODE, capture_output=True, text=True)
    log = proc.stderr + proc.stdout
    tests = re.findall(r"^(test\S*) \((\S+)\)(?:\n.*?)? \.\.\. (ok|FAIL|ERROR|skipped.*)$", log, re.M)
    per_suite = {s: sum(1 for _, where, _ in tests if where.startswith(s + ".")) for s in SUITES}
    versions = subprocess.run([py, "-c", "import sys,numpy,scipy,sklearn,xgboost;print(sys.version.split()[0],"
                               "numpy.__version__,scipy.__version__,sklearn.__version__,xgboost.__version__)"],
                              capture_output=True, text=True).stdout.split()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "unittest_run.log").write_text(log)
    inv = {"command": f"python -m unittest -v {' '.join(SUITES)}", "cwd": "research/benchmark-resource/code",
           "exit_code": proc.returncode,
           "ran": int(re.search(r"Ran (\d+) tests", log).group(1)),
           "passed": sum(1 for t in tests if t[2] == "ok"), "per_suite": per_suite,
           "tests": [f"{where}.{name}" for name, where, _ in tests],
           "environment": dict(zip(["python", "numpy", "scipy", "scikit-learn", "xgboost"], versions),
                               platform=platform.platform()),
           "suite_sha256": {s: hashlib.sha256((CODE / f"{s}.py").read_bytes()).hexdigest() for s in SUITES},
           "log_sha256": hashlib.sha256(log.encode()).hexdigest()}
    (OUT / "unittest_inventory.json").write_text(json.dumps(inv, indent=2) + "\n")
    print(json.dumps({k: inv[k] for k in ("exit_code", "ran", "passed", "per_suite", "environment")}, indent=2))
    sys.exit(proc.returncode)


if __name__ == "__main__":
    main()
