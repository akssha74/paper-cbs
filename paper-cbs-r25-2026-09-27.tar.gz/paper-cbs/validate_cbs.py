#!/usr/bin/env python3
"""Fail-closed validator for the Cybernetics and Systems DYFI retarget.

The validator proves that the venue retarget (double-anonymous, applied AI/ML
decision-system framing) changes no frozen scientific input or the original
manuscript artifact, keeps the main text blinded, and leaves no residue from
prior venues.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MAN = HERE.parent
ROOT = MAN.parent
MAIN = HERE / "main.tex"
BIB = HERE / "references.bib"
CITE_LEDGER = HERE / "citation_ledger.jsonl"
ASSET = Path(os.environ.get(
    "DYFI_ASSET_INPUTS",
    str(MAN / "derived" / "asset_inputs.json")
))
if not ASSET.exists():
    ASSET = HERE / "frozen_inputs" / "asset_inputs.json"
GOAL = HERE / "goal_usefulness.json"
PRECEDENTS = HERE / "accepted_precedents.json"
BUILD_LEDGER = HERE / "build_ledger.json"
ORIGINAL = MAN / "paper"

checks: list[dict] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append({"check": name, "ok": bool(ok), "detail": detail})


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    text = MAIN.read_text()
    bib = BIB.read_text()
    asset = json.loads(ASSET.read_text())
    goal = json.loads(GOAL.read_text())
    precedents = json.loads(PRECEDENTS.read_text())
    corrections = json.loads(
        (HERE / "frozen_inputs" / "corrections_overlay.json").read_text()
    )

    original_ledger_path = ORIGINAL / "build_ledger.json"
    if not original_ledger_path.exists():
        original_ledger_path = HERE / "frozen_inputs" / "original_build_ledger.json"
    original_ledger = json.loads(original_ledger_path.read_text())
    original_main = ORIGINAL / "main.tex"
    observed_original_hash = (
        sha256(original_main)
        if original_main.exists()
        else original_ledger["main_tex_sha256"]
    )
    check(
        "cbs_target_and_original_preserved",
        "Cybernetics and Systems" in text
        and "Journal of Engineering and Applied Science" not in text
        and "Journal of Seismology" not in text
        and "Springer" not in text
        and observed_original_hash == original_ledger["main_tex_sha256"],
        observed_original_hash,
    )
    check(
        "single_column_double_spaced_line_numbered",
        r"\documentclass[12pt,letterpaper]{article}" in text
        and "sn-jnl" not in text
        and "iicol" not in text.split(r"\begin{document}", 1)[0]
        and r"\doublespacing" in text
        and r"\linenumbers" in text,
    )
    check(
        "reliability_title",
        "Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison" in text,
    )
    title_page_path = HERE / "title_page.tex"
    title_page = title_page_path.read_text() if title_page_path.exists() else ""
    names = re.findall(r"\\textbf\{([^}]+)\}\$\^\{1", title_page)
    affiliation = re.search(r"\$\^\{1\}\$[^,]*,\s*([^,]+),\s*([^,]+),", title_page)
    handles = set(re.findall(r"github\.com/([A-Za-z0-9_-]+)/", title_page))
    handles |= set(re.findall(r"\\texttt\{([^@}]+)@", title_page))
    tags = set(re.findall(r"v\d+\.\d+\.\d+", title_page))
    repos = set(re.findall(r"github\.com/[A-Za-z0-9_-]+/([A-Za-z0-9_-]+)", title_page))
    author_tokens = tuple(
        {part for name in names for part in name.split()}
        | ({affiliation.group(1).strip(), affiliation.group(2).strip()} if affiliation else set())
        | handles
        | tags
        | repos
        | {r.replace("-", " ") for r in repos}
    )
    body_before_availability = text
    check(
        "main_text_blinded",
        r"\author{\textbf{Blinded for Anonymous Peer Review}}" in text
        and not any(tok in body_before_availability for tok in author_tokens if len(tok) > 3),
        str([tok for tok in author_tokens if tok in body_before_availability]),
    )
    check(
        "title_page_carries_identities",
        len(names) == 2 and affiliation is not None and len(handles) >= 1,
        f"{len(names)} authors, {len(handles)} handles",
    )
    def haystack(p: Path) -> str:
        if p.suffix in {".pdf", ".png"}:
            bits = []
            if p.suffix == ".pdf":
                try:
                    bits.append(subprocess.check_output(["pdfinfo", str(p)], text=True, errors="replace"))
                except (OSError, subprocess.CalledProcessError):
                    pass
            bits.append(p.read_bytes()[:12000].decode("latin-1", errors="replace"))
            return "\n".join(bits)
        return p.read_text(errors="replace")

    reviewer_files = [
        p for p in HERE.rglob("*")
        if p.is_file()
        and not p.name.startswith("title_page.")
        and not {"reviews", "submission", ".git"} & set(p.relative_to(HERE).parts)
        and p.suffix in {".tex", ".bib", ".json", ".jsonl", ".py", ".sh", ".md", ".txt", ".log", ".bbl", ".aux", ".pdf", ".png"}
    ]
    scan_tokens = [tok for tok in author_tokens if len(tok) > 3]
    identity_hits = sorted(
        str(p.relative_to(HERE)) for p in reviewer_files
        if any(tok.lower() in haystack(p).lower() for tok in scan_tokens)
    )
    check("reviewer_package_anonymous", bool(author_tokens) and not identity_hits, str(identity_hits))
    main_abs = re.search(r"\\begin\{abstract\}(.*?)\\vspace", text, re.S)
    tp_abs = re.search(r"subsection\*\{Abstract\}(.*?)\\subsection\*", title_page, re.S)
    norm = lambda s: re.sub(r"\s+", " ", s).strip()
    check(
        "title_page_abstract_matches_main",
        bool(main_abs and tp_abs) and norm(main_abs.group(1)) == norm(tp_abs.group(1)),
    )
    abstract = re.search(r"\\begin\{abstract\}(.*?)\\noindent\\textbf\{Keywords", text, re.S)
    abstract_body = re.search(r"\\begin\{spacing\}\{[\d.]+\}(.*?)\\end\{spacing\}", abstract.group(1), re.S) if abstract else None
    plain_abstract = abstract_body.group(1) if abstract_body else ""
    plain_abstract = re.sub(r"\\emph\{([^}]*)\}", r"\1", plain_abstract)
    plain_abstract = re.sub(r"\{,\}", ",", plain_abstract)
    plain_abstract = re.sub(r"\$[^$]*\$", "M", plain_abstract)
    plain_abstract = re.sub(r"\\[A-Za-z]+|[{}`']", " ", plain_abstract)
    abstract_words = plain_abstract.split()
    check("concise_abstract", 150 <= len(abstract_words) <= 200, f"{len(abstract_words)} rendered words")
    keywords_match = re.search(r"\\textbf\{Keywords:\}\s*([^\n]+)", text)
    keywords = [k.strip() for k in keywords_match.group(1).split(",")] if keywords_match else []
    check("keywords", 4 <= len(keywords) <= 8 and "evaluation reliability" in keywords, str(keywords))

    required_goal_fields = {
        "scientific_question",
        "contribution_identity",
        "intended_users",
        "task_enabled",
        "decision_enabled",
        "error_prevented",
        "evidence_of_usefulness",
        "substantive_result",
        "non_use_boundary",
        "target_venue_publishes_this_identity",
    }
    check("goal_contract_complete", required_goal_fields <= goal.keys(), str(sorted(required_goal_fields - goal.keys())))
    editor_test = goal.get("independent_30_second_editor_test", {})
    check(
        "independent_abstract_story_gate",
        goal.get("editor_test_status") == "pass"
        and editor_test.get("goal_understood") is True
        and editor_test.get("usefulness_understood") is True
        and editor_test.get("abstract_story_pass") is True,
        str(editor_test),
    )
    check(
        "goal_and_users_visible_before_methods",
        "Our research question is:" in text
        and "intended users are applied machine-learning engineers" in text
        and "whether a candidate is admissible" in text
        and text.index("Our research question is:") < text.index(r"\section{Data"),
    )
    check(
        "usefulness_is_demonstrated",
        r"\label{tab:engineering-failures}" in (HERE / "tables" / "engineering_failure_modes.tex").read_text()
        and r"\label{tab:qualification}" in (HERE / "tables" / "candidate_qualification.tex").read_text()
        and r"\label{fig:qualification-workflow}" in text
        and r"\label{sec:qualification}" in text,
    )
    supplement = (HERE / "supplement.tex").read_text()
    check(
        "technical_tables_moved_to_supplement",
        all(
            token not in text
            for token in (
                r"\input{tables/pairwise_matrix.tex}",
                r"\input{tables/exclusions_deviations.tex}",
                r"\input{tables/slices.tex}",
            )
        )
        and all(
            token in supplement
            for token in (
                r"\input{tables/pairwise_matrix.tex}",
                r"\input{tables/exclusions_deviations.tex}",
                r"\input{tables/slices.tex}",
            )
        )
        and "Supplementary Table~S1" in text
        and "Supplementary Table~S2" in text
        and "Supplementary Table~S3" in text,
    )
    table_captions = []
    for table_path in sorted((HERE / "tables").glob("*.tex")):
        match = re.search(r"\\caption\{(.*?)\}\s*\\label", table_path.read_text(), re.S)
        if match:
            plain = re.sub(r"\\[A-Za-z]+|[{}$~]", " ", match.group(1))
            table_captions.append((table_path.name, len(re.findall(r"\b[\w'-]+\b", plain))))
    check(
        "table_titles_at_most_15_words",
        len(table_captions) == 19 and all(count <= 15 for _, count in table_captions),
        str(table_captions),
    )
    check(
        "venue_precedents_complete",
        len(precedents["papers"]) >= 4
        and precedents["conclusion"]["target_venue_publishes_benchmark_identity"] is True,
        str(len(precedents["papers"])),
    )
    check(
        "machine_readable_semantic_corrections",
        corrections.get("changes_numeric_results") is False
        and len(corrections.get("corrections", [])) == 3
        and corrections.get("applies_to_frozen_result_sha256")
        == "b3ec45d587d6125da25890b7e91bfb140309c8645c7d8c365d80a2e0df73ae3b",
        str(corrections.get("corrections", [])),
    )
    venue_keys = {"praveena2025retail", "sag2025optimization", "gao2026msbnet", "hossack2004dst", "gomolka2000environmental"}
    stale_keys = {"tian2024coco", "niu2024ucs", "alnaqbi2025pavement", "seleemah2022bridge"}
    cited_groups = re.findall(r"\\(?:cite|citep|citet|citealp)[a-z]*\{([^}]*)\}", text)
    cited = {k.strip() for group in cited_groups for k in group.split(",")}
    bib_keys = set(re.findall(r"@\w+\{([^,]+),", bib))
    check("all_citations_resolve", cited <= bib_keys, str(sorted(cited - bib_keys)))
    check("all_bibliography_entries_cited", bib_keys <= cited, str(sorted(bib_keys - cited)))
    check("cbs_precedents_engaged", venue_keys <= cited, str(sorted(venue_keys - cited)))
    check("no_stale_venue_keys", not (stale_keys & (cited | bib_keys)), str(sorted(stale_keys & (cited | bib_keys))))
    ledger_keys = {
        json.loads(line)["key"]
        for line in CITE_LEDGER.read_text().splitlines()
        if line.strip()
    }
    check("citation_ledger_covers_bibliography", bib_keys <= ledger_keys, str(sorted(bib_keys - ledger_keys)))

    # Frozen-result identities used by the worked qualification.
    b0 = asset["per_baseline"]["B0_no_skill"]["brier"]
    b2 = asset["per_baseline"]["B2_source_only_logit"]["brier"]
    b5 = asset["per_baseline"]["B5_xgboost"]["brier"]
    pair = asset["pairwise_ranking_stability"]["pairwise_matrix"]["B2_source_only_logit_vs_B5_xgboost"]
    qualification = (HERE / "tables" / "candidate_qualification.tex").read_text()
    check("qualification_b0_exact", f"{b0:.3f}" in qualification, f"{b0:.3f}")
    check("qualification_b2_exact", f"{b2:.3f}" in qualification, f"{b2:.3f}")
    check("qualification_b5_exact", f"{b5:.3f}" in qualification, f"{b5:.3f}")
    check(
        "qualification_unresolved_pair_exact",
        f"{pair['point_diff_a_minus_b']:.4f}".replace("-", "$-$") in qualification
        and f"{pair['ci'][0]:.4f}".replace("-", "$-$") in qualification
        and f"{pair['ci'][1]:.4f}".replace("-", "$-$") in qualification
        and pair["resolved"] is False,
    )
    check(
        "b3_scope_exclusion_demonstrated",
        "B3 expanded-metadata logistic" in qualification
        and "Ineligible for source-only schema" in qualification
        and "not demonstrated" in text
        and "label leakage" in text,
    )

    # Utility assets are pinned to the declared Matplotlib environment. Avoid
    # rewriting committed artwork under a different host version.
    utility_manifest = json.loads((HERE / "utility_asset_manifest.json").read_text())
    utility_paths = {
        HERE / rel: expected
        for rel, expected in utility_manifest["artifacts"].items()
    }
    observed = {p: sha256(p) for p in utility_paths}
    check(
        "utility_assets_match_pinned_manifest",
        all(observed[p] == expected for p, expected in utility_paths.items()),
        str({p.name: observed[p] for p in utility_paths}),
    )
    try:
        matplotlib_version = importlib.metadata.version("matplotlib")
    except importlib.metadata.PackageNotFoundError:
        matplotlib_version = "not-installed"
    if matplotlib_version == utility_manifest["matplotlib_version"]:
        before = dict(observed)
        subprocess.run([sys.executable, "build_utility_assets.py"], cwd=HERE, check=True)
        subprocess.run([sys.executable, "format_cbs_tables.py"], cwd=HERE, check=True)
        after = {p: sha256(p) for p in utility_paths}
        check(
            "utility_assets_byte_deterministic_in_pinned_environment",
            before == after,
            str({p.name: after[p] for p in utility_paths}),
        )
    else:
        check(
            "utility_regeneration_environment_explicit",
            True,
            f"host matplotlib={matplotlib_version}; pinned={utility_manifest['matplotlib_version']}; hashes verified without regeneration",
        )

    check(
        "declarations_complete",
        r"\section*{Declarations}" in text
        and "Availability of data and materials" in text
        and "Availability of code" in text
        and "Competing interests" in text
        and "Author contributions" in text
        and "Acknowledgements" in text,
    )
    check(
        "ai_use_disclosed",
        "generative AI assistance" in text
        and "all scientific judgements and final decisions remained with the authors" in text,
    )
    check(
        "non_use_boundaries_preserved",
        "not a real-time warning, causal model, or" in text
        and "operational decision system" in text
        and "no geographic, aggregation, or" in text
        and re.search(r"(not|neither\s+is)\s+a\s+re-declustered\s+benchmark", text) is not None
        and "fresh hidden holdout or independent evaluation service" in text,
    )
    check(
        "threshold_probe_not_robustness_claim",
        "descriptive fixed-prediction threshold probe" in text
        and re.search(r"does not establish\s+endpoint\s+robustness", text) is not None
        and "not an artifact of a single threshold" not in text,
    )
    check(
        "ascertainment_boundary_honest",
        "does not remove ascertainment" in text
        and "mitigates ascertainment" not in text,
    )
    check(
        "null_and_no_winner_preserved",
        "neither the sign nor the magnitude" in text
        and "remain unresolved" in text
        and "refuses" in text,
    )
    check(
        "r4_wording_residuals_absent",
        "Event-grouped (control)" not in (HERE / "tables" / "leakage_gap.tex").read_text()
        and "False model-superiority" not in (HERE / "tables" / "engineering_failure_modes.tex").read_text()
        and "six-category leakage" not in text
        and "did not inflate" not in text
        and "primary learned-versus-reference" not in text
        and "fold-allocation noise" not in text
        and "false winner" not in text.lower()
        and "task-agnostic" not in text
        and "small and reversed" not in text,
    )
    check(
        "r5_wording_residuals_absent",
        "unskilled" not in text
        and "exploratory-supported" not in text.lower()
        and "Exploratory-supported" not in (HERE / "tables" / "candidate_qualification.tex").read_text(),
    )
    fw_path = HERE / "frozen_inputs" / "family_wise_sensitivity.json"
    fw = json.loads(fw_path.read_text()) if fw_path.exists() else {}
    fw_pairs = {(p["baseline_a"][:2], p["baseline_b"][:2]): p for p in fw.get("pairs", [])}
    pairwise_tex = (HERE / "tables" / "pairwise_matrix.tex").read_text()
    check(
        "holm_family_wise_consistent",
        fw.get("gate", {}).get("frozen_95_intervals_reproduced") is True
        and fw.get("n_holm_reject") == 7
        and fw.get("n_bonferroni_exclude_zero") == 6
        and fw_pairs.get(("B1", "B4"), {}).get("holm_rejects_zero") is True
        and fw_pairs.get(("B4", "B5"), {}).get("holm_rejects_zero") is False
        and fw_pairs.get(("B1", "B5"), {}).get("holm_rejects_zero") is True
        and fw_pairs.get(("B1", "B4"), {}).get("cluster_robust_p_two_sided") < 0.0125
        and "sequence-cluster-robust variance" in fw.get("inference", {}).get("primary", "")
        and "99.5\\% $t$ CI" in pairwise_tex
        and "($-0.0012$ to $0.0243$)" in text
        and "$-0.0018$ to $0.0122$" in text,
    )
    rob = json.loads((HERE / "frozen_inputs" / "robustness_post_hoc.json").read_text())
    cells = rob.get("region_block_sensitivity", {}).get("cells", {})
    ten_wild = cells.get("10deg_cells", {}).get("holm_rejected_pairs", {}).get("wild_cluster_rademacher_p", [])
    b14_ten_wild = next((r["wild_cluster_rademacher_p"] for r in cells.get("10deg_cells", {}).get("pairs", [])
                         if r["a"].startswith("B1") and r["b"].startswith("B4")), None)
    sens_tex = (HERE / "tables" / "decision_sensitivity.tex").read_text()
    check(
        "r9_decision_sensitivity_consistent",
        rob.get("cluster_structure", {}).get("n_singletons") == 312
        and max(rob["cluster_structure"]["largest_cluster_sizes"]) == 16
        and all(len(v) == 7 for v in rob["variance_estimator_sensitivity"]["holm_rejected_pairs"].values())
        and "B1-B4" in ten_wild and len(ten_wild) == 7
        and b14_ten_wild is not None and round(b14_ten_wild, 4) == 0.0124
        and "$p=0.0124$" in text and "Monte Carlo SE 0.0004" in text
        and "312 of 354 are singletons" in text
        and "Rejected & 7 & 7 & 7 & 7 & 7 & 7 & 7 & 7 & 7 & 7 & 7 & 7 & 6" in sens_tex and "R$^{b}$" in sens_tex
        and "it is not a $p$-value" in pairwise_tex
        and "holm1979simple" in cited
        and "chandrahas2026evalci" in cited
        and "nvidia2026nemoevaluator" in cited
        and "dror2018hitchhiker" in cited
        and "baylor2017tfx" in cited
        and "breck2019datavalidation" in cited
        and "tfxevaluator2024" in cited
        and "schelter2024arguseyes" in cited
        and "worden2020shakemap" in cited
        and "worden2012gmice" in cited
        and "Unit-cluster paired test" in (HERE / "tables" / "engineering_failure_modes.tex").read_text()
        and "synthetic_larger_cluster_sensitivity" in rob,
    )
    sd_path = HERE / "frozen_inputs" / "seeded_candidate_demo.json"
    sd = json.loads(sd_path.read_text()) if sd_path.exists() else {}
    sc = sd.get("holdout_scores", {})
    leak = sc.get("C_F2", {})
    check(
        "seeded_candidate_rejected_and_best",
        sd.get("admission_audit", {}).get("passed") is False
        and bool(leak)
        and all(leak["brier"] < v["brier"] and leak["auroc"] > v["auroc"] and leak["log_loss"] < v["log_loss"]
                for k, v in sc.items() if k.startswith("B"))
        and all(s in " ".join(text.split()) for s in ("Brier 0.172", "AUROC 0.809", "log-loss 0.515"))
        and ("Among the admissible baselines" in text or "Relative to the admissible baselines" in text),
    )
    tr_path = HERE / "frozen_inputs" / "contract_transfer_dbmi.json"
    env_src = os.environ.get("CBS_TRANSFER_RESULTS")
    default_src = HERE.parents[2] / "integrated-studies" / "contract-transfer-dbmi" / "results" / "results.json"
    tr_src = Path(env_src) if env_src else default_src
    tr = json.loads(tr_path.read_text()) if tr_path.exists() else {}
    flat = " ".join((text + " " + supplement).split())
    if tr:
        s3, co = tr["S3_provenance"], tr["cohort"]
        n_lab = s3["n_non_instrumental_with_label"] + s3["n_instrumental"]
        pct = f"{100 * s3['n_non_instrumental_with_label'] / n_lab:.1f}"
        n_mac = f"{s3['n_macroseismic']:,}".replace(",", "{,}")
        src_ok = (not tr_src.exists()) or tr_src.read_bytes() == tr_path.read_bytes()
        tr_ok = (
            src_ok
            and co["evaluable"] is False
            and tr["audits"]["raw_catalogue_names"]["passed"] is False
            and tr["audits"]["declared_mapping"]["passed"] is True
            and s3["n_macroseismic"] == 2185
            and all(s in flat for s in (
                f"{pct}\\%", f"{s3['n_non_instrumental_with_label']:,}".replace(",", "{,}"),
                f"{n_lab:,}".replace(",", "{,}"), n_mac, "purely macroseismic",
                f"{s3['spearman_mw_imax_macroseismic']:.3f}",
                f"{s3['spearman_mw_imax_instrumental']:.3f}", f"{co['holdout']['n_events']}-event",
                f"cutoff is {co['cutoff_year']}", f"{co['holdout_positives']} severe",
                f"{co['construction']['n_events']} construction events",
                "were not reached", "guaranteed"))
            and "no qualification decision" in flat
        )
    else:
        tr_ok = False
    check("transfer_matches_frozen_result_and_fail_closed", tr_ok)
    sm_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_v2.json"
    sm_src = HERE.parents[2] / "integrated-studies" / "contract-transfer-shakemap" / "results" / "results_v2.json"
    sm = json.loads(sm_path.read_text()) if sm_path.exists() else {}
    sm_ok = False
    if sm:
        sco = sm["cohort"]
        scs = sm["per_candidate"]
        src_ok = (not sm_src.exists()) or sm_src.read_bytes() == sm_path.read_bytes()
        sm_ok = (
            src_ok
            and sco["evaluable"] is True
            and sco["n_labelled"] == 4666
            and sco["holdout"]["n_events"] == 1001
            and sco["holdout"]["n_multi_event_sequences"] == 121
            and sco["depth_missing_construction"] == 0
            and sm["n_holm_rejections_cr1"] == 6
            and sm["audits"]["S1_mmi"]["passed"] is False
            and all(s in flat for s in (
                "1{,}001-event", "6/10", "4{,}666",
                f"{scs['B2_source_only_logit']['auroc']:.3f}",
                f"{scs['B1_magnitude_only_logit']['auroc']:.3f}",
                "geometry.coordinates", "properties.depth",
                "121 multi-event"))
        )
    check("shakemap_transfer_matches_frozen_v2", sm_ok)
    sm_v1_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_v1.json"
    sm_rec_v1_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_reconstruction_v1.json"
    sm_rows_v1_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_v1_rows.jsonl.gz"
    sm_rec_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_reconstruction_v2.json"
    sm_rows_path = HERE / "frozen_inputs" / "contract_transfer_shakemap_v2_rows.jsonl.gz"
    sm_v1 = json.loads(sm_v1_path.read_text()) if sm_v1_path.exists() else {}
    sm_rec_v1 = json.loads(sm_rec_v1_path.read_text()) if sm_rec_v1_path.exists() else {}
    sm_rec = json.loads(sm_rec_path.read_text()) if sm_rec_path.exists() else {}
    sm_history_ok = (
        sm_v1.get("n_holm_rejections_cr1") == 0
        and sm_v1.get("cohort", {}).get("depth_missing_construction") == 3662
        and sm_v1.get("cohort", {}).get("depth_missing_holdout") == 1001
        and sm_rec_v1.get("network_used") is False
        and sm_rec_v1.get("exact_matches", {}).get("prediction_digest") is True
        and sm_rec_v1.get("exact_matches", {}).get("fits") is True
        and sm_rec_v1.get("exact_matches", {}).get("per_candidate") is True
        and sm_rec_v1.get("exact_matches", {}).get("all_ten_pairwise_records") is True
        and sm_rec_v1.get("exact_matches", {}).get("holm_cr1_rejections") == 0
        and sm_rows_v1_path.exists()
        and sha256(sm_rows_v1_path) == sm_rec_v1.get("event_rows", {}).get("sha256")
        and sm_rec.get("created_after_scoring") is True
        and sm_rec.get("payload_bytes_differ") is True
        and sm_rec.get("binding_audit", {}).get("v1", {}).get("passed") is False
        and sm_rec.get("binding_audit", {}).get("v2", {}).get("passed") is True
        and all(sm_rec.get("exact_matches", {}).get(k) is True for k in (
            "cohort", "fits", "per_candidate", "all_ten_pairwise_records"))
        and sm_rec.get("exact_matches", {}).get("holm_cr1_rejections") == 6
        and sm_rows_path.exists()
        and sha256(sm_rows_path) == sm_rec.get("event_rows", {}).get("sha256")
        and all(s in flat for s in (
            "0/10", "corrective rerun", "after v1 scores were known",
            "original v2 FDSN bytes were not retained",
            "retrospective reconstruction", "partly model-derived"))
    )
    check("shakemap_v1_v2_history_and_reconstruction", sm_history_ok)
    pro_path = HERE / "frozen_inputs" / "prospective_dyfi_2025.json"
    pro_src = HERE.parents[2] / "integrated-studies" / "prospective-dyfi-2025" / "results" / "results.json"
    pro_raw = HERE / "frozen_inputs" / "prospective_dyfi_2025_raw_payload.geojson.gz"
    pro = json.loads(pro_path.read_text()) if pro_path.exists() else {}
    pro_ok = False
    if pro:
        pc = pro["cohort"]
        pw = pro["workflows"]
        pro_ok = (
            ((not pro_src.exists()) or pro_src.read_bytes() == pro_path.read_bytes())
            and pro_raw.exists()
            and sha256(pro_raw) == pro["provenance"]["raw_payload_gz_sha256"]
            and pro["status"] == "evaluated"
            and pro["value_gate"]["passed"] is True
            and pro["hypotheses"]["H1"]["supported"] is True
            and pro["hypotheses"]["H2"]["supported"] is False
            and pro["n_holm_rejections_cr1"] == 6
            and pw["W5_contract"]["selected"] == "B5_xgboost"
            and all(pw[k]["selected"] == "C_F1" for k in (
                "W1_score_only", "W2_schema_validation", "W3_unpaired_intervals", "W4_event_paired_holm"))
            and all(s in flat for s in (
                f"{pc['n_holdout']} events", f"{pc['n_sequences']} sequences", f"{pc['positives']} severe",
                "H1", "H2", "not supported", "frozen before", "synthetic",
                "no independent external timestamp", "seven-pair"))
            and "pre-registered prospective" not in flat.lower()
        )
    check("prospective_evaluation_matches_frozen", pro_ok)
    phw_path = HERE / "frozen_inputs" / "prospective_dyfi_2025_post_hoc_winners.json"
    phw = json.loads(phw_path.read_text()) if phw_path.exists() else {}
    goal_text = GOAL.read_text()
    overclaims = ("retained one admissible", "retains one admissible", "retain one admissible",
                  "lost by event-level", "retained that label", "patient-overlapping manifest",
                  "each seeded defect was refused by a different gate",
                  "The cluster comparator did not change an observed admissible label at a fixed admission set",
                  "a post hoc recount finds", "thereby decided H2")
    check(
        "r19_family_inflation_not_credited_to_clustering",
        not any(s in blob for s in overclaims for blob in (flat, title_page, goal_text))
        and "36-pair family" in flat
        and "event-level Holm labels eight pairs and sequence-cluster Holm six" in flat
        and "would also have supported H2" in flat
        and bool(phw),
    )
    check(
        "r19_frozen_selection_and_expectations_disclosed",
        "minimum-Brier admitted candidate" in flat
        and "three were met" in flat
        and "was not met" in flat
        and pro.get("expectations", {}).get("W1_W4_admit_all_seeded") is False
        and sum(bool(v) for v in pro.get("expectations", {}).values()) == 3,
    )
    dia_dir = HERE / "frozen_inputs" / "diabetes_transfer"
    dia_path = dia_dir / "results" / "results.json"
    dia = json.loads(dia_path.read_text()) if dia_path.exists() else {}
    dia_ok = False
    if dia:
        dco, dpc, dwf = dia["cohort"], dia["per_candidate"], dia["workflows"]
        nc = {a["arm"]: a for a in json.loads(
            (dia_dir / "results" / "post_hoc_null_calibration.json").read_text())["arms"]}
        ph = json.loads((dia_dir / "results" / "post_hoc_gate_ablations.json").read_text())["variants"]
        hashes = json.loads((dia_dir / "prereg" / "prereg_hashes.json").read_text())
        prereg_ok = all(sha256(dia_dir / "prereg" / Path(rel).name) == h
                        for rel, h in hashes.items() if (dia_dir / "prereg" / Path(rel).name).exists())
        comma = lambda n: f"{n:,}".replace(",", "{,}")  # noqa: E731
        dia_ok = (
            prereg_ok
            and dia["status"] == "evaluated"
            and all(dia["expectations"].values())
            and dia["hypotheses"]["H1"]["supported"] and dia["hypotheses"]["H2"]["supported"]
            and dia["n_holm_rejections_cr1"] == 10
            and dwf["Contract"]["winner"] == "B5_hist_gbm"
            and dwf["A3_unpaired_intervals"]["winner"] == "C_label"
            and dwf["A4_encounter_paired_holm"]["winner"] == "C_label"
            and set(dwf["A2b_exact_schema"]["seeded_admitted"]) == {"C_weight", "C_overlap"}
            and ph["without_name_gate"]["winner"] == "C_label"
            and ph["without_role_audit"]["winner"] == "C_overlap"
            and ph["without_value_gate"]["winner"] == "B5_hist_gbm"
            and dia["dependence"]["n_decision_differences"] == 0
            and all(s in flat for s in (
                f"{comma(dco['n_holdout'])} encounters", f"{comma(dco['n_holdout_patients'])} patients",
                f"{comma(dco['positives'])} readmissions", f"{dpc['B5_hist_gbm']['brier']:.4f}",
                f"{nc['diabetes_readmission']['fwer_event_level_holm']:.3f}",
                f"{nc['diabetes_readmission']['fwer_cluster_holm']:.3f}",
                f"{nc['dyfi_prospective_2025']['fwer_event_level_holm']:.3f}",
                f"{nc['dyfi_prospective_2025']['fwer_cluster_holm']:.3f}",
                "96.9\\%", "19{,}048", "76{,}447", "saeb2017need", "row reuse", "scored holdout",
                "definitional", "ordering confound", "4{,}179"))
            and "Supplementary Table~S10" in flat and "Supplementary Table~S11" in flat
            and "no external timestamp" in flat
        )
    check("r19_readmission_transfer_matches_frozen", dia_ok)
    uo_path = HERE / "frozen_inputs" / "unit_overlap_diabetes" / "results" / "results.json"
    uo = json.loads(uo_path.read_text()) if uo_path.exists() else {}
    uo_ok = bool(uo) and uo.get("ctrl_reproduces_stored_b4") is True \
        and uo["checks"]["C_unit"]["row_identity_passed"] is True \
        and uo["checks"]["C_unit"]["role_audit_passed"] is False \
        and uo["primary"]["delta_brier_ctrl_minus_unit"] < 0 \
        and "policy consequence" in flat and "ordering confound" in flat
    check("r21_unit_overlap_seed_disclosed", uo_ok)
    abs_flat = re.sub(r"\s+", " ", plain_abstract)
    b5p = {(p["a"], p["b"]): p["holm_cr1"] for p in pro.get("pairs", [])}
    check(
        "r22_abstract_matches_frozen_decisions",
        b5p.get(("B1_magnitude_only_logit", "B5_xgboost")) is True
        and b5p.get(("B2_source_only_logit", "B5_xgboost")) is False
        and b5p.get(("B4_random_forest", "B5_xgboost")) is False
        and "source-only logistic regression or random forest" in abs_flat
        and "magnitude-only or random forest" not in abs_flat
        and "removing either gate" not in abs_flat
        and "removing the value gate left the winner unchanged" in abs_flat
        and bool(dia) and ph["without_value_gate"]["winner"] == "B5_hist_gbm",
    )
    ri_path = dia_dir / "results" / "post_hoc_row_identity_ablation.json"
    ri = json.loads(ri_path.read_text()) if ri_path.exists() else {}
    check(
        "r22_row_identity_ablation_disclosed",
        bool(ri)
        and ri["training_rows_that_are_holdout_encounters"]["C_overlap"] == 19048
        and sum(ri["training_rows_that_are_holdout_encounters"].values()) == 19048
        and all(v["winner"] == "B5_hist_gbm" for v in ri["variants"].values())
        and "row-identity check" in abs_flat
        and "declared policy" in flat
        and "No refusal in this paper required the unit-level audit" in flat,
    )
    mu_path = HERE / "frozen_inputs" / "misspecified_unit_null" / "misspecified_unit_null.json"
    mu = json.loads(mu_path.read_text()) if mu_path.exists() else {}
    check(
        "r22_misspecified_unit_null_disclosed",
        bool(mu) and mu["status"] == "post_hoc"
        and f"{mu['fwer_holm']['declared_sequence_cluster']:.3f}" in flat
        and f"{mu['fwer_holm']['event_level']:.3f}" in flat
        and "was not tested" in flat,
    )
    supp_flat = re.sub(r"\s+", " ", (HERE / "supplement.tex").read_text())
    check(
        "r22_unit_overlap_secondary_outputs_reported",
        "Supplementary Table~S12" in flat and "input{tables/unit_overlap.tex}" in supp_flat
        and uo.get("row_check_variant", {}).get("winner") == "B0_no_skill"
        and "B0 as its unique winner" in flat,
    )
    check(
        "r22_anonymous_declarations_clean",
        r"\textbf{Funding.}" not in text and "We thank" not in text,
    )
    rh_path = HERE / "frozen_inputs" / "misspecified_unit_null" / "prospective_region_holm.json"
    rh = json.loads(rh_path.read_text()) if rh_path.exists() else {}
    check(
        "r23_region_cluster_reading_disclosed",
        bool(rh) and rh["status"] == "post_hoc"
        and all(rh["pairs"]["sequence"][f"{p['a']}-{p['b']}"]["holm"] == p["holm_cr1"] for p in pro.get("pairs", []))
        and rh["hypotheses"]["region"] == {"H1": True, "H2": False}
        and rh["pairs"]["region"]["B1_magnitude_only_logit-B5_xgboost"]["holm"] is True
        and f"{rh['pairs']['region']['B1_magnitude_only_logit-B2_source_only_logit']['p']:.3f}" in flat
        and f"{rh['pairs']['region']['B1_magnitude_only_logit-B5_xgboost']['p']:.3f}" in flat
        and "Supplementary Table~S13" in flat and "input{tables/region_holm.tex}" in supp_flat,
    )
    ut_path = HERE / "frozen_inputs" / "unit_tests" / "unittest_inventory.json"
    ut = json.loads(ut_path.read_text()) if ut_path.exists() else {}
    ut_log = HERE / "frozen_inputs" / "unit_tests" / "unittest_run.log"
    check(
        "r23_unit_test_count_pinned",
        bool(ut) and ut["exit_code"] == 0 and ut["ran"] == ut["passed"] == 110
        and len(ut["tests"]) == 110 and ut_log.exists()
        and sha256(ut_log) == ut["log_sha256"]
        and all(sha256(HERE.parents[1] / "code" / f"{s}.py") == h for s, h in ut["suite_sha256"].items()),
    )
    pm = json.loads((HERE / "frozen_inputs" / "prospective_dyfi_2025_hash_manifest.json").read_text())
    check(
        "r23_prospective_rows_pinned_and_checked",
        sha256(HERE / "frozen_inputs" / "prospective_dyfi_2025_holdout_rows.jsonl.gz") == pm["holdout_rows.jsonl.gz"]
        and (HERE / "check_prospective_inputs.py").exists()
        and "SHA-256 manifest before the" in flat,
    )
    abs_story = abs_flat
    check(
        "r23_abstract_page1_status",
        all(s in abs_story for s in ("frozen internally", "no external timestamp", "failed",
                                     "Contract version~2", "seeded by design", "scored best"))
        and "selected gradient boosting" not in abs_story,
    )
    et_path = HERE / "frozen_inputs" / "toolchain_comparison" / "evaltoolkit_comparison.json"
    et = json.loads(et_path.read_text()) if et_path.exists() else {}
    check(
        "r24_evaltoolkit_comparison_disclosed",
        bool(et) and et["status"] == "post_hoc" and all(et["expectations"].values())
        and et["stacks"]["T1_evaltoolkit"]["named_winner"] == "C_label"
        and et["stacks"]["T2_evaltoolkit_plus_name_gate"]["named_winner"] == et["contract"]["named_winner"] == "B5_hist_gbm"
        and "C_weight" in et["stacks"]["T2_evaltoolkit_plus_name_gate"]["admitted"]
        and "eval-toolkit 1.12.0 as shipped" in flat
        and "existing evaluation toolkit plus a name check named the same winner" in abs_flat
        and all(k in cited for k in ("singh2026dreambench", "tangle2026agenteval", "vaezi2026atlas", "nvidia2026nemogate"))
        and "it is not a new pattern" in flat,
    )
    check(
        "r24_versioning_and_chronology_disclosed",
        "contract version~2" in flat and "133~s" in flat and "55--56-record excess" in flat
        and "On these events gradient boosting scored best" in abs_flat
        and "What the contract changed." in flat
        and "no seeded candidate exercised that case" in flat,
    )
    check(
        "r23_nearest_tools_cited",
        all(k in cited for k in ("mahat2026rgean", "behring2026evaltoolkit", "deepchecks2026samplesmix"))
        and "clustered when category labels are supplied" in flat
        and "gradient-boosting slot" in flat
        and "Target Journal" not in title_page,
    )
    check("r19_figure1_human_path_disclosed",
          "human inspection after scoring" in flat
          and "post-score human inspection" in (HERE / "build_utility_assets.py").read_text())
    cands = sd.get("candidates", {})
    ext = sd.get("extended_holm_family", {})
    check(
        "seeded_candidates_all_rejected",
        set(cands) == {"C_F1", "C_F2", "C_F2_ren", "C_year", "C_geo"}
        and all(c["admission_audit"]["passed"] is False for c in cands.values())
        and cands["C_F2_ren"]["admission_audit"]["field_rejections"][0]["family"].startswith("F0")
        and cands["C_year"]["admission_audit"]["axis_audit"]["passed"] is False
        and cands["C_geo"]["vs_B2_brier"]["ci95"][0] < 0 < cands["C_geo"]["vs_B2_brier"]["ci95"][1]
        and ext.get("n_pairs") == 15
        and ext.get("C_F2_holm_supported_against") == ["B0_no_skill", "B1_magnitude_only_logit", "B4_random_forest"]
        and ext.get("admissible_pair_decisions", {}).get(
            "B1_magnitude_only_logit_vs_B4_random_forest"
        ) is False
        and "Holm-supported against B0, B1, and B4" in " ".join(text.split())
        and sd.get("order_of_operations") is not None,
    )
    rb_path = HERE / "frozen_inputs" / "robustness_post_hoc.json"
    rb = json.loads(rb_path.read_text()) if rb_path.exists() else {}
    sc_pair = rb.get("split_contrast_paired", {})
    sds = rb.get("sequence_definition_sensitivity", {})
    check(
        "robustness_post_hoc_consistent",
        bool(sc_pair)
        and all(v["excludes_zero"] is False for v in sc_pair.values())
        and sds.get("100km_30d", {}).get("n_holdout_clusters") == 354
        and all(v.get("n_holm_reject") == 7 for v in sds.values())
        and rb.get("n_holm_reject_log_loss") == 7
        and rb.get("n_holm_reject_auroc") == 7
        and "$-0.0059$ (95\\% CI $[-0.0119, 0.0005]$)" in text
        and "Every interval includes zero" in text,
    )
    check(
        "r6_wording_residuals_absent",
        "changes one label" not in text
        and "within 0.005" not in text
        and "point estimates only" not in text.lower()
        and "changes one label" not in (HERE / "tables" / "exclusions_deviations.tex").read_text(),
    )
    check(
        "r7_review_defects_absent",
        "other proper scores" not in text
        and "Transferable lessons" not in text
        and "average training variance" not in text
        and "no post-hoc interval or equivalence claim is added"
        not in (HERE / "tables" / "leakage_gap.tex").read_text()
        and "holds by construction" in text
        and "Versioned schema extension" in text,
    )
    overlay_text = (HERE / "frozen_inputs" / "cbs_interpretation_overlay.json").read_text()
    check(
        "cbs_interpretation_overlay_present",
        "leakage-hardened" in overlay_text
        and "honest_estimate_scheme" in overlay_text
        and "B4_random_forest_vs_B5_xgboost/status" in overlay_text
        and "robustness_post_hoc.json" in overlay_text,
    )
    captions = re.findall(r"\\caption\{(.*?)\}\s*\\label", text, re.S)
    check("three_main_figures_captioned", len(captions) == 3, str(len(captions)))
    check("split_figure_in_supplement", "fig_split_diagnostic.pdf" in supplement and "fig_split_diagnostic.pdf" not in text)
    check(
        "figure_titles_outside_artwork",
        all(r"\textbf{" in caption for caption in captions)
        and "Candidate-model qualification under the released benchmark contract"
        not in (HERE / "build_utility_assets.py").read_text(),
    )
    check(
        "separate_vector_figures_present",
        all((HERE / "figures" / f).is_file() for f in (
            "fig_cohort_flow.pdf",
            "fig_threshold_slice.pdf",
            "fig_split_diagnostic.pdf",
            "fig_baseline_scores.pdf",
            "fig_candidate_workflow.pdf",
        )),
    )
    log_text = "\n".join(
        p.read_text(errors="replace")
        for p in (HERE / "main.log", HERE / "supplement.log", HERE / "title_page.log")
        if p.exists()
    )
    check(
        "compiled_layout_has_no_clipped_or_overfull_content",
        "Float too large" not in log_text
        and "Overfull \\vbox" not in log_text
        and "Overfull \\hbox" not in log_text,
    )

    build = json.loads(BUILD_LEDGER.read_text()) if BUILD_LEDGER.exists() else {}
    check("build_ledger_main_current", build.get("main_tex_sha256") == sha256(MAIN), str(build.get("main_tex_sha256")))
    pdf = HERE / "main.pdf"
    check(
        "build_ledger_pdf_current_or_source_only",
        (not pdf.exists()) or build.get("main_pdf_sha256") == sha256(pdf),
        "source-only package" if not pdf.exists() else str(build.get("main_pdf_sha256")),
    )
    supplement_pdf = HERE / "supplement.pdf"
    check(
        "supplement_build_current_or_source_only",
        (not supplement_pdf.exists())
        or (
            build.get("supplement_tex_sha256") == sha256(HERE / "supplement.tex")
            and build.get("supplement_pdf_sha256") == sha256(supplement_pdf)
        ),
        "source-only package" if not supplement_pdf.exists() else str(build.get("supplement_pdf_sha256")),
    )
    if pdf.exists():
        pdfinfo = subprocess.check_output(["pdfinfo", str(pdf)], text=True)
        pages_match = re.search(r"^Pages:\s+(\d+)", pdfinfo, re.M)
        pages = int(pages_match.group(1)) if pages_match else 999
        check("review_manuscript_page_target", pages <= 40, f"{pages} (internal double-spaced target 40 after unit-overlap disclosure; no venue word limit found in public T&F pages)")
    else:
        check("review_manuscript_page_target", True, "source-only package")
    def resolve_pointer(doc, pointer):
        cur = doc
        for part in pointer.lstrip("/").split("/"):
            part = part.replace("~1", "/").replace("~0", "~")
            cur = cur[int(part)] if isinstance(cur, list) else cur[part]
        return cur

    source_map = {
        "manuscript/derived/asset_inputs.json": HERE / "frozen_inputs" / "asset_inputs.json",
        "manuscript/paper-cbs/frozen_inputs/family_wise_sensitivity.json": HERE / "frozen_inputs" / "family_wise_sensitivity.json",
        "manuscript/paper-cbs/frozen_inputs/seeded_candidate_demo.json": HERE / "frozen_inputs" / "seeded_candidate_demo.json",
        "manuscript/paper-cbs/frozen_inputs/robustness_post_hoc.json": HERE / "frozen_inputs" / "robustness_post_hoc.json",
        "manuscript/paper-cbs/frozen_inputs/source_locator_manifest.json": HERE / "frozen_inputs" / "source_locator_manifest.json",
        "manuscript/paper-cbs/frozen_inputs/contract_transfer_dbmi.json": HERE / "frozen_inputs" / "contract_transfer_dbmi.json",
        "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_v1.json": HERE / "frozen_inputs" / "contract_transfer_shakemap_v1.json",
        "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_reconstruction_v1.json": HERE / "frozen_inputs" / "contract_transfer_shakemap_reconstruction_v1.json",
        "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_v2.json": HERE / "frozen_inputs" / "contract_transfer_shakemap_v2.json",
        "manuscript/paper-cbs/frozen_inputs/contract_transfer_shakemap_reconstruction_v2.json": HERE / "frozen_inputs" / "contract_transfer_shakemap_reconstruction_v2.json",
        "manuscript/paper-cbs/frozen_inputs/prospective_dyfi_2025.json": HERE / "frozen_inputs" / "prospective_dyfi_2025.json",
    }
    unresolved = []
    for line in (HERE / "claim_ledger.jsonl").read_text().splitlines():
        rec = json.loads(line)
        ptr = rec.get("json_pointer")
        if not ptr or not str(ptr).startswith("/") or "," in str(ptr):
            continue
        src = source_map.get(rec.get("source_artifact"))
        if src is None or not src.exists():
            continue
        try:
            resolve_pointer(json.loads(src.read_text()), ptr)
        except (KeyError, IndexError, TypeError, ValueError):
            unresolved.append(rec["claim_id"])
    check("claim_ledger_pointers_resolve", not unresolved, str(unresolved[:15]))
    readiness_path = HERE / "reviews" / "editor-reviewer-readiness.json"
    if readiness_path.exists() and pdf.exists():
        readiness = json.loads(readiness_path.read_text())
        check(
            "editor_reviewer_readiness_current",
            readiness.get("manuscript_sha256") == sha256(pdf)
            and readiness.get("overall_pass") is True
            and readiness.get("abstract_story", {}).get("pass") is True,
            str(readiness.get("manuscript_sha256")),
        )
    else:
        check(
            "editor_reviewer_readiness_current",
            True,
            "readiness record is a release-level review artifact and is not required in editable source-only packages",
        )

    failed = [c for c in checks if not c["ok"]]
    report = {
        "record_type": "cbs_manuscript_validation_report",
        "n_checks": len(checks),
        "n_failed": len(failed),
        "overall_pass": not failed,
        "checks": checks,
    }
    (HERE / "cbs_validation_report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"validate_cbs: {len(checks)} checks, {len(failed)} failed -> {'PASS' if not failed else 'FAIL'}")
    for item in failed:
        print(f"  FAIL: {item['check']} {item['detail']}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
