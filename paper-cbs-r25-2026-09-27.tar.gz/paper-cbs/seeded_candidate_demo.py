"""Post-hoc seeded-candidate demonstration of the admission gate.

Five candidates extend the B2 pipeline (frozen regularization, no tuning) with
one extra field set. For each, the executable admission audit
(leakage_audit.audit_feature_names, plus the temporal-axis audit) runs FIRST on
the declared field names. Every candidate is then fit on the construction rows
only and scored once on the temporal holdout, solely to show what a
score-ranking or interval-only workflow would have concluded had the gate been
absent. Feature values are always read by the harness from the frozen rows, so
a declared name cannot carry substituted values.

  C_F1      + max_cdi                      direct label constituent
  C_F2      + log1p(num_responses)          post-outcome ascertainment
  C_F2_ren  same values declared n_reports  name evades every family
  C_year    + origin_year                   temporal-axis proxy
  C_geo     + latitude, longitude           outcome-blind, outside schema

An extended Holm family (the ten admissible pairs plus C_F2 against each
admissible baseline) is a worked illustration of how the fixed schema gate and
the comparison rule can return different answers. It is not evidence that an
allowlist detects unknown contamination.

Output: frozen_inputs/seeded_candidate_demo.json
"""
from __future__ import annotations

import itertools
import json
import math
import os
import sys

import numpy as np
from scipy.stats import t as student_t

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "code"))

import asset_common as ac  # noqa: E402
import baselines  # noqa: E402
import common  # noqa: E402
import leakage_audit  # noqa: E402
import metrics  # noqa: E402

OUT = os.path.join(HERE, "frozen_inputs", "seeded_candidate_demo.json")
ALPHA = 0.05


def _col(rows, field, transform=None):
    v = np.asarray([float(r[field]) for r in rows], dtype=np.float64)
    return transform(v) if transform else v


CANDIDATES = {
    "C_F1": {"declared": ["max_cdi"], "cols": [("max_cdi", None)],
             "family": "F1 direct label constituent"},
    "C_F2": {"declared": ["num_responses"], "cols": [("num_responses", np.log1p)],
             "family": "F2 post-outcome ascertainment"},
    "C_F2_ren": {"declared": ["n_reports"], "cols": [("num_responses", np.log1p)],
                 "family": "F2 values under a name that matches no family"},
    "C_year": {"declared": ["origin_year"], "cols": [("origin_year", None)],
               "family": "temporal-axis proxy"},
    "C_geo": {"declared": ["latitude", "longitude"], "cols": [("latitude", None), ("longitude", None)],
              "family": "outcome-blind fields outside the declared schema"},
}


def matrix(rows, cols):
    base = baselines.extract_features(rows, common.SOURCE_ONLY_SCHEMA)
    return np.column_stack([base] + [_col(rows, f, t) for f, t in cols])


def paired(y, pa, pb, groups):
    g = np.asarray(groups, dtype=object)
    uniq = np.array(sorted({v for v in g.tolist()}, key=lambda v: str(v)), dtype=object)
    idx_by = {u: np.where(g == u)[0] for u in uniq}
    rng = np.random.default_rng(ac.BOOTSTRAP_SEED)
    d = []
    for _ in range(ac.BOOTSTRAP_DRAWS):
        ch = rng.integers(0, uniq.shape[0], size=uniq.shape[0])
        idx = np.concatenate([idx_by[uniq[c]] for c in ch])
        va = metrics._metric_scalar("brier", y[idx], pa[idx])
        vb = metrics._metric_scalar("brier", y[idx], pb[idx])
        if va is None or vb is None or not (math.isfinite(va) and math.isfinite(vb)):
            continue
        d.append(va - vb)
    arr = np.sort(np.asarray(d, dtype=np.float64))
    event_diff = (np.asarray(y) - np.asarray(pa)) ** 2 - (np.asarray(y) - np.asarray(pb)) ** 2
    point = float(np.mean(event_diff))
    influence = np.asarray(
        [np.sum(event_diff[g == u] - point) for u in uniq], dtype=np.float64
    )
    se = float(
        np.sqrt(uniq.size / (uniq.size - 1.0) * np.sum(influence ** 2))
        / event_diff.size
    )
    statistic = point / se
    p = max(
        float(2.0 * student_t.sf(abs(statistic), df=uniq.size - 1)),
        float(np.finfo(np.float64).tiny),
    )
    lo, hi = (float(np.quantile(arr, q, method="linear")) for q in (0.025, 0.975))
    return lo, hi, p


def main() -> None:
    recon = ac.reconstruct_frozen_predictions()
    ver = ac.verify_reconstruction(recon)
    if not ver["all_match"] or recon["predictions_digest"] != recon["recorded_predictions_digest"]:
        raise SystemExit("reconstruction verification failed; refusing to emit")

    construction, holdout = recon["construction"], recon["holdout"]
    y_c = baselines.extract_labels(construction)
    y = np.asarray(recon["y_hold"], dtype=np.float64)
    groups = recon["groups"]
    preds = {b: np.asarray(v, dtype=np.float64) for b, v in recon["predictions"].items()}
    spec = {s.id: s for s in baselines.registry()}["B2_source_only_logit"]
    params = dict(recon["frozen_best_params"]["B2_source_only_logit"])

    def score(p):
        return {"brier": ac._round12(metrics.brier_score(y, p).value),
                "auroc": ac._round12(metrics.auroc(y, p).value),
                "log_loss": ac._round12(metrics.log_loss(y, p).value)}

    candidates = {}
    seeded_preds = {}
    for cid, c in CANDIDATES.items():
        declared = ["magnitude", "depth_km"] + c["declared"]
        field = leakage_audit.audit_feature_names(declared, common.SOURCE_ONLY_SCHEMA)
        axis = leakage_audit.audit_features_against_axis(declared, axis="temporal")
        admitted = bool(field["passed"]) and bool(axis.get("passed", True))
        if admitted:
            raise SystemExit(f"admission audit unexpectedly accepted {cid}")
        model = spec.build(params)
        model.fit(matrix(construction, c["cols"]), y_c)
        p = np.asarray(model.predict_proba(matrix(holdout, c["cols"]))[:, 1], dtype=np.float64)
        seeded_preds[cid] = p
        lo, hi, pv = paired(y, p, preds["B2_source_only_logit"], groups)
        candidates[cid] = {
            "declared_fields": c["declared"], "contamination": c["family"],
            "admission_audit": {"passed": False,
                                "field_rejections": field["rejected"],
                                "axis_audit": {k: axis[k] for k in axis if k in ("passed", "axis_proxy_leaks")}},
            "holdout_scores": score(p),
            "vs_B2_brier": {"diff": ac._round12(metrics.brier_score(y, p).value - metrics.brier_score(y, preds["B2_source_only_logit"]).value),
                            "ci95": [ac._round12(lo), ac._round12(hi)],
                            "cluster_robust_p_two_sided": ac._round12(pv)},
        }

    fam = []
    for a, b in itertools.combinations(sorted(preds), 2):
        lo, hi, pv = paired(y, preds[a], preds[b], groups)
        fam.append({"a": a, "b": b, "p": pv})
    for ref in sorted(preds):
        lo, hi, pv = paired(y, seeded_preds["C_F2"], preds[ref], groups)
        fam.append({"a": "C_F2", "b": ref, "p": pv, "ci95": [ac._round12(lo), ac._round12(hi)]})
    order = sorted(range(len(fam)), key=lambda i: fam[i]["p"])
    stop = False
    for rank, i in enumerate(order):
        ok = (not stop) and fam[i]["p"] <= ALPHA / (len(fam) - rank)
        fam[i]["holm_reject"] = bool(ok)
        stop = stop or not ok
    cf2_holm = {r["b"]: r["holm_reject"] for r in fam if r["a"] == "C_F2"}
    admissible_holm = {
        f"{r['a']}_vs_{r['b']}": r["holm_reject"]
        for r in fam if r["a"] != "C_F2"
    }

    comparisons = {}
    for ref in sorted(preds):
        res = metrics.paired_cluster_bootstrap_difference(
            y, seeded_preds["C_F2"], preds[ref], groups, metric="brier",
            n_boot=ac.BOOTSTRAP_DRAWS, seed=ac.BOOTSTRAP_SEED, resolution_floor=ac.RESOLUTION_FLOOR)
        comparisons[ref] = {
            "point_diff_leak_minus_ref": ac._round12(res["point_diff_a_minus_b"]),
            "ci95": [ac._round12(res["ci_lower"]), ac._round12(res["ci_upper"])],
            "excludes_zero": bool(res["resolved"]),
            "prob_leak_better": ac._round12(res["prob_a_better"]),
            "holm_reject_extended_family": cf2_holm[ref],
        }

    out = {
        "record_type": "post_hoc_seeded_contamination_demonstration",
        "status": "post-hoc illustration; not pre-specified; not a performance claim",
        "order_of_operations": "admission audit on declared names first; fit and score afterwards for illustration only",
        "fit_rows": "construction only", "n_fit": len(construction), "n_holdout": int(y.size),
        "frozen_params_reused": params,
        "candidates": candidates,
        "admission_audit": candidates["C_F2"]["admission_audit"],
        "holdout_scores": {"C_F2": candidates["C_F2"]["holdout_scores"], **{b: score(preds[b]) for b in sorted(preds)}},
        "paired_brier_vs_admissible": comparisons,
        "extended_holm_family": {
            "n_pairs": len(fam),
            "alpha": ALPHA,
            "test": "paired Brier-loss mean with sequence-cluster-robust variance and t(G-1)",
            "C_F2_holm_supported_against": sorted(k for k, v in cf2_holm.items() if v),
            "admissible_pair_decisions": admissible_holm,
        },
        "bootstrap": {
            "n_boot": ac.BOOTSTRAP_DRAWS,
            "seed": ac.BOOTSTRAP_SEED,
            "use": "descriptive percentile intervals only",
        },
    }
    with open(OUT, "w") as fh:
        json.dump(out, fh, indent=2, sort_keys=True)
        fh.write("\n")
    for cid, c in candidates.items():
        print(cid, [r["family"] for r in c["admission_audit"]["field_rejections"]],
              c["admission_audit"]["axis_audit"], c["holdout_scores"], c["vs_B2_brier"])
    print("C_F2 Holm-supported (extended family):", out["extended_holm_family"])


if __name__ == "__main__":
    main()
