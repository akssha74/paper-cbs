#!/usr/bin/env python3
"""Reconstruct the ShakeMap v1 release offline from the frozen v2 rows.

V1 and v2 used the same scientific cohort and role assignments. V1 bound
depth to the absent ``properties.depth`` field and therefore imputed 10 km for
every row. This retrospective utility applies that documented v1 binding to the
frozen 4,666-row v2 scientific projection, reruns the v1 fits, and refuses to
write unless the prediction digest, fits, scores, pair records, and Holm count
match the original v1 result. It does not retrieve network data.
"""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from sklearn.metrics import roc_auc_score

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESULTS = ROOT / "results"
sys.path.insert(0, str(HERE))

import run_shakemap_transfer_v2 as core  # noqa: E402


def canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def write_jsonl_gz(path: Path, records: list[dict]) -> str:
    payload = b"".join(canonical_bytes(record) + b"\n" for record in records)
    with path.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as out:
            out.write(payload)
    return sha_bytes(path.read_bytes())


def main() -> int:
    frozen = json.loads((RESULTS / "results.json").read_text())
    design = json.loads((ROOT / "prereg" / "frozen_design.json").read_text())
    with gzip.open(RESULTS / "v2_event_rows.jsonl.gz", "rt") as stream:
        rows = [json.loads(line) for line in stream if line.strip()]

    # Reapply the documented v1 value binding exactly.
    for row in rows:
        row["depth_raw"] = None
        row["depth_km"] = float(frozen["cohort"]["construction_depth_median"])
        row.pop("predictions", None)

    construction = [row for row in rows if row["role"] == "construction"]
    holdout = [row for row in rows if row["role"] == "holdout"]
    y = np.asarray([row["severe_label"] for row in holdout], dtype=float)
    specs = {spec.id: spec for spec in core.baselines.registry()}
    ledger = core.baselines.FitLedger()
    groups = [row["sequence_id"] for row in construction]
    predictions: dict[str, np.ndarray] = {}
    fits: dict[str, dict] = {}
    for candidate in design["candidates"]:
        fitted = core.baselines.tune_and_fit(
            specs[candidate], construction, groups, ledger, axis="temporal"
        )
        predictions[candidate] = core.baselines.predict_proba(fitted, holdout)
        fits[candidate] = {
            "best_params": fitted["best_params"],
            "cv_scores": fitted["cv_scores"],
        }

    digest = sha_bytes(
        json.dumps(
            {
                key: [round(float(value), 12) for value in values]
                for key, values in predictions.items()
            },
            sort_keys=True,
        ).encode()
    )
    if digest != frozen["holdout_predictions_digest"]:
        raise SystemExit("v1 prediction digest mismatch; refusing to write")
    if fits != frozen["fits"]:
        raise SystemExit("v1 fit record mismatch; refusing to write")

    per_candidate: dict[str, dict] = {}
    for candidate, probs in predictions.items():
        per_candidate[candidate] = {
            "brier": float(np.mean((probs - y) ** 2)),
            "log_loss": core.logloss(y, probs),
            "auroc": (
                float(roc_auc_score(y, probs))
                if np.unique(probs).size > 1
                else None
            ),
            "brier_by_threshold": {
                str(threshold): float(
                    np.mean(
                        (
                            probs
                            - np.asarray(
                                [
                                    float(row["mmi"] >= threshold)
                                    for row in holdout
                                ]
                            )
                        )
                        ** 2
                    )
                )
                for threshold in design["threshold_sensitivity"]
            },
        }
    if per_candidate != frozen["per_candidate"]:
        raise SystemExit("v1 score mismatch; refusing to write")

    sequence_groups = [row["sequence_id"] for row in holdout]
    event_groups = [row["event_id"] for row in holdout]
    import itertools

    pairs: list[dict] = []
    for left, right in itertools.combinations(design["candidates"], 2):
        delta = (y - predictions[left]) ** 2 - (y - predictions[right]) ** 2
        point, se, _, p_value, df = core.cr1(delta, sequence_groups)
        _, _, _, event_p, _ = core.cr1(delta, event_groups)
        _, _, cr3_p = core.cr3(delta, sequence_groups)
        pairs.append(
            {
                "a": left,
                "b": right,
                "mean_diff_a_minus_b": point,
                "cr1_se": se,
                "cr1_p": p_value,
                "event_level_p": event_p,
                "cr3_p": cr3_p,
                "df": df,
            }
        )
    for source, target in (
        ("cr1_p", "holm_cr1"),
        ("event_level_p", "holm_event_level"),
        ("cr3_p", "holm_cr3"),
    ):
        decisions = core.holm(
            [row[source] for row in pairs], design["family_alpha"]
        )
        for row, decision in zip(pairs, decisions):
            row[target] = bool(decision)
    if pairs != frozen["pairs"]:
        raise SystemExit("v1 pair record mismatch; refusing to write")
    if sum(row["holm_cr1"] for row in pairs) != 0:
        raise SystemExit("v1 Holm count mismatch; refusing to write")

    for index, row in enumerate(holdout):
        row["predictions"] = {
            key: float(values[index]) for key, values in predictions.items()
        }
    for row in construction:
        row["predictions"] = {}
    for row in rows:
        if row["role"] == "straddle":
            row["predictions"] = {}

    output = RESULTS / "v1_event_rows.jsonl.gz"
    output_hash = write_jsonl_gz(output, rows)
    record = {
        "record_type": "retrospective_v1_release_reconstruction",
        "source_rows": "v2_event_rows.jsonl.gz",
        "network_used": False,
        "binding": {
            "source": "properties.depth",
            "observed_missing_fraction": 1.0,
            "imputed_value_km": frozen["cohort"]["construction_depth_median"],
        },
        "event_rows": {
            "path": "results/v1_event_rows.jsonl.gz",
            "sha256": output_hash,
            "n_rows": len(rows),
            "n_holdout_predictions": len(holdout),
        },
        "exact_matches": {
            "prediction_digest": True,
            "fits": True,
            "per_candidate": True,
            "all_ten_pairwise_records": True,
            "holm_cr1_rejections": 0,
        },
    }
    (RESULTS / "reconstruction_v1.json").write_text(
        json.dumps(record, indent=2) + "\n"
    )
    print(json.dumps(record, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
