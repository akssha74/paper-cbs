#!/usr/bin/env python3
"""Post hoc (not in any frozen plan): prospective DYFI pair decisions under region clustering.

Recomputes the ten pre-declared prospective Brier pairs from the stored holdout
predictions with CR1 paired t-tests clustered by catalogue region code (77
regions) and Holm over the ten pairs (alpha 0.05), alongside the declared
sequence-cluster decisions, and re-evaluates H1 and H2 under region clustering.
The frozen H1/H2 verdicts are unchanged; this is a sensitivity reading only.
"""
from __future__ import annotations

import gzip
import hashlib
import itertools
import json
import os

import numpy as np
from scipy.stats import t as student_t

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
INTEG = os.path.dirname(ROOT)
ALPHA = 0.05
CANDS = ["B0_no_skill", "B1_magnitude_only_logit", "B2_source_only_logit", "B4_random_forest", "B5_xgboost"]


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def cr1(d, inv):
    G = inv.max() + 1
    n = d.size
    tot = np.bincount(inv, weights=d, minlength=G)
    sizes = np.bincount(inv, minlength=G).astype(float)
    m = d.mean()
    se = np.sqrt(G / (G - 1.0) * np.sum((tot - m * sizes) ** 2)) / n
    return float(m), float(se), float(2 * student_t.sf(abs(m) / se, G - 1))


def holm(p):
    order = np.argsort(p)
    rej = np.zeros(len(p), bool)
    for i, k in enumerate(order):
        if p[k] <= ALPHA / (len(p) - i):
            rej[k] = True
        else:
            break
    return rej


def main():
    res = os.path.join(INTEG, "prospective-dyfi-2025", "results")
    path = os.path.join(ROOT, "results", "prospective_region_holm.json")
    if os.path.exists(path):
        raise SystemExit("results exist; refusing to overwrite")
    r = json.load(open(os.path.join(res, "results.json")))
    rows = [json.loads(line) for line in gzip.open(os.path.join(res, "holdout_rows.jsonl.gz"))]
    y = np.asarray([row["severe_label"] for row in rows], dtype=float)
    preds = {c: np.asarray(r["holdout_predictions"][c]) for c in CANDS}
    _, inv_seq = np.unique([row["sequence_id"] for row in rows], return_inverse=True)
    _, inv_reg = np.unique([row["region_code"] for row in rows], return_inverse=True)
    pairs = list(itertools.combinations(CANDS, 2))
    stats = {}
    for unit, inv in (("sequence", inv_seq), ("region", inv_reg)):
        out = [cr1((y - preds[a]) ** 2 - (y - preds[b]) ** 2, inv) for a, b in pairs]
        rej = holm(np.array([o[2] for o in out]))
        stats[unit] = {f"{a}-{b}": {"mean_diff": o[0], "se": o[1], "p": o[2], "holm": bool(x)}
                       for (a, b), o, x in zip(pairs, out, rej)}
    frozen = {f"{p['a']}-{p['b']}": p["holm_cr1"] for p in r["pairs"]}
    assert all(stats["sequence"][k]["holm"] == frozen[k] for k in frozen), "sequence decisions differ from frozen"

    def supported(unit, better, worse):
        k = f"{better}-{worse}" if f"{better}-{worse}" in stats[unit] else f"{worse}-{better}"
        s = stats[unit][k]
        sign_ok = s["mean_diff"] < 0 if k.startswith(better) else s["mean_diff"] > 0
        return s["holm"] and sign_ok

    learned = CANDS[1:]
    h = {unit: {"H1": all(supported(unit, c, "B0_no_skill") for c in learned),
                "H2": all(supported(unit, c, "B1_magnitude_only_logit") for c in CANDS[2:])}
         for unit in stats}
    out = {"status": "post_hoc", "design": __doc__.strip(), "arm": "dyfi_prospective_2025",
           "n": int(y.size), "sequences": int(inv_seq.max() + 1), "regions": int(inv_reg.max() + 1),
           "alpha": ALPHA, "pairs": stats, "hypotheses": h,
           "n_holm": {u: sum(v["holm"] for v in s.values()) for u, s in stats.items()},
           "sources": {"results.json": sha(os.path.join(res, "results.json")),
                       "holdout_rows.jsonl.gz": sha(os.path.join(res, "holdout_rows.jsonl.gz"))}}
    json.dump(out, open(path, "w"), indent=2)
    print(json.dumps({"n_holm": out["n_holm"], "hypotheses": h,
                      "region_rejected": sorted(k for k, v in stats["region"].items() if v["holm"])}, indent=2))


if __name__ == "__main__":
    main()
