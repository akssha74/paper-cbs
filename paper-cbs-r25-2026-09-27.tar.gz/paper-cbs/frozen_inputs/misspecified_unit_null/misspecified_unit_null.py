#!/usr/bin/env python3
"""Post hoc (not in any frozen plan): misspecified-unit sign-flip null on prospective DYFI.

The ten admissible pairwise Brier loss differences are centred and multiplied by
one Rademacher sign per coarse unit (catalogue region code), shared across pairs,
so dependence exists at a unit coarser than the declared sequence. Each draw
applies event-level, declared sequence-cluster, and region-cluster CR1 paired
t-tests with Holm (alpha 0.05) and records any-rejection (FWER). The readmission
table releases no unit coarser than the patient, so it is not evaluated.
"""
from __future__ import annotations

import gzip
import hashlib
import itertools
import json
import os

import numpy as np
from scipy.stats import t as student_t

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
INTEG = os.path.dirname(ROOT)
DRAWS, SEED, ALPHA = 4000, 20260927, 0.05
CANDS = ["B0_no_skill", "B1_magnitude_only_logit", "B2_source_only_logit", "B4_random_forest", "B5_xgboost"]


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def holm_any(p):
    m = p.shape[1]
    order = np.argsort(p, axis=1)
    ps = np.take_along_axis(p, order, axis=1)
    keep = np.cumprod(ps <= ALPHA / (m - np.arange(m)), axis=1).astype(bool)
    return keep.any(axis=1)


def cluster_p(Dk_signed, inv, G, n):
    tot = np.stack([np.bincount(inv, weights=row, minlength=G) for row in Dk_signed])
    sizes = np.bincount(inv, minlength=G).astype(float)
    m = tot.sum(axis=1) / n
    c = tot - m[:, None] * sizes
    se = np.sqrt(G / (G - 1.0) * np.sum(c ** 2, axis=1)) / n
    return 2 * student_t.sf(np.abs(m) / se, G - 1)


def main():
    res = os.path.join(INTEG, "prospective-dyfi-2025", "results")
    r = json.load(open(os.path.join(res, "results.json")))
    rows = [json.loads(line) for line in gzip.open(os.path.join(res, "holdout_rows.jsonl.gz"))]
    y = np.asarray([row["severe_label"] for row in rows], dtype=float)
    preds = {c: np.asarray(r["holdout_predictions"][c]) for c in CANDS}
    n = y.size
    _, inv_seq = np.unique([row["sequence_id"] for row in rows], return_inverse=True)
    _, inv_reg = np.unique([row["region_code"] for row in rows], return_inverse=True)
    Gs, Gr = inv_seq.max() + 1, inv_reg.max() + 1
    pairs = list(itertools.combinations(CANDS, 2))
    D = np.stack([(y - preds[a]) ** 2 - (y - preds[b]) ** 2 for a, b in pairs])
    D = D - D.mean(axis=1, keepdims=True)
    rng = np.random.default_rng(SEED)
    S = rng.choice([-1.0, 1.0], size=(DRAWS, Gr))[:, inv_reg]
    p_ev = np.empty((DRAWS, len(pairs)))
    p_seq = np.empty_like(p_ev)
    p_reg = np.empty_like(p_ev)
    for k in range(len(pairs)):
        X = S * D[k]
        m = X.mean(axis=1)
        se_ev = np.sqrt(np.sum((X - m[:, None]) ** 2, axis=1) / (n - 1.0) / n)
        p_ev[:, k] = 2 * student_t.sf(np.abs(m) / se_ev, n - 1)
        p_seq[:, k] = cluster_p(X, inv_seq, Gs, n)
        p_reg[:, k] = cluster_p(X, inv_reg, Gr, n)
    fw = {name: float(holm_any(p).mean()) for name, p in
          (("event_level", p_ev), ("declared_sequence_cluster", p_seq), ("region_cluster", p_reg))}
    reg_sizes = np.bincount(inv_reg)
    out = {"status": "post_hoc", "design": __doc__.strip(), "arm": "dyfi_prospective_2025",
           "n": int(n), "sequences": int(Gs), "regions": int(Gr),
           "multi_member_regions": int((reg_sizes > 1).sum()), "largest_region": int(reg_sizes.max()),
           "draws": DRAWS, "seed": SEED, "alpha": ALPHA,
           "fwer_holm": fw,
           "monte_carlo_se": {k: float(np.sqrt(v * (1 - v) / DRAWS)) for k, v in fw.items()},
           "sources": {"results.json": sha(os.path.join(res, "results.json")),
                       "holdout_rows.jsonl.gz": sha(os.path.join(res, "holdout_rows.jsonl.gz"))}}
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    path = os.path.join(ROOT, "results", "misspecified_unit_null.json")
    if os.path.exists(path):
        raise SystemExit("results exist; refusing to overwrite")
    json.dump(out, open(path, "w"), indent=2)
    print(json.dumps({k: out[k] for k in ("n", "sequences", "regions", "largest_region", "fwer_holm", "monte_carlo_se")}, indent=2))


if __name__ == "__main__":
    main()
