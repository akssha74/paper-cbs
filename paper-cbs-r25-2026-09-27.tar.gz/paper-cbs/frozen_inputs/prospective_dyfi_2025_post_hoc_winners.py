#!/usr/bin/env python3
"""Post hoc (not in the frozen plan): inferential winners for each decision rule.

Reads the one-shot results and holdout rows. A winner is the unique admitted
candidate supported as better than every other admitted candidate under the
rule's own test (A3 disjoint unpaired intervals; A4 event-level paired Holm
over all admitted pairs; A2b+event exact-schema admission with event-level
Holm over the ten admissible pairs; contract sequence-cluster CR1 Holm).
"""
from __future__ import annotations

import gzip
import hashlib
import itertools
import json
import os

import numpy as np
from scipy.stats import t as student_t

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")


def cr1(d, groups):
    point = float(np.mean(d))
    uniq, inv = np.unique(np.asarray(groups), return_inverse=True)
    infl = np.bincount(inv, weights=d - point)
    G = len(uniq)
    se = float(np.sqrt(G / (G - 1.0) * np.sum(infl ** 2)) / d.size)
    return point, (1.0 if se == 0 else float(2 * student_t.sf(abs(point / se), G - 1)))


def holm(p, alpha=0.05):
    order = sorted(range(len(p)), key=lambda i: p[i])
    rej = [False] * len(p)
    for k, i in enumerate(order):
        if p[i] <= alpha / (len(p) - k):
            rej[i] = True
        else:
            break
    return rej


def winner(adm, dec):
    wins = [c for c in adm if all(dec.get((c, d), dec.get((d, c))) == c for d in adm if d != c)]
    return wins[0] if len(wins) == 1 else None


def tested(adm, y, preds, groups):
    pairs = list(itertools.combinations(adm, 2))
    st = [cr1((y - preds[a]) ** 2 - (y - preds[b]) ** 2, groups) for a, b in pairs]
    rej = holm([s[1] for s in st])
    return {(a, b): ((a if s[0] < 0 else b) if x else None) for (a, b), s, x in zip(pairs, st, rej)}


def main():
    r = json.load(open(os.path.join(RES, "results.json")))
    rows = [json.loads(line) for line in gzip.open(os.path.join(RES, "holdout_rows.jsonl.gz"))]
    y = np.asarray([row["severe_label"] for row in rows], dtype=float)
    seq = [row["sequence_id"] for row in rows]
    ev = [row["event_id"] for row in rows]
    preds = {k: np.asarray(v) for k, v in r["holdout_predictions"].items()}
    wf = r["workflows"]
    admissible = list(r["fits"])
    adm_pairs = list(itertools.combinations(admissible, 2))
    out = {"status": "post_hoc", "source_results_sha256": hashlib.sha256(
        open(os.path.join(RES, "results.json"), "rb").read()).hexdigest(), "rules": {}}

    ci = wf["W3_unpaired_intervals"]["intervals"]
    a2 = wf["W2_schema_validation"]["admitted"]
    a3 = {}
    for a, b in itertools.combinations(a2, 2):
        a3[(a, b)] = a if ci[a][1] < ci[b][0] else b if ci[b][1] < ci[a][0] else None
    rules = {
        "A3_unpaired_intervals": (a2, a3),
        "A4_event_paired_holm": (a2, tested(a2, y, preds, ev)),
        "A2b_exact_schema_event_holm": (admissible, tested(admissible, y, preds, ev)),
        "Contract": (admissible, tested(admissible, y, preds, seq)),
    }
    for name, (adm, dec) in rules.items():
        out["rules"][name] = {
            "admitted": adm, "family_size": len(dec),
            "admissible_pair_labels": sorted(f"{a}-{b}" for a, b in adm_pairs
                                             if dec.get((a, b), dec.get((b, a))) is not None),
            "winner": winner(adm, dec),
        }
    json.dump(out, open(os.path.join(RES, "post_hoc_winners.json"), "w"), indent=2)
    for k, v in out["rules"].items():
        print(k, v["family_size"], len(v["admissible_pair_labels"]), v["winner"])


if __name__ == "__main__":
    main()
