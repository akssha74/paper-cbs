#!/usr/bin/env python3
"""Post hoc executed comparison: eval-toolkit 1.12.0 versus the frozen readmission contract.

Usage: PYTHONPATH=<eval-toolkit>/src python3 run_evaltoolkit_comparison.py <eval-toolkit archive>
See ../prereg/analysis_plan.md. Refuses to overwrite its results.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import os
import sys
import time

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ARM = os.path.join(os.path.dirname(ROOT), "contract-transfer-diabetes")
sys.path.insert(0, os.path.join(ARM, "code"))
import contract_diabetes as cd  # noqa: E402

import eval_toolkit  # noqa: E402
from eval_toolkit import paired_bootstrap_diff  # noqa: E402
from eval_toolkit.harness import EvalSlice  # noqa: E402
from eval_toolkit.leakage import CrossSplitLeakageCheck, GroupLeakageCheck, run_leakage_checks  # noqa: E402
from eval_toolkit.metrics import brier_score  # noqa: E402
from eval_toolkit.text_dedup import ExactNormalizedHashStrategy  # noqa: E402


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def slice_(name, rows, unit, design):
    df = pd.DataFrame({"text": [str(r["encounter_id"]) for r in rows],
                       "label": [int(cd.label(r, design)) for r in rows],
                       unit: [r[unit] for r in rows]})
    return EvalSlice(name=name, df=df)


def named_winner(adm, resolved_lower):
    w = [c for c in adm if all(resolved_lower.get((c, o)) for o in adm if o != c)]
    return w[0] if len(w) == 1 else None


def main():
    out_path = os.path.join(ROOT, "results", "evaltoolkit_comparison.json")
    if os.path.exists(out_path):
        sys.exit(f"refusing to overwrite {out_path}")
    archive = sys.argv[1]
    manifest = json.load(open(os.path.join(ARM, "results", "hash_manifest.json")))
    for key, rel in (("results.json", "results/results.json"), ("raw_data.zip", "results/raw_data.zip")):
        assert sha(os.path.join(ARM, rel)) == manifest[key], key
    design = json.load(open(os.path.join(ARM, "prereg", "frozen_design.json")))
    rec = json.load(open(os.path.join(ARM, "results", "results.json")))
    rows, _ = cd.read_rows(open(os.path.join(ARM, "results", "raw_data.zip"), "rb").read(),
                           design["data_member_suffix"])
    unit = design["unit"]
    hold = [r for r in rows if cd.is_holdout_unit(r[unit], design)]
    cons = [r for r in rows if not cd.is_holdout_unit(r[unit], design)]
    y = np.asarray([cd.label(r, design) for r in hold], dtype=float)
    preds = {k: np.asarray(v, dtype=float) for k, v in rec["holdout_predictions"].items()}
    gates = rec["gates"]
    manifests = {c: cons for c in design["candidates"]}
    for cid, spec in design["seeded"].items():
        if "train_fraction_encounters" in spec:
            rng = np.random.default_rng(design["random_state"])
            keep = rng.random(len(rows)) < spec["train_fraction_encounters"]
            manifests[cid] = [r for r, k in zip(rows, keep) if k]
        else:
            manifests[cid] = cons

    checks = [GroupLeakageCheck(group_col=unit),
              CrossSplitLeakageCheck(strategy=ExactNormalizedHashStrategy())]
    hold_slice = slice_("holdout", hold, unit, design)
    audit, cache, t_checks = {}, {}, 0.0
    for c in preds:
        key = id(manifests[c])
        if key not in cache:
            t0 = time.perf_counter()
            rep = run_leakage_checks(checks, {"train": slice_("train", manifests[c], unit, design),
                                              "holdout": hold_slice})
            t_checks += time.perf_counter() - t0
            cache[key] = {f.check_name: {"severity": f.severity, "n_affected": int(f.n_affected),
                                         "message": f.message} for f in rep.findings}
        fired = sorted(n for n, f in cache[key].items() if f["severity"] == "error" and f["n_affected"] > 0)
        audit[c] = {"findings": cache[key], "refused_by": fired}

    def compare(adm):
        t0 = time.perf_counter()
        res, lower = {}, {}
        for a, b in itertools.combinations(adm, 2):
            ci = paired_bootstrap_diff(y, preds[a], preds[b], brier_score)
            res[f"{a}-{b}"] = {"delta_b_minus_a": float(ci.delta), "ci": [float(ci.ci_low), float(ci.ci_high)],
                               "resolved": not ci.overlaps_zero}
            if not ci.overlaps_zero:
                lower[(b, a) if ci.delta < 0 else (a, b)] = True
        return res, lower, time.perf_counter() - t0

    brier = {c: float(brier_score(y, preds[c])) for c in preds}
    stacks = {"T1_evaltoolkit": lambda c: not audit[c]["refused_by"],
              "T2_evaltoolkit_plus_name_gate": lambda c: not audit[c]["refused_by"] and gates[c]["name_passed"]}
    out = {"status": "post_hoc", "design": "../prereg/analysis_plan.md",
           "tool": {"name": "eval-toolkit", "version": eval_toolkit.__version__,
                    "archive_sha256": sha(archive)},
           "inputs": {"results.json": manifest["results.json"], "raw_data.zip": manifest["raw_data.zip"]},
           "n_holdout": int(y.size), "brier": brier, "audit": audit,
           "config_statements": {"T1": len(checks) + 1, "T2": len(checks) + 2},
           "runtime_seconds": {"leakage_checks": round(t_checks, 2)}, "stacks": {}}
    for name, ok in stacks.items():
        adm = [c for c in preds if ok(c)]
        res, lower, dt = compare(adm)
        out["runtime_seconds"][name + "_bootstrap"] = round(dt, 2)
        out["stacks"][name] = {"admitted": adm, "seeded_admitted": sorted(set(adm) & set(design["seeded"])),
                               "lowest_point": min(adm, key=brier.get), "named_winner": named_winner(adm, lower),
                               "n_pairs": len(res), "n_resolved": sum(v["resolved"] for v in res.values()),
                               "pairs": res}
    wf = rec["workflows"]["Contract"]
    out["contract"] = {"admitted": [c for c in preds if all(gates[c][g] for g in ("name_passed", "value_passed", "role_passed"))],
                       "named_winner": wf["winner"]}
    s1, s2 = out["stacks"]["T1_evaltoolkit"], out["stacks"]["T2_evaltoolkit_plus_name_gate"]
    out["expectations"] = {"E1_group_check_refuses_C_overlap": "GroupLeakageCheck" in audit["C_overlap"]["refused_by"],
                           "E2_T1_admits_feature_defects": all(c in s1["admitted"] for c in ("C_label", "C_id", "C_weight")),
                           "E3_T1_lowest_point_C_label": s1["lowest_point"] == "C_label",
                           "E4_T2_admits_C_weight": "C_weight" in s2["admitted"]}
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    json.dump(out, open(out_path, "w"), indent=2)
    print(json.dumps({k: out[k] for k in ("tool", "expectations", "contract", "runtime_seconds")}, indent=2))
    for n, s in out["stacks"].items():
        print(n, {k: s[k] for k in ("admitted", "lowest_point", "named_winner", "n_pairs", "n_resolved")})
    print({c: a["refused_by"] for c, a in audit.items()})


if __name__ == "__main__":
    main()
