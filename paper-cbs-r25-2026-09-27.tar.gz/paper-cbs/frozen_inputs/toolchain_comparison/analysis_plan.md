# Post hoc executed tool comparison on the frozen readmission arm (eval-toolkit 1.12.0)

Status: post hoc. Written and committed locally before execution (no external
timestamp). It uses only the frozen readmission artifacts (`raw_data.zip`,
`results.json`, hash-checked against `hash_manifest.json`) and refits nothing.

## Question
Which of the contract's refusals and decisions does the nearest executable
binary-classification evaluation stack reproduce when it is run, as shipped, on
the same frozen candidates?

## Tool
eval-toolkit 1.12.0 (source archive of the public GitHub `main` branch,
SHA-256 recorded; vendored under `vendor/`). PyPI was not reachable from the
execution host, so the source archive is imported via `PYTHONPATH`. Deepchecks
could not be installed offline (notebook-UI dependencies) and is not executed.

## Stacks
- **T1 (eval-toolkit as shipped).** For each candidate, the training manifest
  (construction rows, or the frozen Bernoulli 75% sample for C_overlap) and the
  scored holdout are passed as `train`/`holdout` slices to
  `run_leakage_checks([GroupLeakageCheck(group_col="patient_nbr"),
  CrossSplitLeakageCheck(strategy=ExactNormalizedHashStrategy())])`, with the
  encounter_id as the slice text. A candidate is refused if any error-severity
  finding affects at least one row. Admitted candidates are compared with
  `paired_bootstrap_diff(y, p_a, p_b, brier_score)` (tool defaults: 1,000
  row-level resamples, 95%, seed 42). A pair is resolved if the interval
  excludes zero (the tool's `overlaps_zero`); no multiplicity correction (none
  is shipped). Named winner: the unique admitted candidate resolved better than
  every other admitted candidate; otherwise none.
- **T2 (T1 plus an exact declared-schema name gate).** T1 admission and the
  contract's recorded name-gate outcome.

eval-toolkit's leakage checks see row identities and group ids, not feature
columns, so no eval-toolkit check is configured for feature names or values.

## Outputs
Per candidate: findings and refusing checks. Per stack: admitted set, seeded
candidates admitted, lowest point Brier, named winner, number of resolved pairs,
per-pair intervals; runtime of checks and bootstrap; number of configuration
statements. The contract's recorded admitted set and winner are copied for
comparison.

## Expectations (declared before execution)
- E1: GroupLeakageCheck refuses C_overlap.
- E2: T1 admits C_label, C_id and C_weight.
- E3: T1's lowest point Brier is C_label.
- E4: T2 admits C_weight.

No outcome of this comparison changes any frozen readmission result.
