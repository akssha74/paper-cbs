#!/usr/bin/env python3
"""Offline verification of the prospective DYFI 2025-2026 run.

Checks the retained raw payload hash, re-derives eligibility and the value gate
from the raw bytes, and recomputes scores, the ten CR1/CR3/event-level pairs,
Holm decisions, hypotheses, and comparator-workflow decisions from the released
holdout rows and predictions. Floats are compared within RTOL/ATOL; counts,
identities, admitted sets, selections, and Holm decisions must match exactly.
Exits nonzero on any mismatch.
"""
from __future__ import annotations

import gzip
import hashlib
import itertools
import json
import math
import platform
import sys
from pathlib import Path

import numpy as np
import scipy
import sklearn
from scipy.stats import t as student_t
from sklearn.metrics import roc_auc_score

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if (ROOT / "results").exists():
    FILES = {"results": ROOT / "results" / "results.json",
             "raw": ROOT / "results" / "raw_payload.geojson.gz",
             "rows": ROOT / "results" / "holdout_rows.jsonl.gz",
             "design": ROOT / "prereg" / "frozen_design.json"}
else:
    FILES = {"results": HERE / "prospective_dyfi_2025.json",
             "raw": HERE / "prospective_dyfi_2025_raw_payload.geojson.gz",
             "rows": HERE / "prospective_dyfi_2025_holdout_rows.jsonl.gz",
             "design": HERE / "prospective_dyfi_2025_frozen_design.json"}
RTOL = 1e-9
ATOL = 1e-12
MIN_RESPONSES = 10


def close(a, b, path=""):
    if isinstance(a, bool) or isinstance(b, bool) or a is None or b is None:
        return [] if a == b and type(a) is type(b) else [path]
    if isinstance(a, float) or isinstance(b, float):
        if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
            return [path]
        return [] if math.isclose(a, b, rel_tol=RTOL, abs_tol=ATOL) else [path]
    if isinstance(a, dict) and isinstance(b, dict):
        if set(a) != set(b):
            return [path + ":keys"]
        return [m for k in a for m in close(a[k], b[k], f"{path}.{k}")]
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return [path + ":len"]
        return [m for i, (x, z) in enumerate(zip(a, b)) for m in close(x, z, f"{path}[{i}]")]
    return [] if a == b else [path]


def cr1(d, groups):
    point = float(np.mean(d))
    g = np.asarray(groups, dtype=object)
    uniq = sorted(set(g.tolist()), key=str)
    infl = np.asarray([np.sum(d[g == u] - point) for u in uniq])
    G = len(uniq)
    se = float(np.sqrt(G / (G - 1.0) * np.sum(infl ** 2)) / d.size)
    if se == 0.0:
        return point, 0.0, 1.0, G - 1
    return point, se, float(2 * student_t.sf(abs(point / se), G - 1)), G - 1


def cr3(d, groups):
    g = np.asarray(groups, dtype=object)
    uniq = sorted(set(g.tolist()), key=str)
    G = len(uniq)
    loo = np.asarray([float(np.mean(d[g != u])) for u in uniq])
    se = float(np.sqrt((G - 1.0) / G * np.sum((loo - loo.mean()) ** 2)))
    if se == 0.0:
        return 1.0
    return float(2 * student_t.sf(abs(float(np.mean(d)) / se), G - 1))


def holm(pvals, alpha):
    order = sorted(range(len(pvals)), key=lambda i: pvals[i])
    rej = [False] * len(pvals)
    for k, i in enumerate(order):
        if pvals[i] <= alpha / (len(pvals) - k):
            rej[i] = True
        else:
            break
    return rej


def logloss(y, p):
    p = np.clip(p, 1e-15, 1 - 1e-15)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def fail(msg):
    print(json.dumps({"verified": False, "error": msg}))
    raise SystemExit(1)


def main():
    frozen = json.loads(FILES["results"].read_text())
    design = json.loads(FILES["design"].read_text())
    raw_gz = FILES["raw"].read_bytes()
    if hashlib.sha256(raw_gz).hexdigest() != frozen["provenance"]["raw_payload_gz_sha256"]:
        fail("raw payload gzip hash")
    raw = gzip.decompress(raw_gz)
    if hashlib.sha256(raw).hexdigest() != frozen["provenance"]["payload_sha256"]:
        fail("raw payload hash")
    payload = json.loads(raw.decode("utf-8"))
    feats = payload["features"]
    if len(feats) != frozen["provenance"]["payload_features"]:
        fail("payload feature count")
    elig, mags, deps = [], [], []
    for f in feats:
        p = f.get("properties") or {}
        if p.get("cdi") is None or p.get("felt") is None or float(p["felt"]) < MIN_RESPONSES:
            continue
        c = (f.get("geometry") or {}).get("coordinates") or []
        mags.append(p.get("mag"))
        deps.append(c[2] if len(c) > 2 else None)
        elig.append(f.get("id"))
    if len(elig) != frozen["cohort"]["eligibility"]["n_eligible"]:
        fail("eligibility count")
    for name, v in (("magnitude", mags), ("depth_km", deps)):
        pres = [float(x) for x in v if x is not None]
        g = frozen["value_gate"]["fields"][name]
        if close([1.0 - len(pres) / len(v), float(np.var(pres))], [g["missing_fraction"], g["variance"]]):
            fail(f"value gate {name}")

    with gzip.open(FILES["rows"], "rt") as fh:
        hold = [json.loads(line) for line in fh if line.strip()]
    if len(hold) != frozen["cohort"]["n_holdout"] or not {r["event_id"] for r in hold} <= set(elig):
        fail("holdout rows")
    y = np.asarray([r["severe_label"] for r in hold], dtype=float)
    if [int(r["max_cdi"] >= design["severe_threshold"]) for r in hold] != [int(v) for v in y]:
        fail("labels")
    if int(y.sum()) != frozen["cohort"]["positives"]:
        fail("positives")
    preds = {k: np.asarray(v, dtype=float) for k, v in frozen["holdout_predictions"].items()}
    digest = hashlib.sha256(json.dumps({k: [round(float(x), 12) for x in v] for k, v in preds.items()},
                                       sort_keys=True).encode()).hexdigest()
    if digest != frozen["holdout_predictions_digest"]:
        fail("prediction digest")

    per = {}
    for c, p in preds.items():
        per[c] = {"brier": float(np.mean((p - y) ** 2)), "log_loss": logloss(y, p),
                  "auroc": float(roc_auc_score(y, p)) if np.unique(p).size > 1 else None,
                  "brier_by_threshold": {str(t): float(np.mean((p - np.asarray(
                      [float(r["max_cdi"] >= t) for r in hold])) ** 2)) for t in design["threshold_sensitivity"]}}
    bad = close(per, frozen["per_candidate"], "per_candidate")
    if bad:
        fail(f"scores {bad}")
    g_h = [r["sequence_id"] for r in hold]
    e_h = [r["event_id"] for r in hold]
    adm = list(design["candidates"])
    pairs = list(itertools.combinations(adm, 2))
    rows = []
    for a, b in pairs:
        d = (y - preds[a]) ** 2 - (y - preds[b]) ** 2
        pt, se, p1, df = cr1(d, g_h)
        rows.append({"a": a, "b": b, "mean_diff_a_minus_b": pt, "cr1_se": se, "cr1_p": p1, "df": df,
                     "event_level_p": cr1(d, e_h)[2], "cr3_p": cr3(d, g_h)})
    for key, name in (("cr1_p", "holm_cr1"), ("event_level_p", "holm_event_level"), ("cr3_p", "holm_cr3")):
        for r, x in zip(rows, holm([r[key] for r in rows], design["family_alpha"])):
            r[name] = bool(x)
    bad = close(rows, frozen["pairs"], "pairs")
    if bad:
        fail(f"pairs {bad}")
    for h, spec in design["hypotheses"].items():
        sup = True
        for a, b in spec["pairs"]:
            r = next(x for x in rows if {x["a"], x["b"]} == {a, b})
            diff = r["mean_diff_a_minus_b"] if r["a"] == a else -r["mean_diff_a_minus_b"]
            sup = sup and diff < 0 and r["holm_cr1"]
        if sup != frozen["hypotheses"][h]["supported"]:
            fail(f"hypothesis {h}")

    wf = frozen["workflows"]

    def best(cs):
        return min(cs, key=lambda c: per[c]["brier"])

    for k in ("W1_score_only", "W2_schema_validation", "W3_unpaired_intervals", "W4_event_paired_holm", "W5_contract"):
        if best(wf[k]["admitted"]) != wf[k]["selected"]:
            fail(f"selection {k}")
    if set(wf["W5_contract"]["admitted"]) != set(adm):
        fail("contract admitted set")
    w2 = wf["W2_schema_validation"]["admitted"]
    w4_pairs = list(itertools.combinations(w2, 2))
    w4_rej = holm([cr1((y - preds[a]) ** 2 - (y - preds[b]) ** 2, e_h)[2] for a, b in w4_pairs], design["family_alpha"])
    w4_claims = [f"{a}-{b}" for (a, b), r in zip(w4_pairs, w4_rej) if r and (a, b) in pairs]
    if w4_claims != wf["W4_event_paired_holm"]["claimed_pairs"]:
        fail("W4 claims")
    if [f"{r['a']}-{r['b']}" for r in rows if r["holm_cr1"]] != wf["W5_contract"]["claimed_pairs"]:
        fail("W5 claims")
    bs = design["w3_bootstrap"]
    idx = np.random.default_rng(bs["seed"]).integers(0, len(y), size=(bs["draws"], len(y)))
    ci = {c: [float(np.quantile(((preds[c] - y) ** 2)[idx].mean(axis=1), q)) for q in (0.025, 0.975)] for c in w2}
    if close(ci, wf["W3_unpaired_intervals"]["intervals"], "w3"):
        fail("W3 intervals")

    print(json.dumps({
        "verified": True,
        "environment": {"python": platform.python_version(), "numpy": np.__version__,
                        "scipy": scipy.__version__, "sklearn": sklearn.__version__, "platform": platform.platform()},
        "tolerance": {"rtol": RTOL, "atol": ATOL,
                      "exact": "hashes, counts, labels, admitted sets, selections, Holm decisions, hypotheses"},
        "payload_features": len(feats), "eligible": len(elig), "holdout": len(hold),
        "holm_cr1_rejections": sum(r["holm_cr1"] for r in rows),
        "hypotheses": {h: frozen["hypotheses"][h]["supported"] for h in design["hypotheses"]},
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
