#!/usr/bin/env python3
"""Offline verification of the reconstructed ShakeMap v1 rows and predictions."""
from __future__ import annotations

import gzip
import hashlib
import itertools
import json
import math
import platform
from pathlib import Path

import numpy as np
import scipy
import sklearn
from scipy.stats import t as student_t
from sklearn.metrics import roc_auc_score

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if (ROOT / "results").exists():
    RESULT_PATH = ROOT / "results" / "results.json"
    ROWS_PATH = ROOT / "results" / "v1_event_rows.jsonl.gz"
else:
    RESULT_PATH = HERE / "contract_transfer_shakemap_v1.json"
    ROWS_PATH = HERE / "contract_transfer_shakemap_v1_rows.jsonl.gz"
RTOL = 1e-9
ATOL = 1e-12


def close(a: object, b: object, path: str = "") -> list[str]:
    if isinstance(a, bool) or isinstance(b, bool) or a is None or b is None:
        return [] if a == b and type(a) is type(b) else [path]
    if isinstance(a, float) or isinstance(b, float):
        if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
            return [path]
        return [] if math.isclose(a, b, rel_tol=RTOL, abs_tol=ATOL) else [path]
    if isinstance(a, dict) and isinstance(b, dict):
        if set(a) != set(b):
            return [path + ":keys"]
        return [m for key in a for m in close(a[key], b[key], f"{path}.{key}")]
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return [path + ":len"]
        return [
            m
            for index, (left, right) in enumerate(zip(a, b))
            for m in close(left, right, f"{path}[{index}]")
        ]
    return [] if a == b else [path]


def seqstats(rows: list[dict]) -> dict:
    counts: dict[object, int] = {}
    for row in rows:
        counts[row["sequence_id"]] = counts.get(row["sequence_id"], 0) + 1
    sizes = sorted(counts.values(), reverse=True)
    return {
        "n_events": len(rows),
        "n_sequences": len(sizes),
        "n_singletons": sum(size == 1 for size in sizes),
        "largest": sizes[0] if sizes else 0,
        "n_multi_event_sequences": sum(size > 1 for size in sizes),
    }


def cr1(delta: np.ndarray, groups: list[object]) -> tuple[float, float, float, int]:
    point = float(np.mean(delta))
    group_array = np.asarray(groups, dtype=object)
    unique = sorted(set(group_array.tolist()), key=str)
    influence = np.asarray(
        [np.sum(delta[group_array == group] - point) for group in unique]
    )
    count = len(unique)
    se = float(
        np.sqrt(count / (count - 1.0) * np.sum(influence**2)) / delta.size
    )
    p_value = (
        1.0
        if se == 0.0
        else float(2 * student_t.sf(abs(point / se), count - 1))
    )
    return point, se, p_value, count - 1


def cr3(delta: np.ndarray, groups: list[object]) -> float:
    group_array = np.asarray(groups, dtype=object)
    unique = sorted(set(group_array.tolist()), key=str)
    count = len(unique)
    leave_one_out = np.asarray(
        [float(np.mean(delta[group_array != group])) for group in unique]
    )
    se = float(
        np.sqrt(
            (count - 1.0)
            / count
            * np.sum((leave_one_out - leave_one_out.mean()) ** 2)
        )
    )
    point = float(np.mean(delta))
    return (
        1.0
        if se == 0.0
        else float(2 * student_t.sf(abs(point / se), count - 1))
    )


def holm(p_values: list[float], alpha: float) -> list[bool]:
    order = sorted(range(len(p_values)), key=lambda index: p_values[index])
    decisions = [False] * len(p_values)
    for rank, index in enumerate(order):
        if p_values[index] <= alpha / (len(p_values) - rank):
            decisions[index] = True
        else:
            break
    return decisions


def logloss(y: np.ndarray, probabilities: np.ndarray) -> float:
    probabilities = np.clip(probabilities, 1e-15, 1 - 1e-15)
    return float(
        -np.mean(
            y * np.log(probabilities)
            + (1 - y) * np.log(1 - probabilities)
        )
    )


def main() -> int:
    frozen = json.loads(RESULT_PATH.read_text())
    with gzip.open(ROWS_PATH, "rt") as stream:
        rows = [json.loads(line) for line in stream if line.strip()]
    construction = [row for row in rows if row["role"] == "construction"]
    holdout = [row for row in rows if row["role"] == "holdout"]
    straddle = [row for row in rows if row["role"] == "straddle"]
    y = np.asarray([row["severe_label"] for row in holdout], dtype=float)
    candidates = list(frozen["per_candidate"])
    predictions = {
        candidate: np.asarray(
            [row["predictions"][candidate] for row in holdout], dtype=float
        )
        for candidate in candidates
    }
    digest = hashlib.sha256(
        json.dumps(
            {
                key: [round(float(value), 12) for value in values]
                for key, values in predictions.items()
            },
            sort_keys=True,
        ).encode()
    ).hexdigest()
    if digest != frozen["holdout_predictions_digest"]:
        raise SystemExit("prediction digest mismatch")
    cohort = {
        "n_raw_fdsn": frozen["cohort"]["n_raw_fdsn"],
        "skipped": frozen["cohort"]["skipped"],
        "n_labelled": len(rows),
        "construction": seqstats(construction),
        "holdout": seqstats(holdout),
        "straddle_events": len(straddle),
        "construction_prevalence": float(
            np.mean([row["severe_label"] for row in construction])
        ),
        "holdout_prevalence": float(y.mean()),
        "holdout_positives": int(y.sum()),
        "holdout_negatives": int(len(holdout) - y.sum()),
        "construction_depth_median": float(
            np.median([row["depth_km"] for row in construction])
        ),
        "depth_missing_construction": sum(
            row["depth_raw"] is None for row in construction
        ),
        "depth_missing_holdout": sum(
            row["depth_raw"] is None for row in holdout
        ),
        "evaluable": True,
    }
    bad = close(cohort, frozen["cohort"], "cohort")
    if bad:
        raise SystemExit(f"cohort mismatch: {bad}")

    thresholds = [
        float(value)
        for value in next(iter(frozen["per_candidate"].values()))[
            "brier_by_threshold"
        ]
    ]
    scores: dict[str, dict] = {}
    for candidate, probs in predictions.items():
        scores[candidate] = {
            "brier": float(np.mean((probs - y) ** 2)),
            "log_loss": logloss(y, probs),
            "auroc": (
                float(roc_auc_score(y, probs))
                if np.unique(probs).size > 1
                else None
            ),
            "brier_by_threshold": {
                str(threshold): float(
                    np.mean(
                        (
                            probs
                            - np.asarray(
                                [
                                    float(row["mmi"] >= threshold)
                                    for row in holdout
                                ]
                            )
                        )
                        ** 2
                    )
                )
                for threshold in thresholds
            },
        }
    bad = close(scores, frozen["per_candidate"], "per_candidate")
    if bad:
        raise SystemExit(f"score mismatch: {bad}")

    sequence_groups = [row["sequence_id"] for row in holdout]
    event_groups = [row["event_id"] for row in holdout]
    pairs: list[dict] = []
    for left, right in itertools.combinations(candidates, 2):
        delta = (y - predictions[left]) ** 2 - (y - predictions[right]) ** 2
        point, se, p_value, df = cr1(delta, sequence_groups)
        _, _, event_p, _ = cr1(delta, event_groups)
        pairs.append(
            {
                "a": left,
                "b": right,
                "mean_diff_a_minus_b": point,
                "cr1_se": se,
                "cr1_p": p_value,
                "event_level_p": event_p,
                "cr3_p": cr3(delta, sequence_groups),
                "df": df,
            }
        )
    for source, target in (
        ("cr1_p", "holm_cr1"),
        ("event_level_p", "holm_event_level"),
        ("cr3_p", "holm_cr3"),
    ):
        for row, decision in zip(
            pairs, holm([row[source] for row in pairs], 0.05)
        ):
            row[target] = bool(decision)
    bad = close(pairs, frozen["pairs"], "pairs")
    if bad:
        raise SystemExit(f"pairwise mismatch: {bad}")
    if [row["holm_cr1"] for row in pairs] != [
        row["holm_cr1"] for row in frozen["pairs"]
    ]:
        raise SystemExit("Holm decision mismatch")

    report = {
        "verified": True,
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "sklearn": sklearn.__version__,
            "platform": platform.platform(),
        },
        "tolerance": {
            "rtol": RTOL,
            "atol": ATOL,
            "exact": "counts, identities, keys, and Holm decisions",
        },
        "rows": len(rows),
        "holdout_predictions": len(holdout),
        "all_ten_pairs_match": True,
        "holdout_predictions_digest_recomputed": digest,
        "holm_cr1_rejections": sum(row["holm_cr1"] for row in pairs),
        "depth_missing_fraction": float(
            np.mean([row["depth_raw"] is None for row in rows])
        ),
        "depth_unique_construction": int(
            np.unique([row["depth_km"] for row in construction]).size
        ),
    }
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
