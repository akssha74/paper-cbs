# Diabetes contract transfer: results (one shot, evaluated)

Chronology (local Git, no external timestamp): plan `a2dedbdf` and runner
`87ee1198` committed 2026-09-26T20:17:03Z; recorded retrieval 20:17:10Z.
Public data and labels.

* Rows 101,766; holdout 25,410 encounters from 17,858 patients (4,179 with
  more than one encounter; largest 23); 2,925 readmitted within 30 days
  (11.5%). Construction 76,356 encounters.
* Core value gate passed for all 19 fields. `weight` 96.9%, `payer_code`
  39.6%, `medical_specialty` 49.1% missing.
* Holdout Brier: B0 0.10188, B1 0.09946, B2 0.09804, B4 0.09748, B5 0.09702;
  C_label 0.08524, C_id 0.09803, C_weight 0.09790, C_overlap 0.09295.
* Patient-cluster CR1 Holm rejects all ten admissible pairs; H1 and H2
  supported; the contract names B5 as the unique supported candidate.
* Encounter-level and patient-cluster Holm decisions agree on all ten pairs;
  cluster/encounter SE ratio median 1.07, max 1.36.
* Gates: name rejects C_label and C_id; value rejects C_weight; role audit
  rejects C_overlap (19,048 of its 76,447 training rows belong to holdout
  patients). All four pre-declared expectations met.
* Ablations: A1 admits all nine; A2 admits eight (rejects C_weight); A2b
  (exact names) admits seven including C_weight and C_overlap, whose point
  Brier is lowest; A3 and A4 name C_label as the unique winner; the contract
  names B5.
* Post hoc (`post_hoc_gate_ablations.json`): removing the name gate makes
  C_label the Holm-supported winner; removing the role audit makes C_overlap
  the winner; removing the value gate admits C_weight but B5 remains winner.
* Verifier: statistics reproduce under Python 3.11/scikit-learn 1.5.2 and
  Python 3.14/scikit-learn 1.9.1; full refit reproduces only under the
  pinned 3.11 environment.
