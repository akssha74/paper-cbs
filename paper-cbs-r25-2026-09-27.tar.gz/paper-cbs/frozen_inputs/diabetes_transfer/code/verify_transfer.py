#!/usr/bin/env python3
"""Offline verifier for the diabetes contract transfer.

Recomputes the cohort, labels, gates, scores, pair statistics, Holm decisions,
hypotheses, ablations, and expectations from the retained raw zip and stored
holdout predictions. With --refit it also refits every candidate and compares
predictions. Floats use rtol 1e-9 / atol 1e-12 (1e-6 for refit predictions);
counts, sets, labels, and decisions must match exactly.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import contract_diabetes as cd  # noqa: E402

RTOL, ATOL = 1e-9, 1e-12


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def compare(a, b, path, errs, rtol=RTOL, atol=ATOL):
    if isinstance(a, dict) and isinstance(b, dict):
        if set(a) != set(b):
            errs.append(f"{path}: keys {sorted(set(a) ^ set(b))}")
            return
        for k in a:
            compare(a[k], b[k], f"{path}.{k}", errs, rtol, atol)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            errs.append(f"{path}: length {len(a)} vs {len(b)}")
            return
        for i, (x, y) in enumerate(zip(a, b)):
            compare(x, y, f"{path}[{i}]", errs, rtol, atol)
    elif isinstance(a, bool) or isinstance(b, bool) or a is None or b is None or isinstance(a, str):
        if a != b:
            errs.append(f"{path}: {a!r} vs {b!r}")
    elif isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if not np.isclose(float(a), float(b), rtol=rtol, atol=atol):
            errs.append(f"{path}: {a} vs {b}")
    elif a != b:
        errs.append(f"{path}: {a!r} vs {b!r}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=os.path.join(os.path.dirname(HERE), "results"))
    ap.add_argument("--design", default=os.path.join(os.path.dirname(HERE), "prereg", "frozen_design.json"))
    ap.add_argument("--refit", action="store_true")
    a = ap.parse_args()
    design = json.load(open(a.design))
    rec = json.load(open(os.path.join(a.results, "results.json")))
    errs = []
    raw = open(os.path.join(a.results, "raw_data.zip"), "rb").read()
    if cd.sha_bytes(raw) != rec["provenance"]["raw_zip_sha256"]:
        errs.append("raw zip hash mismatch")
    rows, _ = cd.read_rows(raw, design["data_member_suffix"])
    preds = {k: np.asarray(v, dtype=float) for k, v in rec["holdout_predictions"].items()}
    digest = cd.sha_bytes(json.dumps({k: [round(float(x), 12) for x in v] for k, v in preds.items()},
                                     sort_keys=True).encode())
    if digest != rec["holdout_predictions_digest"]:
        errs.append("prediction digest mismatch")
    again = cd.evaluate(design, rows, preds, rec["declared_fields"], rec["manifest_overlaps_holdout"])
    for k, v in again.items():
        compare(v, rec[k], k, errs)

    unit = design["unit"]
    hold = [r for r in rows if cd.is_holdout_unit(r[unit], design)]
    hold_units = {r[unit] for r in hold}
    if a.refit:
        cons = [r for r in rows if not cd.is_holdout_unit(r[unit], design)]
        fits = {}
        for cid in design["candidates"]:
            fitted, info = cd.tune_and_fit(cid, cons, design)
            fits[cid] = info
            compare(info["best_params"] if "best_params" in info else info,
                    rec["fits"][cid]["best_params"] if "best_params" in rec["fits"][cid] else rec["fits"][cid],
                    f"refit.{cid}.params", errs)
            compare([float(x) for x in cd.predict(fitted, hold)], rec["holdout_predictions"][cid],
                    f"refit.{cid}.pred", errs, rtol=1e-6, atol=1e-9)
        for cid, spec in design["seeded"].items():
            fitted, train = cd.fit_seeded(cid, spec, cons, rows, fits, design)
            compare(any(r[unit] in hold_units for r in train), rec["manifest_overlaps_holdout"][cid],
                    f"refit.{cid}.overlap", errs)
            compare([float(x) for x in cd.predict_seeded(fitted, hold)], rec["holdout_predictions"][cid],
                    f"refit.{cid}.pred", errs, rtol=1e-6, atol=1e-9)

    summary = {"rows": len(rows), "holdout": len(hold), "holdout_patients": len(hold_units),
               "holm_cr1": again["n_holm_rejections_cr1"],
               "H1": again["hypotheses"]["H1"]["supported"], "H2": again["hypotheses"]["H2"]["supported"],
               "expectations": again["expectations"], "refit": a.refit, "mismatches": len(errs)}
    print(json.dumps(summary, indent=2))
    if errs:
        print("\n".join(errs[:50]))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
