#!/usr/bin/env python3
"""Post hoc (not in the frozen plan): replace the patient-level role audit by a row-identity check.

Training manifests are rebuilt without refitting (construction rows for every
candidate; the frozen Bernoulli seed for C_overlap). A candidate fails the
row-identity check if any training encounter_id is a scored holdout encounter.
Decisions reuse the stored holdout predictions with patient-cluster CR1 paired
Brier tests and Holm over every pair among the admitted set.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import contract_diabetes as cd  # noqa: E402


def main():
    design = json.load(open(os.path.join(ROOT, "prereg", "frozen_design.json")))
    res_dir = os.path.join(ROOT, "results")
    path = os.path.join(res_dir, "post_hoc_row_identity_ablation.json")
    if os.path.exists(path):
        sys.exit(f"refusing to overwrite {path}")
    rec_bytes = open(os.path.join(res_dir, "results.json"), "rb").read()
    rec = json.loads(rec_bytes)
    raw = open(os.path.join(res_dir, "raw_data.zip"), "rb").read()
    rows, _ = cd.read_rows(raw, design["data_member_suffix"])
    unit = design["unit"]
    hold = [r for r in rows if cd.is_holdout_unit(r[unit], design)]
    cons = [r for r in rows if not cd.is_holdout_unit(r[unit], design)]
    hold_enc = {r["encounter_id"] for r in hold}
    hold_units = {r[unit] for r in hold}
    y = np.asarray([cd.label(r, design) for r in hold], dtype=float)
    pat = [r[unit] for r in hold]
    preds = {k: np.asarray(v, dtype=float) for k, v in rec["holdout_predictions"].items()}
    gates = rec["gates"]

    manifests = {c: cons for c in design["candidates"]}
    for cid, spec in design["seeded"].items():
        if "train_fraction_encounters" in spec:
            rng = np.random.default_rng(design["random_state"])
            keep = rng.random(len(rows)) < spec["train_fraction_encounters"]
            manifests[cid] = [r for r, k in zip(rows, keep) if k]
        else:
            manifests[cid] = cons
    row_hits = {c: sum(r["encounter_id"] in hold_enc for r in m) for c, m in manifests.items()}
    unit_hits = {c: sum(r[unit] in hold_units for r in m) for c, m in manifests.items()}
    for c in preds:
        assert (unit_hits[c] > 0) == (not gates[c]["role_passed"]), c

    row_ok = {c: row_hits[c] == 0 for c in preds}
    variants = {
        "exact_schema_plus_row_identity": lambda c: gates[c]["name_passed"] and row_ok[c],
        "name_value_plus_row_identity": lambda c: gates[c]["name_passed"] and gates[c]["value_passed"] and row_ok[c],
    }
    out = {"status": "post_hoc", "source_results_sha256": hashlib.sha256(rec_bytes).hexdigest(),
           "training_rows_that_are_holdout_encounters": row_hits,
           "training_rows_of_holdout_patients": unit_hits, "variants": {}}
    for name, ok in variants.items():
        adm = [c for c in preds if ok(c)]
        pairs = list(itertools.combinations(adm, 2))
        stats = []
        for a, b in pairs:
            d = (y - preds[a]) ** 2 - (y - preds[b]) ** 2
            pt, _, p, _ = cd.cr1(d, pat)
            stats.append((p, pt))
        rej = cd.holm([s[0] for s in stats], design["family_alpha"])
        dec = {(a, b): ((a if s[1] < 0 else b) if x else None) for (a, b), x, s in zip(pairs, rej, stats)}
        out["variants"][name] = {
            "admitted": adm, "n_pairs_compared": len(pairs),
            "seeded_admitted": sorted(set(adm) & set(design["seeded"])),
            "lowest_point": min(adm, key=lambda c: float(np.mean((preds[c] - y) ** 2))),
            "winner": cd.winner(adm, dec),
            "supported_pairs": sorted(f"{a}-{b}" for (a, b), v in dec.items() if v is not None),
        }
    json.dump(out, open(path, "w"), indent=2)
    print(json.dumps({"row_hits": row_hits, "unit_hits": unit_hits,
                      **{k: {kk: v[kk] for kk in ("admitted", "lowest_point", "winner", "n_pairs_compared")}
                         for k, v in out["variants"].items()}}, indent=2))


if __name__ == "__main__":
    main()
