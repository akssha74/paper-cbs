#!/usr/bin/env python3
"""One-shot non-seismic contract transfer (diabetes 30-day readmission).

Refuses to run if the frozen-plan hashes mismatch or results exist. The raw zip
bytes are written and hashed before parsing. DRYRUN_ZIP/DRYRUN_OUT run the same
code on a synthetic file into a scratch directory.
"""
from __future__ import annotations

import datetime as dt
import gzip
import hashlib
import json
import os
import platform
import sys
import time
import urllib.request

import numpy as np
import scipy
import sklearn

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import contract_diabetes as cd  # noqa: E402

PREREG = os.path.join(ROOT, "prereg")


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def check_prereg():
    rec = json.load(open(os.path.join(PREREG, "prereg_hashes.json")))
    for f in ("analysis_plan.md", "frozen_design.json"):
        if sha(os.path.join(PREREG, f)) != rec[f]:
            raise SystemExit(f"frozen-plan hash mismatch: {f}")
    return rec


def get(url):
    last = None
    for attempt in range(1, 6):
        try:
            return urllib.request.urlopen(url, timeout=300).read()
        except Exception as exc:  # noqa: BLE001
            last = exc
            time.sleep(min(60, 2 ** attempt))
    raise SystemExit(f"retrieval failed: {last}")


def main():
    prereg = check_prereg()
    design = json.load(open(os.path.join(PREREG, "frozen_design.json")))
    dry = os.environ.get("DRYRUN_ZIP")
    results = os.environ.get("DRYRUN_OUT") if dry else os.path.join(ROOT, "results")
    os.makedirs(results, exist_ok=True)
    out_path = os.path.join(results, "results.json")
    raw_path = os.path.join(results, "raw_data.zip")
    if os.path.exists(out_path) or os.path.exists(raw_path):
        raise SystemExit("results already exist; one-shot refuses to overwrite")

    t_access = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    raw = open(dry, "rb").read() if dry else get(design["data_url"])
    with open(raw_path, "wb") as fh:
        fh.write(raw)
    rows, member = cd.read_rows(raw, design["data_member_suffix"])
    env = {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
           "sklearn": sklearn.__version__, "platform": platform.platform()}
    result = {"study": design["study"], "prereg_hashes": prereg, "dry_run": bool(dry),
              "provenance": {"access_utc": t_access, "url": design["data_url"], "member": member,
                             "raw_zip_sha256": cd.sha_bytes(raw), "n_rows": len(rows)},
              "environment": env}

    def finish(status):
        result["status"] = status
        json.dump(result, open(out_path, "w"), indent=2, default=str)
        man = {"results.json": sha(out_path), "raw_data.zip": sha(raw_path),
               "run_transfer.py": sha(os.path.abspath(__file__)),
               "contract_diabetes.py": sha(os.path.join(HERE, "contract_diabetes.py")),
               "analysis_plan.md": prereg["analysis_plan.md"], "frozen_design.json": prereg["frozen_design.json"]}
        hp = os.path.join(results, "holdout_rows.jsonl.gz")
        if os.path.exists(hp):
            man["holdout_rows.jsonl.gz"] = sha(hp)
        json.dump(man, open(os.path.join(results, "hash_manifest.json"), "w"), indent=2)
        print(json.dumps({k: result.get(k) for k in ("status", "provenance", "cohort", "n_holm_rejections_cr1",
                                                      "expectations", "dependence")}, indent=2, default=str))

    core_gate = {f: cd.value_gate_field(rows, f, design) for f in design["core_fields"]}
    result["core_value_gate"] = core_gate
    if not all(v["passed"] for v in core_gate.values()):
        return finish("refused_core_value_gate")
    unit = design["unit"]
    hold = [r for r in rows if cd.is_holdout_unit(r[unit], design)]
    cons = [r for r in rows if not cd.is_holdout_unit(r[unit], design)]
    y = np.asarray([cd.label(r, design) for r in hold], dtype=float)
    ev = design["evaluability"]
    if len(hold) < ev["min_holdout"] or min(y.sum(), len(y) - y.sum()) < ev["min_per_class"]:
        result["cohort"] = {"n_holdout": len(hold), "positives": int(y.sum())}
        return finish("non_evaluable")
    with gzip.GzipFile(os.path.join(results, "holdout_rows.jsonl.gz"), "wb", mtime=0) as fh:
        for r in hold:
            fh.write((json.dumps({"encounter_id": r["encounter_id"], unit: r[unit],
                                  "y": cd.label(r, design)}, sort_keys=True) + "\n").encode())

    hold_units = {r[unit] for r in hold}
    preds, fits, overlap, declared = {}, {}, {}, {}
    for cid in design["candidates"]:
        fitted, info = cd.tune_and_fit(cid, cons, design)
        preds[cid] = cd.predict(fitted, hold)
        fits[cid] = info
        overlap[cid] = False
        declared[cid] = [] if cid.startswith("B0") else cd.fields_for(cid, design)
    for cid, spec in design["seeded"].items():
        fitted, train = cd.fit_seeded(cid, spec, cons, rows, fits, design)
        preds[cid] = cd.predict_seeded(fitted, hold)
        overlap[cid] = any(r[unit] in hold_units for r in train)
        declared[cid] = cd.fields_for(spec["base"], design) + list(spec["declared_extra"])
        fits[cid] = {"base": spec["base"], "params": fits[spec["base"]]["best_params"], "n_train": len(train),
                     "n_train_holdout_patient_rows": sum(r[unit] in hold_units for r in train)}
    result.update(cd.evaluate(design, rows, preds, declared, overlap))
    result.update({
        "fits": fits, "declared_fields": declared, "manifest_overlaps_holdout": overlap,
        "holdout_predictions_digest": cd.sha_bytes(json.dumps(
            {k: [round(float(x), 12) for x in v] for k, v in preds.items()}, sort_keys=True).encode()),
        "holdout_predictions": {k: [float(x) for x in v] for k, v in preds.items()},
    })
    finish("evaluated")


if __name__ == "__main__":
    main()
