"""Shared data, model, gate, and inference code for the diabetes contract transfer."""
from __future__ import annotations

import csv
import hashlib
import io
import itertools
import zipfile

import numpy as np
from scipy.stats import t as student_t
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GroupKFold

ICD_GROUPS = ("circulatory", "respiratory", "digestive", "diabetes", "injury",
              "musculoskeletal", "genitourinary", "neoplasms", "other")


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def read_rows(zip_bytes, member_suffix):
    zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    names = [n for n in zf.namelist() if n.endswith(member_suffix)]
    if len(names) != 1:
        raise SystemExit(f"expected one {member_suffix} in zip, found {names}")
    text = zf.read(names[0]).decode("utf-8")
    return list(csv.DictReader(io.StringIO(text))), names[0]


def is_missing(v, design):
    return v is None or v.strip() in design["missing_tokens"]


def value_gate_field(rows, field, design):
    if not rows or field not in rows[0]:
        return {"present": False, "missing_fraction": 1.0, "distinct": 0, "passed": False}
    vals = [r[field] for r in rows]
    present = [v for v in vals if not is_missing(v, design)]
    miss = 1.0 - len(present) / len(vals)
    distinct = len(set(present))
    vg = design["value_gate"]
    return {"present": True, "missing_fraction": miss, "distinct": distinct,
            "passed": miss <= vg["max_missing_fraction"] and distinct >= vg["min_distinct"]}


def is_holdout_unit(unit, design):
    s = design["split"]
    h = int(hashlib.sha256(f"{s['salt']}:{unit}".encode()).hexdigest()[:8], 16)
    return h < s["holdout_fraction"] * 2 ** 32


def label(r, design):
    return int(r[design["endpoint"]["field"]] == design["endpoint"]["positive"])


def icd_group(code):
    c = (code or "").strip()
    if not c or c == "?" or c[0] in "VE":
        return "other"
    try:
        x = float(c)
    except ValueError:
        return "other"
    if 390 <= x < 460 or int(x) == 785:
        return "circulatory"
    if 460 <= x < 520 or int(x) == 786:
        return "respiratory"
    if 520 <= x < 580 or int(x) == 787:
        return "digestive"
    if int(x) == 250:
        return "diabetes"
    if 800 <= x < 1000:
        return "injury"
    if 710 <= x < 740:
        return "musculoskeletal"
    if 580 <= x < 630 or int(x) == 788:
        return "genitourinary"
    if 140 <= x < 240:
        return "neoplasms"
    return "other"


def age_mid(v):
    try:
        lo, hi = v.strip("[)").split("-")
        return (float(lo) + float(hi)) / 2.0
    except Exception:  # noqa: BLE001
        return np.nan


class Encoder:
    """Deterministic encoder fitted on construction rows for a declared field list."""

    def __init__(self, fields, design):
        self.fields = list(fields)
        self.design = design
        self.num = set(design["numeric_fields"])

    def _raw(self, r, f):
        if f == "age":
            return age_mid(r[f])
        if f == "diag_1":
            return icd_group(r[f])
        if f == "readmitted":
            return float(r[f] == ">30")
        if f == "patient_nbr":
            return float(r[f])
        if f in self.num:
            v = r[f]
            return np.nan if is_missing(v, self.design) else float(v)
        return r[f].strip()

    def _is_numeric(self, f):
        return f in self.num or f in ("age", "readmitted", "patient_nbr")

    def fit(self, rows):
        self.levels, self.stats = {}, {}
        for f in self.fields:
            vals = [self._raw(r, f) for r in rows]
            if self._is_numeric(f):
                a = np.asarray(vals, dtype=float)
                med = float(np.nanmedian(a))
                a = np.where(np.isnan(a), med, a)
                self.stats[f] = (med, float(a.mean()), float(a.std()) or 1.0)
            else:
                counts = {}
                for v in vals:
                    counts[v] = counts.get(v, 0) + 1
                self.levels[f] = sorted(v for v, n in counts.items() if n >= self.design["min_level_count"])
        return self

    def transform(self, rows):
        cols = []
        for f in self.fields:
            vals = [self._raw(r, f) for r in rows]
            if self._is_numeric(f):
                med, mu, sd = self.stats[f]
                a = np.asarray(vals, dtype=float)
                a = np.where(np.isnan(a), med, a)
                cols.append(((a - mu) / sd)[:, None])
            else:
                lv = self.levels[f]
                idx = {v: i for i, v in enumerate(lv)}
                m = np.zeros((len(rows), len(lv) + 1))
                for i, v in enumerate(vals):
                    m[i, idx.get(v, len(lv))] = 1.0
                cols.append(m)
        return np.hstack(cols) if cols else np.zeros((len(rows), 0))


def build(cid, params, design):
    rs = design["random_state"]
    if cid.startswith("B1") or cid.startswith("B2"):
        return LogisticRegression(C=params["C"], max_iter=5000)
    if cid.startswith("B4"):
        return RandomForestClassifier(n_estimators=300, max_features="sqrt", n_jobs=-1, random_state=rs,
                                      min_samples_leaf=params["min_samples_leaf"])
    if cid.startswith("B5"):
        return HistGradientBoostingClassifier(max_iter=200, learning_rate=params["learning_rate"],
                                              max_leaf_nodes=params["max_leaf_nodes"], early_stopping=False,
                                              random_state=rs)
    raise KeyError(cid)


def fields_for(cid, design):
    if cid.startswith("B1"):
        return ["number_inpatient"]
    return list(design["core_fields"])


def matrix(cid, rows, enc):
    x = enc.transform(rows)
    if cid.startswith("B1"):
        return np.log1p(np.maximum(x * enc.stats["number_inpatient"][2] + enc.stats["number_inpatient"][1], 0))
    return x


def grid(cid, design):
    g = design["grids"][cid]
    keys = sorted(g)
    return [dict(zip(keys, vals)) for vals in itertools.product(*(g[k] for k in keys))]


def tune_and_fit(cid, rows, design):
    y = np.asarray([label(r, design) for r in rows], dtype=float)
    if cid.startswith("B0"):
        return {"kind": "constant", "p": float(y.mean())}, {"prevalence": float(y.mean())}
    groups = np.asarray([r[design["unit"]] for r in rows])
    folds = list(GroupKFold(n_splits=design["cv_folds"]).split(np.zeros(len(rows)), y, groups))
    fields = fields_for(cid, design)
    cv = []
    for params in grid(cid, design):
        scores = []
        for tr, va in folds:
            tr_rows = [rows[i] for i in tr]
            va_rows = [rows[i] for i in va]
            enc = Encoder(fields, design).fit(tr_rows)
            m = build(cid, params, design).fit(matrix(cid, tr_rows, enc), y[tr])
            p = m.predict_proba(matrix(cid, va_rows, enc))[:, 1]
            scores.append(float(np.mean((p - y[va]) ** 2)))
        cv.append({"params": params, "mean_brier": float(np.mean(scores))})
    best = min(cv, key=lambda c: (c["mean_brier"], str(c["params"])))
    enc = Encoder(fields, design).fit(rows)
    m = build(cid, best["params"], design).fit(matrix(cid, rows, enc), y)
    return {"kind": "model", "cid": cid, "enc": enc, "model": m}, {"best_params": best["params"], "cv": cv}


def predict(fitted, rows):
    if fitted["kind"] == "constant":
        return np.full(len(rows), fitted["p"])
    x = matrix(fitted["cid"], rows, fitted["enc"])
    return np.asarray(fitted["model"].predict_proba(x)[:, 1], dtype=np.float64)


def fit_seeded(cid, spec, construction, full, fits, design):
    base = spec["base"]
    params = fits[base]["best_params"]
    fields = fields_for(base, design) + list(spec["declared_extra"])
    if "train_fraction_encounters" in spec:
        rng = np.random.default_rng(design["random_state"])
        keep = rng.random(len(full)) < spec["train_fraction_encounters"]
        train = [r for r, k in zip(full, keep) if k]
    else:
        train = construction
    y = np.asarray([label(r, design) for r in train], dtype=float)
    enc = Encoder(fields, design).fit(train)
    m = build(base, params, design).fit(enc.transform(train), y)
    return {"kind": "model", "cid": "seeded", "enc": enc, "model": m}, train


def predict_seeded(fitted, rows):
    return np.asarray(fitted["model"].predict_proba(fitted["enc"].transform(rows))[:, 1], dtype=np.float64)


def cr1(d, groups):
    point = float(np.mean(d))
    g = np.asarray(groups)
    uniq, inv = np.unique(g, return_inverse=True)
    infl = np.bincount(inv, weights=d - point)
    G = len(uniq)
    se = float(np.sqrt(G / (G - 1.0) * np.sum(infl ** 2)) / d.size)
    if se == 0.0:
        return point, 0.0, 1.0, G - 1
    return point, se, float(2 * student_t.sf(abs(point / se), G - 1)), G - 1


def cr3(d, groups):
    g = np.asarray(groups)
    uniq, inv = np.unique(g, return_inverse=True)
    G = len(uniq)
    tot, cnt = np.bincount(inv, weights=d), np.bincount(inv)
    loo = (d.sum() - tot) / (d.size - cnt)
    se = float(np.sqrt((G - 1.0) / G * np.sum((loo - loo.mean()) ** 2)))
    if se == 0.0:
        return 1.0
    return float(2 * student_t.sf(abs(float(np.mean(d)) / se), G - 1))


def holm(pvals, alpha):
    order = sorted(range(len(pvals)), key=lambda i: pvals[i])
    rej = [False] * len(pvals)
    m = len(pvals)
    for k, i in enumerate(order):
        if pvals[i] <= alpha / (m - k):
            rej[i] = True
        else:
            break
    return rej


def logloss(y, p):
    p = np.clip(p, 1e-15, 1 - 1e-15)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def scores(y, p):
    return {"brier": float(np.mean((p - y) ** 2)), "log_loss": logloss(y, p),
            "auroc": float(roc_auc_score(y, p)) if np.unique(p).size > 1 else None}


def winner(admitted, decided):
    """decided[(a, b)] = 'a' | 'b' | None; unique candidate better than every other admitted one."""
    wins = []
    for c in admitted:
        ok = True
        for d in admitted:
            if d == c:
                continue
            key = (c, d) if (c, d) in decided else (d, c)
            if decided.get(key) != c:
                ok = False
                break
        if ok:
            wins.append(c)
    return wins[0] if len(wins) == 1 else None


def evaluate(design, rows, preds, declared, manifests_overlap):
    """All statistics and decision rules from predictions; shared by runner and verifier."""
    hold = [r for r in rows if is_holdout_unit(r[design["unit"]], design)]
    y = np.asarray([label(r, design) for r in hold], dtype=float)
    pat = [r[design["unit"]] for r in hold]
    enc_ids = [r["encounter_id"] for r in hold]
    adm = list(design["candidates"])
    seeded = list(design["seeded"])
    all_c = adm + seeded
    per = {c: scores(y, preds[c]) for c in all_c}

    pairs = list(itertools.combinations(adm, 2))
    prow = []
    for a, b in pairs:
        d = (y - preds[a]) ** 2 - (y - preds[b]) ** 2
        pt, se, p1, df = cr1(d, pat)
        _, se_e, pe, _ = cr1(d, enc_ids)
        prow.append({"a": a, "b": b, "mean_diff_a_minus_b": pt, "cr1_se": se, "cr1_p": p1, "df": df,
                     "event_level_se": se_e, "event_level_p": pe, "cr3_p": cr3(d, pat)})
    for key, name in (("cr1_p", "holm_cr1"), ("event_level_p", "holm_event_level"), ("cr3_p", "holm_cr3")):
        for r, x in zip(prow, holm([r[key] for r in prow], design["family_alpha"])):
            r[name] = bool(x)
    lookup = {(r["a"], r["b"]): r for r in prow}

    hyp = {}
    for h, spec in design["hypotheses"].items():
        items = []
        for a, b in spec["pairs"]:
            r = lookup.get((a, b)) or lookup[(b, a)]
            diff = r["mean_diff_a_minus_b"] if (a, b) in lookup else -r["mean_diff_a_minus_b"]
            items.append({"better": a, "worse": b, "brier_diff_better_minus_worse": diff,
                          "direction_ok": diff < 0, "holm_cr1": r["holm_cr1"], "cr1_p": r["cr1_p"]})
        hyp[h] = {"pairs": items, "supported": all(i["direction_ok"] and i["holm_cr1"] for i in items)}

    allow = set(design["allowlist"])
    gates = {}
    for c in all_c:
        name_ok = all(f in allow for f in declared[c])
        vg = {f: value_gate_field(rows, f, design) for f in declared[c]}
        value_ok = all(v["passed"] for v in vg.values())
        role_ok = not manifests_overlap[c]
        gates[c] = {"name_passed": name_ok, "value_passed": value_ok, "role_passed": role_ok,
                    "value_detail": {f: {k: v[k] for k in ("missing_fraction", "distinct", "passed")}
                                     for f, v in vg.items()},
                    "admitted": name_ok and value_ok and role_ok}

    def a2_ok(c):
        return all(value_gate_field(rows, f, design)["passed"] for f in declared[c])

    def decided_from(test_pairs, rej):
        out = {}
        for (a, b), (x, diff) in zip(test_pairs, rej):
            out[(a, b)] = (a if diff < 0 else b) if x else None
        return out

    def adm_labels(dec):
        return sorted(f"{a}-{b}" for a, b in pairs if dec.get((a, b)) is not None)

    wf = {}
    lowest = lambda cs: min(cs, key=lambda c: per[c]["brier"])  # noqa: E731
    wf["A1_point_score_only"] = {"admitted": all_c, "lowest_point": lowest(all_c), "pair_labels": None,
                                 "winner": None}
    a2 = [c for c in all_c if a2_ok(c)]
    wf["A2_permissive_validation"] = {"admitted": a2, "lowest_point": lowest(a2), "pair_labels": None,
                                      "winner": None}
    a2b = [c for c in all_c if all(f in allow for f in declared[c])]
    wf["A2b_exact_schema"] = {"admitted": a2b, "lowest_point": lowest(a2b), "pair_labels": None,
                              "winner": None}

    bs = design["a3_bootstrap"]
    rng = np.random.default_rng(bs["seed"])
    idx = rng.integers(0, len(y), size=(bs["draws"], len(y)))
    ci = {}
    for c in a2:
        draws = ((preds[c] - y) ** 2)[idx].mean(axis=1)
        ci[c] = [float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))]
    a3_pairs = list(itertools.combinations(a2, 2))
    a3_dec = {}
    for a, b in a3_pairs:
        if ci[a][1] < ci[b][0]:
            a3_dec[(a, b)] = a
        elif ci[b][1] < ci[a][0]:
            a3_dec[(a, b)] = b
        else:
            a3_dec[(a, b)] = None
    wf["A3_unpaired_intervals"] = {"admitted": a2, "lowest_point": lowest(a2), "intervals": ci,
                                   "pair_labels": adm_labels(a3_dec), "winner": winner(a2, a3_dec)}

    a4_pairs = list(itertools.combinations(a2, 2))
    a4_stats = []
    for a, b in a4_pairs:
        d = (y - preds[a]) ** 2 - (y - preds[b]) ** 2
        pt, _, p, _ = cr1(d, enc_ids)
        a4_stats.append((p, pt))
    a4_rej = holm([s[0] for s in a4_stats], design["family_alpha"])
    a4_dec = decided_from(a4_pairs, [(x, s[1]) for x, s in zip(a4_rej, a4_stats)])
    wf["A4_encounter_paired_holm"] = {"admitted": a2, "lowest_point": lowest(a2), "family_size": len(a4_pairs),
                                      "pair_labels": adm_labels(a4_dec), "winner": winner(a2, a4_dec)}

    con = [c for c in all_c if gates[c]["admitted"]]
    con_pairs = list(itertools.combinations(con, 2))
    con_stats = []
    for a, b in con_pairs:
        d = (y - preds[a]) ** 2 - (y - preds[b]) ** 2
        pt, _, p, _ = cr1(d, pat)
        con_stats.append((p, pt))
    con_rej = holm([s[0] for s in con_stats], design["family_alpha"])
    con_dec = decided_from(con_pairs, [(x, s[1]) for x, s in zip(con_rej, con_stats)])
    wf["Contract"] = {"admitted": con, "lowest_point": lowest(con), "family_size": len(con_pairs),
                      "pair_labels": adm_labels(con_dec), "winner": winner(con, con_dec)}
    post = set(design["post_outcome"])
    for w in wf.values():
        w["seeded_admitted"] = sorted(set(w["admitted"]) & set(seeded))
        w["post_outcome_admitted"] = sorted(set(w["admitted"]) & post)

    s = set(seeded)
    expect = {
        "E1_A1_admits_all_seeded": s <= set(wf["A1_point_score_only"]["admitted"]),
        "E2_A2_rejects_only_C_weight": sorted(s - set(a2)) == ["C_weight"],
        "E3_A2b_rejects_label_id_admits_weight_overlap": (not ({"C_label", "C_id"} & set(a2b))
                                                          and {"C_weight", "C_overlap"} <= set(a2b)),
        "E4_contract_rejects_all_seeded": not (s & set(con)),
    }
    ratios = [r["cr1_se"] / r["event_level_se"] for r in prow if r["event_level_se"] > 0]
    units = {}
    for u in pat:
        units[u] = units.get(u, 0) + 1
    dependence = {
        "decision_differences_event_vs_cluster": sorted(f"{r['a']}-{r['b']}" for r in prow
                                                        if r["holm_cr1"] != r["holm_event_level"]),
        "n_decision_differences": sum(r["holm_cr1"] != r["holm_event_level"] for r in prow),
        "median_cluster_to_event_se_ratio": float(np.median(ratios)) if ratios else None,
        "max_cluster_to_event_se_ratio": float(np.max(ratios)) if ratios else None,
    }
    cohort = {"n_rows": len(rows), "n_holdout": len(hold), "n_construction": len(rows) - len(hold),
              "n_holdout_patients": len(units), "n_multi_encounter_patients": sum(v > 1 for v in units.values()),
              "largest_patient_cluster": max(units.values()) if units else 0,
              "encounters_in_multi_encounter_patients": sum(v for v in units.values() if v > 1),
              "positives": int(y.sum()), "negatives": int(len(y) - y.sum()),
              "prevalence": float(y.mean()) if len(y) else None}
    return {"cohort": cohort, "per_candidate": per, "pairs": prow, "hypotheses": hyp, "gates": gates,
            "workflows": wf, "expectations": expect, "dependence": dependence,
            "n_holm_rejections_cr1": sum(r["holm_cr1"] for r in prow),
            "n_holm_rejections_event_level": sum(r["holm_event_level"] for r in prow),
            "n_holm_rejections_cr3": sum(r["holm_cr3"] for r in prow),
            "negative_control_p": cr1(np.zeros(len(y)), pat)[2]}
