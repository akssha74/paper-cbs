#!/usr/bin/env python3
"""Post hoc (not in the frozen plan): the contract with one gate removed at a time.

Uses only the retained raw zip and stored holdout predictions; patient-cluster
CR1 paired Brier tests with Holm over every pair among the admitted set.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import contract_diabetes as cd  # noqa: E402


def main():
    design = json.load(open(os.path.join(ROOT, "prereg", "frozen_design.json")))
    res_dir = os.path.join(ROOT, "results")
    rec = json.load(open(os.path.join(res_dir, "results.json")))
    raw = open(os.path.join(res_dir, "raw_data.zip"), "rb").read()
    rows, _ = cd.read_rows(raw, design["data_member_suffix"])
    hold = [r for r in rows if cd.is_holdout_unit(r[design["unit"]], design)]
    y = np.asarray([cd.label(r, design) for r in hold], dtype=float)
    pat = [r[design["unit"]] for r in hold]
    preds = {k: np.asarray(v, dtype=float) for k, v in rec["holdout_predictions"].items()}
    gates = rec["gates"]
    variants = {
        "full_contract": ("name_passed", "value_passed", "role_passed"),
        "without_name_gate": ("value_passed", "role_passed"),
        "without_value_gate": ("name_passed", "role_passed"),
        "without_role_audit": ("name_passed", "value_passed"),
    }
    out = {"status": "post_hoc", "source_results_sha256": hashlib.sha256(
        open(os.path.join(res_dir, "results.json"), "rb").read()).hexdigest(), "variants": {}}
    for name, keys in variants.items():
        adm = [c for c in preds if all(gates[c][k] for k in keys)]
        pairs = list(itertools.combinations(adm, 2))
        stats = []
        for a, b in pairs:
            d = (y - preds[a]) ** 2 - (y - preds[b]) ** 2
            pt, _, p, _ = cd.cr1(d, pat)
            stats.append((p, pt))
        rej = cd.holm([s[0] for s in stats], design["family_alpha"])
        dec = {(a, b): ((a if s[1] < 0 else b) if x else None) for (a, b), x, s in zip(pairs, rej, stats)}
        out["variants"][name] = {
            "admitted": adm, "family_size": len(pairs),
            "seeded_admitted": sorted(set(adm) & set(design["seeded"])),
            "lowest_point": min(adm, key=lambda c: float(np.mean((preds[c] - y) ** 2))),
            "winner": cd.winner(adm, dec),
            "supported_pairs": sorted(f"{a}-{b}" for (a, b), v in dec.items() if v is not None),
        }
    path = os.path.join(res_dir, "post_hoc_gate_ablations.json")
    json.dump(out, open(path, "w"), indent=2)
    print(json.dumps({k: {kk: v[kk] for kk in ("seeded_admitted", "lowest_point", "winner", "family_size")}
                      for k, v in out["variants"].items()}, indent=2))


if __name__ == "__main__":
    main()
