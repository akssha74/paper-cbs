#!/usr/bin/env python3
"""Post hoc (not in any frozen plan): error-rate calibration under a cluster sign-flip null.

For each arm, the ten admissible pairwise Brier loss differences are centred
(so every pair is exactly null in mean) and multiplied by one Rademacher sign
per dependence unit, shared across pairs. This keeps the observed within-unit
and cross-pair dependence while making all ten nulls true. Each draw applies
the event-level and the unit-cluster CR1 paired t-tests with Holm (alpha 0.05)
over the ten pairs and records per-pair rejection and any-rejection (FWER).
"""
from __future__ import annotations

import gzip
import hashlib
import itertools
import json
import os

import numpy as np
from scipy.stats import t as student_t

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
INTEG = os.path.dirname(ROOT)
DRAWS, SEED, ALPHA = 4000, 20260927, 0.05


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def load_dyfi():
    res = os.path.join(INTEG, "prospective-dyfi-2025", "results")
    r = json.load(open(os.path.join(res, "results.json")))
    rows = [json.loads(line) for line in gzip.open(os.path.join(res, "holdout_rows.jsonl.gz"))]
    y = np.asarray([row["severe_label"] for row in rows], dtype=float)
    units = [row["sequence_id"] for row in rows]
    cands = ["B0_no_skill", "B1_magnitude_only_logit", "B2_source_only_logit", "B4_random_forest", "B5_xgboost"]
    return {"name": "dyfi_prospective_2025", "unit": "sequence", "y": y, "units": units,
            "preds": {c: np.asarray(r["holdout_predictions"][c]) for c in cands},
            "sources": {"results.json": sha(os.path.join(res, "results.json")),
                        "holdout_rows.jsonl.gz": sha(os.path.join(res, "holdout_rows.jsonl.gz"))}}


def load_diabetes():
    res = os.path.join(ROOT, "results")
    r = json.load(open(os.path.join(res, "results.json")))
    rows = [json.loads(line) for line in gzip.open(os.path.join(res, "holdout_rows.jsonl.gz"))]
    y = np.asarray([row["y"] for row in rows], dtype=float)
    units = [row["patient_nbr"] for row in rows]
    cands = ["B0_no_skill", "B1_inpatient_logit", "B2_core_logit", "B4_random_forest", "B5_hist_gbm"]
    return {"name": "diabetes_readmission", "unit": "patient", "y": y, "units": units,
            "preds": {c: np.asarray(r["holdout_predictions"][c]) for c in cands},
            "sources": {"results.json": sha(os.path.join(res, "results.json")),
                        "holdout_rows.jsonl.gz": sha(os.path.join(res, "holdout_rows.jsonl.gz"))}}


def holm_any(p):
    """p: (draws, m). Returns reject matrix under Holm step-down."""
    m = p.shape[1]
    order = np.argsort(p, axis=1)
    ps = np.take_along_axis(p, order, axis=1)
    thresh = ALPHA / (m - np.arange(m))
    ok = ps <= thresh
    keep = np.cumprod(ok, axis=1).astype(bool)
    rej = np.zeros_like(keep)
    np.put_along_axis(rej, order, keep, axis=1)
    return rej


def calibrate(arm):
    y, preds = arm["y"], arm["preds"]
    n = y.size
    uniq, inv = np.unique(np.asarray(arm["units"]), return_inverse=True)
    G = len(uniq)
    pairs = list(itertools.combinations(list(preds), 2))
    D = np.stack([(y - preds[a]) ** 2 - (y - preds[b]) ** 2 for a, b in pairs])
    D = D - D.mean(axis=1, keepdims=True)
    rng = np.random.default_rng(SEED)
    S = rng.choice([-1.0, 1.0], size=(DRAWS, G))
    sizes = np.bincount(inv, minlength=G).astype(float)
    p_ev = np.empty((DRAWS, len(pairs)))
    p_cl = np.empty((DRAWS, len(pairs)))
    for k in range(len(pairs)):
        tot = np.bincount(inv, weights=D[k], minlength=G)
        m = (S @ tot) / n
        se_ev = np.sqrt(n / (n - 1.0) * (np.sum(D[k] ** 2) - n * m ** 2)) / n
        csum = S * tot - m[:, None] * sizes
        se_cl = np.sqrt(G / (G - 1.0) * np.sum(csum ** 2, axis=1)) / n
        p_ev[:, k] = 2 * student_t.sf(np.abs(m) / se_ev, n - 1)
        p_cl[:, k] = 2 * student_t.sf(np.abs(m) / se_cl, G - 1)
    r_ev, r_cl = holm_any(p_ev), holm_any(p_cl)
    sizes = sizes.astype(int)
    return {
        "arm": arm["name"], "unit": arm["unit"], "n": int(n), "units": int(G),
        "multi_member_units": int((sizes > 1).sum()), "largest_unit": int(sizes.max()),
        "draws": DRAWS, "seed": SEED, "alpha": ALPHA, "sources": arm["sources"],
        "fwer_event_level_holm": float(r_ev.any(axis=1).mean()),
        "fwer_cluster_holm": float(r_cl.any(axis=1).mean()),
        "per_pair": [{"a": a, "b": b,
                      "unadjusted_rate_event": float((p_ev[:, k] <= ALPHA).mean()),
                      "unadjusted_rate_cluster": float((p_cl[:, k] <= ALPHA).mean())}
                     for k, (a, b) in enumerate(pairs)],
    }


def main():
    out = {"status": "post_hoc", "design": __doc__.strip(),
           "arms": [calibrate(load_dyfi()), calibrate(load_diabetes())]}
    path = os.path.join(ROOT, "results", "post_hoc_null_calibration.json")
    json.dump(out, open(path, "w"), indent=2)
    for a in out["arms"]:
        print(a["arm"], a["n"], a["units"], "FWER event", a["fwer_event_level_holm"], "cluster", a["fwer_cluster_holm"])
        for p in a["per_pair"]:
            print("   ", p["a"][:3], p["b"][:3], round(p["unadjusted_rate_event"], 3), round(p["unadjusted_rate_cluster"], 3))


if __name__ == "__main__":
    main()
