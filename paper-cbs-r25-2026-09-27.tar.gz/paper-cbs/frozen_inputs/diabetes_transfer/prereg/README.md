This directory holds an internally frozen analysis plan committed to a local Git repository before execution.
It is not an externally registered preregistration and carries no independent external timestamp.
The directory name is historical; the manuscript describes these plans as internally frozen.
