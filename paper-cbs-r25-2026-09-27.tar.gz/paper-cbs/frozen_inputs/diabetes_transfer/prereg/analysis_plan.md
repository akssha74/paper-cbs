# Non-seismic contract transfer: 30-day readmission on a patient-dependent table

Internally frozen (local Git commit) before this study retrieves the data file.
No external timestamp exists. The data and labels are public; "frozen" means
fixed before this study downloaded or read any row. Prior knowledge used in the
design comes only from the dataset documentation and the source article
(field list, the documented ~97% missingness of `weight`, repeated encounters
per patient); no row, label, prevalence, or prediction was computed before the
freeze.

## Purpose

The qualification contract was demonstrated on seismic catalogues only. This
arm executes the same contract components on a non-seismic table whose
dependence unit (patient) is declared in advance, so that each component can
be checked for whether it changes a decision:

1. name gate against a maintainer allowlist;
2. value-binding gate (missingness <= 20% and nonzero variation for every
   declared field);
3. role audit: the candidate's training manifest must share no dependence
   unit (patient) with the holdout;
4. patient-cluster CR1 paired Brier tests with Holm over the complete
   declared admissible family.

It is a retrospective transfer on public labels, not a prospective or hidden
test, and it is not a clinical model.

## Data

* UCI Machine Learning Repository dataset 296, "Diabetes 130-US Hospitals for
  Years 1999-2008" (CC BY 4.0), file `diabetic_data.csv`, retrieved once as
  the repository zip. The raw zip bytes are written and SHA-256 hashed before
  parsing.
* Missing tokens for every field: `?` and the empty string. All other values,
  including `None` and `Unknown/Invalid`, are categories.
* Endpoint: `y = 1` iff `readmitted == "<30"`, else 0.
* Dependence unit: `patient_nbr`.

## Roles

Deterministic patient-level assignment: a patient is holdout iff
`int(sha256("20260927:" + patient_nbr)[:8], 16) < 0.25 * 2**32`. All
encounters of holdout patients form the holdout; all other encounters form the
construction set. Patient-cluster CR1 uses the holdout patients as clusters.

## Maintainer allowlist (admission/discharge-time fields named by the source)

race, gender, age, weight, admission_type_id, discharge_disposition_id,
admission_source_id, time_in_hospital, payer_code, medical_specialty,
num_lab_procedures, num_procedures, num_medications, number_outpatient,
number_emergency, number_inpatient, diag_1, number_diagnoses, change,
diabetesMed, insulin, metformin.

## Admissible candidates

All declare the core field set (the allowlist minus `weight`, `payer_code`,
`medical_specialty`). Encoding is fixed: numeric fields as floats; `age` as the
bin midpoint; `diag_1` mapped to nine ICD-9 groups (circulatory, respiratory,
digestive, diabetes, injury, musculoskeletal, genitourinary, neoplasms,
other); remaining categoricals one-hot with levels seen >= 100 times in
construction and an `other` level.

* B0 no-skill: construction prevalence.
* B1 inpatient-history logit: logistic regression on log1p(number_inpatient);
  C in {0.01, 0.1, 1, 10}.
* B2 core logit: standardized logistic regression on all core fields;
  C in {0.01, 0.1, 1}.
* B4 random forest: 300 trees, max_features sqrt, min_samples_leaf in
  {20, 50, 100}, random_state 20260927.
* B5 histogram gradient boosting: max_iter 200, learning_rate in {0.03, 0.1},
  max_leaf_nodes in {15, 31}, random_state 20260927.

Tuning: 5-fold GroupKFold by patient on construction rows, minimum mean Brier;
refit once on all construction rows.

## Seeded submissions (each has a documented or common defect)

* C_label: B2 pipeline and B2's tuned C, plus the indicator
  `readmitted == ">30"` declared as `readmitted`. Post-outcome field.
* C_id: B2 plus standardized `patient_nbr`. Identifier, not in the allowlist.
* C_weight: B2 plus `weight`, `payer_code`, `medical_specialty` as categoricals
  (`?` kept as a level). Names are allowlisted; `weight` is documented as
  almost entirely missing.
* C_overlap: B4 pipeline and B4's tuned parameters trained on a random 75%
  encounter-level sample of the full table (seed 20260927), the common
  row-level split practice. Its fields are the core set; its training manifest
  includes holdout patients.

Seeded candidates are scored only to evaluate decision rules.

## Contract gates (executed before scoring; fail closed)

1. Evaluability and baseline value gate: every core field must pass the value
   gate on the full table, the holdout must have >= 1,000 encounters and
   >= 100 per class; otherwise scoring is refused and the refusal reported.
2. Per candidate: name gate (every declared field in the allowlist), value
   gate (every declared field missing <= 20% of full-table rows and >= 2
   distinct values), and role audit (training-manifest patients disjoint
   from holdout patients). Any failure rejects the candidate.

## Confirmatory hypotheses (patient-cluster CR1, t(G-1), Holm alpha 0.05 over the ten admissible pairs)

* H1 (primary): B1, B2, B4, B5 each have lower holdout Brier than B0 and all
  four pairs are Holm-rejected.
* H2 (secondary): B2, B4, B5 each have lower holdout Brier than B1 and all
  three pairs are Holm-rejected.
* Pairs among B2, B4, B5 are descriptive.
* Dependence contrast (descriptive, no direction assumed): the number of the
  ten admissible pairs whose Holm decision differs between encounter-level
  and patient-cluster tests, and the median ratio of cluster to encounter
  standard errors.

## Decision-rule ablations (synthetic; they do not execute named tools)

Same holdout predictions for all nine candidates.

* A1 point-score only: admit all.
* A2 permissive declared-field validation: admit iff each candidate-declared
  field exists as a column, is missing <= 20%, and has >= 2 distinct values.
* A2b exact maintainer schema: admit iff every declared field is in the
  allowlist (names only).
* A3 unpaired intervals: after A2, encounter bootstrap (2,000 draws, seed
  20260927) 95% Brier intervals; a pair label requires disjoint intervals.
* A4 encounter-level paired tests: after A2, paired t-tests over all admitted
  pairs, Holm alpha 0.05.
* Contract: gates, then patient-cluster CR1 Holm over the ten admissible pairs.

Reported per rule: admitted set, lowest point Brier (descriptive), pair labels
among the ten admissible pairs, and winner (a unique candidate supported
against every other admitted candidate, else none).

Pre-declared expectations (reported as met or not met):
E1 A1 admits all four seeded candidates; E2 among seeded candidates A2
rejects only C_weight; E3 A2b rejects C_label and C_id and admits C_weight
and C_overlap; E4 the contract rejects all four seeded candidates.

## Outputs

`results/results.json` (one shot; the runner refuses to overwrite),
`results/raw_data.zip`, `results/holdout_rows.jsonl.gz`,
`results/hash_manifest.json`, and a standalone offline verifier.
