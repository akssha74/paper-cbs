#!/usr/bin/env python3
"""Create an immutable, independently checkable derivative of the v2 transfer.

This is a retrospective release/reconstruction utility, not part of the
pre-score v2 analysis.  It downloads the same public FDSN query, keeps only the
scientific fields used by v2, reruns the frozen pipeline, and refuses to write
artifacts unless every reported cohort, score, pairwise result, and prediction
digest exactly matches the frozen v2 result.
"""
from __future__ import annotations

import datetime as dt
import gzip
import hashlib
import itertools
import json
import os
from pathlib import Path
import sys

import numpy as np
from sklearn.metrics import roc_auc_score

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESULTS = ROOT / "results"
sys.path.insert(0, str(HERE))

import run_shakemap_transfer_v2 as core  # noqa: E402


def canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def write_jsonl_gz(path: Path, records: list[dict]) -> str:
    payload = b"".join(canonical_bytes(record) + b"\n" for record in records)
    with path.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as out:
            out.write(payload)
    return sha_bytes(path.read_bytes())


def role_rows(
    rows: list[dict], design: dict
) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
    hold_start = dt.datetime.strptime(
        design["holdout_start"], "%Y-%m-%dT%H:%M:%SZ"
    )
    rows = core.decluster.assign_sequences(
        rows, design["space_km"], design["time_days"]
    )
    seq_times: dict[object, list[dt.datetime]] = {}
    for row in rows:
        when = dt.datetime.strptime(row["origin_time"], "%Y-%m-%dT%H:%M:%SZ")
        seq_times.setdefault(row["sequence_id"], []).append(when)
    for row in rows:
        times = seq_times[row["sequence_id"]]
        if max(times) < hold_start:
            row["role"] = "construction"
        elif min(times) >= hold_start:
            row["role"] = "holdout"
        else:
            row["role"] = "straddle"
        row["severe_label"] = int(row["mmi"] >= design["severe_threshold"])
    construction = [row for row in rows if row["role"] == "construction"]
    holdout = [row for row in rows if row["role"] == "holdout"]
    straddle = [row for row in rows if row["role"] == "straddle"]
    depths = [
        row["depth_raw"]
        for row in construction
        if row["depth_raw"] is not None
    ]
    depth_median = float(np.median(depths)) if depths else 10.0
    for row in rows:
        row["depth_km"] = (
            row["depth_raw"] if row["depth_raw"] is not None else depth_median
        )
    return rows, construction, holdout, straddle


def binding_audit(rows: list[dict], construction: list[dict]) -> dict:
    raw = np.asarray(
        [np.nan if row["depth_raw"] is None else row["depth_raw"] for row in rows],
        dtype=float,
    )
    values = np.asarray([row["depth_km"] for row in construction], dtype=float)
    missing_fraction = float(np.mean(np.isnan(raw)))
    unique = int(np.unique(values).size)
    passed = missing_fraction <= 0.20 and unique > 1 and float(np.std(values)) > 0
    return {
        "rule": "reject before scoring if missing fraction >0.20, construction "
        "variance is zero, or fewer than two unique construction values remain",
        "missing_fraction": missing_fraction,
        "construction_unique_values": unique,
        "construction_std": float(np.std(values)),
        "passed": passed,
    }


def main() -> int:
    frozen = json.loads((RESULTS / "results_v2.json").read_text())
    v1 = json.loads((RESULTS / "results.json").read_text())
    design = json.loads((ROOT / "prereg" / "frozen_design.json").read_text())
    exclusions = set(
        (ROOT / "prereg" / "frozen_dyfi_exclusion_ids.txt").read_text().split()
    )

    rows, skipped, payload_sha, n_raw = core.load_events(exclusions)
    rows, construction, holdout, straddle = role_rows(rows, design)
    audit = binding_audit(rows, construction)
    if not audit["passed"]:
        raise SystemExit(f"v2 binding audit failed: {audit}")

    v1_missing = v1["cohort"]["depth_missing_construction"] + v1["cohort"][
        "depth_missing_holdout"
    ]
    v1_total = (
        v1["cohort"]["construction"]["n_events"]
        + v1["cohort"]["holdout"]["n_events"]
    )
    v1_audit = {
        "missing_fraction": v1_missing / v1_total,
        "construction_unique_values_after_imputation": 1,
        "passed": False,
    }

    y_holdout = np.asarray([row["severe_label"] for row in holdout], dtype=float)
    specs = {spec.id: spec for spec in core.baselines.registry()}
    ledger = core.baselines.FitLedger()
    construction_groups = [row["sequence_id"] for row in construction]
    predictions: dict[str, np.ndarray] = {}
    fits: dict[str, dict] = {}
    for candidate in design["candidates"]:
        fitted = core.baselines.tune_and_fit(
            specs[candidate],
            construction,
            construction_groups,
            ledger,
            axis="temporal",
        )
        predictions[candidate] = core.baselines.predict_proba(fitted, holdout)
        fits[candidate] = {
            "best_params": fitted["best_params"],
            "cv_scores": fitted["cv_scores"],
        }

    per_candidate: dict[str, dict] = {}
    for candidate, probs in predictions.items():
        per_candidate[candidate] = {
            "brier": float(np.mean((probs - y_holdout) ** 2)),
            "log_loss": core.logloss(y_holdout, probs),
            "auroc": (
                float(roc_auc_score(y_holdout, probs))
                if np.unique(probs).size > 1
                else None
            ),
            "brier_by_threshold": {
                str(threshold): float(
                    np.mean(
                        (
                            probs
                            - np.asarray(
                                [
                                    float(row["mmi"] >= threshold)
                                    for row in holdout
                                ]
                            )
                        )
                        ** 2
                    )
                )
                for threshold in design["threshold_sensitivity"]
            },
        }

    sequence_groups = [row["sequence_id"] for row in holdout]
    event_groups = [row["event_id"] for row in holdout]
    pair_rows: list[dict] = []
    for left, right in itertools.combinations(design["candidates"], 2):
        delta = (y_holdout - predictions[left]) ** 2 - (
            y_holdout - predictions[right]
        ) ** 2
        point, se, _, p_value, df = core.cr1(delta, sequence_groups)
        _, _, _, event_p, _ = core.cr1(delta, event_groups)
        _, _, cr3_p = core.cr3(delta, sequence_groups)
        pair_rows.append(
            {
                "a": left,
                "b": right,
                "mean_diff_a_minus_b": point,
                "cr1_se": se,
                "cr1_p": p_value,
                "event_level_p": event_p,
                "cr3_p": cr3_p,
                "df": df,
            }
        )
    for source, target in (
        ("cr1_p", "holm_cr1"),
        ("event_level_p", "holm_event_level"),
        ("cr3_p", "holm_cr3"),
    ):
        decisions = core.holm(
            [row[source] for row in pair_rows], design["family_alpha"]
        )
        for row, decision in zip(pair_rows, decisions):
            row[target] = bool(decision)

    prediction_digest = sha_bytes(
        json.dumps(
            {
                key: [round(float(value), 12) for value in values]
                for key, values in predictions.items()
            },
            sort_keys=True,
        ).encode()
    )
    exact_checks = {
        "cohort": {
            "n_raw_fdsn": n_raw,
            "skipped": skipped,
            "n_labelled": len(rows),
            "construction": core.seqstats(construction),
            "holdout": core.seqstats(holdout),
            "straddle_events": len(straddle),
            "construction_prevalence": float(
                np.mean([row["severe_label"] for row in construction])
            ),
            "holdout_prevalence": float(y_holdout.mean()),
            "holdout_positives": int(y_holdout.sum()),
            "holdout_negatives": int(len(holdout) - y_holdout.sum()),
            "construction_depth_median": float(
                np.median([row["depth_km"] for row in construction])
            ),
            "depth_missing_construction": sum(
                row["depth_raw"] is None for row in construction
            ),
            "depth_missing_holdout": sum(
                row["depth_raw"] is None for row in holdout
            ),
            "evaluable": True,
        },
        "fits": fits,
        "per_candidate": per_candidate,
        "pairs": pair_rows,
        "holdout_predictions_digest": prediction_digest,
    }
    for field, observed in exact_checks.items():
        if observed != frozen[field]:
            raise SystemExit(f"reconstruction mismatch in {field}")

    release_rows: list[dict] = []
    holdout_index = {row["event_id"]: index for index, row in enumerate(holdout)}
    for row in sorted(rows, key=lambda item: (item["origin_time"], item["event_id"])):
        record = {
            key: row[key]
            for key in (
                "event_id",
                "origin_time",
                "latitude",
                "longitude",
                "magnitude",
                "depth_raw",
                "depth_km",
                "mmi",
                "sequence_id",
                "role",
                "severe_label",
            )
        }
        if row["event_id"] in holdout_index:
            index = holdout_index[row["event_id"]]
            record["predictions"] = {
                candidate: float(values[index])
                for candidate, values in predictions.items()
            }
        release_rows.append(record)

    rows_path = RESULTS / "v2_event_rows.jsonl.gz"
    rows_sha = write_jsonl_gz(rows_path, release_rows)
    projection_sha = sha_bytes(
        canonical_bytes(
            [
                {
                    key: record[key]
                    for key in (
                        "event_id",
                        "origin_time",
                        "latitude",
                        "longitude",
                        "magnitude",
                        "depth_raw",
                        "mmi",
                    )
                }
                for record in release_rows
            ]
        )
    )
    record = {
        "record_type": "retrospective_v2_release_reconstruction",
        "created_after_scoring": True,
        "claim_boundary": (
            "This record establishes exact reproducibility from a later retrieval "
            "whose scientific projection and predictions reproduce v2; it is not "
            "evidence that the original payload bytes were archived before scoring."
        ),
        "source_query": core.FDSN,
        "original_payload_sha256": frozen["payload_sha256"],
        "reconstruction_payload_sha256": payload_sha,
        "payload_bytes_differ": payload_sha != frozen["payload_sha256"],
        "scientific_projection_sha256": projection_sha,
        "event_rows": {
            "path": rows_path.name,
            "sha256": rows_sha,
            "n_rows": len(release_rows),
            "n_holdout_predictions": len(holdout),
        },
        "binding_audit": {"v1": v1_audit, "v2": audit},
        "exact_matches": {
            "cohort": True,
            "fits": True,
            "per_candidate": True,
            "all_ten_pairwise_records": True,
            "holdout_predictions_digest": prediction_digest,
            "holm_cr1_rejections": sum(row["holm_cr1"] for row in pair_rows),
        },
    }
    record_path = RESULTS / "reconstruction_v2.json"
    record_path.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
