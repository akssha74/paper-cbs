# Prospective DYFI 2025-2026 contract confirmation (pre-registered)

Frozen before any outcome-bearing (`/query`) retrieval for the window below.
Before freezing, the only live request against this window was the
outcome-free FDSN `/count` preflight (959 events for 2025-01-01..2026-07-01,
M>=5, producttype=dyfi), which returns an integer and no event fields. No
2025-2026 DYFI event, CDI value, felt count, or prediction for this window has
been read by this study.

## Purpose

The DYFI benchmark's Holm decisions (7/10) were labelled post hoc and the
ShakeMap v2 transfer was a corrective rerun. This arm executes the complete
qualification contract once, prospectively, on events that post-date the frozen
2015-2024 snapshot, with every gate, hypothesis, comparator workflow, and
success criterion fixed here. No amendment after retrieval is permitted; any
defect is reported, not repaired.

## Data

* Training (construction): the frozen release table
  `benchmark-resource/bundle/release/event_level_table.csv`, all rows except
  role `temporal_straddle_excluded` (2,360 events, 2015-2024), with their
  frozen `sequence_id` values as CV groups. Values are the frozen snapshot
  values; nothing in the training table is re-fetched.
* Prospective holdout: one FDSN `/query` GeoJSON retrieval,
  `minmagnitude=5, starttime=2025-01-01, endtime=2026-07-01,
  producttype=dyfi, eventtype=earthquake, orderby=time-asc, limit=20000`.
  The end date leaves at least 12 weeks of DYFI report accumulation before
  retrieval. The window is not extended or shortened after retrieval.
* The raw response bytes are written to disk (gzip) and SHA-256 hashed
  before any parsing. A `/count` preflight is taken immediately before the
  `/query`; if the payload feature count differs from that preflight by more
  than 5 events, the run refuses to score (drift receipt recorded).
* Eligibility is the frozen rule (`ingest_eligibility.parse_geojson`): CDI
  present and felt >= 10 responses; label `severe = max_cdi >= 6.0`;
  threshold sensitivity 5.5 and 6.5.
* Any prospective event ID present in the frozen table is dropped (none are
  expected; the count is reported).

## Sequences and roles

Frozen rows and prospective eligible rows are declustered jointly with the
frozen rule (single-link, 100 km, 30 days). A prospective event whose sequence
contains any pre-2025 event is `straddle` and is excluded from scoring. The
remaining prospective events form the holdout; their joint-decluster sequence
IDs are the inference clusters.

## Contract gates (executed before scoring; fail closed)

1. Name and role gate: `leakage_audit.audit_feature_names` against the
   two-field allowlist (`magnitude`, `depth_km`) and the temporal-axis audit,
   applied to every submitted candidate's declared fields.
2. Value-binding gate (the gate proposed after the ShakeMap v1 defect, now
   applied prospectively): `magnitude <- properties.mag`,
   `depth_km <- geometry.coordinates[2]`. Among payload features with CDI and
   felt >= 10, each allowlisted field must have missingness <= 20% and nonzero
   variance. Failure refuses scoring for every candidate.
3. Evaluability: >= 100 holdout events and >= 20 per class; otherwise the run
   reports non-evaluable and stops.

## Candidates

Admissible suite (unchanged from the paper): B0_no_skill,
B1_magnitude_only_logit, B2_source_only_logit, B4_random_forest, B5_xgboost,
each tuned by grouped CV on the construction rows with the frozen grids and
refit once (`baselines.tune_and_fit`, axis=temporal).

Seeded submissions (the paper's five), each the B2 pipeline with B2's tuned
regularisation plus extra fields: C_F1 (+max_cdi), C_F2 (+log1p num_responses),
C_F2_ren (the same values declared `n_reports`), C_year (+origin_year), C_geo
(+latitude, longitude). They are fit on construction rows and scored on the
holdout only to evaluate comparator workflows.

## Confirmatory hypotheses (sequence-cluster CR1, t(G-1), Holm alpha 0.05 over the ten admissible pairs)

* H1 (primary): each of B1, B2, B4, B5 has lower holdout Brier than B0, and
  all four pairs are Holm-rejected. Success requires all four.
* H2 (secondary): each of B2, B4, B5 has lower holdout Brier than B1, and all
  three pairs are Holm-rejected. Success requires all three.
* The three pairs among B2, B4, B5 carry no directional hypothesis and are
  reported descriptively.
* All ten p-values, the Holm decisions, the rejection count, and the point
  Brier/log-loss/AUROC of every candidate are reported whatever the outcome.
* Sensitivity (not confirmatory): event-level paired t-test with Holm, CR3
  jackknife with Holm, thresholds 5.5 and 6.5.

## Pre-declared comparator decision rules (capability emulations)

These are emulations of capability classes; they do not run the named tools.
All use the same holdout predictions for the ten submitted candidates.

* W1 score-only leaderboard: admit every candidate; select minimum Brier.
* W2 schema validation (TFDV-style): admit a candidate iff each declared field
  exists in the retrieved payload rows, is numeric, has missingness <= 20%,
  and nonzero variance; then select minimum Brier among admitted.
* W3 unpaired per-candidate intervals (TFMA-style): after W2 admission, event
  bootstrap (2,000 draws, seed 20260927) 95% interval for each admitted
  candidate's Brier; A is declared better than B iff A's interval lies entirely
  below B's.
* W4 dependence-unaware paired tests: after W2 admission, event-level paired
  t-tests over all admitted pairs with Holm alpha 0.05.
* W5 the contract: gates 1-2, then CR1 sequence-cluster paired tests with Holm
  over the admitted pairs.

Pre-declared decision outcomes per workflow: admitted set; selected candidate;
whether any post-outcome candidate (C_F1, C_F2, C_F2_ren) is admitted or
selected; number of superiority claims among the ten admissible pairs; and,
for W4 versus W5, the number of admissible pairs with different decisions.

Pre-declared expectations (reported as met or not met): W1-W4 admit all
seeded candidates and select C_F1; W5 rejects all five seeded candidates and
selects no post-outcome candidate.

## Outputs

`results/results.json` (one shot; the runner refuses to overwrite),
`results/raw_payload.geojson.gz`, `results/holdout_rows.jsonl.gz`,
`results/hash_manifest.json`, and a standalone tolerance-based verifier.
