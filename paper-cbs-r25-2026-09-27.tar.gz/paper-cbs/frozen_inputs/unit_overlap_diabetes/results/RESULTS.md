# Post hoc unit-only overlap seed: results

Plan frozen at commit 22a9dd70 (plan sha256 077523d1...) before execution;
run once in Python 3.11.15, numpy 1.26.4, scipy 1.13.1, scikit-learn 1.5.2.

* 4,179 repeat holdout patients; 7,552 donor rows (earlier encounters); one
  evaluated last encounter per patient (285 positives).
* C_ctrl reproduces the stored frozen B4 predictions on these rows.
* C_unit (76,356 training rows, equal to C_ctrl) passes the encounter-identity
  check and fails the patient-level role audit, as designed.
* Primary: Brier(C_ctrl) - Brier(C_unit) = -0.00267 (SE 0.00017, p < 1e-54).
  C_unit is worse, not optimistic. Pre-declared reading: no detectable optimism
  from patient-only overlap on this table.
* AUROC on the evaluated rows: C_unit 0.612, C_ctrl 0.615.
* Point-score rank on the evaluated rows: B0, B4, B2, B5, C_unit, B1. Under the
  row-check variant (15 pairs, Holm), 14 pairs are rejected and B0 is the unique
  winner.

Post hoc descriptive diagnostic (not in the plan,
`post_hoc_prevalence_diagnostic.json`): donor rows are 27.6% positive and the
evaluated last encounters are 6.8% positive (construction 11.0%). A within-30-day
readmission implies a later encounter, so earlier encounters are enriched for
positives and last encounters depleted. Training on donor rows therefore shifts
C_unit's calibration upward on the evaluated rows, and even the constant B0 is
best on Brier. The design confounds patient overlap with this ordering
selection; it cannot isolate an optimism effect, and it found none in Brier or
AUROC.

Consequence for the paper: on this table the contract's refusal of a
patient-overlapping, row-disjoint candidate is a policy consequence; no
optimistic score from patient-only overlap was demonstrated.
