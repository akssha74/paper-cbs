#!/usr/bin/env python3
"""Post hoc unit-only overlap seed on the frozen readmission table (one-shot)."""
from __future__ import annotations

import hashlib
import itertools
import json
import os
import platform
import sys

import numpy as np
import scipy
import sklearn
from scipy.stats import t as student_t

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ARM = os.path.join(os.path.dirname(ROOT), "contract-transfer-diabetes")
sys.path.insert(0, os.path.join(ARM, "code"))
import contract_diabetes as cd  # noqa: E402

PREREG = os.path.join(ROOT, "prereg")
RESULTS = os.path.join(ROOT, "results")
RAW_SHA = "f82ac129da2ddd2299391ff6fbae3a6a58b3edcf59ac9d7bd480c00fe453112a"


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def ttest(d):
    n = d.size
    m = float(d.mean())
    se = float(d.std(ddof=1) / np.sqrt(n))
    p = 1.0 if se == 0 else float(2 * student_t.sf(abs(m / se), n - 1))
    return m, se, p


def main():
    rec = json.load(open(os.path.join(PREREG, "prereg_hashes.json")))
    if sha(os.path.join(PREREG, "analysis_plan.md")) != rec["analysis_plan.md"]:
        raise SystemExit("plan hash mismatch")
    out = os.path.join(RESULTS, "results.json")
    if os.path.exists(out):
        raise SystemExit("results already exist; refusing to overwrite")
    os.makedirs(RESULTS, exist_ok=True)

    design = json.load(open(os.path.join(ARM, "prereg", "frozen_design.json")))
    frozen = json.load(open(os.path.join(ARM, "results", "results.json")))
    raw_path = os.path.join(ARM, "results", "raw_data.zip")
    if sha(raw_path) != RAW_SHA:
        raise SystemExit("raw archive hash mismatch")
    rows, _ = cd.read_rows(open(raw_path, "rb").read(), design["data_member_suffix"])
    unit = design["unit"]

    hold = [r for r in rows if cd.is_holdout_unit(r[unit], design)]
    cons = [r for r in rows if not cd.is_holdout_unit(r[unit], design)]
    hold_index = {r["encounter_id"]: i for i, r in enumerate(hold)}
    by_patient = {}
    for r in hold:
        by_patient.setdefault(r[unit], []).append(r)
    donors, evals = [], []
    for enc in by_patient.values():
        if len(enc) < 2:
            continue
        enc = sorted(enc, key=lambda r: int(r["encounter_id"]))
        donors.extend(enc[:-1])
        evals.append(enc[-1])
    eval_ids = {r["encounter_id"] for r in evals}
    hold_patients = set(by_patient)

    rng = np.random.default_rng(design["random_state"])
    cons_patients = sorted({r[unit] for r in cons})
    order = rng.permutation(len(cons_patients))
    counts = {}
    for r in cons:
        counts[r[unit]] = counts.get(r[unit], 0) + 1
    removed, n_removed = set(), 0
    for i in order:
        if n_removed >= len(donors):
            break
        p = cons_patients[i]
        removed.add(p)
        n_removed += counts[p]
    cons_reduced = [r for r in cons if r[unit] not in removed]
    train_unit = cons_reduced + donors

    params = frozen["fits"]["B4_random_forest"]["best_params"]
    fields = cd.fields_for("B4_random_forest", design)

    def fit(train):
        y = np.asarray([cd.label(r, design) for r in train], dtype=float)
        enc = cd.Encoder(fields, design).fit(train)
        m = cd.build("B4_random_forest", params, design).fit(cd.matrix("B4_random_forest", train, enc), y)
        return enc, m

    def pred(model, rs):
        enc, m = model
        return np.asarray(m.predict_proba(cd.matrix("B4_random_forest", rs, enc))[:, 1], dtype=np.float64)

    y = np.asarray([cd.label(r, design) for r in evals], dtype=float)
    idx = [hold_index[r["encounter_id"]] for r in evals]
    p_ctrl = pred(fit(cons), evals)
    p_unit = pred(fit(train_unit), evals)
    stored = {c: np.asarray(v, dtype=float)[idx] for c, v in frozen["holdout_predictions"].items()}
    ctrl_reproduces = bool(np.allclose(p_ctrl, stored["B4_random_forest"], rtol=1e-6, atol=1e-9))

    checks = {
        "C_ctrl": {"row_identity_passed": not any(r["encounter_id"] in eval_ids for r in cons),
                   "role_audit_passed": not any(r[unit] in hold_patients for r in cons), "n_train": len(cons)},
        "C_unit": {"row_identity_passed": not any(r["encounter_id"] in eval_ids for r in train_unit),
                   "role_audit_passed": not any(r[unit] in hold_patients for r in train_unit),
                   "n_train": len(train_unit), "n_donor_rows": len(donors),
                   "n_removed_construction_rows": n_removed, "n_removed_construction_patients": len(removed)},
    }
    loss_ctrl, loss_unit = (p_ctrl - y) ** 2, (p_unit - y) ** 2
    delta, se, p = ttest(loss_ctrl - loss_unit)
    primary = {"delta_brier_ctrl_minus_unit": delta, "se": se, "p_two_sided": p, "rejected": p <= 0.05,
               "reading": ("patient-only overlap produced an optimistic score admitted by a row-identity check"
                           if (p <= 0.05 and delta > 0) else
                           "no detectable optimism from patient-only overlap on this table")}

    cands = {"B0_no_skill": stored["B0_no_skill"], "B1_inpatient_logit": stored["B1_inpatient_logit"],
             "B2_core_logit": stored["B2_core_logit"], "B4_random_forest": stored["B4_random_forest"],
             "B5_hist_gbm": stored["B5_hist_gbm"], "C_unit": p_unit}
    sc = {c: cd.scores(y, v) for c, v in cands.items()}
    sc["C_ctrl"] = cd.scores(y, p_ctrl)
    rank = sorted(cands, key=lambda c: sc[c]["brier"])
    pairs = []
    for a, b in itertools.combinations(cands, 2):
        m_, s_, pv = ttest((cands[a] - y) ** 2 - (cands[b] - y) ** 2)
        pairs.append({"a": a, "b": b, "mean_diff_a_minus_b": m_, "p": pv})
    for pr, rej in zip(pairs, cd.holm([x["p"] for x in pairs], 0.05)):
        pr["holm"] = bool(rej)
    decided = {}
    for pr in pairs:
        if pr["holm"]:
            better = pr["a"] if pr["mean_diff_a_minus_b"] < 0 else pr["b"]
            decided[(pr["a"], pr["b"])] = better
    win = None
    for c in cands:
        others = [o for o in cands if o != c]
        if all(decided.get((c, o), decided.get((o, c))) == c for o in others):
            win = c

    result = {
        "status": "post_hoc_evaluated",
        "plan_sha256": rec["analysis_plan.md"],
        "raw_zip_sha256": RAW_SHA,
        "environment": {"python": platform.python_version(), "numpy": np.__version__,
                        "scipy": scipy.__version__, "sklearn": sklearn.__version__},
        "sets": {"n_holdout": len(hold), "n_holdout_patients": len(hold_patients),
                 "n_repeat_patients": len(evals), "n_donor_rows": len(donors), "n_eval_rows": len(evals),
                 "eval_positives": int(y.sum())},
        "b4_params": params,
        "ctrl_reproduces_stored_b4": ctrl_reproduces,
        "checks": checks,
        "primary": primary,
        "scores_on_E_R": sc,
        "point_rank_on_E_R": rank,
        "row_check_variant": {"pairs": pairs, "n_holm": sum(x["holm"] for x in pairs), "winner": win},
    }
    json.dump(result, open(out, "w"), indent=2)
    json.dump({"results.json": sha(out), "run_unit_overlap.py": sha(os.path.abspath(__file__)),
               "analysis_plan.md": rec["analysis_plan.md"]},
              open(os.path.join(RESULTS, "hash_manifest.json"), "w"), indent=2)
    print(json.dumps({k: result[k] for k in ("sets", "ctrl_reproduces_stored_b4", "checks", "primary",
                                             "point_rank_on_E_R")}, indent=2))
    print("winner", win)


if __name__ == "__main__":
    main()
