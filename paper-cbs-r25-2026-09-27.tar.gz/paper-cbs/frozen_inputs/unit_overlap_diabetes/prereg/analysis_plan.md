# Post hoc unit-only overlap seed on the frozen readmission table

Status: post hoc. Designed after the frozen readmission arm was scored and after
reviewers noted that its role-audit seed (C_overlap) trained on scored holdout
rows. This plan is committed locally before the runner is executed; no external
timestamp exists. It reuses the retained UCI archive (sha256 f82ac129...) and the
frozen readmission design (split salt, core fields, encoder, B4 hyperparameters).
Nothing in the frozen readmission results is changed.

## Question

Does a candidate whose training manifest shares patients, but no rows, with the
evaluated encounters obtain an optimistic holdout score? Such a candidate passes
a train/test encounter-identity check and fails the contract's patient-level
role audit, so the answer shows whether the unit-level audit changes a decision
beyond a row-identity check on this table.

## Sets

* Holdout patients H: frozen salted-hash rule (25% of patients).
* Repeat holdout patients R: patients in H with two or more encounters.
* For each patient in R, encounters are ordered by integer encounter_id (a
  proxy for time; the table has no admission date). The last encounter is an
  evaluation row; all earlier encounters are donor rows D.
* Primary evaluation set E_R: the last encounter of each patient in R (one row
  per patient).

## Candidates (B4 random forest, frozen best parameters from the readmission arm)

* C_ctrl: trained on all construction encounters (patients not in H). This is
  the frozen B4 fit; its predictions must reproduce the stored B4 holdout
  predictions on E_R (the frozen verifier's refit tolerance, rtol 1e-6, atol
  1e-9, in the pinned Python 3.11 environment) or the run is reported as a
  reproduction failure.
* C_unit: trained on construction encounters minus a size-matched set of
  construction patients, plus D. Construction patients are removed in a random
  order (numpy default_rng seed 20260927) until the removed encounter count is
  at least |D|, so C_unit trains on no more rows than C_ctrl.

## Checks (reported, applied to both candidates)

* Row-identity check: no training encounter_id equals an evaluated encounter_id.
* Role audit (contract): no training patient is in H.

Expected: C_ctrl passes both; C_unit passes the row-identity check and fails the
role audit.

## Primary estimand and test

Delta = Brier(C_ctrl) - Brier(C_unit) on E_R. Rows in E_R are one per patient,
so the paired test is a two-sided one-sample t test on per-row loss differences
(equivalently patient-cluster CR1 with singleton clusters), alpha 0.05.

Pre-declared reading:
* Delta > 0 and rejected: patient-only overlap produced an optimistic score that
  a row-identity check would admit; the patient-level audit changes the decision.
* Otherwise: no detectable optimism from patient-only overlap on this table; the
  audit's refusal of such a candidate is a policy consequence only.

## Secondary (descriptive)

* AUROC and log-loss of both candidates on E_R.
* Point-score rank of C_unit among B0, B1, B2, B4, B5 (stored frozen
  predictions restricted to E_R) and C_unit.
* Row-check variant: if C_unit were admitted by a row-identity check instead of
  the role audit, the unique winner under patient-level Holm over all 15 pairs
  of these six candidates on E_R.

No other analysis is run. Results are written once; the runner refuses to
overwrite.
