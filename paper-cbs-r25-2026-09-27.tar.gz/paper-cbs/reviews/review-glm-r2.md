# Independent Default-Reject Review — R2 (GLM-5.2)

**Manuscript:** *A Fail-Closed Qualification Contract for Comparing Machine-Learning Classifiers on Versioned, Dependent Event Data: A Seismic Felt-Intensity Case Study*
**Target venue:** *Cybernetics and Systems* (Taylor & Francis) — double-anonymous
**Revision:** R2
**Reviewer model:** GLM-5.2
**Date:** 2026-09-26

## Summary

R2 retitles the work as a *fail-closed qualification contract* plus a seismic felt-intensity case study, and the reframe is genuine: the abstract now states the two-feature (magnitude, depth) allowlist, the magnitude-dominated endpoint (B1 AUROC 0.719; B2 0.786), that generality beyond this dataset is untested, that B1 is the domain-simple comparator, that the split-assignment diagnostic is a point estimate only, and that B3 is a schema-policy exclusion rather than a leakage finding. R2 also adds the canonical classifier-comparison references (Dietterich, Demšar, Benavoli, Kapoor, Bergmeir), reports calibration intercepts/slopes and holdout recall, articulates transferable lessons, anonymizes data/code statements in the main text, contrasts the contract with a conventional point-score reading, and states the bootstrap estimand. The singleton misstatement from R1 is fixed (the text now says the ledger does not record a singleton count, so no singleton claim is made).

I verified every result-bearing number in the abstract, prose, Tables 2–6, and Supplementary Tables S1–S3 against `frozen_inputs/asset_inputs.json`. All match exactly (cohort 7,520→2,362→1,573/357/430/+2; 703/702 severe; 1,885/1,530/354 sequences; threshold sensitivity 0.458/0.351/0.260, Brier 0.240/0.181/0.143, AUROC 0.734/0.786/0.815; baseline Brier/log-loss/AUROC/calibration/accuracy for B0–B5; recall 0.25/0.32/0.29/0.37; all ten pairwise point differences and CIs; split diagnostic 0.2048/0.2009/0.1990 and −0.0059/−0.0124; temporal slices 0.185/0.797 and 0.174/0.777; geographic 82 cells, median 0.151, range 0.002–0.825). I verified all 42 bibliography entries resolve; the eight CBS-critical and method citations (Hossain & Sağ, Praveena, Gao MSB-Net, Hossack, Gomołka, Dietterich, Kapoor, Bergmeir) were confirmed against Crossref, and Demšar/Benavoli JMLR URLs and the EarthquakeNPP OpenReview record resolve. Blinding is clean: no GitHub URL, no `akssha74`/author names, no project name `dyfi-benchmark-reliability`, and no `v1.1.1` anywhere in `main.tex`, `supplement.tex`, `tables/*.tex`, or `references.bib`; identities are correctly confined to the separate title page.

## Scores (0–3 each, total /30)

| # | Criterion | Score |
|---|---|---|
| 1 | CBS venue fit | 3 |
| 2 | Novelty | 2 |
| 3 | Soundness | 2 |
| 4 | Numeric integrity | 3 |
| 5 | Claim calibration | 2 |
| 6 | Editor page-1 | 3 |
| 7 | Reproducibility | 3 |
| 8 | Related work/citations | 3 |
| 9 | Formatting/blinding | 3 |
| 10 | Usefulness | 2 |
| **Total** | | **26 / 30** |

## Verdict

**Major revisions.** Below the 28/30 acceptance bar. No vetoes.

## Vetoes

None. No fabricated citation (all 42 verified via Crossref/OpenAlex/publisher), no numeric mismatch (all result cells match `asset_inputs.json`), no blinding breach (main/supplement/tables/references clean; identities only on title page), not out of scope (CBS applied-AI/decision-systems fit is explicit), and no unsupported winner overclaim (the contract correctly leaves B2 vs B5 unresolved and claims no winner).

## Top required changes

1. **Fix the "four learned models improve over B1" overclaim (abstract + conclusion).** The abstract states "All four learned models improved on both the no-skill reference and the magnitude-only comparator," and the conclusion repeats "four learned candidates improve over no-skill and over magnitude-only B1." This is internally inconsistent: the four learned models evaluated on the holdout are B1, B2, B4, B5, and B1 *is* the magnitude-only comparator, so B1 cannot improve over itself. The body (Section 5.5) is correct — "B2, B4, and B5 each have a paired Brier interval below B1 as well as below B0" — so only *three* of the four beat B1. Reword to: "B1 improves over no-skill; B2, B4, and B5 each improve over both no-skill and the magnitude-only comparator B1." Apply the same correction to the conclusion and to the title-page abstract.

2. **Strengthen or explicitly bound the split-assignment diagnostic.** R2 demotes it to a point estimate and discloses the missing paired interval as a deviation (Supplementary Table S2), which is the right posture. However, the headline sentence "sequence grouping produced a Brier score 0.0059 lower and an AUROC 0.0124 higher than random-event splitting" still reads as a directional finding. Add a one-sentence caveat in the result paragraph (not just the note) that no paired interval was retained, so no sign claim — including the "slightly reversed" framing — is supported, only the point estimates are reportable.

3. **Confirm publication year for the two 2025 CBS precedents.** Crossref lists Hossain & Sağ (10.1080/01969722.2025.2588199) and Praveena & Prasanna Devi (10.1080/01969722.2025.2583968) with print date 2026 (online 2025; DOI year 2025). The manuscript cites them as 2025. If the journal's house style uses the print year, update; otherwise keep the online/DOI year and add "(online 2025; print 2026)" for transparency.

4. **Minor: estimand sentence in Section 5.5 is good but could move earlier.** The explicit statement that the Brier intervals quantify only resampling variation over the 354 holdout sequences given frozen fits (no training, hyperparameter, sequence-definition, or future-catalogue uncertainty) appears late. Surfacing this in Section 4.4 (where the bootstrap is defined) would head off a common misreading before the results.

## Detailed justification

**Venue fit (3).** Retitle, abstract, keywords, and five CBS precedents (Hossain & Sağ; Praveena & Prasanna Devi; Gao MSB-Net; Hossack; Gomołka) place this squarely in CBS's applied-AI/ML and decision-systems scope. The decision-support framing ("admit/reject" and "supported/unresolved" decisions preceding model adoption) matches the journal's environmental decision-system lineage.

**Novelty (2).** The authors explicitly disclaim component novelty ("No component is claimed as new") and position the contribution as a packaged, executable contract — timestamped hashed corpus + allowlist feature/proxy/role audits + outcome-independent sequence-grouped roles + temporal holdout + fixed baselines + paired Brier interval + exact reconstruction — for one task. The fail-closed qualification framing and the DYFI-specific combination are defensible-beyond-incremental, but no single component is new, generality is untested (single dataset), and the headline result is largely null (no winner). This is a legitimate contribution but not a 3.

**Soundness (2).** Methodology is largely sound: version pinning with SHA-256, outcome-independent role assignment (unit-tested to take no label argument), temporal holdout, paired sequence-cluster Brier intervals, calibration reporting, single-use authorization with deterministic replays, and full disclosure of exclusions/deviations. Two issues hold it to 2: (a) the abstract/conclusion overclaim in item 1 above; (b) the split-contrast interval was not retained, so a protocol-required uncertainty is missing (disclosed, but it leaves a headline contrast without inferential support).

**Numeric integrity (3).** Every reported number I checked matches `asset_inputs.json` to the rounding used in the paper. No hand-edited cells; claim ledger has 104 entries with zero flagged mismatches; reconstruction digest and result hash are recorded.

**Claim calibration (2).** Mostly excellent — no winner is claimed, generality is explicitly untested, the split contrast is descriptive, B3 is a schema-policy not a leakage finding, the holdout is "held out from development" but not "untouched/confirmatory," and near-zero bootstrap endpoints are interpreted cautiously. The single notable defect is the "four learned models improve over B1" overclaim (item 1), which is an unsupported statement in the abstract and conclusion that contradicts the body and Table 6.

**Editor page-1 (3).** Page 1 conveys goal, intended users, the two decisions, the two-feature allowlist, the magnitude-dominated endpoint, the untested-generality caveat, and the B1 comparator. An editor can understand the contribution identity in under a minute.

**Reproducibility (3).** Frozen SHA-256 source snapshot, pinned scientific-Python environment (NumPy 1.26.4, SciPy 1.13.1, scikit-learn 1.5.2, XGBoost 2.1.4), 120-fit cap (91 executed), fit-ledger digest, single-use authorization token with two deterministic replays, bit-for-bit prediction reconstruction, 110 unit tests across four suites, public anonymized review archive with manifests, datasheet + FAIR documentation. Best-in-class for this venue.

**Related work/citations (3).** 42 references span DYFI/macro-seismic data, felt-intensity ML, leakage taxonomies, classifier comparison (Dietterich, Demšar, Benavoli — all added in R2), blocked/temporal CV (Roberts, Bergmeir), and CBS venue precedents. Coverage of the closest same-source DYFI ML neighbor (Kumar et al.) and the LLM DYFI leakage test (Li et al.) is explicit. All citations resolve.

**Formatting/blinding (3).** Single-column, double-spaced, line-numbered; tables ≤15-word titles; five figures with captions outside artwork; vector + raster figures supplied. Main, supplement, tables, and references are fully blinded; identities and repository URL/version are correctly on the title page only. The only blemish is the 2025/2026 print-year ambiguity for two CBS precedents (item 3), which does not affect blinding.

**Usefulness (2).** The contract is a genuinely useful transparent audit harness: the worked example demonstrates a real decision change (B3 excluded; B2/B4/B5 supported over B0 and B1; B2 vs B5 left unresolved), the six-category audit rejects all seeded contamination, and the three transferable lessons (hash-pin benchmarks; paired intervals for every superiority claim; audit feature provenance against the evaluation axis) stand independently of the DYFI scores. Usefulness is bounded by single-dataset generality and the public-label / non-confirmatory status, which the authors state honestly; this caps the score at 2 rather than 3.

## Bottom line

This is a carefully done, well-calibrated, reproducible contribution that fits CBS and fixes most of R1's defects. It is not yet acceptance-ready because the abstract and conclusion contain an internal logical overclaim (four models beating a comparator that is itself one of the four) and the split-contrast inferential gap remains. Both are fixable without touching any frozen result. I recommend **major revisions** with the changes above; on satisfactory correction I would move to accept.
