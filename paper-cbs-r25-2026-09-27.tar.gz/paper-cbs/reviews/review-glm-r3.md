# Independent Default-Reject Review — R3 (GLM-5.2)

**Manuscript:** *A Fail-Closed Qualification Contract for Comparing Machine-Learning Classifiers on Versioned, Dependent Event Data: A Seismic Felt-Intensity Case Study*
**Target venue:** *Cybernetics and Systems* (Taylor & Francis) — double-anonymous
**Revision:** R3
**Reviewer model:** GLM-5.2
**Date:** 2026-09-26

## Summary

R3 is a clean, well-calibrated revision that resolves the substantive R2 defect. The abstract and conclusion no longer overclaim. The abstract now reads: "All four learned models improved on the no-skill reference. On descriptive unadjusted paired intervals, B2, B4, and B5 also improved on the magnitude-only comparator B1 (B1 cannot improve on itself)" — which is exactly correct, since B1 *is* the magnitude-only comparator. The conclusion mirrors this ("four learned candidates improve over no-skill, B2, B4, and B5 also improve over magnitude-only B1 on exploratory unadjusted intervals"). The body (Section 5.5) was already correct in R2 and remains so.

I verified every result-bearing number in the abstract, prose, Tables 2–6, and Supplementary Tables S1–3 against `frozen_inputs/asset_inputs.json` and the provenance numbers against `frozen_inputs/source_locator_manifest.json` and `claim_ledger.jsonl`. All match exactly: cohort 7,520→2,362→1,573/357/430/+2; 703/702 severe; 1,885/1,530/354 sequences; threshold sensitivity 0.458/0.351/0.260, Brier 0.240/0.181/0.143, AUROC 0.734/0.786/0.815; baseline Brier/log-loss/AUROC/calibration/recall for B0–B5; all ten pairwise point differences and CIs (B4-vs-B1 lower endpoint 0.0023; joint-ordering B2 prob-best 0.613); split diagnostic random 0.2048/0.6952/0.9640, event-grouped 0.2009/0.7058/0.9223, sequence-grouped 0.1990/0.7076/0.9709, Brier diff −0.0059, AUROC diff +0.0124, event-grouped Brier gap 0.0039; temporal slices 0.185/0.797 and 0.174/0.777; geographic 82 cells, median 0.151, range 0.002–0.825; provenance access instant 2026-09-01T06:33:30Z, preliminary 7,575→7,576, 50-second recount lag, 56-record prelim-minus-payload difference, 91/120 fits, three self-referential stale records, 110 unit tests (24+35+31+20). `cbs_validation_report.json` passes 42/42 checks.

Blinding of the manuscript PDF is clean: no GitHub URL, no `akssha74`, no author names, no `dyfi-benchmark-reliability`, no `v1.1.1` in `main.tex`, `supplement.tex`, `tables/*.tex`, or `references.bib`; identities are correctly confined to the separate title page.

## R3 fixes — all confirmed

| Fix | Status |
|---|---|
| B1 is NOT claimed to beat itself | ✓ (abstract line 55–58; conclusion line 730) |
| Four learned models beat B0 | ✓ |
| Only B2/B4/B5 beat B1 | ✓ (body, abstract, conclusion) |
| "unsupported winner" not "false winner" | ✓ (lines 65, 662, 734) |
| B1 comparisons labeled exploratory/unadjusted | ✓ (lines 56, 146, 394, 579, 586, 731) |
| Leakage audit demoted to two-field allowlist | ✓ (contribution #2; Section 4.1 body: "not a general leakage detector for arbitrary new covariates") |
| Split diagnostic has no sign inference | ✓ (lines 509–510: "no sign claim—including 'slightly reversed'—is inferentially supported") |
| Log-loss 0.9709 vs 0.9640 disclosed | ✓ (line 508–509) |
| Event-grouped is a second allocation, not a control | ✓ (line 518–519) |
| Intercept not treated as calibration-in-the-large | ✓ (lines 549–551) |
| Two (not three) changed decisions | ✓ (lines 656–660: B3 ineligible + B2-vs-B5 unresolved; B2/B4/B5 beating B1 explicitly "not a changed decision") |
| Provenance numbers in `claim_ledger.jsonl` | ✓ (P_access_instant, P_count_min, P_count_max, P_costamped, P_recount_lag_s, P_prelim_minus_payload) |

## Scores (0–3 each, total /30)

| # | Criterion | Score |
|---|---|---|
| 1 | CBS venue fit | 3 |
| 2 | Novelty | 2 |
| 3 | Soundness | 3 |
| 4 | Numeric integrity | 3 |
| 5 | Claim calibration | 3 |
| 6 | Editor page-1 | 3 |
| 7 | Reproducibility | 3 |
| 8 | Related work/citations | 3 |
| 9 | Formatting/blinding | 3 |
| 10 | Usefulness | 2 |
| **Total** | | **28 / 30** |

## Verdict

**Minor revisions.** At the 28/30 bar, I would accept with at most minor revisions. No vetoes.

## Vetoes

None. No fabricated citation (all 42 resolve; CBS precedents verified). No numeric mismatch (every checked cell matches `asset_inputs.json`/`source_locator_manifest.json`; 42/42 validation checks pass). No blinding breach in the manuscript PDF (main/supplement/tables/references clean; identities only on the title page). Not out of scope (CBS applied-AI/decision-systems fit is explicit with five engaged CBS precedents). No unsupported overclaim (the R2 "four beat B1" overclaim is fixed; no winner is claimed; B2-vs-B5 left unresolved; split contrast descriptive only).

## Top required changes

1. **(Minor) CBS precedent print-year.** `sag2025optimization` and `praveena2025retail` are cited as 2025, but Crossref lists print date 2026 (online 2025; DOI year 2025). This was flagged in R2 and not changed in R3. If Taylor & Francis house style uses the print year, update to 2026; otherwise keep the DOI year and add "(online 2025; print 2026)" for transparency.

2. **(Minor) Scrub build metadata before archiving.** `build_ledger.json` and `frozen_inputs/original_build_ledger.json` contain the identifying GitHub URL, the `akssha74` handle, and the `v1.1.1` tag. These are build-engineering artifacts, not part of the compiled manuscript, so they do not breach blinding of the review PDF. The risk arises only if they ship unscrubbed in the anonymized review archive supplied to the editor. Confirm they are excluded or scrubbed before submission.

3. **(Minor) Optional heading retitle.** Section 4.1 is still headed "Feature sets and the six-category leakage audit," while the body now correctly describes a two-field (magnitude, depth) allowlist that is "not a general leakage detector for arbitrary new covariates." The "six-category" label refers to the F1–F6 family taxonomy, not six feature fields, but a hasty reader could misread the heading as contradicting the two-field demotion. Consider "Feature sets, the two-field allowlist, and the six-family leakage audit" to make the two axes explicit.

## Detailed justification

**Venue fit (3).** Retitle, abstract, keywords, and five CBS precedents (Hossain & Sağ; Praveena & Prasanna Devi; Gao MSB-Net; Hossack; Gomołka) place this squarely in CBS's applied-AI/ML and decision-systems scope. The "admit/reject" and "supported/unresolved" decisions preceding model adoption match the journal's environmental decision-system lineage. Task-agnostic controls with DYFI as one instantiation.

**Novelty (2).** The authors explicitly disclaim component novelty ("No component is claimed as new") and position the contribution as a packaged, executable contract — timestamped hashed corpus + two-field allowlist feature/proxy/role audits + outcome-independent sequence-grouped roles + temporal holdout + fixed baselines + paired Brier interval + exact reconstruction — for one task. The fail-closed qualification framing and the DYFI-specific combination are defensible-beyond-incremental, but no single component is new, generality is untested (single dataset), and the headline result is null. This is a legitimate contribution but not a 3.

**Soundness (3).** Methodology is sound: version pinning with SHA-256, outcome-independent role assignment (unit-tested to take no label argument), temporal holdout, paired sequence-cluster Brier intervals, calibration reporting with the intercept explicitly not treated as calibration-in-the-large, single-use authorization with two deterministic replays, bit-for-bit reconstruction, and full disclosure of exclusions/deviations. The R2 overclaim is fixed. The split-contrast interval was not retained, but the authors correctly demoted it to a descriptive point estimate, draw no sign inference (including no "slightly reversed" inference), disclose it as a deviation, and the contract's claims do not rest on that contrast. The estimand is stated. B3 is a schema-policy exclusion, not a leakage finding. Exactly two changed decisions are claimed. The single-dataset limitation is a generality caveat (disclosed), not a soundness defect.

**Numeric integrity (3).** Every reported number matches `asset_inputs.json` and `source_locator_manifest.json` to the rounding used in the paper. Provenance numbers are present in `claim_ledger.jsonl`. No hand-edited cells. `validate_cbs.py` reports 42 checks, 0 failed. Reconstruction digest and result hash recorded.

**Claim calibration (3).** Exemplary in R3. No winner is claimed. B1 is not claimed to beat itself. Only B2/B4/B5 beat B1, labeled exploratory/unadjusted. "unsupported winner" is used (not "false winner"). The split diagnostic draws no sign inference and discloses log-loss 0.9709 vs 0.9640. Event-grouped is a second allocation, not a control. The intercept is not calibration-in-the-large. Two (not three) changed decisions. Generality is explicitly untested. The holdout is "held out from development" but not "untouched/confirmatory." Near-zero bootstrap endpoints are interpreted cautiously. B3 is a schema-policy, not leakage. This is a model of calibrated writing.

**Editor page-1 (3).** Page 1 conveys goal, intended users, the two decisions, the two-feature allowlist, the magnitude-dominated endpoint, the untested-generality caveat, the B1 comparator, the no-winner stance, and the descriptive split diagnostic. An editor can understand the contribution identity in under a minute.

**Reproducibility (3).** Frozen SHA-256 source snapshot, pinned scientific-Python environment (NumPy 1.26.4, SciPy 1.13.1, scikit-learn 1.5.2, XGBoost 2.1.4), 120-fit cap (91 executed), fit-ledger digest, single-use authorization token with two deterministic replays, bit-for-bit prediction reconstruction, 110 unit tests across four suites, public anonymized review archive with manifests, datasheet + FAIR documentation. Best-in-class for this venue.

**Related work/citations (3).** 42 references span DYFI/macro-seismic data, felt-intensity ML, leakage taxonomies (Kapoor, Kaufman), classifier comparison (Dietterich, Demšar, Benavoli), blocked/temporal CV (Roberts, Bergmeir), and CBS venue precedents. Coverage of the closest same-source DYFI ML neighbor (Kumar et al.) and the LLM DYFI leakage test (Li et al.) is explicit. All citations resolve.

**Formatting/blinding (3).** Single-column, double-spaced, line-numbered; tables ≤15-word titles; five figures captioned outside artwork; vector + raster figures supplied. Main, supplement, tables, and references are fully blinded; identities and repository URL/version are correctly on the title page only. The only blemishes are the 2025/2026 print-year ambiguity for two CBS precedents (item 1) and the build-ledger identity leakage into build metadata (item 2), neither of which affects the manuscript PDF.

**Usefulness (2).** The contract is a genuinely useful transparent audit harness: the worked example demonstrates a real decision change (B3 excluded; B2/B4/B5 supported over B0 and B1; B2 vs B5 left unresolved), the two-field audit rejects all seeded contamination, and the three transferable lessons (hash-pin benchmarks; paired intervals for every superiority claim; audit feature provenance against the evaluation axis) stand independently of the DYFI scores. Usefulness is bounded by single-dataset generality and the public-label / non-confirmatory status, which the authors state honestly; this caps the score at 2 rather than 3.

## Bottom line

This is a carefully done, well-calibrated, reproducible contribution that fits CBS and fixes the R2 overclaim. R3 correctly resolves the "four beat B1" inconsistency, uses "unsupported winner" framing, labels B1 comparisons exploratory/unadjusted, demotes the leakage audit to a two-field allowlist, draws no sign inference from the split diagnostic (while disclosing log-loss 0.9709 vs 0.9640), treats event-grouped as a second allocation, declines to treat the intercept as calibration-in-the-large, claims exactly two changed decisions, and records provenance in the claim ledger. All numbers reconcile; blinding of the manuscript PDF is intact; no vetoes. The score is capped at 28 by inherent contribution limits (incremental novelty and single-dataset usefulness), not by any remaining defect. I recommend **minor revisions** with the three minor items above; on satisfactory correction I would move to accept.
