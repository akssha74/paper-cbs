# Independent default-reject review, round 7 (Claude Opus 5.5)

**Manuscript:** A Fail-Closed Qualification Contract for Machine-Learning Classifier Comparison, Demonstrated on a Versioned Seismic Felt-Intensity Catalogue
**Venue:** Cybernetics and Systems (Taylor & Francis)
**Prior reviews consulted:** none

## Verdict

**Reject in current form (major revision required). Total 19/30. No veto fires.**

All numbers I checked are correct and reproducible, and the claims are calibrated with unusual care. The paper is held back by four things:

- a supplement table that is visibly truncated and loses disclosure content;
- a stale table note that contradicts the main text;
- a novelty claim whose key demonstration holds by construction;
- a two-field schema that limits practical usefulness.

## Artifact verification

| File | Claimed SHA-256 matches |
|---|---|
| main.pdf | yes |
| main.tex | yes |
| supplement.pdf | yes |

- `build_ledger.json` agrees with all three hashes.
- **Reproduction.** I backed up the frozen records, then ran `family_wise_sensitivity.py`, `seeded_candidate_demo.py` and `robustness_post_hoc.py` in the pinned environment (`/tmp/dyfi-analytics-venv`). All three exited 0 and regenerated their frozen JSON records byte-identically. I restored the originals afterwards, and no file is left modified.

## Scores

| Criterion | Score |
|---|---|
| cbs_venue_fit | 2 |
| novelty | 1 |
| soundness | 2 |
| numeric_integrity | 3 |
| claim_calibration | 2 |
| editor_page_1 | 2 |
| reproducibility | 3 |
| related_work_citations | 2 |
| formatting_blinding | 1 |
| usefulness | 1 |
| **Total** | **19/30** |

**Vetoes:** none. I found no fabricated citation, no numeric mismatch, no blinding breach, no scope violation and no unsupported overclaim.

## Results of the requested checks

- **Holm labels: pass.** `family_wise_sensitivity.json` has n_holm_reject = 6, Bonferroni exclusions = 6, and unadjusted exclusions = 8.
  - B1–B4 (p = 0.0180, rank-7 threshold 0.0125) and B4–B5 (p = 0.0350) are not rejected.
  - I recomputed the Holm step-down by hand. The Table S1 p-values and the 99.5% Bonferroni intervals match to four decimals.
- **"Fragile" B4 vs B1: pass.** `robustness_post_hoc.json` shows that B1–B4 is rejected under:
  - the 7-pair reference-only family;
  - the log-loss and AUROC Holm families (7 rejections each, with B4–B5 still not rejected);
  - the 200 km/60 d window (295 clusters).

  It is not rejected at the default window (354 clusters) or at 50 km/15 d (375 clusters). Sections 5.5, 6 and 8 and Table S2 agree with this.
- **Split-contrast intervals: pass.** All intervals include zero:

  | Contrast | Point | 95% CI |
  |---|---|---|
  | Sequence minus random, Brier | −0.0059 | [−0.0119, 0.0005] |
  | Sequence minus random, AUROC | +0.0124 | [−0.0019, 0.0266] |
  | Sequence minus random, log-loss | +0.0069 | [−0.127, 0.148] |
  | Event-grouped minus random, Brier | −0.0040 | [−0.0097, 0.0023] |

  Section 5.3 prints the event-grouped gap unsigned; see minor issue m3.
- **Seeded candidates: pass.**

  | Candidate | Audit outcome | Holdout scores |
  |---|---|---|
  | C_F1 | rejected, family F1 | Brier 0.025, AUROC 1.000 |
  | C_F2 | rejected, family F2 | Brier 0.172, AUROC 0.809, log-loss 0.515 |
  | C_F2 renamed | rejected as non-allowlisted (F0) | same as C_F2 |
  | C_year | rejected by allowlist and temporal-axis audit | Brier 0.178 |
  | C_geo | rejected as non-allowlisted (F0) | Brier 0.179; vs B2 −0.0012 [−0.0031, 0.0008] |

  - C_F2 vs B5: −0.0090 [−0.0182, −0.0004].
  - C_F2 vs B2: −0.0083 [−0.0181, 0.0005], probability better 0.965.
  - In the 15-pair extended Holm family, C_F2 is supported against B0, B1 and B4. This matches the paper.
- **RF probe: pass.** The random-event Brier is 0.2048 against a construction constant of 0.2040, and the sequence-grouped Brier is 0.1990. The constant-prevalence log-loss is about 0.598, so "far exceeds" is correct for the probe's 0.92–0.97.
- **Post-hoc disclosure: partial.** The abstract and Sections 4.4, 5.5, 5.6, 5.9 and 7 disclose the post-hoc status. In the supplement PDF, however, Table S2 is truncated (M1 below) and the Table S5 note is stale (M2 below).
- **Release distinction: pass.** Section 5.9 and the title page consistently separate public tag v1.1.1 from the review-archive additions, which carry SHA-256 hashes.
- **Overlay: pass, with one gap.** `cbs_interpretation_overlay.json` supersedes:
  - the "small and slightly reversed" and "leakage-hardened" strings;
  - the `*_inflation_*` keys, `honest_estimate_scheme` and `probe_baseline`;
  - the B1–B4 and B4–B5 directional statuses.

  It sets changes_numeric_results = false. It does not cover the stale manuscript Table S5 note.
- **Patelli correction: pass.** Reference [7] lists Sci. Rep. 16, 9208 (doi:10.1038/s41598-026-44475-8). Both DOIs resolve.
- **BetterBench and Knap et al.: mostly pass.**
  - BetterBench is described accurately: 46 lifecycle practices, and most benchmarks omit statistical significance.
  - Knap et al. is accurate on recording-level splits, the two bearing datasets and common baselines. The claim that they "average training variance over repeated seeds" overstates their "repeated-seed follow-up used where necessary" for deep-learning models.
- **Numbers vs frozen assets: pass.** I checked cohort counts, sequences, Table 3 (all columns), recall, the threshold probe, the near-threshold fraction, slices, joint ordering, the fit budget and the 0.228 oracle constant against `asset_inputs.json`, and found no mismatch.
- **Task-agnostic claims: pass.** Generality is repeatedly limited to this frozen DYFI task.
- **Blinding: pass.** Neither PDF contains names, affiliations, URLs or tags, and the PDF metadata is clean. Identities appear only on the title page.
- **Citations: pass.** I spot-checked 14 DOIs through Crossref, DataCite and OpenAlex. The three Cybernetics and Systems precedents match their abstracts:
  - [1]: Wilcoxon and Friedman tests over ten datasets;
  - [2]: accuracy, precision and recall;
  - [23]: 2.15 percentage-point Dice gain.

  The Gomołka and Orłowski Crossref record has a mangled author field, but the manuscript citation is correct.

## Major issues

**M1. Supplementary Table S2 is truncated in supplement.pdf.**
- `supplement.log` reports: `Float too large for page by 207.68723pt on input line 26`.
- The "Seeded candidates" row is cut after "with B2's frozen".
- The "Equivalence interpretation" row and the table note are missing entirely.
- Section 5.7 says Table S2 "records this interpretive restriction", but that row cannot be seen.
- The validator (51/51 checks passing) did not detect this.

Required: split the table (for example with `longtable`) or shorten it, and add a build check that fails on float or overfull errors.

**M2. The Table S5 note is stale and contradicts the paper.** `tables/leakage_gap.tex` says "no post-hoc interval or equivalence claim is added". Section 5.3, the supplement prose, the Figure S1 caption and the Table S2 "Split-contrast intervals" row all report post-hoc paired intervals.

Required: rewrite the note to point to the post-hoc intervals, all of which include zero.

**M3. The novelty demonstration holds by construction.** The claim that the admission gate adds "marginal value over the interval rule" follows automatically from a two-field allowlist, which rejects every other field. The renamed C_F2 and the harmless C_geo are rejected exactly like the contaminated field. This shows that an allowlist blocks what it does not list, not that the contract detects contamination. The acknowledged delta is a combination of established pieces applied to one magnitude-dominated corpus. I classify the novelty as incremental.

Required: present the seeded result as an illustration, not as detection evidence. Add a second task or catalogue, or a demonstration of an extensible schema tested on fields not used during design.

**M4. Usefulness and venue fit are limited by the schema.** The contract admits only magnitude and depth, so any candidate that adds information fails it. The contract is therefore a fixed-feature learner comparison, and the transferable lessons in Section 6 are generic. The decision-system framing for Cybernetics and Systems readers is thin.

Required: specify how a maintainer extends the allowlist under the contract (a versioned schema with a provenance-timestamp rule), or narrow the claim.

## Minor issues

- **m1.** In the abstract, "the interval rule alone would certify it" can be read as a winner claim. Say it would certify C_F2 as better than B0, B1 and B4; it is not Holm-supported against B2 or B5.
- **m2.** Correct the Knap et al. repeated-seed characterization (see above).
- **m3.** Sign the event-grouped Brier gap as −0.0040 so it matches its interval.
- **m4.** The abstract is 286 words and dense with model codes. Check the journal limit, which I could not confirm online, and simplify.
- **m5.** State that the ten admissible labels are unchanged in the 15-pair extended family. My hand computation suggests they are.
- **m6.** Note that five Holm p-values sit at the bootstrap floor of 2/2001.
- **m7.** Explain why the Brier and log-loss B2–B4 bootstrap p-values are identical (0.061969), which is plausible with shared replicates.
- **m8.** Figure 1 is sparse. Label the rejection branches with the F1–F6 families.
- **m9.** Consider engaging the literature on variance in ML benchmarks and the "benchmark lottery" (Bouthillier et al. 2021; Dehghani et al. 2021) when discussing the fixed-fit-interval limitation.

## Strengths

- Every number I checked matches the frozen assets, and the post-hoc analyses reproduce byte-for-byte.
- Claim calibration is exemplary in most places:
  - no winner is named;
  - B4 vs B1 is labeled "fragile" rather than forced either way;
  - the split contrast is reported as unresolved;
  - the holdout is not called "untouched" or "confirmatory";
  - generality is explicitly untested.
- The provenance chain is strong: a hashed snapshot, digest-gated scripts, and a non-destructive interpretation overlay.
- The release distinction is honest, and blinding is clean.

## Top required changes

1. Fix the Table S2 overflow so the seeded-candidate and equivalence rows and the table note appear, and add a build check for float and overfull errors.
2. Correct the stale Table S5 note.
3. Reframe the seeded "gate value" result as an illustration that holds by construction, and strengthen novelty with a second task or an extensible-schema demonstration.
4. Show how the schema is extended under the contract, or narrow the usefulness claim.
5. Tighten the abstract's "would certify it", fix the Knap et al. wording, and sign the event-grouped Brier gap.
