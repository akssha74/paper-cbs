# Review (GLM, Round 10) — Default-Reject Independent Reviewer

**Manuscript:** A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study
**Venue:** Cybernetics and Systems (Taylor & Francis)
**Reviewer:** GLM-5.2 (independent default-reject reviewer)

Per instructions, I did not read earlier-round review files (`review-glm-r1..r9`, `review-gpt-*`, `review-opus-*`) and did not open `title_page.tex` (the only file permitted to carry identities, excluded from the anonymized reviewer package). I did not edit the manuscript, scripts, frozen inputs, or other studies. All six required SHA-256 hashes verified byte-for-byte; no scientific file was modified.

## Scores

| Criterion | Score (0–3) |
|---|---|
| cbs_venue_fit | 3 |
| novelty | 2 |
| soundness | 2 |
| numeric_integrity | 3 |
| claim_calibration | 3 |
| editor_page_1 | 3 |
| reproducibility | 3 |
| related_work_citations | 3 |
| formatting_blinding | 3 |
| usefulness | 2 |
| **Total** | **27 / 30** |

**Recommendation:** major_revision.
**Vetoes triggered:** none (fabricated_citation, numeric_mismatch, blinding_breach, clearly_out_of_scope, unsupported_overclaim all false).

Default-reject stance: started skeptical, no score inflated; credit given only for defects demonstrably fixed and verified against frozen inputs. The two 2/3 areas are genuine limitations (combination-level novelty, weak cluster structure on this corpus, single-corpus usefulness), not defects fixable by editing alone.

## SHA-256 verification

`main.pdf` `b88d00d9…4124`, `main.tex` `4edcfef2…fab6`, `supplement.pdf` `2fab4596…f22a`, `supplement.tex` `0f2b5efe…e395`, `references.bib` `eaef0dbd…42b6`, `build_ledger.json` `b620af77…297e` — all verified.

## Verification of the seven checked items

1. **Abstract ≤200 words, on page 1, states practical output.** PASS. Validator enforces `150 ≤ words ≤ 200`, reports "187 rendered words"; I independently counted 188 from `pdftotext` (1-word gap from hyphenation of "Did You Feel It?"). Abstract fully on page 1; states "an admit/reject decision for each candidate and a supported/unresolved label for each pairwise improvement claim."

2. **Harness sentence in §5.6 vs `seeded_candidate_demo.py`.** PASS. `C_F2_ren` declares `["n_reports"]` (matches no named family) but reads values from `num_responses`; `audit_feature_names` rejects it because `n_reports` is outside the two-field allowlist (`magnitude`, `depth_km`). `frozen_inputs/seeded_candidate_demo.json` confirms `C_F2_ren.admission_audit.passed = false`. A clean declared name cannot launder disallowed values past the allowlist, exactly as written.

3. **Wild-cluster bootstrap, 99,999 draws, MC SE, B1–B4 borderline.** PASS. `robustness_post_hoc.py` `WILD_DRAWS = 99999`; MC SE = `sqrt(p(1-p)/n)`. `frozen_inputs/robustness_post_hoc.json` (10° cells): B1–B4 `wild_cluster_rademacher_p = 0.01244`, `wild_cluster_mc_se = 0.0003505` → reported p=0.0124, MC SE 0.0004 vs threshold 0.0125; gap 0.0001 = 0.29 MC SE, within two MC SE (Table S6 `R^b`). B1–B4 "marginal and family-dependent." Cluster disclosure 312/354 singletons, largest 16, `G/(G-1)=1.003`.

4. **Cluster-robust paired Brier with Holm.** PASS. `family_wise_sensitivity.json`: `n_holm_reject = 7`. B1–B4 p=0.010855 (threshold 0.0125, reject; manuscript 0.0109); B2–B4 p=0.0485, B4–B5 p=0.0350, B2–B5 p=0.8269 (unresolved). Six Bonferroni 99.5% `t` intervals exclude zero; B1–B4 Bonferroni `[-0.0012, 0.0243]` includes zero. p-values labelled by method. "best Brier, AUROC, and log-loss" wording present. `H_unresolved` claim-ledger entry authoritative.

5. **Anonymity.** PASS. Validator enforces `main_text_blinded`, `reviewer_package_anonymous`, `title_page_carries_identities`; all pass, no identity hits. `build_ledger.json` withholds `public_repository` and `public_release_tag`. `title_page.tex` is the only identity-bearing file and is excluded from the reviewer package.

6. **`H_unresolved` authoritative; typography; no clipped content.** PASS. Table 1 (`engineering_failure_modes.tex`) ragged-right `p`-columns; Table 4 (`candidate_qualification.tex`) math-mode minus signs; data DOIs present. `main.log`: one cosmetic Underfull hbox (keywords); no Overfull/clipped boxes; validator `compiled_layout_has_no_clipped_or_overfull_content` passes.

7. **Numbers, citations, release/archive distinction, no universal recommendation.** PASS. `evalci` (arXiv:2607.04429) independently verified via web search as a real 2026 preprint; bibtex matches official entry. Holm 1979 and Diebold–Mariano 1995 correct. Release/archive distinction drawn (anonymized review archive vs new immutable tag on acceptance, distinguished on title page). No universal recommendation ("Reuse on other catalogues is untested"; "not operational").

## Cohort arithmetic (recomputed)

1573+357+430+2=2362; 449+102+151+1=703 severe; 449+102+151=702 role-assigned severe; 1573+357+430=2360 role-assigned events; 151/430=0.351; 551/1930=0.285; MC SE for p=0.01244, n=99999 = 0.0003505 → 0.0004. All reconcile.

## Findings

**F1 — Page count vs venue limit (formatting_blinding, minor, fixable).** Validator reports internal target 32; rendered `main.pdf` is 33 pages; venue limit not verified. Fix: verify the Cybernetics and Systems limit and trim one page if needed.

**F2 — Singleton-cluster structure weakly exercises the central machinery (soundness, moderate, requires new data).** §5.4: 312/354 singletons, largest 16, `G/(G-1)=1.003`; cluster-robust test "differs little from an event-level paired t test, and its independence assumption is only lightly exercised." The dependence-handling value is shown by construction, not by data. At 10° cells B1–B4 is borderline within MC precision. Fix: add a simulation or second catalogue with richer within-sequence dependence.

**F3 — B1–B4 marginality buried in abstract (claim_calibration, minor, fixable).** Abstract subordinates the random-forest marginality to the supported statement; B1–B4 flips to unresolved in the 15-pair family and sits within MC precision at 10° cells. Fix: reorder the abstract so the marginality is not a trailing clause.

**F4 — Combination-level novelty on one corpus (novelty, moderate, requires new data).** §2: pieces established separately; contribution is the fail-closed combination on one frozen corpus; reuse untested. Fix: a second-corpus demonstration would convert design proposal into empirical generalization.

**F5 — Allowlist not a general leakage detector; usefulness on one corpus (usefulness, moderate, requires new data).** §4.1: rejects undeclared fields and named families but cannot detect unknown contamination; illustrated on one corpus with one seeded candidate. Fix: apply to at least one additional catalogue/task.

**F6 — Figure regeneration not exercised here (reproducibility, minor, fixable).** Validator: "host matplotlib=not-installed; pinned=3.11.1; hashes verified without regeneration." Fix: run regeneration in the pinned matplotlib 3.11.1 environment on acceptance and record hashes.

**F7 — Cosmetic Underfull hbox (formatting_blinding, minor, fixable).** `main.log` lines 70–71 (keywords). Optional fix.

## Top required changes

1. **[fixable]** More prominently flag the singleton-cluster limitation's impact on the central statistical claim (F2).
2. **[fixable]** Verify the venue page/word limit and trim to fit (F1).
3. **[fixable]** Elevate the B1–B4 marginality qualifier in the abstract (F3).
4. **[fixable]** Exercise figure regeneration in pinned matplotlib 3.11.1 on acceptance (F6).
5. **[requires new data, optional but material]** Add a second-corpus or simulation demonstration with richer within-sequence dependence to raise soundness/usefulness/novelty (F2/F4/F5).

## Limitations vs fixable defects

- **Requires new data/simulation:** F2, F4, F5.
- **Fixable in this study (editing only):** F1, F3, F6, F7.

## Overall assessment

A carefully executed, honestly calibrated, fully reproducible methods/contract paper with a worked seismic case study. All checked numbers reconcile with frozen inputs, no veto is triggered, and the previously raised defects I could verify (abstract length/page-1, harness sentence, wild-cluster MC SE, Holm/Bonferroni reporting, anonymity, typography, citation integrity) are demonstrably fixed. Remaining concerns are the genuine limitations of a single-corpus demonstration — cluster-robust machinery barely exercised by the data, combination-level novelty, usefulness untested beyond one corpus — plus minor formatting items. Major revision: in-study fixes 1–4 are required before acceptance; the second-corpus/simulation demonstration (5) would materially raise the soundness/usefulness/novelty scores but is not a blocker for this venue.
