# Review R12 — Claude Opus (independent, default-reject)

**Manuscript:** A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study
**Venue:** Cybernetics and Systems: An International Journal
**Verdict:** **Reject** (resubmission possible after major revision)
**Total:** **18 / 30**

I did not read reviews from earlier rounds.

## Integrity and verification

- All six SHA-256 hashes match (main.pdf, main.tex, supplement.pdf, supplement.tex, references.bib, build_ledger.json).
- main.pdf has 32 pages and supplement.pdf has 8.
- I re-ran `validate_cbs.py`: 56 checks, 0 failed, PASS. The re-run report differed from the stored one only in the host-matplotlib environment string, and I restored the original byte-for-byte.
- I re-ran `family_wise_sensitivity.py`, `seeded_candidate_demo.py` and `robustness_post_hoc.py` with `/tmp/dyfi-analytics-venv`. All three outputs are byte-identical to the frozen JSON, and the frozen files were restored.
- **Holm arithmetic.** Sorted p-values are five below 0.0001, then B1–B5 0.0031 (threshold 0.0100), B1–B4 0.0109 (threshold 0.0125), and B4–B5 0.0350 (threshold 0.0167, where the step-down stops). That gives 7 rejections, which is correct. Six Bonferroni 99.5% intervals exclude zero, which is also correct.
- **Cohort arithmetic.** 1573+357+430+2 = 2362, and severe counts 449+102+151+1 = 703. Both are correct.
- **C_F2 point scores.** Brier 0.1724 is below B2 (0.1807) and B5 (0.1814). AUROC 0.8093 is above B2 (0.7858). Log-loss 0.5153 is below B2 (0.5364). Against B2 the interval is [−0.0181, 0.0005] with p = 0.076.
- **Unit tests.** 20+24+31+35 = 110 test functions across four suites. Only about 18 call sites, in three suites, touch the audit functions.

## Requested checks

| Check | Status |
|---|---|
| TFX / Breck positioning and narrowed delta | Partially satisfied |
| Figure 3 labels | Acceptable, minor defects |
| C_F2 relative-to-admissible wording | Numerically correct, rhetorically inconsistent |
| 32 pages | Verified |
| 56/56 PASS | Verified (re-run) |

**TFX and Breck positioning.** Lines 248–252 correctly concede that TFX and Breck already validate data against a schema and bless a candidate when a point metric clears a baseline. The problem is the next sentence (L253–255): "The remaining delta here is that pre-score two-field allowlist plus role gate, event-sequence clustering, version pinning, …". It still lists the allowlist first and adds version pinning, which is also standard practice. Contribution 2 (L119) and L264–267 also still present the allowlist as a contribution. So the intended narrowed delta (paired dependence-aware Holm, plus the sequence-role audit, plus the DYFI case) is not stated cleanly. The sentence is also ungrammatical. In addition, "bless a candidate" belongs to TFX (Baylor 2017), not to Breck 2019, which is about data validation.

**Figure 3.** Panels (a) and (b), the axes, and the bar annotations are correct, and the annotated values match Tables S3 and S4. There are three defects:
- Panel (a) plots Prevalence under a y-axis titled "Metric value", and the caption ("Performance as the severe-intensity cutoff varies") never mentions it.
- The dotted line at 6.0 is not explained.
- On main.pdf p. 17 the legend and tick text render at roughly 5 pt.

**C_F2 wording.** The claim that C_F2 "beats every admissible baseline" (abstract, L151, L800, L875) is true for point scores. But under the paper's own 15-pair Holm rule, C_F2 is unresolved against B2 and B5. A paper whose thesis is "point scores are not superiority claims" should not use "beats" here. Table 4's "best among admissible baselines" also reads as though C_F2 were admissible.

## Novelty

- **Class: incremental.** Every component is prior art, and the paper says so.
- **Dependence handling is barely tested.** The one part that is not already occupied is the dependence-aware paired Holm test, and this case barely exercises it. 312 of the 354 holdout clusters are singletons, G/(G−1) = 1.003, and an event-level paired t test reproduces all seven decisions (Table S6, "Event t" column). On this dataset the contract is therefore not distinguishable from paired t plus Holm, which evalci and NeMo Evaluator already package.
- **The seeded reversal is built in.** Any field outside the allowlist is rejected, so the reversal holds by construction, as L730 itself acknowledges.

## Scores (0–3)

| # | Criterion | Score |
|---|---|---|
| C1 | Problem significance | 2 |
| C2 | Novelty / originality | 1 |
| C3 | Methodological soundness | 2 |
| C4 | Evidence strength / validation | 1 |
| C5 | Reproducibility / transparency | 3 |
| C6 | Claim calibration | 2 |
| C7 | Related-work positioning | 2 |
| C8 | Venue fit (Cybernetics and Systems) | 1 |
| C9 | Clarity / organization | 2 |
| C10 | Figures, tables, formatting | 2 |
| | **Total** | **18 / 30** |

## Vetoes

**Hard vetoes:** none triggered. The hashes match, the validator passes, the numbers reproduce, the main text is blinded, and the spot-checked citations are consistent.

**Soft vetoes that block acceptance:**
1. **Incremental novelty.** The one component that is not already occupied is empirically indistinguishable from an event-level paired t test on this case.
2. **All decisions are post hoc.** The Holm family, the B2-versus-B0 comparison, the seeded candidates and the robustness checks were all specified after the holdout was opened. There is no confirmatory evidence of the contract's value.
3. **Narrow evidence.** There is one catalogue, the endpoint is magnitude-dominated, and generality is untested by the authors' own admission.

## Major issues and required changes

1. **M1: The dependence-aware part is not exercised.**
   - *Required:* demonstrate a clustered setting where CR1 or CR3 decisions differ from event-level decisions. This could be another catalogue, a lower magnitude threshold, or a synthetic dependence study. Otherwise, narrow the claim.
2. **M2: The novelty delta still includes the allowlist.**
   - *Required:* restate the delta as exactly paired sequence-cluster-robust Holm, plus the dependent-event role audit, plus the DYFI case.
   - Present the allowlist and version pinning as standard mechanisms instantiated here, including in Contribution 2.
   - Attribute blessing to TFX (and TFMA) and schema validation to Breck, separately.
3. **M3: All inference is post hoc, and the family choice changes a decision.** B1–B4 is supported in the 10-pair family but unresolved in the 15-pair family.
   - *Required:* freeze the family, reference set and margin, then apply them to a fresh holdout of events after the freeze.
   - Alternatively, report simulated false-admit and false-support rates.
4. **M4: "Beats" wording for C_F2.**
   - *Required:* replace "beats" with the contract's own vocabulary, for example "lower point Brier, lower log-loss and higher AUROC than every admissible baseline; Holm-supported against three of five".
5. **M5: Venue fit is thin.**
   - *Required:* add a systems-level analysis of the decision contract, such as its operating characteristics or a feedback loop for schema versioning, or retarget to another venue.

## Minor issues

- **Test count.** "110 unit tests" is attributed to the allowlist (L122, L357), but that counts all four suites. Only a subset exercise the audit functions; report that count instead.
- **Grammar.** L253, "The remaining delta here is that pre-score …", is ungrammatical.
- **Figure 3.** Enlarge fonts to at least 8 pt at print size, name prevalence in the caption or give it its own axis, and explain the 6.0 line.
- **Figure 1.** The arrows are tiny chevrons, and "Allowlist and F1 to F6 role and axis audit" merges three gates into one box.
- **Captions.** They lack terminal full stops, contrary to Taylor & Francis style.
- **Missing column.** The "seven-pair reference-only family" is cited in the main text (L650) but has no column in Table S6.
- **Abstract.** The sentence "Otherwise, post-hoc Holm analysis supports …" is awkward.
- **Repetition.** Caveats are repeated five to eight times each, which inflates the manuscript to 32 pages.

## Paths to 3 per criterion

- **C1.** Show how often real published comparisons would have been refused by the contract, rather than relying on a seeded example.
- **C2.** Find a case where cluster-robust Holm changes a decision compared with an event-level test, or reframe the paper as a case study or resource paper.
- **C3.** Freeze the Holm family and margin, apply them to a fresh hidden holdout, and formally address the fact that the family choice changes decisions.
- **C4.** Add a second catalogue or task, a prospective holdout, and the unexecuted leave-region-out and aggregation-grid branches.
- **C5.** Already at 3. Deposit the new immutable tag.
- **C6.** Use supported/unresolved vocabulary for C_F2, correct the test count, and say in the abstract that the seeded reversal holds by construction.
- **C7.** Narrow the delta as in M2, split the TFX and Breck attributions, and acknowledge TFMA's bootstrap confidence intervals.
- **C8.** Add a systems or decision-theoretic analysis of the contract's error properties, and engage the Cybernetics and Systems literature more deeply.
- **C9.** Consolidate the caveats and move the detail in Sections 5.3 and 5.8 to the supplement, reducing the length substantially.
- **C10.** Apply the Figure 1 and Figure 3 fixes, add caption full stops, and change Table 4's wording to "better than every admissible baseline".

## Convergence

M1, M3 and M5 need new evidence or retargeting and cannot be fixed by wording while the scientific tree is frozen. M2, M4 and the minor issues are wording and presentation fixes, worth about 1–2 points. On the current evidence the review has converged: further wording-only rounds are unlikely to raise the total much above 20/30.
