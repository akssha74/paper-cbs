# Independent default-reject review — round 5 (Claude Opus 5.5)

**Manuscript:** "A Fail-Closed Qualification Contract for Comparing Machine-Learning Classifiers on Versioned Event Data: A Seismic Felt-Intensity Case Study"
**Target venue:** Cybernetics and Systems
**Verdict:** **REJECT**. Score **14/30**; the veto is triggered.

Prior-round reviews (r1–r4) were not consulted.

## Hash verification

| File | Claimed = observed |
|---|---|
| `main.pdf` | `d76c4793…a6e507`: match |
| `main.tex` | `6eb516ae…e89f2d`: match |

## Scores (0–3)

| Category | Score |
|---|---|
| 1 Scope / venue fit | 1 |
| 2 Novelty / contribution | 1 |
| 3 Significance / demonstrated usefulness | 1 |
| 4 Methodological soundness | 1 |
| 5 Numeric accuracy / traceability | 2 |
| 6 Claims–evidence alignment | 1 |
| 7 Protocol adherence / disclosure | 1 |
| 8 Statistical reporting | 2 |
| 9 Reproducibility / provenance | 2 |
| 10 Presentation / format / blinding | 2 |
| **Total** | **14/30** |

## Veto

The veto is triggered for two reasons.

1. **No demonstrated usefulness beyond standard practice.** The manuscript itself says: *"Those are the only comparison-policy differences demonstrated on these candidates."* Those two differences are:
   - B3 is excluded by schema policy: *"a schema policy, not a leakage finding"*.
   - B2 versus B5 is left unresolved because a paired 95% CI includes zero. Any paired-bootstrap report would reach the same result.

   The authors also concede: *"Those pieces are established separately"* and *"Reuse on other catalogues is untested."* No second dataset is evaluated, no seeded-contamination candidate is scored end-to-end in the Results, and no counterfactual shows a conventional workflow reaching a wrong conclusion that the contract prevents.

2. **The registered primary result failed and was demoted after the fact.** The manuscript states: *"The frozen internal protocol named that contrast the primary quantitative result; this manuscript reports it as a secondary descriptive diagnostic because no paired interval was retained."* The abstract adds: *"B2 versus B0 is a post-hoc comparison."* The disclosure is honest, but disclosure does not make a post-hoc reframing confirmatory.

## Requested checks

### Residual "small and reversed"
**The manuscript is clean, but the released artifacts fail.**

- In the manuscript, the phrase appears only in negated form: `main.tex:522` reads *"no sign claim—including 'slightly reversed'—is inferentially supported."*
- `frozen_inputs/asset_inputs.json` → `exclusions_and_deviations.F3_split_contrast_framing` reads *"The split contrast is small and slightly reversed on this M>=5 one-row-per-event corpus."* This field is not overlaid.
- `corrections_overlay.json` has an **authoritative** replacement that reads *"Observed differences are small and reversed relative to the expected optimistic-random-split direction."* The machine-readable correction therefore asserts the very sign claim the paper disowns.
- The key `leakage_inflation_headline` still carries *"the sequence-grouped split is the honest, leakage-hardened estimate … This is the resource's headline."*

### "Task-agnostic"
**Passes, with a note.**

- The word is absent from `main.tex`, the supplement, `tables/` and the claim ledger.
- The title still implies a general contract for "Versioned Event Data", whereas the abstract says *"generality beyond this dataset is untested"*, and the allowlist is hard-coded to magnitude and depth.

### "Supported" vs "Exploratory-supported"
**Fails (minor residual).**

- The Fig. 1 artwork reads *"Interval excludes zero: supported"*.
- Contribution 5 says it *"supports an improvement only when…"*.
- The Table 6 rule says *"…supports improvement over the declared reference"* and then *"…therefore exploratory-supported"*.
- Everywhere else the text uses "exploratory-supported". The flow diagram is the first visual summary of the contract and should match.

### Diagnostic random-forest skill
**Fails (overstatement).**

The manuscript says the probe is *"essentially unskilled"*, and the Conclusion says, without qualification, *"The diagnostic model is unskilled on the construction sample."* The frozen values do not support that.

| Scheme | Brier | Brier minus no-skill floor (0.203986) | AUROC | Log-loss |
|---|---|---|---|---|
| Random-event | 0.204834 | +0.00085 | 0.695 | 0.964 |
| Event-grouped | 0.200874 | −0.0031 | 0.706 | 0.922 |
| Sequence-grouped | 0.198955 | −0.0050 | 0.708 | 0.971 |

- Under sequence grouping, which the paper treats as the honest scheme, the forest beats the no-skill floor.
- AUROC of about 0.70 is close to magnitude-only B1 on the holdout (0.719).
- Constant-prevalence log-loss is 0.598, which I recomputed from prevalence 0.28549. A log-loss of 0.92–0.97 therefore indicates severe **miscalibration** from an unrestricted-depth forest, not absence of skill.
- The contrast is uninformative because it has no interval and the probe is miscalibrated, not because the model has "no skill".

### Multiplicity disclosure
**Disclosed but not controlled.**

The disclosure itself is clear and repeated: *"Those labels are not multiplicity-adjusted: the B1–B4 and B4–B5 lower endpoints (0.0023 and 0.0003) … are not claimed to survive family-wise control."*

I approximated a Holm correction over the 10 pairs, using two-sided p ≈ 2·min(P(A better), P(B better)) from Table S1:

| Pair | Approximate p | Holm threshold | Result |
|---|---|---|---|
| B1–B5 | 0.002 | 0.010 | Passes |
| B1–B4 | 0.018 | 0.0125 | Fails |
| B4–B5 | 0.034 | 0.0167 | Fails |

The abstract and Conclusion still list B4 as improving on B1, with the qualifier "descriptive unadjusted". A contract whose stated job is to *"refuse unsupported … claims"* should not issue labels without error control.

### Alvarez citation [18]
**Passes.** The ADS abstract for 2012JSeis..16..489A says the regressions used *"the 'Did You Feel It?' database of the US Geological Survey and the database of the Center for Engineering Strong Motion Data for the California region."* So "DYFI-linked" is accurate, and the volume, issue, pages and DOI match.

### Rounding of 0.0040
**Passes.**

- The event-grouped gap is 0.204833647 − 0.200874491 = 0.0039592, which rounds to 0.0040.
- Differencing the printed table values would give 0.0039, so the "unrounded" qualifier is needed, and it is present.
- 0.0059 and 0.0124 also verify.

**Traceability gap:** none of the 4-decimal values printed in Table 4 and the prose appear in `claim_ledger.jsonl`. The ledger stores 3-decimal values (L1 "−0.006"), and L1/L2 `appears_in` still lists "abstract", which no longer contains these numbers.

## Numeric verification

**Passed:**
- Cohort accounting: 1573 + 357 + 430 + 2 = 2362; severe counts 449 + 102 + 151 + 1 = 703.
- All prevalences.
- Events per sequence: 1930/1530 = 1.26.
- All holdout Brier values and CIs.
- Recall: 0.245 / 0.318 / 0.291 / 0.371.
- Accuracy.
- Calibration pairs.
- Table S1.
- Joint ordering: 0.613 / 0.387.
- Threshold probe.

**Minor:**
- Table S1 prints P(A better) for B1–B4 as 0.009; the frozen value is 0.0085. This is immaterial.
- B0 uses construction prevalence on a holdout whose prevalence is 0.351. A holdout-prevalence climatology would score 0.2278 rather than 0.232, so every "improvement over B0" is inflated by about 0.004. The paper does not state this.

## Major issues

1. **The contribution is a combination of standard practices.** "Fail-closed" amounts to a two-field allowlist (*"any extra or unknown field is rejected"*), so every rejection in the F1–F4 families is guaranteed by construction.
2. **The decision rule has no multiplicity control and no practical margin.** It uses unadjusted 95% CIs, and the paper states *"no pre-specified ROPE"*.
3. **Protocol adherence is poor, although disclosure is thorough.**
   - The registered primary lost its interval.
   - The leave-region-out geographic branch was not executed.
   - The aggregation-grid sensitivity was not executed.
   - Intervals for non-Brier metrics were not retained.
   - No equivalence margin was specified.
   - The protocol was first publicly timestamped 18 days after the internal freeze.
4. **The diagnostic random forest is mischaracterised as "unskilled"** (see the check above).
5. **The released artifacts contradict the manuscript**: the "small and reversed" wording and the "leakage-hardened headline" key remain.
6. **Venue fit is weak.** The task is *"close to magnitude thresholding"*, and the "decision system" is a four-step rule. Three recent Cybernetics and Systems papers are cited as foils [1, 2, 23] but are not re-evaluated under the contract, so relevance to journal practice is asserted rather than shown.

## Minor issues

- The bootstrap CI type (percentile, BCa or basic) is not stated, and the Monte Carlo error of near-zero endpoints is not quantified.
- The abstract is 278 words and dominated by caveats; check it against the venue limit.
- Caveats repeat 3–6 times each ("not multiplicity-adjusted", "not untouched", "not a leakage finding"), which raises reader burden.
- References [1] and [2] mix the year 2025 with "print 2026".
- Table 1 cells wrap poorly in the PDF.

## Strengths

- Every printed number I checked reconciles with the frozen assets.
- Deviation disclosure is unusually candid.
- The paired sequence-cluster bootstrap with an explicit tie probability, and the refusal to name a winner, are appropriate.
- Hash pinning, the single-use run token and the deterministic replays are good provenance practice.
- The main text and PDF metadata are blinded.

## Required for reconsideration

1. Show usefulness: evaluate at least one independent dataset, or re-score published candidate comparisons, and show a case where the contract changes a conclusion.
2. Build error control into the rule (Holm or closed testing, or a pre-declared ROPE) and re-derive the labels.
3. Correct the "unskilled" claim, or re-run a calibrated probe with a paired interval as a new, openly labelled analysis.
4. Purge or overlay the "small and (slightly) reversed" and "leakage-hardened headline" strings in the released artifacts, and change Fig. 1 to say "exploratory-supported".
5. Add ledger entries for every printed 4-decimal value and fix the stale `appears_in` fields.

*The reviewer did not execute code; the unit-test count (110) is taken from the ledger.*
