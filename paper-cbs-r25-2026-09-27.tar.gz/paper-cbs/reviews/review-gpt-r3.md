# Independent DEFAULT-REJECT review — R3

Target: *Cybernetics and Systems: An International Journal*  
Reviewer: GPT-5.6  
Reviewed object: current `main.pdf` (31 pages)  
Recommendation: **REJECT — MAJOR REVISION**  
Score: **26/30**  
Vetoes: **none**

Review pin: repository HEAD `b3fcc66f77139194d9185eeb7f9db88039f27bd0`; untracked current working-tree package; `main.pdf` SHA-256 `ddfc65b3ed334f4b50e5ae62dd6988f67abcaf7ecb6c835a12fbea7a6bb5ae01`; `main.tex` SHA-256 `689f0b9637ba34eaec8f0ada04b00df4aea578ba765ff1db0399503d623876e5`; frozen asset SHA-256 `b7f7dea60c7421b0b75870d45421c094e3cd4b5e325702c94b498ebc7926ace9`.

The R3 numerical surface matches `frozen_inputs/asset_inputs.json`, the B0/B1 hierarchy is corrected, and blinding passes. The manuscript remains below the strict 28/30 acceptance threshold because its contribution is still an incremental one-dataset integration and the compiled PDF retains semantic inconsistencies in the split diagnostic.

## Scores

- CBS venue fit: **3/3**
- Novelty: **1/3**
- Soundness: **3/3**
- Numeric integrity: **3/3**
- Claim calibration: **2/3**
- Editor page 1: **3/3**
- Reproducibility: **3/3**
- Related work/citations: **3/3**
- Formatting/blinding: **2/3**
- Usefulness: **3/3**

Total: **26/30**

## Goal and usefulness

The paper asks whether candidate-classifier comparisons remain admissible and supportable after fixing data version, feature schema, dependent-event roles, temporal evaluation, paired uncertainty, and reconstruction.

The intended users are applied-ML engineers, benchmark maintainers, and reviewers. The harness lets them decide whether a candidate is within the declared comparison contract and whether a Brier-score improvement over a reference is supported or unresolved. The demonstrated result is that four learned models improve over B0; on exploratory unadjusted intervals B2, B4, and B5 improve over B1; B3 is outside the source-only contract; and B2 versus B5 remains unresolved.

- `goal_understood`: true
- `usefulness_understood`: true
- `abstract_story_pass`: true
- Contribution identity: task-specific benchmark and executable evaluation contract
- Novelty class: **incremental**

The official journal scope includes applied AI/ML, intelligent systems, decision making, and environmental systems, so the submission is in scope. Its non-use boundary is also clear: this is not operational, causal, confirmatory, geographic-transfer, or cross-system evidence.

## R3 fix verification

Confirmed:

- B1 is not claimed to beat itself.
- All four learned models beat B0; only B2, B4, and B5 beat B1.
- The manuscript uses `unsupported winner`, not `false winner`.
- B1 comparisons are labeled descriptive/exploratory and unadjusted in the abstract, Methods, Table 6, and conclusion.
- Sequence-grouped log-loss `0.9709` versus random-event `0.9640` is disclosed.
- The jointly estimated intercept is not treated as calibration-in-the-large.
- The worked example identifies two, not three, changed decisions.
- Provenance entries `P_access_instant`, `P_count_min`, `P_count_max`, `P_costamped`, `P_recount_lag_s`, `P_prelim_minus_payload`, and `P_unit_tests` are present in `claim_ledger.jsonl` and agree with the source manifest and arithmetic.

Not fully resolved:

1. **Event-grouped is still labeled a control.** Compiled Table 4 says `Event-grouped (control)`, while the immediately following prose says it is `a second fold allocation ... not a distinct control`. This is a direct contradiction in the reviewed PDF.
2. **Split-direction wording is not fully harmonized.** Results correctly says that no sign claim is inferentially supported. Discussion nevertheless says the estimate is `small and slightly reversed` and that random splitting `did not inflate` the score; the conclusion again says `small and reversed`. The surrounding caveats avoid a veto, but the categorical wording should be removed.
3. **The allowlist demotion is partial.** The contribution now accurately calls the mechanism a `two-field source-only schema allowlist` and says it is not a general leakage detector. Section 4.1 still uses the title `six-category leakage audit` and says the executable audit `enforces six leakage families`. Under an exact allowlist, the field-family behavior is schema enforcement, not general leakage detection.

## Numeric audit

No numeric mismatch was found against `frozen_inputs/asset_inputs.json`.

- Cohort: `1573 + 357 + 430 + 2 = 2362`; `703` eligible severe events and `702` severe role-assigned events.
- Sequences: `1885` eligible, `1530` construction, `354` holdout, and `1` straddle sequence.
- Threshold probe at 5.5/6.0/6.5: prevalence `0.458/0.351/0.260`, Brier `0.240/0.181/0.143`, AUROC `0.734/0.786/0.815`.
- Split diagnostic: random/event/sequence Brier `0.2048/0.2009/0.1990`, AUROC `0.6952/0.7058/0.7076`, and log-loss `0.9640/0.9223/0.9709`.
- B0/B1/B2/B4/B5 Brier scores, intervals, log-loss, AUROC, calibration pairs, accuracy, and recalls match after printed rounding.
- All ten pairwise Brier differences and intervals match. B2–B4 and B2–B5 include zero.
- Temporal slices sum to `250 + 180 = 430`; the 82 geographic cells also sum to 430.
- Provenance values `7575`, `7576`, `7520`, `50 s`, and `56` match `source_locator_manifest.json`.

## Citations, blinding, and presentation

No fabricated citation was found. The availability audit resolved all harvested DOI/URL identities after manually checking `10.5066/P143CZ3R`; it is a valid DataCite/USGS DOI even though a Crossref-only probe reports it as unregistered.

Novelty class: **incremental**. The nearest published work includes *Leakage and the Reproducibility Crisis in ML-Based Science* (2023), Roberts et al. (2017) on dependence-aware validation, Demšar (2006) and Benavoli et al. (2017) on classifier comparison, Kumar et al. (2025) on DYFI prediction, and EBES (2024) on standardized event-sequence benchmarking. Search queries recorded for this round were:

- `DYFI model comparison temporal holdout benchmark paired bootstrap leakage contract`
- `dependent event classifier benchmark qualification reproducibility versioned dataset`
- `event-level macroseismic classifier benchmark temporal validation paired uncertainty`

The concrete delta is an executable integration of established controls on one frozen DYFI task. The nearest work search did not establish a second-domain demonstration or a controlled counterfactual audit that would move the contribution beyond incremental.

Blinding passes. Extracted `main.pdf` and supplement text contain no author name, affiliation, email, GitHub URL, repository owner, project name, or `v1.1.1` tag. Main and supplement PDF metadata contain no Author field. Identifying information is confined to the separate title page.

The five figures are legible and agree with their captions. The build log retains one 8.67 pt overfull box in Table 3, and Table 6 has awkward wrapping. No undefined citation or reference warning was found.

## Required changes

1. **Relabel Table 4.** Replace `Event-grouped (control)` with `Event-grouped (second allocation)` or equivalent in the generator, rebuild the PDF, and remove any remaining control characterization.
2. **Remove residual split-direction inference.** Report the observed point differences, then state that neither their direction nor magnitude is inferentially established. Delete `did not inflate`.
3. **Align the leakage terminology.** Rename the mechanism as a two-field allowlist plus split/axis checks, or demonstrate provenance-aware admission and rejection of new covariates before retaining general leakage-audit wording.
4. **Strengthen or narrow the contribution.** A second event dataset or controlled counterfactual audit of published comparisons is needed for a beyond-incremental research contribution. Otherwise position the work as a task-specific reproducibility/benchmark resource.
5. **Clean the package.** `main.txt` is stale and still says `three decisions`, whereas current `main.pdf` says two. Regenerate or remove it, and clear the overfull table warning.

## Final assessment

The central R3 number and comparator corrections are successful, and none of the five veto categories is triggered. The paper is not yet acceptable under the requested default-reject standard: one explicit R3 semantic fix remains visibly false in Table 4, two related framing issues remain partial, and the one-dataset demonstration does not yet establish a beyond-incremental research contribution.
