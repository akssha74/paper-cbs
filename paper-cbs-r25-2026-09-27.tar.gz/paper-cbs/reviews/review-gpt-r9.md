# Independent default-reject review — GPT-5.6, round 9

## Verdict

**Reject the current reviewer-facing package; invite resubmission after a mandatory blinding fix.**

The scientific manuscript is substantially stronger than this verdict may suggest: its narrow retrospective claims are numerically consistent, the post-hoc status and dependence limitations are explicit, the primary inference is implemented coherently, and the rendered paper is clean. The rejection is caused by a veto, not by a result error: `build_ledger.json` exposes the identifying repository outside the separate title page.

**Score: 25/30**

- `cbs_venue_fit`: **3/3**
- `novelty`: **2/3**
- `soundness`: **3/3**
- `numeric_integrity`: **3/3**
- `claim_calibration`: **3/3**
- `editor_page_1`: **3/3**
- `reproducibility`: **2/3**
- `related_work_citations`: **3/3**
- `formatting_blinding`: **1/3**
- `usefulness`: **2/3**

## Vetoes

- `fabricated_citation`: **false**
- `numeric_mismatch`: **false**
- `blinding_breach`: **true**
- `clearly_out_of_scope`: **false**
- `unsupported_overclaim`: **false**

## Version pin and review coverage

All five requested hashes match:

- `main.pdf`: `bdf1d472b618961f153c0eeb8620df12383ac9170d2f2113f0c1d6c15008be96`
- `main.tex`: `502a29585807e99af2636c3a0fe2eabebcd3c69f8be20fe93c16e14f3a125b17`
- `supplement.pdf`: `b8ac8c09812ea92d433feb100e56a7120d317980d301b26aa586ed5a0bd0e7f0`
- `supplement.tex`: `23ab5a8115fc08f9ffe3e9818a70b4e0f48202220cd85783857acaaf5529640d`
- `references.bib`: `d66922836e00938d0df070323c6d47d0c495925b2a98095e06a46a60e55fd026`

I extracted both PDFs, inspected all 32 main-manuscript pages and all 8 supplement pages, and inspected the requested source, tables, figure, scripts, frozen records, overlays, ledgers, validation report, bibliography, title page, and build ledger. I did not execute the author scripts because read-only recomputation from the frozen JSON records resolved the decision-bearing checks without risking writes to frozen outputs.

## Blocking finding

### R9-F1 — Reviewer-facing build ledger breaks anonymity

**Severity:** blocking  
**Touches:** evidence  
**Veto:** `blinding_breach`

Exact evidence:

- The blinded manuscript says: **“Identifying repository details appear only on the title page.”**
- `build_ledger.json` contains:
  `https://github.com/akssha74/dyfi-benchmark-reliability`
- `title_page.tex` states that the manuscript-level artifacts are supplied in the review archive.

The main and supplementary PDFs themselves are clean: their author blocks read “Blinded for Anonymous Peer Review,” and no author name, affiliation, email, or repository appears in either rendered PDF. The problem is the supplied artifact package. The repository handle links the package to the author identity and contradicts the manuscript’s “only on the title page” statement.

**Required action:** create a reviewer-specific archive that excludes the title page and every identity-bearing ledger, or replaces identity-bearing fields with blinded placeholders. Run an anonymity scan over every distributed file—not only `main.tex`—for names, affiliations, emails, handles, repository URLs, release tags, and unique project identifiers.

This is fully fixable without changing data, methods, results, or the frozen scientific claim.

## Scientific and numeric audit

### Paired cluster-robust inference

The source, scripts, and JSON agree on:

- \(d_{ig}=(y_{ig}-p_{a,ig})^2-(y_{ig}-p_{b,ig})^2\)
- event-weighted mean \(\hat\theta\)
- cluster influence totals \(U_g=\sum_i(d_{ig}-\hat\theta)\)
- CR1 factor \(G/(G-1)\)
- \(t_{G-1}\) reference with \(G=354\)
- Holm step-down over all ten admissible pairs

Independent recomputation from `family_wise_sensitivity.json` gives exactly seven Holm rejections and six Bonferroni 99.5% \(t\) intervals excluding zero. The ordered Holm boundary is correct:

- B1–B4: \(p=0.010855349147\), threshold \(0.0125\), rejected
- B4–B5: \(p=0.034959417716\), threshold \(0.0166667\), unresolved
- B2–B4: \(p=0.048519812716\), unresolved
- B2–B5: \(p=0.826880333639\), unresolved

B1–B4’s Bonferroni interval is \([-0.0011884, 0.0242537]\), so the manuscript correctly distinguishes its rank-specific Holm rejection from the simultaneous-interval result.

### Dependence checks

The reported cluster structure matches `robustness_post_hoc.json`: 430 events, 354 sequence clusters, 312 singletons, largest cluster 16, and \(G/(G-1)=1.0028329\), printed as 1.003.

The sensitivity decisions also match:

- default CR1, CR3, default wild-cluster, event-level \(t\), 50 km/15 d, 200 km/60 d, 5° CR1/wild, 10° CR1, log-loss, and exploratory AUROC: **seven**
- 10° wild-cluster: **six**, because B1–B4 has \(p=0.0130>0.0125\)
- seeded 15-pair family: **six**, again losing B1–B4

B1–B4 is the only admissible-pair decision that changes across Table S6. The abstract, Contributions, Section 5.5, Discussion, Conclusion, Table 4, and Table S6 consistently call it marginal and family/clustering dependent.

### Seeded candidate

The five seeded candidates are fitted on construction rows with B2’s frozen regularization only after rejection by the admission audit. The 15-pair family is correctly formed from the ten admissible pairs plus C\(_{F2}\) against the five admissible baselines. C\(_{F2}\) remains Holm-supported against B0, B1, and B4, while B1–B4 becomes unresolved.

The manuscript repeatedly states that this is a **by-construction policy illustration**, not evidence that the allowlist detects unknown contamination. The prospective schema-extension workflow is described but explicitly not claimed as evaluated.

### Other arithmetic

The core counts reconcile:

- roles plus straddles: \(1573+357+430+2=2362\)
- severe total: \(449+102+151+1=703\)
- role-assigned severe total: \(449+102+151=702\)

No numeric mismatch was found in the abstract, prose, tables, figures, or frozen JSON records.

## Tables, figures, and formatting

- Table 1 correctly reads **“Cluster-robust paired test + Holm control.”**
- Discussion’s four changed decisions correctly include B4–B5, not a family contrast.
- Table S1 is not wrapped in `resizebox`.
- Table S1 defines \(P(A\text{ better})\) as a descriptive bootstrap share, explicitly not a \(p\)-value.
- Table S1 explains the B2–B4 percentile-interval/test disagreement.
- Its \(p\)-values use consistent four-decimal presentation, with `<0.0001` for smaller values.
- Table S2 is single-spaced and repeats its header after the page break.
- Table S6 matches the JSON records in every cell and total.
- Figure 4’s labels and intervals are clear of the B0 reference line.
- No clipped or overfull content was found. `main.log` has zero overfull boxes; seven underfull boxes produce no visible defect.
- Notes are legible and justified.

The abstract is fully on page 1 and communicates the practical outputs, quantitative result, post-hoc status, single-catalogue scope, non-operational boundary, and need for fresh hidden data. Pandoc plain-text counting gives **193 words**, within the requested 200-word limit.

## Related work and novelty

Independent online checks confirmed:

- Holm (1979): the sequentially rejective Bonferroni procedure and family-wise error control
- Diebold and Mariano (1995): equal predictive-accuracy testing through paired loss differentials
- `evalci`, arXiv:2607.04429: paired tests, clustered bootstrap intervals, and all-pair Holm correction
- BetterBench: 46 benchmark-lifecycle practices and weak significance/reproducibility reporting across audited benchmarks
- Knap et al. (2026): recording-level leakage-safe benchmarking on two bearing datasets
- Kapoor and Narayanan (2023): leakage taxonomy and model information sheets

No fabricated or materially misattributed citation was found.

**Novelty class: incremental.** The sceptical reduction is: established benchmark-hygiene and paired-inference components packaged for one DYFI classifier comparison. The paper survives the stronger “occupied/reskin” objection because it supplies a concrete candidate-level fail-closed admission workflow coupled to family-wise decisions and reconstruction. It does not establish a new statistical method, prospective operating benefit, or cross-domain generalization. The manuscript states this remaining delta honestly and does not strengthen novelty after citing concurrent `evalci`.

## Nonblocking artifact findings

### R9-F2 — Claim ledger retains a pre-Holm interpretation

`claim_ledger.jsonl` entry `P_unresolved` says **“two learned-baseline pairs unresolved (B2 vs B4; B2 vs B5)”** and maps that statement to the abstract and prose. The manuscript’s authoritative Holm conclusion has three unresolved pairs: B2–B4, B2–B5, and B4–B5. A separate `H_B4_B5` entry correctly records `holm_rejects_zero=false`, so the numbers are present but the semantic usage mapping is stale.

**Action:** rename the old entry as an unadjusted-interval result, add a current Holm-unresolved entry listing all three pairs, and map abstract/prose usages only to the current entry and interpretation overlay. This is fixable without new data.

### R9-F3 — Abstract validator does not test the requested limit

`cbs_validation_report.json` records `concise_abstract=true` with detail `211`; the validator accepts 150–300 tokens and counts LaTeX control text. The rendered abstract is 193 words, so the manuscript passes, but the validation artifact does not establish that fact.

**Action:** count rendered/plain text, exclude commands and keywords, enforce `<=200`, and regenerate the report. This is fixable without new data.

## Reproducibility and release distinction

The public v1.1.1 release resolves. The title page and manuscript correctly distinguish that release from the review archive: the current Holm, seeded-candidate, robustness, and interpretation-overlay artifacts postdate v1.1.1 and are supplied locally for review. That is not an overclaim.

Before publication, the promised new immutable tag must contain the current scripts, JSON outputs, overlay, repaired claim ledger, and regenerated validation report. Until then, the public release is not the complete artifact for this manuscript version.

## Limitations requiring new data, not wording fixes

These are disclosed limitations, not correctness defects:

1. The Holm family, alternative inference checks, seeded candidates, and split-contrast intervals are post hoc. Confirmatory status requires fresh hidden outcomes with a prospectively frozen family.
2. B1–B4 is genuinely family- and clustering-dependent. Resolving it requires an independent sample under a predeclared dependence structure.
3. The contract is demonstrated on one magnitude-dominated catalogue, and the prospective schema-extension workflow is untested. A stronger novelty/usefulness score requires prospective application on a fresh benchmark version or independent event corpus.

## Top required changes

1. **Remove the blinding breach** from every reviewer-facing artifact and validate the entire archive.
2. **Repair the claim ledger** to represent the authoritative three unresolved Holm pairs.
3. **Fix the abstract validation gate**; the manuscript already satisfies the 200-word limit.
4. **Before publication, create a new immutable release** containing all current manuscript-level analysis and interpretation artifacts.

After the first change is independently verified, no scientific-result veto remains. The remaining two current-study defects are minor artifact corrections; stronger novelty and usefulness would require new prospective data rather than more wording.
