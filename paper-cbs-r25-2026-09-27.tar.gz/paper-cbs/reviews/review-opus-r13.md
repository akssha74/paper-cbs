# Review R13 (Claude Opus, independent, default-reject)

**Manuscript:** *A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study*
**Venue:** Cybernetics and Systems (double-anonymous)
**Recommendation:** Major revision (reject in current form under default-reject)
**Total:** 20 / 30. No veto triggered.

## Verification performed

- All eight SHA-256 hashes match. `frozen_inputs/contract_transfer_dbmi.json` is byte-identical to `contract-transfer-dbmi/results/results.json`. The hash-manifest entries for the runner, both xlsx files, `baselines.py`, `leakage_audit.py`, and `decluster.py` match. The three code hashes also appear in the 2026-09-01 frozen artifact manifest, so the "unchanged code" claim is verifiable.
- Main text is 32 pages, the supplement 8. The abstract is 200 words. The LaTeX log has no warnings.
- `validate_cbs.py` passes 57/57 in a `/tmp` copy that preserves the `research/` directory depth. A flat copy fails the transfer check, because the source is resolved by relative depth.
- Blinding is clean in both PDFs: no names, handles, repository URLs, or identifying metadata.
- Git chronology of the transfer: prereg commit `c5136429` (18:16:51Z), then runner, then a one-line import fix, then results `396ef501` (18:18:58Z). **The preregistration was committed before the results.** However, the commits are local and author-timestamped, and they are not contained in any fetched remote branch.

## Credited fixes

- The Sec. 5.7 numbers match `results.json`:
  - 382 instrumental events (1905–2020), cutoff 2005.
  - 312/70 split, with 218 and 62 sequences.
  - 21 severe and 49 not severe, no straddles.
  - 1,985 + 571 + 200 = 2,756 of 3,138 = 87.8%.
  - Spearman 0.755 vs 0.300 (but see F1 on the population).
- The fail-closed evaluability refusal is reported honestly: nothing was fitted, scored, or tested, no decision was issued, and the text says explicitly that no second test of the paired Holm decisions exists.
- Prior exposure is disclosed in both the plan and the manuscript.
- Related work now separates TFX model validation (Baylor), schema validation (Breck), and TFMA intervals, and concedes that allowlisting and version pinning are standard.
- The Fig. 3 caption now explains the dashed-grey prevalence series and the dotted 6.0 line, and the legend is legible.
- The abstract is accurate against the tables and `results.json`.

## Major findings

**F1. The Spearman coefficient is attributed to the wrong population (numeric integrity).**
The text says that for the 2,756 intensity-derived or mixed events, "magnitude tracks the label (Spearman 0.755…)". `results.json` computes 0.755 on `n_macroseismic = 2185` (Mdm + MIo + Mpc + Mio), which excludes the 571 Wmim events; `RESULTS.md` correctly says n = 2,185. The validator checks only the string "Spearman 0.755". Fix the attribution, or compute the coefficient on all 2,756 as a labelled post-hoc descriptive.

**F2. The refusal was arithmetically guaranteed (soundness).**
The cutoff rule caps the holdout at 20% of the cohort, and 0.2 × 382 = 76 < 100. So any instrumental cohort under 500 events must fail the 100-event floor. Cohort size depends only on outcome-blind `TMwDef` codes in files the authors had already read, and the plan records no expected cohort size or feasibility check. The refusal is therefore a gate demonstration, not an informative outcome of a transfer test. Disclose this, and ideally add a feasible design that exercises the paired decisions on a second catalogue.

**F3. Transfer behaviours are attributed to the "unchanged" contract (claim calibration).**
The provenance rule lives in `run_transfer.py load()`, and the evaluability floor in lines 242–252 of the same file. Neither is in `leakage_audit.py` or `baselines.py`, and neither appears in Fig. 1 or Table 1. Yet the contribution list says "with unchanged code, showing that … the contract refuses", and the related-work delta claims "provenance-bound admission" as a contribution. Attribute both behaviours to the transfer plan and propose them for a version-2 contract, or implement them in the contract, the figure, and the table.

## Moderate findings

**F4. Inconsistent standard for "preregistration".**
Sec. 3 refuses the word for the DYFI protocol because it was not publicly timestamped. The transfer is called "preregistered" throughout on the basis of a local commit made two minutes before execution. Apply one standard, or add an external timestamp.

**F5. Novelty is incremental.**
The remaining delta items are largely occupied:
- Provenance and availability binding is prior art in Kaufman et al.'s legitimacy tagging (already cited) and in point-in-time feature stores.
- Event-sequence roles are blocked/grouped cross-validation.
- The cited evalci already packages all-pair Holm with cluster intervals.
- The "second worked catalogue" produced no paired decision.

## Minor findings

- **F6.** "Blessing" is TFX Evaluator documentation terminology, not language from the 2017 KDD paper. The TFMA citation should be pinned to a commit.
- **F7.** The 0.755 vs 0.300 contrast is confounded by era and magnitude range (range restriction). Rest the argument on the derivation codes.
- **F8.** In the non-evaluable branch, the runner returns before it writes `hash_manifest.json`, so the committed manifest was produced outside the preregistered runner, and that step is undocumented. The gate-skipped prereg items (negative control, threshold sensitivity, S1 illustration) are not itemised in Supplementary Table S2. The validator is path-dependent.
- **F9.** The abstract is accurate, but it puts caveats before results. Its transfer sentence implies that the contract "shows" provenance binding.
- **F10.** The provenance lesson is useful but advisory: it is not shipped as an executable contract field.

## Scores

| Criterion | Score |
|---|---|
| cbs_venue_fit | 2 |
| novelty | 1 |
| soundness | 2 |
| numeric_integrity | 2 |
| claim_calibration | 2 |
| editor_page_1 | 2 |
| reproducibility | 2 |
| related_work_citations | 2 |
| formatting_blinding | 3 |
| usefulness | 2 |
| **Total** | **20 / 30** |

Vetoes: fabricated_citation, numeric_mismatch, blinding_breach, clearly_out_of_scope, and unsupported_overclaim are all false. F1 comes close to numeric_mismatch but does not change any conclusion.

## Changes needed to raise each sub-3 criterion to 3

- **novelty:** Credit Kaufman legitimacy tags and point-in-time feature stores as prior art. Restate the delta as the fail-closed combination. Drop "two worked catalogues".
- **soundness:** Disclose that refusal was guaranteed (0.2 × 382 < 100) and whether the count was known in advance. Ideally, add a feasible second catalogue with paired decisions.
- **numeric_integrity:** Attribute Spearman 0.755 to the 2,185 events, or recompute it on all 2,756.
- **claim_calibration:** Apply one timestamp standard to the word "preregistered". Attribute the provenance rule and evaluability floor to the transfer plan.
- **editor_page_1:** Reorder the abstract so that each result comes before its caveat, and rephrase the transfer sentence.
- **reproducibility:** Document how the manifest was generated. List the gate-skipped prereg items in S2. Track the transfer helpers and inputs, or give their archive hashes. Make the validator path-independent.
- **related_work_citations:** Cite the TFX Evaluator docs for "blessing", pin TFMA to a commit, and add the Kaufman / feature-store comparison.
- **cbs_venue_fit:** Frame the contract as a formal accept/reject controller with explicit error rates and a version-bump feedback loop, and include the transfer lessons in it.
- **usefulness:** Ship provenance binding and the evaluability floor as tested contract fields, and show one complete paired decision outside DYFI.
