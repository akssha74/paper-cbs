# Independent default-reject review — GPT-5.6, round 6

## Verdict

**Reject in current form; invite resubmission after major evidence and release corrections.**

The manuscript is numerically consistent, unusually transparent about post-hoc analyses, clearly written on page 1, well blinded, and reproducible from the supplied local package. Default-reject is retained because the contribution is an incremental integration of established controls demonstrated on one corpus, registered robustness and uncertainty branches remain incomplete, and the named public release does not contain the current CBS overlay or the two post-hoc scripts and records supporting headline decisions.

Novelty class: **incremental**.

## Scores

- `cbs_venue_fit`: **2/3**
- `novelty`: **1/3**
- `soundness`: **2/3**
- `numeric_integrity`: **3/3**
- `claim_calibration`: **3/3**
- `editor_page_1`: **3/3**
- `reproducibility`: **2/3**
- `related_work_citations`: **3/3**
- `formatting_blinding`: **3/3**
- `usefulness`: **2/3**
- **Total: 24/30**

## Vetoes

- `fabricated_citation`: **false**
- `numeric_mismatch`: **false**
- `blinding_breach`: **false**
- `clearly_out_of_scope`: **false**
- `unsupported_overclaim`: **false**

No veto was triggered. The rejection recommendation follows from the default-reject evidence threshold, not from a fatal integrity defect.

## Version pin and review coverage

- `main.pdf` SHA-256: `50b01d3b9b8162e1bd64abded703d5b77f8e04e6cb5d27fe61b156622801e406`
- `main.tex` SHA-256: `a7617360a5c9fce017ab1e15d9c8109a5025d5465b15e84dfc6995aad6fa9c59`
- `supplement.pdf` SHA-256: `b74a7a3eaa6fc0ad012ef1180780769cac9fe4f246d1a3cc461f076e83c9c69c`
- The claimed `main.pdf` and `main.tex` hashes match, and the pair matches `build_ledger.json`.
- Repository HEAD was `b3fcc66f77139194d9185eeb7f9db88039f27bd0`; `paper-cbs` was untracked, so this review pins the reviewed working-tree files by hash.
- The PDF text, all five rendered figures, all four supplement pages, `main.tex`, every `tables/*.tex` file, the four requested frozen-input records, both post-hoc scripts, both ledgers, the validation report, bibliography, title page, and build ledger were checked.

## Specific required checks

### Holm-controlled labels — pass

`family_wise_sensitivity.json` and Supplementary Table S1 agree. Six of ten pairwise hypotheses are rejected under Holm. B1–B4 and B4–B5 are the two comparisons that change from unadjusted 95% exclusion to unresolved; B2–B4 and B2–B5 were already unresolved. The same six Bonferroni 99.5% intervals exclude zero.

### Seeded response-count candidate — pass

C_F2 is reported as Brier **0.172**, AUROC **0.809**, and log-loss **0.515**. The frozen record gives unrounded values 0.172389679459, 0.809276270503, and 0.515321511554. The executable admission audit rejects `num_responses` as family F2 before its scores are used.

### Post-hoc disclosure — pass

The post-hoc status of the Holm family, B2-versus-B0 comparison, and seeded candidate is disclosed in the abstract, Section 4.4, Results, Limitations, and Supplementary Table S2. The manuscript does not present these as confirmatory findings.

### Figure 1 and other figures — pass

Figure 1 correctly shows declare → input/role audit → temporal-holdout score → paired comparison, with fail-closed, Holm-supported, and unresolved outcomes. All five rendered figures are legible, correctly numbered, and consistent with their captions and tables. Figure 4’s axes start at zero as stated.

### Diagnostic random forest — pass

The diagnostic is separated from tuned baseline B4 and accurately characterized as poorly calibrated with moderate discrimination: AUROC 0.70–0.71, Brier near the construction no-skill floor, and log-loss 0.92–0.97. No leakage, sign, equivalence, or win inference is made.

### B0 construction-prevalence note — pass

Independent arithmetic gives a holdout-prevalence constant Brier score of 0.227847485127, printed as **0.228**, versus **0.232160107935** for the construction-prevalence constant. The manuscript’s “about 0.004” statement is correct.

### BetterBench and Knap et al. — pass

BetterBench evaluates 24 benchmarks against 46 lifecycle practices and reports weak statistical-significance/uncertainty reporting; the manuscript correctly distinguishes benchmark assessment from candidate gating. Knap et al. use two bearing datasets, six fixed source–target scenarios, recording-level separation, and common ML/DL baselines; the manuscript correctly describes that work as broader in corpus coverage.

### Interpretation overlay — pass

The manuscript-level overlay explicitly supersedes the stale “small and slightly reversed” and “leakage-hardened” interpretations. The manuscript uses descriptive point-estimate language and makes no inferential sign claim.

### Scope and blinding — pass

No task-agnostic empirical claim was found; reuse beyond DYFI is repeatedly stated as untested. The main PDF and supplement contain no author, institution, email, or repository identity. Identifying information is confined to the separate title page, consistent with double-anonymous review.

### Reproduction — local pass, public-release gap

In an isolated copy using Python 3.11.15, scikit-learn 1.5.2, and XGBoost 2.1.4, both post-hoc scripts verified the prediction digest and regenerated byte-identical JSON outputs.

The public `v1.1.1` tag resolves to commit `8d5918977732a56e38f2f81d162cb80c2c038473`, but its recursive tree contains `paper-jeas` and the original manuscript assets, not `manuscript/paper-cbs`, `cbs_interpretation_overlay.json`, `family_wise_sensitivity.py/json`, or `seeded_candidate_demo.py/json`.

## Major findings

### R1 — Current CBS artifacts are absent from the public tag

**Touches:** evidence.

Section 5.9 says the manuscript-level overlay and the Holm and seeded-candidate scripts and records are released. The exact public tag named on the title page does not contain the current CBS package or those five artifacts. A reader using the named release cannot reproduce the current interpretation and post-hoc headline decisions without the separate review package.

**Required action:** publish an immutable release containing the exact reviewed CBS source, overlay, both scripts, both JSON outputs, and their hashes. Alternatively, explicitly distinguish the editor-only archive from the older public tag and remove any implication that the tag contains the current additions.

### R2 — Novelty and usefulness rest on one post-hoc demonstration

**Touches:** evidence.

The manuscript acknowledges that its components are established separately. It evaluates one DYFI corpus and demonstrates conclusion reversal with one deliberately seeded response-count field introduced after holdout opening. BetterBench and Knap et al. already occupy benchmark-quality and leakage-safe reproducible benchmarking territory.

The candidate-level admission gate coupled to a family-wise decision is a clear integration delta, but the evidence does not yet establish a broadly useful systems contribution beyond this constructed case.

**Required action:** add a pre-specified qualification on fresh hidden data and at least one independent catalogue or application family. Otherwise, position the work explicitly as an incremental DYFI case-study protocol and temper the “Transferable lessons” paragraph.

### R3 — Registered robustness and uncertainty coverage remains incomplete

**Touches:** evidence.

Supplementary Table S2 records that the split contrast lacks its required paired interval, aggregation-grid sensitivity was not run, the geographic transport branch was not run, and only Brier-based intervals were retained. The fixed 100-km/30-day sequence definition was not varied.

These omissions are disclosed and therefore do not create a numeric-integrity veto, but they cap soundness and the strength of the qualification evidence.

**Required action:** complete the registered interval and sensitivity analyses, including sequence-definition sensitivity. If that is infeasible, remove the split diagnostic from the contribution narrative and keep all conclusions explicitly conditional on the fixed design.

## Minor findings

### P1 — Holm column uses interval language

Supplementary Table S1 labels Holm outcomes “excludes 0” and “includes 0,” although Holm is applied to bootstrap p-values and the adjacent column already reports Bonferroni interval inclusion.

**Required action:** change the Holm cells to “reject” and “unresolved” or “do not reject”; reserve “excludes/includes 0” for the Bonferroni interval column.

### C1 — Corrected near-neighbor is not recorded as corrected

The Patelli et al. *Scientific Reports* article has a March 2026 correction concerning its dataset. The cited DOI now resolves to the corrected version, and the random 70/30 partition statement remains verifiable, so this is neither a fabricated nor a misapplied citation. However, neither `references.bib` nor `citation_ledger.jsonl` records the correction.

**Required action:** record the correction notice and confirm that the corrected version still supports the attached partition claim.

## Strengths

- Every checked number agrees with the supplied frozen assets, tables, and ledgers.
- Claims are carefully separated into unadjusted, post-hoc, descriptive, and confirmatory categories.
- The first page states the pain point, goal, main quantitative results, users, and non-use boundary.
- The nearest-work discussion accurately engages BetterBench and Knap et al. without claiming a new statistical primitive.
- The manuscript and supplement are cleanly blinded, visually readable, and use embedded fonts.

## Top required changes

1. Release the exact current CBS package and headline-supporting artifacts under an immutable public tag, or narrow the release claims.
2. Provide pre-specified confirmation on fresh hidden data and an independent second application, or reposition the contribution as an incremental single-corpus case study.
3. Complete the missing split-contrast uncertainty and registered robustness analyses, especially sequence-definition and aggregation-grid sensitivity.
4. Relabel the Supplementary Table S1 Holm column and record the Patelli et al. correction.

Finding tally: **0 result, 4 evidence, 1 presentation, 0 self-description**. Convergence is not declared because evidence findings R1–R3 remain open.
