# Independent Default-Reject Review (GLM-5.2) — review-glm-r7

**Manuscript:** *A Fail-Closed Qualification Contract for Machine-Learning Classifier Comparison, Demonstrated on a Versioned Seismic Felt-Intensity Catalogue*
**Venue:** Cybernetics and Systems (Taylor & Francis) — broad applied AI/ML, decision systems
**Stance:** Independent default-reject. No scores from prior rounds (r1–r6) were read. Source tree treated as frozen; no manuscript, script, frozen input, or other study was modified.

## Hash verification (shasum -a 256)

| File | Claimed | Computed | Match |
|---|---|---|---|
| `main.pdf` | `5b693ca8…6a46d2a8` | `5b693ca8…6a46d2a8` | ✓ |
| `main.tex` | `f0ae5bde…1a40dd14` | `f0ae5bde…1a40dd14` | ✓ |
| `supplement.pdf` | `2056f843…ff243688` | `2056f843…ff243688` | ✓ |

All three claimed hashes match.

## Vetoes

| Veto | Triggered | Basis |
|---|---|---|
| fabricated_citation | No | All citations resolve (`cbs_validation_report.json`: `all_citations_resolve` ok); Patelli correction recorded in `references.bib` note field and `citation_ledger.jsonl`. |
| numeric_mismatch | No | Every number I cross-checked (Tables 3, 4, S1; abstract; Sections 5.2–5.7) matches the frozen assets exactly. The Table 4/S1 cross-reference defect (RC1) is a documentation mislabel, not a wrong reported value. |
| blinding_breach | No | `main.tex` author block is "Blinded for Anonymous Peer Review"; identities and GitHub URL are confined to the separate `title_page.tex`; acknowledgements are non-identifying. |
| clearly_out_of_scope | No | Decision-support contract for ML classifier comparison; five engaged venue precedents. |
| unsupported_overclaim | No | Heavily hedged: "fragile" label, no winning model, unresolved split contrast, post-hoc disclosed, single-corpus scope repeated. |

**No veto triggered.**

## Scores (0–3 each, total /30)

| Criterion | Score |
|---|---|
| cbs_venue_fit | 3 |
| novelty | 1 |
| soundness | 2 |
| numeric_integrity | 2 |
| claim_calibration | 2 |
| editor_page_1 | 2 |
| reproducibility | 3 |
| related_work_citations | 3 |
| formatting_blinding | 2 |
| usefulness | 2 |
| **total_score** | **22 / 30** |

**Recommendation: reject-unless-revised.** An honestly-hedged but genuinely incremental resource/protocol packaging on a single frozen corpus with every inferential analysis post-hoc. Two documentation defects in the Table 4 / Table S1 cross-reference must be fixed before the supplement can be verified standalone; none is veto-worthy.

## Cross-checks against frozen assets

### Holm labels (family_wise_sensitivity.json)
- `n_holm_reject = 6`; manuscript: "Six of the ten pairwise differences remain rejected under Holm." ✓
- Rejected pairs: B0–B1, B0–B2, B0–B4, B0–B5, B1–B2, B1–B5. ✓
- B1–B4 `holm_rejects_zero = false`; B4–B5 `holm_rejects_zero = false`. ✓ (manuscript: "B1–B4 … and B4–B5 become unresolved")
- `n_bonferroni_exclude_zero = 6` (same six). ✓
- Bonferroni 99.5% CIs: B1–B4 `[-0.002040, 0.023454]` → manuscript `(-0.0020, 0.0235)` ✓; B4–B5 `[-0.001497, 0.011288]` → `(-0.0015, 0.0113)` ✓.
- **Table S1 caveat:** the column is labelled "95% CI" and the values equal `ci95_reproduced` (e.g. B1–B4 `[0.0023, 0.0205]`), **not** the Bonferroni 99.5% intervals. The two-sided bootstrap p-values that drive Holm (`bootstrap_p_two_sided`) are **not** tabulated in S1; only `P(A better)` is. See RC1/RC2.

### B4-vs-B1 "fragile" label (robustness_post_hoc.json)
- Ten-pair Brier, default 100 km/30 d (354 clusters): B1–B4 `holm_reject = false` → unresolved. ✓
- Seven-pair reference-only family: B1–B4 in `holm_rejected_pairs` → supported. ✓
- AUROC Holm family: B1–B4 `holm_reject = true` → supported. ✓
- Log-loss Holm family: B1–B4 `holm_reject = true` → supported. ✓
- 200 km/60 d (295 clusters): B1–B4 `holm_reject = true` → supported (wider window). ✓
- 50 km/15 d (375 clusters): B1–B4 `holm_reject = false` → unresolved. ✓
- "All other decisions identical under every alternative" — confirmed against the three sequence-definition blocks and the reference-only block. ✓

### Post-hoc paired split-contrast intervals (robustness_post_hoc.json, `split_contrast_paired`)
All include zero. ✓
- seq−rand Brier: `−0.005878` → `−0.0059`, CI `[-0.011920, 0.000523]` → `[-0.0119, 0.0005]` ✓
- seq−rand AUROC: `0.012397` → `0.0124`, CI `[-0.001925, 0.026594]` → `[-0.0019, 0.0266]` ✓
- seq−rand log-loss: `0.006859` → `0.0069`, CI `[-0.126843, 0.147924]` → `[-0.127, 0.148]` ✓
- event−rand Brier: point `−0.003959`, CI `[-0.009724, 0.002289]` → `[-0.0097, 0.0023]` ✓ (manuscript states magnitude "0.0040" without sign — see RC3)

### Five seeded candidates (seeded_candidate_demo.json)
- **C_F1** (adds `max_cdi`): Brier `0.024622` → 0.025, AUROC 1.000, family F1, rejected. ✓
- **C_F2** (adds `num_responses`): Brier `0.172390` → 0.172, AUROC `0.809276` → 0.809, log-loss `0.515322` → 0.515, family F2, rejected. ✓
- **C_F2 renamed** (`n_reports`): family `F0_unknown_non_allowlisted`, rejected by allowlist; scores identical to C_F2. ✓ (manuscript: "matches no named family… still rejected, because it is outside the two-field allowlist")
- **C_year** (`origin_year`): Brier `0.178460` → 0.178, `axis_audit.passed = false` (temporal proxy), rejected by allowlist and temporal-axis audit. ✓
- **C_geo** (lat/lon): Brier `0.179497` → 0.179, vs B2 diff `−0.001164` → −0.0012, CI `[-0.003101, 0.000796]` → `[-0.0031, 0.0008]`, unresolved, rejected. ✓
- **C_F2 vs admissible**: vs B2 CI `[-0.018092, 0.000482]` includes zero, `prob_better = 0.965`; vs B5 CI `[-0.018170, -0.000442]` → `[-0.0182, -0.0004]` excludes zero. Extended 15-pair Holm: `C_F2_holm_supported_against = [B0, B1, B4]`, `n_pairs = 15`. ✓ (manuscript: "Holm-supported against B0, B1, and B4"; abstract: "Holm-supported against three admissible models")

### Table 3 holdout scores (asset_inputs.json / seeded_candidate_demo.json)
B0 0.232 [0.212, 0.253] ✓; B1 0.198 [0.177, 0.219], AUROC 0.719, cal 0.32/1.02 ✓; B2 0.181, AUROC 0.786, log-loss 0.536 ✓; B4 0.187, AUROC 0.777, cal 0.74/1.48 ✓; B5 0.181, AUROC 0.783, cal 0.42/1.07 ✓.

### RF probe wording (asset_inputs.json)
- random-event Brier `0.204833` → 0.2048; construction no-skill constant `0.203986` → 0.2040; sequence-grouped Brier `0.198955` → 0.1990.
- "0.0050 better" = 0.2040 − 0.1990 (vs constant); "0.0059 lower" = 0.2048 − 0.1990 (vs random). Both comparisons are stated and internally consistent. ✓

### B0 prevalence arithmetic
- Construction prevalence 0.285492; holdout prevalence 0.351163. B0 (constant 0.285) holdout Brier = 0.232160 ✓. Holdout-prevalence constant Brier = 0.2275 → 0.228 ✓. Difference 0.232 − 0.228 ≈ 0.004 ✓.

### Cohort accounting (Table 2)
7,520 → 2,362 eligible (703 severe) → 1,573 + 357 + 430 + 2 = 2,362 ✓; construction 1,930 / 1,530 sequences; holdout 430 / 354 sequences; eligible 1,885 sequences ✓.

### Post-hoc disclosure
Post-hoc status is disclosed in the **abstract**, **Section 4.4** (Holm rule, B2-vs-B0), **Section 5.5** (family/metric/window sensitivity, B2-vs-B0), **Section 5.6** (seeded candidates), **Section 5.7/5.9**, **Section 7 limitations**, and **Table S2**. The split contrast is demoted from the protocol's primary to a secondary diagnostic. ✓

### Release distinction (title_page.tex / Section 5.9)
Public tag v1.1.1 carries the frozen release; manuscript-level overlay and Holm/seeded/robustness scripts + outputs postdate v1.1.1, are supplied in the review archive with SHA-256, and will be deposited under a new immutable tag on acceptance, leaving v1.1.1 unchanged. The title page distinguishes the two tags. Honest. ✓

### Overlay (cbs_interpretation_overlay.json)
Present; `supersedes_for_this_manuscript = true`; `changes_numeric_results = false`; `leaves_hashed_release_files_unchanged = true`. It deprecates the stale "small and slightly reversed" / "leakage-hardened" framings, the `*_inflation_*` and `honest_estimate_scheme` keys, and the `resolved_directional` status for B1–B4 and B4–B5. ✓

### Patelli correction
Recorded in `references.bib` (`note = {Correction: Sci. Rep. 16, 9208 (2026), doi:10.1038/s41598-026-44475-8}`) and in `citation_ledger.jsonl` (correction field, `verification = web_verified_2026-09-26`). The printed reference [7] includes the correction line. ✓

### BetterBench / Knap et al.
BetterBench (Reuel et al. 2024) is correctly characterized as benchmark-level (46 lifecycle practices; most omit significance) and contrasted with this candidate-level gate. Knap et al. is correctly characterized as broader (two bearing datasets, recording-level splits, common baselines) and the repeated-seed averaging distinction is explicitly disclosed. ✓

### Blinding
`main.tex` author block is "Blinded for Anonymous Peer Review"; identities, affiliations, CRediT, and GitHub URL appear only on `title_page.tex`. `cbs_validation_report.json` confirms `main_text_blinded` and `title_page_carries_identities`. No breach. ✓

### Task-agnostic claims
None. Scope is repeatedly limited to "this frozen DYFI task"; "reuse outside this dataset is untested" appears in abstract, contributions, discussion, and conclusion. ✓

## Top required changes

1. **RC1 (major, documentation).** The Table 4 note states "Bonferroni 99.5% intervals are in Supplementary Table S1", but Table S1 reports **unadjusted 95% CIs** (column header "95% CI"; values equal `ci95_reproduced`, not `bonferroni_ci`). The Bonferroni 99.5% intervals currently appear only in the Section 5.5 prose. Either add a Bonferroni 99.5% CI column to Table S1, or correct the Table 4 note to point to the prose and `family_wise_sensitivity.json`.
2. **RC2 (major, transparency).** The Holm step-down (Section 4.4) operates on two-sided bootstrap p-values, but Table S1 reports only `P(A better)`. A reader cannot reproduce the six Holm rejections from the supplement. Add `bootstrap_p_two_sided` as a Table S1 column.
3. **RC3 (minor, wording).** Section 5.3 gives the event-grouped vs random-event Brier gap as unsigned "0.0040" while the sequence-grouped gap is signed ("0.0059 lower"). State the event-grouped direction explicitly for consistency.
4. **RC4 (minor, novelty).** Novelty is genuinely incremental (authors concede no component is new; single corpus). To clear the venue bar, demonstrate the contract on at least one second corpus, or explicitly position the paper as a resource note rather than a research article.
5. **RC5 (minor, scope).** Every inferential analysis is post-hoc and disclosed as such. Consider preregistering a confirmatory re-run on a fresh hidden holdout so at least one decision is confirmatory rather than post-hoc.

## Strengths
- Exceptionally honest calibration: "fragile" B4-vs-B1 label, no winning model, unresolved split contrast, post-hoc status disclosed everywhere it matters.
- All reported numbers verified against frozen assets; no numeric mismatch.
- Strong reproducibility: hashed versioned release, pinned environment, digest-verified reconstruction, build ledger, machine-readable overlays that leave hashed files byte-identical.
- Patelli correction recorded in both `references.bib` and `citation_ledger.jsonl`.
- Five engaged Cybernetics and Systems precedents with clear deltas.
- Blinding intact.

## Weaknesses
- Incremental novelty (packaged combination of established pieces on one frozen corpus; authors concede this).
- Every inferential analysis is post-hoc; no confirmatory result.
- Single dataset; reuse on other catalogues untested.
- Magnitude-dominated endpoint (B1 AUROC 0.719; B2 0.786) makes the classification task easy; the contract, not the modelling, is the contribution.
- Table 4 / Table S1 cross-reference defects (RC1, RC2) reduce standalone verifiability of the supplement.
