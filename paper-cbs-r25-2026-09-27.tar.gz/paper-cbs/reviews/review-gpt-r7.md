# Independent default-reject review — GPT-5.6, round 7

**Venue:** *Cybernetics and Systems*  
**Verdict:** Reject in present form  
**Total:** **21/30**  
**Veto triggered:** `unsupported_overclaim`

## Scores

- `cbs_venue_fit`: **2/3** — In scope for applied AI, decision making, and systems, but demonstrated on only one seismic catalogue.
- `novelty`: **2/3** — The candidate-level admission gate plus family-wise decision and contaminated-winner demonstration is a concrete integration; its constituent methods are established.
- `soundness`: **2/3** — The design is transparent, but the claimed family-wise control depends on bootstrap tail-area p-values whose null validity is not established.
- `numeric_integrity`: **3/3** — Requested values and labels match the frozen records; all three optional reproductions were byte-identical.
- `claim_calibration`: **1/3** — Strong local caveats are offset by a task-agnostic recommendation and an inaccurate “proper scores” description.
- `editor_page_1`: **2/3** — The abstract clearly gives the problem, task, results, post-hoc status, and non-use boundary, but its fragile-result sentence is technically inaccurate.
- `reproducibility`: **3/3** — Pinned scripts regenerate all three post-hoc JSON records byte-for-byte; release/archive distinctions are explicit.
- `related_work_citations`: **3/3** — BetterBench, Knap et al., the Patelli correction, venue precedents, and domain neighbors are substantively engaged.
- `formatting_blinding`: **1/3** — Blinding passes, but Supplementary Table S2 is visibly truncated in the PDF.
- `usefulness`: **2/3** — Intended users and the admit/reject workflow are concrete; transfer beyond this frozen task is untested.

## Vetoes

- `fabricated_citation`: **false**
- `numeric_mismatch`: **false**
- `blinding_breach`: **false**
- `clearly_out_of_scope`: **false**
- `unsupported_overclaim`: **true**

## Major findings

### R7-1 — Task-agnostic recommendation exceeds the evidence
**Touches:** evidence

The Discussion states: “Transferable lessons. Independent of the DYFI scores: (i) pin any benchmark used for model selection … (ii) report a paired, family-wise-controlled interval for every superiority claim …”. The limitations state that no second non-seismic dataset was evaluated and reuse is untested.

The universal “any” and “every” recommendations are not established by one retrospective DYFI instantiation. Delete this language or scope it to proposed practices for similar versioned, dependent-event retrospective comparisons. This finding triggers the `unsupported_overclaim` veto.

### R7-2 — Holm control relies on unvalidated bootstrap p-values
**Touches:** result

`family_wise_sensitivity.py` and `robustness_post_hoc.py` resample clusters from the observed data and define a two-sided p-value as twice the smaller fraction of ordinary bootstrap differences on either side of zero. The resampling distribution is not centered under the null or studentized.

Holm controls family-wise error only when its input p-values have the needed null validity. Exact reproduction verifies computation, not p-value calibration. Validate this construction, use a null-valid paired procedure, or narrow the wording to exploratory Holm-adjusted bootstrap tail-area labels without a formal family-wise-error guarantee.

### R7-3 — Supplementary Table S2 is truncated
**Touches:** presentation

On `supplement.pdf` page 4, Table S2 runs through the footer. The “Seeded candidates” rationale is cut after “B2’s frozen,” the page number overlaps the table, and page 5 begins with Table S3. The rest of that row and the equivalence row in the source never render.

Use a breakable `longtable` or split Table S2, rebuild, and visually confirm every row.

### R7-4 — Table S5 contradicts the added split intervals
**Touches:** self-description

The supplement introduction, main Section 5.3, and Table S2 say post-hoc paired split-contrast intervals were added. Table S5 instead says: “This deviation is disclosed, and no post-hoc interval or equivalence claim is added.”

Replace the stale note with wording that distinguishes the absent frozen-protocol interval from the added post-hoc intervals and states that those intervals include zero.

## Minor findings

1. The abstract says B4 versus B1 is supported under “other proper scores.” The sensitivity uses log-loss and AUROC; AUROC is not a proper scoring rule. Name “log-loss and AUROC” directly.
2. Knap et al. report mean ± standard deviation across seeds 41, 42, and 43 for shortlisted deep-learning configurations. Replace “average training variance over repeated seeds” with that exact description.

## Requested factual checks

- **Hashes:** all three claimed SHA-256 values match.
- **Ten-pair Holm family:** 6/10 rejected. B1–B4 (`p=0.017991`) and B4–B5 (`p=0.034983`) are not rejected; their Bonferroni 99.5% intervals include zero.
- **B4 versus B1 fragility:** matches the asset. It is unresolved for the default ten-pair Brier family and 50 km/15 d window; supported for the seven-pair reference-only family, log-loss, AUROC, and 200 km/60 d window.
- **Split contrasts:** all six event/sequence-versus-random Brier, AUROC, and log-loss intervals include zero.
- **Seeded candidates:** C_F1, C_F2, renamed C_F2, C_year, and C_geo are correctly rejected with matching scores. In the 15-pair family, C_F2 is Holm-supported against B0, B1, and B4.
- **RF probe:** correctly reports random-event Brier 0.2048 versus constant 0.2040.
- **Post-hoc disclosure:** passes in the abstract, Sections 4.4/5.5/5.6, and limitations. Table S2’s source is complete but its PDF rendering is truncated; Table S5 is contradictory.
- **Release distinction:** honest. Public tag `v1.1.1` does not contain the named manuscript-level Holm, seeded-candidate, robustness, or interpretation-overlay additions; the title page says they are in the review archive pending a new immutable tag.
- **Overlay:** correctly supersedes the stale split-framing strings, `*_inflation_*`/`honest_estimate_scheme` keys, probe identity, and unadjusted B1–B4/B4–B5 directions without changing numbers.
- **Patelli:** the correction DOI `10.1038/s41598-026-44475-8` appears in the bibliography and compiled PDF.
- **BetterBench:** accurately described as a 46-practice assessment of 24 benchmarks that identifies weak statistical-significance and replication reporting.
- **Knap et al.:** the two datasets, six scenarios, recording-level split, common baselines, and repeated-seed follow-up are accurate; only the “average training variance” phrasing needs correction.
- **Task-agnostic claim:** fails because of the “Transferable lessons” paragraph.
- **Blinding:** main and supplement contain no author identity, affiliation, email, repository URL, or author PDF metadata. The identifying title page is separate.

## Reproduction

Using `/tmp/dyfi-analytics-venv/bin/python`:

- `family_wise_sensitivity.py` → byte-identical JSON
- `seeded_candidate_demo.py` → byte-identical JSON
- `robustness_post_hoc.py` → byte-identical JSON

The original frozen records were restored.

## Top required changes

1. Remove or narrowly scope the task-agnostic “Transferable lessons.”
2. Validate/replace the bootstrap p-values or narrow the formal Holm family-wise-control claim.
3. Repair clipped Supplementary Table S2 and rebuild the supplement.
4. Correct the stale Table S5 note and the abstract’s “other proper scores” wording.
