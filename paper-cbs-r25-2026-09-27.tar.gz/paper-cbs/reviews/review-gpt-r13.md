# Independent default-reject review — GPT-5.6, round 13

Venue: *Cybernetics and Systems* (Taylor & Francis), double-anonymous  
Reviewed commit: `d7ce6a5f1b1b39e0c0190158be75ed33ad891a1f`  
Verdict: **Reject and resubmit after major correction**  
Score: **24/30**

## Scores

- `cbs_venue_fit`: **3/3**
- `novelty`: **2/3**
- `soundness`: **2/3**
- `numeric_integrity`: **2/3**
- `claim_calibration`: **2/3**
- `editor_page_1`: **3/3**
- `reproducibility`: **2/3**
- `related_work_citations`: **2/3**
- `formatting_blinding`: **3/3**
- `usefulness`: **3/3**

## Vetoes

- `fabricated_citation`: **false**
- `numeric_mismatch`: **true**
- `blinding_breach`: **false**
- `clearly_out_of_scope`: **false**
- `unsupported_overclaim`: **true**

The paper is in scope, clearly motivated, useful, and extensively auditable. Rejection is nevertheless required because the new transfer section attaches a reported correlation to the wrong population and overstates which parts of the parent code were actually executed.

## Pin and package checks

All requested SHA-256 values match:

- `main.pdf`: `51e273420579ac0f045a507b07e51c0dff94ad502d2aa5ea8c9eebe5dfe06e68`
- `main.tex`: `0589c91a6382febe637fd0081c4005ffc28d5ad1a8ed3280cb2ca804fa5cfa2b`
- `supplement.pdf`: `77cb18c162298fdd6fa29c0d91c6e79e0c250c24f40ca57a86f564fe72af4a3a`
- `supplement.tex`: `0f2b5efe4b257ad8889cdb60bc421076b81be18a0e02ac1bbea8e91ac87be395`
- `references.bib`: `a2e1f75b8d0658d0aaf2ce968f6e9d5cc32b6c73fa577a9805ee8c18dc0305ad`
- `build_ledger.json`: `cc8dbb18fdc57695ec93d7f31fe43282e0b44f89b8be7c36a70865c2d0eeab62`
- `frozen_inputs/contract_transfer_dbmi.json`: `5e76d7b35c09f2efe9dbbff69d1675ffd4f16a7f4783455fcc2d10cc2651a002`
- transfer `prereg/analysis_plan.md`: `dbc2b6a0b3dc4de245ef6a774d3fdf0146c8095da4903a2be67895aaf3063bfe`

The main PDF has 32 pages and the supplement has 8. The supplied validation report records 57/57 passing checks. I did not rerun `validate_cbs.py` because it writes artifacts; I independently checked the requested hashes, principal arithmetic, transfer chronology, transfer denominators, and Holm sequence.

## Goal and usefulness

The study asks whether a candidate-model improvement remains admissible and statistically supportable after version, feature-boundary, dependence, temporal-holdout, multiplicity, and reconstruction controls are enforced.

The intended users are applied-ML engineers, benchmark maintainers, and reviewers. The enabled task is concrete: return an admit/reject decision before scoring and a Holm-supported/unresolved label after paired comparison. Usefulness is demonstrated by two worked refusals: the post-event response-count candidate is rejected despite having the best point scores, and the Italian transfer refuses a 70-event holdout that fails its preregistered floor.

Contribution identity: benchmark plus executable evaluation protocol. The target journal explicitly covers applied AI/ML, systems engineering, and decision-making systems.  
`goal_understood: true`  
`usefulness_understood: true`  
`abstract_story_pass: true`

## Required findings

### R13-F1 — Blocking result finding: wrong denominator for Spearman 0.755

Section 5.7 says that 2,756 of 3,138 events have macroseismically derived or mixed magnitude and then states: “For those events, magnitude tracks the label (Spearman 0.755 with maximum intensity, versus 0.300 for the 382 instrumental events).”

The supplied result does not compute 0.755 over those 2,756 events:

- `n_non_instrumental_with_label = 2,756`
- `n_macroseismic = 2,185`
- `spearman_mw_imax_macroseismic = 0.7553676541`
- `n_instrumental = 382`
- `spearman_mw_imax_instrumental = 0.3000176850`

The runner excludes the 571 `Wmim` mixed events from the 0.755 calculation. Independent recomputation from the pinned workbooks gives:

- all 2,756 non-instrumental-or-mixed events: Spearman **0.720236**
- 2,185 purely macroseismic events: **0.755368**
- 571 mixed events: **0.584152**
- 382 instrumental events: **0.300018**

Required correction: either state that 0.755 applies to the 2,185 purely macroseismic-provenance events, separately describing the 571 mixed events, or report 0.720 for all 2,756. Bind the coefficient and denominator together in the claim ledger and validator. This triggers `numeric_mismatch`.

### R13-F2 — Major evidence finding: “same code” overstates the executed path

The paper says the transfer applied “the same code (allowlist audit, sequence rule, role logic, candidate grids, and cluster-robust Holm test).” The preregistration similarly names `role_assignment.grouped_cv_folds` and the CR1 test.

The runner imports unchanged `baselines.py`, `leakage_audit.py`, and `decluster.py`, but:

- temporal role assignment is implemented locally in `run_transfer.py`;
- CR1 is implemented locally in `run_transfer.py`;
- `role_assignment.grouped_cv_folds` is only reachable indirectly inside baseline tuning;
- the evaluability failure returns before any baseline fitting, prediction, CR1 test, or Holm procedure executes.

Required correction: say that the executed path reused the unchanged feature-audit and declustering modules, with catalogue-specific mapping, cutoff, role, provenance, and evaluability glue. State that the candidate-grid and CR1/Holm branch was preserved but not reached. This triggers `unsupported_overclaim`.

### R13-F3 — Major evidence finding: non-evaluable runs do not emit the claimed manifest

On the observed fail-closed path, `run_transfer.py` writes `results.json` and returns before the code that writes `hash_manifest.json`. The committed manifest therefore was not emitted by that run path. It also omits executed dependencies such as `xlsx_read.py` and `common.py`, and omits `role_assignment.py` despite the preregistration’s reuse claim.

Required correction: emit the manifest on evaluable and non-evaluable exits; include every executed data, configuration, and code dependency, the preregistration files, and the exact Git commit; document how the current manifest was produced.

### R13-F4 — Major evidence finding: closest provenance work is missing

The related-work section now correctly separates:

- TFX candidate blessing using configured metric thresholds;
- Breck et al.’s schema/data-anomaly validation;
- TFMA’s Poisson-bootstrap or jackknife intervals.

The resulting contrast—none of those components supplies this paper’s paired, dependence-aware, family-wise candidate decision with semantic source-provenance binding—is defensible. However, the nearest-work audit omits provenance-based screening of ML data-preparation pipelines, notably Grafberger et al., “Automated Provenance-Based Screening of ML Data Preparation Pipelines,” *Datenbank-Spektrum*, DOI `10.1007/s13222-024-00483-4`, which uses record-level provenance to identify correctness defects including train/test leakage.

Required correction: cite the closest provenance-screening and fine-grained feature-lineage work, then distinguish semantic source provenance here from record-level transformation lineage.

### R13-F5 — Minor presentation finding: TFX wording is too narrow

“TFX blesses a candidate only when a point metric clears a baseline threshold” captures the point-estimate nature of the gate but understates the interface. TFX supports configured value thresholds and baseline-relative change thresholds across selected metrics and slices.

Required correction: describe those configured value/change thresholds while retaining the accurate distinction that TFX does not itself provide this paper’s paired dependence-aware family-wise test.

Finding tally: `result=1`, `evidence=3`, `presentation=1`, `self-description=0`.

## Transfer audit

The preregistration chronology passes:

- preregistration commit `c5136429e057767407792f9949b88979c815c252`, 2026-09-26 23:46:51 +05:30;
- runner commit `e187ddf78bbdd4f633907bfb789322c30ff74cee`;
- pre-execution import-path fix `ffc6065ee53b8c96adc577f0ea7a0f7615076068`;
- result commit `396ef501624bbe2cfc3297ee7ce5d4b1caa692e2`, 2026-09-26 23:48:58 +05:30.

The preregistration commit contains only the three preregistration files; results first appear in the later result commit.

Except for R13-F1, Section 5.7 matches the frozen result:

- 382 instrumental events;
- cutoff 2005;
- 312 construction / 70 holdout;
- 21 severe / 49 non-severe;
- 2,756 of 3,138 = 87.8266%, printed correctly as 87.8%;
- no fitted candidate, score, test, or qualification decision after the 70-event holdout failed the 100-event floor.

The refusal is honestly reported. Prior exposure to the same public files under a different random split and threshold is explicitly disclosed. The provenance-binding lesson is supported: a name-only mapping would admit magnitude values partly or wholly derived from the intensity source. The lesson should remain a demonstrated catalogue-specific counterexample and design requirement, not a claim that the current generic allowlist already implements semantic provenance verification.

## Numeric and statistical checks

The original-study arithmetic reconciles:

- `1,573 + 357 + 430 + 2 = 2,362`;
- `449 + 102 + 151 + 1 = 703`;
- eligible prevalence `703/2,362 = 0.297629`;
- holdout prevalence `151/430 = 0.351163`.

The ten-pair Holm sequence independently reproduces seven rejections. The last rejection is B1–B4 at `p=0.010855 < 0.0125`; B2–B4, B2–B5, and B4–B5 remain unresolved. The manuscript correctly labels this analysis post hoc and the B1–B4 decision marginal and family-dependent.

The seeded-candidate scores, baseline values, pairwise differences, robustness summaries, and table/figure values checked against the frozen JSON artifacts agree. R13-F1 is the only observed numerical/estimand mismatch, but it is load-bearing because the transfer is a named contribution.

## Novelty

Classification: **defensible-beyond-incremental**, currently 2/3.

Sceptical reduction: this packages established schema controls, version pinning, grouped evaluation, paired testing, and Holm correction around one seismic benchmark.

The paper survives that reduction because the response-count reversal and the Italian magnitude-provenance counterexample demonstrate concrete interactions that a score-only or name-only workflow misses. The ceiling remains that the full paired-decision contract is tested on only one catalogue and the closest provenance-screening literature is not yet engaged.

## Figures, formatting, and blinding

- Figure 3’s caption identifies the dashed prevalence series and dotted primary 6.0 cutoff.
- The reviewed PNG legends and labels are legible; no clipping or overlap was observed.
- The main PDF is exactly 32 pages.
- The abstract is exactly 200 rendered words and accurately states the original-study result, transfer refusal, post-hoc status, and non-operational boundary.
- No author identity was found in `main.tex`, `supplement.tex`, `references.bib`, the compiled text, or PDF metadata.
- `title_page.tex` was not treated as a reviewer-facing identity leak.
- No fabricated citation was found in the audited citation set.

## Changes needed for every sub-3 score

- `novelty` 2→3: engage provenance-screening/feature-lineage predecessors and demonstrate the complete admission-plus-paired-decision contract on an evaluable second catalogue. The latter requires new data or a new study.
- `soundness` 2→3: correct the transfer estimand/denominator and execute the full preregistered decision layer on an independent holdout meeting the evaluability floor. This requires new data or a new study.
- `numeric_integrity` 2→3: correct R13-F1 and add a denominator-bound validation assertion.
- `claim_calibration` 2→3: replace “same code” with an exact account of executed, preserved-but-unreached, and locally implemented components.
- `reproducibility` 2→3: make the fail-closed branch automatically emit a complete dependency manifest and demonstrate it in a copied one-shot rerun.
- `related_work_citations` 2→3: add the nearest provenance-screening/lineage literature and refine the TFX description.

The 3/3 criteria are already at ceiling for this version: venue fit, editor page 1, formatting/blinding, and usefulness.

## Convergence

Not converged. One result finding and three evidence findings remain open, and two vetoes apply. A focused re-review is required after the Section 5.7 denominator, executed-code description, transfer manifest, and provenance-related-work corrections are made.
