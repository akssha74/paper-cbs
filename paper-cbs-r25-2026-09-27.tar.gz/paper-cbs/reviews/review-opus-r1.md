# Review (Round 1): Cybernetics and Systems: An International Journal

**Manuscript:** *Reliable Comparison of Severe Felt-Intensity Classifiers with Versioned and Dependent Event Data: A USGS DYFI Benchmark*
**Reviewer / handling AE:** Claude Opus 5.5 (independent, default-reject)
**Date:** 2026-09-26

## Recommendation: **REJECT** (15 / 30; one veto)

**Veto: blinding breach.** The blinded Declarations state *"Project: DYFI Benchmark Reliability. ... Archived version: release v1.1.1."* A GitHub search for "dyfi benchmark reliability" (or just "DYFI benchmark") returns exactly one public repository, `akssha74/dyfi-benchmark-reliability`, which carries a `v1.1.1` tag. Its owner's public profile shows the name **"Akshay Sharma"**, who is the corresponding author on the title page. Everything else is clean: I scanned the text of `main.pdf` and `supplement.pdf`, the PDF metadata, the table sources and the PNG metadata, and found no names, affiliations or URLs.

Even without the veto, the score falls well short of the acceptance threshold at this venue. The main reasons are weak fit with CBS, incremental novelty, and a "qualification contract" that in practice is an allowlist of two features.

## Summary of the submission

The authors freeze a USGS DYFI snapshot of 7,520 records with M≥5, filter it to 2,362 events with at least 10 felt reports, and group the events into 1,885 space–time sequences. Events from 2023–2024 (430 events) form the temporal holdout. The paper then defines a fail-closed "candidate-qualification contract": a feature/role audit followed by paired sequence-cluster bootstrap Brier intervals. The contract is applied to six fixed baselines (no-skill, logistic regression, random forest, XGBoost) over **magnitude and depth only**. The findings are:

- All four learned models beat no-skill.
- B2 and B5 are unresolved against each other.
- B3 is excluded because it uses event year.
- A random-versus-sequence split diagnostic is small and reversed, and is reported as a point estimate only.

## Rubric

| # | Criterion | Score |
|---|---|---|
| 1 | Venue scope fit (CBS) | 1 |
| 2 | Contribution / novelty clarity | 1 |
| 3 | Methodological soundness | 2 |
| 4 | Numeric / evidence integrity | 2 |
| 5 | Claim calibration | 2 |
| 6 | Editor readiness (page 1) | 2 |
| 7 | Reproducibility / artifact | 2 |
| 8 | Related work & citation accuracy incl. CBS parity | 1 |
| 9 | Formatting & double-anonymous compliance | 1 |
| 10 | Usefulness / decision impact for applied-AI practitioners | 1 |
| | **Total** | **15 / 30** |

- **Editor gates:** the goal is understood (yes), the usefulness is understood (yes), and the abstract story does **not** pass.
- **Why the story fails:** the title is domain-first; one of the three result sentences reports a null, descriptive diagnostic with an unsigned direction; and the abstract hides the fixed two-feature scope.

## Venue fit and CBS parity

Recent CBS applied-AI papers each propose a new model or algorithm and compare it with baselines. Three of them are cited here:

- StackRetailNet (accuracy 98.95%);
- CLFSTO (ten datasets, Wilcoxon and Friedman tests);
- MSB-Net (a Dice gain of 2.15 percentage points).

This submission proposes no model. Its candidates are off-the-shelf learners on two tabular seismic features, and the five CBS citations serve mainly as rhetorical foils. The reframing as a "decision-support harness" is plausible under *Decision Making* / *Applied AI*, but its generality is never shown outside one seismic dataset. I do not judge the paper *clearly* out of scope, so there is no scope veto. **Desk-rejection risk is nonetheless high:** a title that leads with "Severe Felt-Intensity Classifiers ... USGS DYFI" reads as seismology.

## Novelty

The authors state that "no individual component is claimed as new". The nearest prior work is:

- Kapoor & Narayanan (2023): leakage taxonomy and model info sheets;
- Roberts et al. (2017): blocked cross-validation;
- Benavoli et al. (2017): Bayesian comparison of classifiers with a region of practical equivalence (ROPE);
- EarthquakeNPP (2026): a leakage-aware seismological benchmark;
- Patelli (2026) and Mori (2025): felt-intensity ML that I verified uses a random 70/30 split and stratified 10-fold cross-validation, respectively.

The contribution is packaging and case-study work. **Class: incremental.**

## Numeric verification (all against `frozen_inputs/asset_inputs.json`)

Every result number in the abstract, prose, tables, captions and figures matches the frozen assets. I checked the following:

- **Cohort arithmetic:**
  - 1,573 + 357 + 430 + 2 = 2,362;
  - 449 + 102 + 151 + 1 = 703 severe events;
  - 1,530 + 354 + 1 = 1,885 sequences;
  - prevalences 0.298, 0.285 and 0.351.
- **B0 Brier recomputed independently:** using construction prevalence 0.2855 on holdout prevalence 0.3512 gives 0.23216, equal to the reported 0.232.
- **Pairwise differences recomputed from per-model Brier scores:** B0−B2 = 0.0515, B1−B2 = 0.0176, B2−B4 = −0.0060, B2−B5 = −0.0008, B4−B5 = 0.0052.
- **Split diagnostic:** −0.005878 and +0.012397.
- **Other values:** the threshold probe, temporal slices (250 + 180 = 430 events), geographic summary (82 cells, n summing to 430, Brier range 0.002–0.825, median 0.151), and 91 of 120 permitted fits.

**One misstatement remains (R5).** The prose says "1,885 sequences are largely singleton (1,530 in construction)". But 1,530 is the *total* number of construction sequences, not a singleton count. The cohort counts imply that 20–40% of eligible events sit in multi-event sequences, which contradicts the claim of "limited within-sequence structure".

`validate_cbs.py` passes (42/42), but it does not catch R5.

## Citation verification

I checked 12 citations against Crossref, 11 of them also against their OpenAlex abstracts, and 3 against full text.

- **Accurate:** all five CBS citations, Rösler 2022, Patelli 2026 (full text: random 70/30), and Mori 2025 (full text: stratified 10-fold).
- **Minor imprecision:**
  - Praveena: "commonly" rests on one abstract.
  - Gomolka: "verified construction of fuzzy rules" overstates an abstract that describes membership-function verification.
  - Li (EMNLP 2025): called "concurrent" although it was published about 10 months before the snapshot. Its leakage test removes city and state names from LLM prompts.
- **Unverifiable from the abstract:** the claim that Kumar (ICECA 2025) "uses a naive split". The bib entry is also missing pp. 1743–1749.

No fabricated or materially mis-characterized citation was found, so there is no citation veto.

## Required changes (condensed; full verbatim quotes and fixes are in the JSON)

1. **R1 (blocking): de-anonymization.** Remove "Project: DYFI Benchmark Reliability" and "release v1.1.1" from the blinded files. Provide an anonymized mirror (anonymous.4open.science), and make the GitHub repository private during review or disclose it to the editor.
2. **R2 (blocking): contribution identity.** Retitle so the systems/AI contribution comes first and DYFI is the case study. Either demonstrate the contract on a second, non-seismic dependent-event dataset, or state in the abstract that generality is untested.
3. **R3: the "audit" is an allowlist.** The manuscript says "any extra or unknown field is rejected", so candidates can differ only in model class over {magnitude, depth}. Either redesign the audit as a rule-based classifier for arbitrary new fields and demonstrate it, or state the restriction prominently and demote the audit as a headline contribution. Also report what the 110 unit tests actually cover.
4. **R4: split diagnostic is within allocation noise.** Event-grouped and random folds impose the identical constraint yet differ by 0.0039 in Brier, comparable to the 0.0059 "effect". Repeat over at least 50 fold seeds and report the distribution, or drop contribution 6.
5. **R5: fix the singleton misstatement.** Report the exact singleton-sequence count, the number of events in multi-event sequences, and the sequence-size distribution.
6. **R6: resolve the headline contradiction.** Sec. 5.3 calls the random-split optimism "the resource's headline quantity", which conflicts with the abstract and conclusion and echoes the deprecated asset template.
7. **R7: engage the model-comparison and leakage literature.** Cover Dietterich 1998, Demšar 2006, Benavoli 2017 (ROPE), Bouthillier 2021, Kapoor & Narayanan 2023, and temporal-CV work. State the delta relative to model info sheets and ROPE-based comparison.
8. **R8: use a non-trivial qualification reference.** Beating a constant predictor is trivial. Use B1 or the incumbent model as the reference and state how multiplicity is handled.
9. **R9: interpret calibration honestly.** Positive intercepts (0.32–0.74) mean systematic under-prediction on the holdout. Also report recall at the 0.5 cutoff (0.25–0.37).
10. **R10: sign the abstract's split numbers,** or better, remove the sentence (see R4).
11. **R11 and R12: tighten citation characterizations** for Praveena, Gomolka, Kumar and Li.
12. **R13: make the artifact reviewer-accessible.** Provide the anonymized artifact and add claim-ledger entries for the provenance numbers (110 tests, 7,575→7,576, 56, 50 s, the access instant).
13. **R14: remove "provably" (R14) and tidy the package (R15).** Delete the unused `fig_leakage_split` files, whose truncated axes exaggerate the split difference, and fix the overlapping labels in `fig_threshold_slice`.

## Strengths (for balance)

- The disclosures are exceptionally candid: unexecuted branches, the missing interval, the absent equivalence margin, and "not untouched" holdout semantics are all stated.
- There is exact numeric traceability between the frozen assets, the tables and the prose, and the single-use protected evaluation adds to it.
- The paper reports "unresolved" rather than naming a winner, which is good evaluation hygiene of the kind the venue's own recent papers often lack.

## Bottom line

This is a carefully executed, honestly reported, but incremental evaluation-protocol paper on a thin two-feature seismic task, and it fits CBS poorly. The blinding breach alone requires return. After R1–R4 it might be reconsidered as a *resource/methods* paper, but a better venue is likely a data or benchmark journal (for example *Scientific Data*, *Data in Brief* or *SRL Data Mine*), or an ML-evaluation venue if the audit is generalized.
