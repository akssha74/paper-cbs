# Independent default-reject review, round 10 (Claude Opus)

**Manuscript:** A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study
**Venue:** Cybernetics and Systems (Taylor & Francis)
**Verdict:** Minor revision. Score 22/30, with no vetoes.

## Package integrity and reproduction

- All six SHA-256 hashes match (main.pdf `b88d00d9…`, main.tex `4edcfef2…`, supplement.pdf `2fab4596…`, supplement.tex `0f2b5efe…`, references.bib `eaef0dbd…`, build_ledger.json `b620af77…`).
- I backed up `frozen_inputs/*.json` and `cbs_validation_report.json`, then ran four scripts with `/tmp/dyfi-analytics-venv/bin/python`:
  - `family_wise_sensitivity.py`
  - `seeded_candidate_demo.py`
  - `robustness_post_hoc.py` (99,999 wild draws, 24 s)
  - `validate_cbs.py` (55 checks, 0 failed)
- All four outputs are byte-identical to the frozen files. SHA-256 of frozen inputs, ledgers, tables, figures and sources is unchanged before and after the runs.
- Not reproduced:
  - figure regeneration (matplotlib is absent from the venv; the pinned figure hashes were verified instead);
  - the 110 unit tests;
  - the upstream holdout fit, which lives in `../code`.

## Scores

| Criterion | Score |
|---|---|
| cbs_venue_fit | 2 |
| novelty | 1 |
| soundness | 2 |
| numeric_integrity | 3 |
| claim_calibration | 2 |
| editor_page_1 | 3 |
| reproducibility | 3 |
| related_work_citations | 2 |
| formatting_blinding | 2 |
| usefulness | 2 |
| **Total** | **22 / 30** |

**Vetoes:** none. I checked all five:
- **fabricated_citation:** evalci arXiv:2607.04429 and Knap DOI 10.36001/phme.2026.v9i1.4924 were verified online.
- **numeric_mismatch:** all checked values match the frozen JSON.
- **blinding_breach:** none. The validator literals (F5) are only a weak searchable cue.
- **clearly_out_of_scope:** no.
- **unsupported_overclaim:** no. F1 is a scope error, not a conclusion-bearing overclaim.

## Verification of the seven requested checks

1. **Wild bootstrap and B1–B4 wording: verified.**
   - `WILD_DRAWS = 99999`, with p = (exceed+1)/(n+1) and MC SE = sqrt(p(1−p)/n).
   - The null-imposed Rademacher sign flip of cluster sums, re-studentized with CR1, is implemented correctly.
   - In the 10° cells, B1–B4 wild p = 0.01244 with MC SE = 0.00035. This prints as "p=0.0124 (Monte Carlo SE 0.0004)" against the 0.0125 threshold. The gap is 0.17 SE, so "borderline within Monte Carlo precision" and the Table S6 R^b marker are accurate.
   - "Marginal and family-dependent" appears in the abstract, contributions, Section 5.5, Discussion, Conclusion, Table 4, the overlay and the supplement.
2. **Method-labelled p-values: verified, with one residual.**
   - Section 5.5 reports CR1 0.0109, CR3 0.0109, wild 0.0096 and event-level 0.0092, matching the JSON values 0.010855, 0.010891, 0.00962 and 0.009219.
   - Section 4.4 reports p = 0.0485, matching 0.048520.
   - "Best Brier, AUROC, and log-loss" appears in the contributions, related work, Discussion, Conclusion and Table 4.
   - The harness sentence is present.
   - Residual: Section 5.6 still says "best holdout value on every reported score" (F1), and the harness clause is duplicated (F7).
3. **Abstract: verified.** The validator counts 187 words and my independent pdftotext count is about 192, both within 200. The whole abstract and the keywords fit on page 1, and the abstract states the practical admit/reject and supported/unresolved output.
4. **Typography: verified for the listed items.**
   - Table 1 is ragged-right, Table 4 uses true minus signs, and the Table S2 caption spans the text width.
   - References [38] and [39] print their doi.org URLs.
   - Figure 4 is clean, and `main.log` has no overfull boxes.
   - Residuals are in other objects: Figure 3, Figure 1 and Table S1 (F2–F4).
5. **Anonymity: verified, with one residual.**
   - Both build ledgers withhold the repository URL and tag.
   - Identity tokens are derived from `title_page.tex`, and I found no hit outside the title page.
   - Main, supplement and figure PDF metadata are clean.
   - Residual: the validator hard-codes two tokens and does not scan binary metadata (F5).
6. **Claim ledger: verified.**
   - `H_unresolved` = [B2–B4, B2–B5, B4–B5] and is marked as the authoritative decision rule.
   - `P_unresolved_unadjusted_95` is labelled legacy and superseded.
   - Residual: several JSON pointers do not resolve (F6).
7. **Inference, robustness and citations: verified.**
   - I recomputed Holm step-down from the frozen p-values. There are seven rejections: B1–B4 passes at 0.01086 ≤ 0.0125, and B4–B5 stops at 0.0350 > 0.0167.
   - Sequence windows give 375, 354 and 295 clusters, each with 7 rejections. The log-loss and AUROC families also give 7 each.
   - In the 15-pair family, C_F2 is supported against B0, B1 and B4, and B1–B4 becomes unresolved.
   - The "by construction" framing is present, and the evalci, Holm and Diebold–Mariano citations resolve.
   - Section 5.9 separates the older public tag from the anonymized review archive and the new tag on acceptance.

## Findings (all fixable in this study)

**F1 (moderate, claim calibration): the "best" claim for C_F2 is unscoped.**
- Section 5.6 (l.705–706) says C_F2 "has the best holdout value on every reported score".
- The same section (l.688–689) reports C_F1 at Brier 0.025 and AUROC 1.000, which beats C_F2 on both.
- C_F2 also has no reported calibration or accuracy, so "every reported score" is wrong on a second count.
- The abstract, contributions, related work, Discussion and Conclusion scope "best" only implicitly. The validator check compares C_F2 against the baselines only.
- **Fix:** write "best among the admissible baselines B0–B5" everywhere.

**F2 (minor, formatting): Figure 3 labels collide.**
- In panel (b), the legend hides the 2023 AUROC label "0.797".
- In panel (a), the "0.458" and "0.260" labels sit on their markers, and "0.815" touches the frame.
- Unexplained dashed white lines run inside the AUROC bars.
- **Fix:** move the legend, offset the labels, and remove or explain the lines.

**F3 (minor, formatting): Figure 1 text is crowded.**
- "Cluster-robust paired test" touches both box borders.
- "F1--F6" renders as a literal double hyphen.
- The outcome box uses a smaller font than the flow boxes.
- **Fix:** widen the boxes or break the line, use an en dash, and harmonize font sizes.

**F4 (minor, formatting): residual table typography.**
- Table S1 prints negatives with an ASCII hyphen (`-0.0060`, `[-0.0012, 0.0243]`).
- The Table 2 note is centred rather than justified.
- The Table 4 note writes the pair label as "B2−B5" with a math minus, while elsewhere pairs use an en dash.

**F5 (minor, blinding): the validator hard-codes a tag and project title.**
- `validate_cbs.py` l.99 and l.124 contain the literals `"v1.1.1"` and `"DYFI Benchmark Reliability"` and exempt them from the package scan.
- The project title is a searchable cue: the title page shows the repository slug is its hyphenated form.
- The scan also skips PDF/PNG files. I checked their metadata manually and it is clean.
- **Fix:** derive the tag and slug from the title page, scan for them, and add a PDF/figure metadata scan.

**F6 (minor, reproducibility): claim-ledger pointers do not resolve.**
- `H_*` entries point to `/pairs/<name>`, but `pairs` is an array.
- `ROB_alt_families` uses a comma-separated list of pointers.
- `SEED_extended_holm` lists "abstract" in `appears_in`, although the trimmed abstract no longer states the 15-pair result.
- The values themselves are correct.
- **Fix:** use RFC 6901 indices and add a validator check that every pointer resolves and matches its value.

**F7 (minor, calibration): the harness sentence is duplicated and its precondition is unstated.**
- l.680–685 state the declared-name audit twice.
- "A clean declared name cannot launder disallowed values" holds only if the harness materializes every input column from allowlisted names.
- The demo script itself decouples `declared` from `cols`, and no test covers a model artefact that carries external information.
- **Fix:** keep one sentence and state the precondition explicitly.

**F8 (minor, related work): core benchmark-variance papers are missing, and one Knap detail is unverified.**
- Missing: Bouthillier et al. (2021, MLSys) "Accounting for Variance in ML Benchmarks" and Dror et al. (2018, ACL) on significance testing. Both address this paper's stated question.
- The claim that Knap et al. report "three repeated-seed runs" is sourced in the ledger to the Crossref abstract, which says only "repeated-seed follow-up used where necessary".
- **Fix:** add both papers with a sentence on the delta, and verify "three" against the full text or soften it.

## Limitations that need new data (not fixable in this study)

- **Novelty ceiling.** The paper concedes the components are "established separately", and the concurrent evalci already packages paired tests, cluster bootstrap and all-pair Holm. The remaining delta (admission gate, sequence clustering, version pinning) is shown on one catalogue only.
- **Not confirmatory.** The Holm family, robustness checks and seeded candidates were all declared post hoc on a public holdout. Confirmation needs a fresh hidden holdout.
- **B1–B4 stays marginal.** Only more holdout sequences can resolve it; more resampling cannot.
- **The seeded reversal is by construction.** It shows how the policy operates, not that the gate detects anything. Showing that it prevents real errors needs third-party submissions.
- **Usefulness is argued, not observed.** No external user and no second benchmark are reported.

## What would earn 3 on each criterion below 3

- **cbs_venue_fit, novelty, soundness, usefulness:** no in-study change is sufficient. Each needs new data: a second non-seismic corpus, a hidden-holdout service, or external candidate submissions.
- **claim_calibration:** fix F1 and F7.
- **related_work_citations:** fix F8.
- **formatting_blinding:** fix F2–F5.

## Top required changes

1. Scope every C_F2 "best" claim to the admissible baselines, and remove "every reported score" from Section 5.6 (F1).
2. Fix the Figure 3 label and legend collisions and the Figure 1 crowding and "F1--F6" (F2, F3).
3. Remove the tag and title literals from the validator, and scan binary metadata (F5).
4. Use true minus signs in Table S1 and make the ledger pointers resolvable (F4, F6).
5. State the harness precondition once, add Bouthillier 2021 and Dror 2018, and verify or soften the Knap detail (F7, F8).
