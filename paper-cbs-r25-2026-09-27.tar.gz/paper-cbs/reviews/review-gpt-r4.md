# Independent default-reject review — R4

Reviewer model: GPT-5.6  
Venue: *Cybernetics and Systems: An International Journal* (Taylor & Francis)  
Verdict: **Major revision**  
Score: **25/30**

## Review pin and independence

- `main.pdf`: SHA-256 `28f5c57c9b80d8a2384d345933f883b230ce46d710477066c166a3bb42c3803b` — expected pin matched; 31 pages.
- `main.tex`: SHA-256 `cce6009c39435f43f75de1b74e806c1017aae81cb70517b466c6349554e1fffd` — expected pin matched.
- `supplement.pdf`: SHA-256 `53883e61b85eae5eb10b869156be413e4e88fa89e59e1d5d6fbb19bb281d8268` — 3 pages.
- Git HEAD: `b3fcc66f77139194d9185eeb7f9db88039f27bd0`; the `paper-cbs` directory is an untracked working-tree review object.
- I re-extracted the PDF text and did not use stale `main.txt`.
- I did not read R1–R3 review files.
- The two primary hashes were rechecked immediately before filing and had not changed.

## Scores

1. `cbs_venue_fit`: **2/3**
2. `novelty`: **1/3**
3. `soundness`: **2/3**
4. `numeric_integrity`: **3/3**
5. `claim_calibration`: **3/3**
6. `editor_page_1`: **3/3**
7. `reproducibility`: **3/3**
8. `related_work_citations`: **3/3**
9. `formatting_blinding`: **3/3**
10. `usefulness`: **2/3**

Total: **25/30**

## Overall assessment

This is a careful, auditable resource paper. Its strongest features are numeric integrity, explicit non-use boundaries, honest handling of an unresolved winner, a clear first-page story, a public scientific release, and correct double-anonymous packaging.

The paper is in scope: it describes “a decision-support test harness for transparent retrospective model comparison,” directly aligning with applied AI/ML and decision systems. Its first page identifies the users, the two decisions they need, the main quantitative outcomes, and the non-operational boundary.

The limiting issue is not a hidden numeric error. It is the evidential level of the contribution. The manuscript says:

> “No component is claimed as new. The submission is a task-specific reproducibility and benchmark resource for this DYFI classification task, not a general evaluation-method contribution.”

That is appropriately honest, but it makes the contribution an incremental packaging of established comparison, leakage, temporal-validation, and reproducibility controls. Further, the original primary dependence contrast was reclassified after the protocol and has no interval:

> “The frozen internal protocol named that contrast the primary quantitative result; this manuscript reports it as a secondary descriptive diagnostic because no paired interval was retained.”

The current analyses support the manuscript’s narrowed descriptive claims. They do not yet demonstrate a confirmatory, reusable qualification rule for repeated model adoption decisions.

## Ranked required changes

### 1. Major — make the decision rule multiplicity- and reuse-safe

Evidence:

> “Remaining versus-B0, versus-B1, and pairwise intervals are unadjusted and exploratory.”

> “They do not generalize to repeated model development.”

> “The output is a decision-support test harness for transparent retrospective model comparison: a small, rule-based evaluation system whose outputs are the admit/reject and supported/unresolved decisions that precede adoption of an applied ML model.”

The disclosure is correct, but the reusable contract still maps interval exclusion to an adoption-facing “supported” decision. With several candidates or repeated submissions, that rule does not control the error rate that the fail-closed framing is intended to prevent.

Required action: define one pre-specified candidate/reference contrast per qualification, or enforce a family/repeated-use adjustment policy in the harness. Otherwise emit and report `exploratory-supported`, not `supported`, for these families and remove adoption-facing language. Provide a frozen comparison-family rule, enforcement tests, and regenerated worked decisions.

### 2. Major — add a confirmatory dependence-bearing demonstration

Evidence:

> “The frozen internal protocol named that contrast the primary quantitative result; this manuscript reports it as a secondary descriptive diagnostic because no paired interval was retained.”

> “No second, non-seismic dataset was evaluated, so reuse on other event catalogues is untested.”

> “The present result neither demonstrates practically important leakage from random splitting nor establishes its absence.”

The case study demonstrates the machinery and two changed decisions, but not that dependence control changes a supported result on dependent-event data.

Required action: run a separately frozen evaluation on fresh hidden data or a second event dataset with materially stronger multi-event sequences, including a pre-specified paired split-contrast interval. If that is infeasible, narrow the contribution and usefulness claims to implemented audit mechanics rather than empirical validation of dependence handling.

### 3. Minor — complete the DYFI machine-learning lineage

Evidence:

> “Felt-intensity models have used random forests or boosting with instrumental, catalogue, or crowdsourced predictors.”

> “The closest same-source study reports a single random-forest regression without grouped or temporal evaluation.”

The review omits Alvarez, Hurtado, and Bedoya-Ruíz, “Prediction of modified Mercalli intensity from PGA, PGV, moment magnitude, and epicentral distance using several nonlinear statistical algorithms,” *Journal of Seismology* 16 (2012), DOI `10.1007/s10950-012-9291-x`. It is not the same event-level task, but it is directly relevant DYFI/nonlinear-ML lineage.

Required action: cite and distinguish it by observation unit, predictors, endpoint, and validation design. Retain Kumar et al. as the closest match only if the basis for “closest” is stated.

## Numeric audit

No numeric veto was found.

- The claim ledger has 111 unique entries. One hundred direct JSON-pointer values matched the frozen files, and 10 derived/special result or provenance checks also matched. The remaining ledger entry is the mechanism count of 110 unit tests, which is not stored in `asset_inputs.json`; it is reported by the validation record but was not rerun under this review’s two-output-file write restriction.
- Cohort: `1,573 + 357 + 430 + 2 = 2,362`.
- Severe events: `449 + 102 + 151 + 1 = 703`; the role-assigned total is `449 + 102 + 151 = 702`.
- Prevalence: `703/2,362 = 0.297629`, `551/1,930 = 0.285492`, and `151/430 = 0.351163`, matching 0.298, 0.285, and 0.351.
- Split diagnostic:
  - Brier: `0.198955440399 − 0.204833647433 = −0.005878207034`, matching 0.0059 lower.
  - AUROC: `0.707630927485 − 0.695234059242 = 0.012396868243`, matching 0.0124 higher.
  - Log-loss: `0.970903842537 − 0.964044860549 = 0.006858981988`, confirming the opposite point-estimate direction.
  - Event-grouped Brier gap: `0.204833647433 − 0.200874490602 = 0.003959156831`, matching 0.0039.
- All four learned models beat B0:
  - B1−B0: `−0.033946`, CI `[−0.051105, −0.017105]`.
  - B2−B0: `−0.051499`, CI `[−0.068063, −0.034206]`.
  - B4−B0: `−0.045479`, CI `[−0.059797, −0.030656]`.
  - B5−B0: `−0.050722`, CI `[−0.068236, −0.031889]`.
- Only B2, B4, and B5 beat B1:
  - B2−B1: `−0.017552`, CI `[−0.024854, −0.010119]`.
  - B4−B1: `−0.011533`, CI `[−0.020505, −0.002320]`.
  - B5−B1: `−0.016775`, CI `[−0.027327, −0.005483]`.
- B2−B5 is unresolved: `−0.0007769`, CI `[−0.0077885, 0.0068150]`.
- Recall range: `37/151 = 0.2450` through `56/151 = 0.3709`, matching 0.25–0.37.
- Provenance: `7,576 − 7,575 = 1`; `06:34:20Z − 06:33:30Z = 50 s`; `7,576 − 7,520 = 56`.

## R4 fix spot-checks

All requested spot-checks pass.

1. **B1 does not beat itself.** The abstract says, “B2, B4, and B5 also improved on magnitude-only B1”; Table 6 compares B1 only with B0.
2. **Four learned models beat B0; only B2/B4/B5 beat B1.** All corresponding paired intervals exclude zero.
3. **No false winner.** “It does not support naming B2 or B5 as the winner: their direct paired interval includes zero.”
4. **B1 comparisons are exploratory/unadjusted.** “Remaining versus-B0, versus-B1, and pairwise intervals are unadjusted and exploratory.”
5. **Two-field allowlist, not a six-category general leakage detector.** Section 4.1 is titled “Feature sets, the two-field allowlist, and split-axis checks,” and states: “The executable mechanism is a two-field allowlist plus split and axis checks, not a general leakage detector for arbitrary new covariates.”
6. **No split-sign inference.** Discussion reports log-loss `0.9709` versus `0.9640`, says it points in the opposite direction, and states that neither sign nor magnitude is inferentially established. The Conclusion repeats that no inferential sign claim is supported.
7. **Event grouping is a second allocation, not a control.** Table 4 labels it “Event-grouped (second allocation),” and the body says it is “not a distinct control.”
8. **Joint intercept is not CITL.** “The intercept from a joint intercept-and-slope recalibration is not calibration-in-the-large for any model.”
9. **Two changed decisions, not three.** The paper names only B3 ineligibility and B2-versus-B5 unresolved status.
10. **Protocol reclassification is disclosed.** Table S2 labels it “Post-protocol disclosure,” and Section 5.8 repeats the change from primary to secondary descriptive diagnostic.
11. **B2 versus B0 is post-hoc.** The paper says it “was not designated in that protocol.”
12. **The title does not claim demonstrated general dependent-event capability.** It ends “A Seismic Felt-Intensity Case Study”; the abstract says generality beyond this dataset is untested.
13. **Provenance is in the claim ledger.** `P_access_instant`, `P_count_min`, `P_count_max`, `P_costamped`, `P_recount_lag_s`, and `P_prelim_minus_payload` match the source locator and arithmetic.

## Citations, release, formatting, and blinding

- All 38 harvested DOI records and 5 URL records resolved after registry-aware checking. The automated Crossref fallback falsely marked `10.5066/P143CZ3R`; DataCite confirms it as the cited 2026 USGS *Macroseismic Intensity Dataset in Western North America*.
- The v1.1.1 public tag resolves and contains the event-level table, results, fit ledger, source locator, reconstruction code, locked environment, and a 217-file `PUBLIC_RELEASE_MANIFEST.json`.
- The main PDF has no blank page and uses embedded fonts. All five figures were visually inspected and are legible, unclipped, and consistent with their captions.
- The main manuscript and supplement are anonymous. Names, affiliations, email, and identifying repository links are confined to the separate title page, consistent with the venue’s double-anonymous policy.

## Veto check

- Fabricated citation: **false**
- Numeric mismatch: **false**
- Blinding breach: **false**
- Clearly out of scope: **false**
- Unsupported overclaim: **false**

No veto is activated. The major-revision recommendation rests on novelty, confirmatory evidence, and multiplicity-safe decision design, not on a result-integrity failure.
