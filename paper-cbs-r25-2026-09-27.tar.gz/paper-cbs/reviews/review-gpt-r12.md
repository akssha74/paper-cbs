# Independent default-reject review — GPT-5.6

Venue: *Cybernetics and Systems*  
Decision: **Reject and resubmit**  
Score: **26/30**  
Vetoes: **None**

## Summary

This is a numerically coherent, unusually transparent, reproducible, well-calibrated, in-scope, and correctly blinded package. The default-reject decision is driven by contribution strength rather than a correctness failure. The remaining delta is an incremental integration of established schema/model gates, paired inference, multiplicity control, version pinning, and grouped evaluation. Its only conclusion-reversal demonstration is deliberately seeded, so it proves policy operation by construction rather than prospective or external effectiveness.

## Scores

- `cbs_venue_fit`: **3/3** — Direct fit to the journal’s applied-AI/ML, decision-making, systems-engineering, and environmental-systems scope; five journal precedents are substantively engaged.
- `novelty`: **1/3** — Incremental integration. TFX/Breck cover schema or data validation plus threshold/baseline model gating; NeMo Evaluator covers paired confidence-interval quality gates with fail-closed outcomes; evalci covers paired/clustered comparisons and all-pair Holm correction.
- `soundness`: **2/3** — The frozen-candidate estimand and calculations are coherent, but the multiplicity rule and most sensitivity analyses are post hoc; 312/354 sequence clusters are singletons; grouping is heuristic; and training/tuning uncertainty is excluded.
- `numeric_integrity`: **3/3** — All pins and independently rerun headline analyses matched.
- `claim_calibration`: **3/3** — The paper consistently disclaims confirmatory, operational, causal, geographic-transport, equivalence, contamination-detection, and unique-winner interpretations.
- `editor_page_1`: **3/3** — The title, 190-word abstract, and opening identify the problem, goal, users, decisions, principal results, post-hoc status, and non-use boundary.
- `reproducibility`: **3/3** — Source, frozen inputs, code, ledgers, build metadata, and reviewer artifacts are present; all three requested analyses reran successfully.
- `related_work_citations`: **3/3** — The TFX/Breck, Dror/Bouthillier, NeMo, and evalci distinctions were verified; no fabricated citation was identified.
- `formatting_blinding`: **3/3** — The 32-page main PDF and 8-page supplement are readable, line-numbered, double-spaced, and use embedded fonts. Figure 3(a) has no numeric labels and no numeric-label collisions. The TFX bibliography entry renders with “et al.”; no reviewer-facing identity leak was found.
- `usefulness`: **2/3** — The workflow and outputs are concrete, but reuse outside one two-feature DYFI contract is untested and the reversal case is constructed.

## Vetoes

- `fabricated_citation`: false
- `numeric_mismatch`: false
- `blinding_breach`: false
- `clearly_out_of_scope`: false
- `unsupported_overclaim`: false

## Findings

### F1 — Major, evidence: incremental delta and constructed demonstration

The manuscript states:

> “Those pieces are established separately; what is released is their fail-closed combination as a reconstructable decision rule for this DYFI classification task.”

That calibration is accurate. TFX/Breck supply schema/data validation and model gating; NeMo supplies paired confidence-interval quality gates with fail-closed outcomes; evalci supplies paired and clustered inference with all-pair Holm correction. The remaining contribution is their task-specific coupling to an allowlist, role/axis audit, event-sequence clustering, version pinning, and one seismic case.

The main reversal example is also explicitly described as one that “holds by construction” and “illustrates policy operation, not contamination detection.” It verifies execution of the rule but does not show a prospectively encountered model-selection failure.

Required change: add a prospective or external demonstration on a second catalogue or independently supplied candidate family where the contract detects a naturally occurring invalid comparison or changes a predeclared decision. If that is infeasible, present the work explicitly as an incremental reproducible systems case study.

### F2 — Major, evidence: central decisions remain exploratory

The manuscript states:

> “The Holm family was declared after the holdout was opened; the labels are therefore disclosed post-hoc decisions, not confirmatory findings.”

The original protocol’s split-assignment primary result is unresolved on all three metrics, and the public holdout cannot support a new confirmatory run. The post-hoc calculations are technically coherent and honestly labelled, so this is not a numeric mismatch or overclaim veto. It nevertheless means the case study does not prospectively validate the contract.

Required change: predeclare the complete comparison family, variance estimator, decision thresholds, and admission policy, then execute them once on fresh hidden data or through an independent evaluation service. Treat the present results as development evidence.

### F3 — Minor, presentation: the main paper is overextended

`main.pdf` is 32 pages, including five pages of references. The B1–B4 marginality, post-hoc status, no-winner boundary, and seeded-candidate interpretation recur across the abstract, contributions, results, discussion, limitations, and conclusion.

No formal venue page limit could be independently confirmed, so this is not a compliance violation. Move robustness-family enumeration and repeated boundary statements to the supplement.

### F4 — Limitation, not an error: frozen candidates are not algorithms

The paper states that its intervals exclude training-sample, hyperparameter-search, and future-catalogue uncertainty, and it correctly cites Bouthillier et al. on those sources of variance. Current wording is sufficiently conditional. Preserve the frozen-candidate scope; broader algorithm-superiority claims would require repeated full-pipeline fits.

## Verification

All requested SHA-256 pins matched:

- `main.pdf`: `3fbc88381bcb0e587940f1225ff060e2091453022499f3c1d6380c152ec33541`
- `main.tex`: `cc7d1a3931a322656ec28a9c6eb0116bdf08e8f25c44d15c310e529f4a7fa928`
- `supplement.pdf`: `77cb18c162298fdd6fa29c0d91c6e79e0c250c24f40ca57a86f564fe72af4a3a`
- `supplement.tex`: `0f2b5efe4b257ad8889cdb60bc421076b81be18a0e02ac1bbea8e91ac87be395`
- `references.bib`: `5aedb90ed724a2dc17b364e33e6076ecb40ec42717438344dbf5801e2e9e8efd`
- `build_ledger.json`: `268cbafc52886370762c1c9f9c1d6901d830326cbb283d3ef3456821ef735399`

The supplied validator reports **56/56 checks passed**. Independent reruns with `/tmp/dyfi-analytics-venv/bin/python` reproduced:

- all ten paired Brier results;
- seven Holm rejections and six Bonferroni 99.5% interval exclusions;
- seeded C_F2 Brier/AUROC/log-loss of **0.172/0.809/0.515**;
- every split-contrast interval including zero;
- the sequence-window, CR3, wild-cluster, event-level, regional-cell, and synthetic-cluster sensitivity records;
- the 86-cluster claim-ledger pointer and B1–B4 CR1 `p=0.013763249604`.

The abstract reports log-loss 0.515 and leads with the marginal, family-dependent B1–B4 result before the stable conclusions. Figure 3(a) contains no numeric labels. The TFX/Breck remaining delta, Dror/Bouthillier split, and NeMo/evalci positioning are accurate.

## Top required changes

1. Demonstrate the contract prospectively or externally on fresh hidden data and a naturally occurring candidate comparison.
2. Predeclare the complete family, estimator, and decision rule before that evaluation.
3. Shorten the 32-page main paper by moving repeated robustness and qualification detail to the supplement.

## Final assessment

No veto is triggered, and no numeric, citation-fabrication, blinding, or scope failure was identified. The rejection is a contribution-and-evidence judgment: the paper is technically strong but does not yet show that its incremental integration delivers a prospectively validated, reusable advance beyond the nearest existing gates and statistical toolkits.
