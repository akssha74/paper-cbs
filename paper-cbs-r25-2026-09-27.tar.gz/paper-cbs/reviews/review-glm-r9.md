# Review (Round R9, GLM-5.2, Independent Default-Reject)

**Manuscript:** A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study
**Venue:** Cybernetics and Systems (Taylor & Francis) — broad applied AI/ML and decision systems
**Scientific tree:** frozen for this review (no manuscript/script/frozen-input edits; prior-round reviews not consulted).

## SHA-256 verification (all match)

| File | Expected | Verified |
|---|---|---|
| main.pdf | bdf1d472b618961f153c0eeb8620df12383ac9170d2f2113f0c1d6c15008be96 | yes |
| main.tex | 502a29585807e99af2636c3a0fe2eabebcd3c69f8be20fe93c16e14f3a125b17 | yes |
| supplement.pdf | b8ac8c09812ea92d433feb100e56a7120d317980d301b26aa586ed5a0bd0e7f0 | yes |
| supplement.tex | 23ab5a8115fc08f9ffe3e9818a70b4e0f48202220cd85783857acaaf5529640d | yes |
| references.bib | d66922836e00938d0df070323c6d47d0c495925b2a98095e06a46a60e55fd026 | yes |

## Criterion scores (0–3 each, /30)

| Criterion | Score | Rationale |
|---|---|---|
| cbs_venue_fit | 3 | Decision-support comparison contract; engages C&S precedents (sag2025, praveena2025, gao2026, hossack2004, gomolka2000). |
| novelty | 2 | Honest "fail-closed combination" of established pieces; defensible-beyond-incremental but not highly novel. |
| soundness | 3 | Correct cluster-robust paired Brier test (CR1, G/(G-1), t(G-1)), Holm step-down, Bonferroni intervals, plus CR3 jackknife, wild-cluster bootstrap-t, region-block and sequence-window sensitivity. Assumptions and limitations candidly disclosed. |
| numeric_integrity | 3 | Every number cross-checked across main text, tables, supplement, and frozen JSONs; all reconcile. |
| claim_calibration | 3 | B4-over-B1 "marginal and family-/clustering-dependent" everywhere required; seeded candidate "by construction"; no universal recommendation; unresolved ≠ equivalent. |
| editor_page_1 | 2 | Abstract on page 1, states practical output, explicitly post-hoc/single-corpus; but ~211 words (validator) slightly over a strict 200-word limit. |
| reproducibility | 3 | SHA-256 fingerprinting, digest-verified reconstruction, scripts gate on exact reproduction, pinned env, build ledger, 54/54 validation checks. |
| related_work_citations | 3 | Demšar/Benavoli/Kapoor/evalci/BetterBench/Knap engaged; new citations (Holm 1979, Diebold-Mariano 1995, evalci 2026, Cameron-Miller 2015) verified real and correctly described. |
| formatting_blinding | 2 | Double-anonymous (main blinded, identities on title page); no overfull/clipped content; Fig 4 legible; Table S2 single-spaced with repeated headers; abstract length borderline. |
| usefulness | 2 | Executable contract demonstrated on one catalogue; generalization untested (honestly stated). |
| **total_score** | **26/30** | |

## Vetoes

None triggered.

- fabricated_citation: **no** — all new citations verified online (evalci arXiv:2607.04429 exists; Holm, Diebold-Mariano, Cameron-Miller well-known and correct).
- numeric_mismatch: **no** — all 18 cross-checked numbers reconcile across main text, tables, supplement, and frozen JSONs.
- blinding_breach: **no** — main.tex blinded; identities/affiliations/CRediT/repository URL only on title_page.tex.
- clearly_out_of_scope: **no** — fits C&S applied AI/ML and decision-systems scope.
- unsupported_overclaim: **no** — B1-B4 hedged as marginal; seeded candidate "by construction"; no universal/task-agnostic recommendation; unresolved ≠ equivalent.

**Recommendation:** default-reject (no veto; 26/30). The manuscript is methodologically sound, numerically consistent, and honestly calibrated. The remaining concerns are limitations requiring new data (single catalogue, magnitude-dominated endpoint, lightly clustered holdout, public holdout) rather than defects fixable in this round.

## Findings

### F1 — Abstract length slightly over 200 words (minor, fixable in this study)
**Location:** `main.tex` abstract; `cbs_validation_report.json` check `concise_abstract` detail=`211`.
**Evidence:** The project's own validator reports the abstract at 211 words, slightly above a strict 200-word limit. The abstract is otherwise accurate, fully on page 1 (verified in `main.txt`: abstract occupies lines 5–22, page number "1" at line 25), explicitly post-hoc and single-corpus, and states the practical output (admit/reject + supported/unresolved labels). By PDF whitespace tokenisation the count is lower (~164–193) because line-wrapping merges hyphenated compounds, but by the source-token count used by the validator it is 211.
**Fix:** Trim ~11 words (e.g. tighten the "It admits only a declared outcome-blind schema..." sentence) to bring the source-token count safely under 200 without losing the practical output statement.

### F2 — "Reads feature values by declared name" slightly idealised vs script (minor, fixable)
**Location:** `main.tex` Section 5.6 (`sec:seeded`); `seeded_candidate_demo.py` `CANDIDATES['C_F2_ren']`.
**Evidence:** The prose states "The harness reads feature values from the frozen rows by declared name, so a name cannot carry substituted values." The script actually reads values via a separately specified `cols` field; for `C_F2_ren` it reads `num_responses` values while declaring the name `n_reports`. The allowlist logic (decides on the declared name) is correct and the candidate is rejected as `F0_unknown_non_allowlisted`, but the "reads by declared name" mechanism is slightly idealised relative to the implementation.
**Fix:** Soften to "the admission audit runs on declared field names, so a clean declared name cannot be used to launder disallowed values past the allowlist."

### F3 — Single-catalogue evaluation (limitation, requires new data)
**Location:** `main.tex` Section 7, Conclusion.
**Evidence:** "No second, non-seismic dataset was evaluated, so reuse on other event catalogues is untested." Honestly disclosed.
**Fix:** None in-round. A second corpus or hidden evaluation service is needed to support any reuse claim.

### F4 — Magnitude-dominated endpoint (limitation, requires new data)
**Location:** `main.tex` Section 3; abstract "magnitude-only AUROC 0.719".
**Evidence:** Magnitude-only AUROC 0.719 vs B2 0.786 — the task is close to thresholding. The authors correctly frame the contribution as the comparison contract, not a hard new classifier.
**Fix:** None in-round. A harder, less magnitude-dominated endpoint would strengthen the demonstration but is not required for the contract contribution.

### F5 — Within-sequence dependence lightly exercised (limitation, requires new data)
**Location:** `main.tex` Section 5.4 lines ~445–456; `robustness_post_hoc.json` `cluster_structure`.
**Evidence:** 312/354 holdout sequences are singletons (largest 16, G/(G-1)=1.003), so the default-sequence test differs little from an event-level paired t. The authors disclose this and add region-block re-clustering (5°=140 clusters, 10°=82 clusters) that genuinely exercises cross-sequence dependence; B1–B4 flips to unresolved under 10° wild-cluster bootstrap (p=0.0130 > 0.0125). Honestly handled.
**Fix:** None in-round. B1–B4 marginality is already disclosed in all required locations.

### F6 — Public, non-confirmatory holdout (limitation, requires new data)
**Location:** `main.tex` Section 3, Section 7.
**Evidence:** "Held out from model development with aggregate feasibility previously known, not untouched or confirmatory." Confirmatory use requires a fresh hidden holdout. Honestly stated.
**Fix:** None in-round. Requires a hidden evaluation service.

### F7 — Wild-cluster bootstrap-t methodology correct (observation, no change needed)
**Location:** `robustness_post_hoc.py` `variance_estimator_p` / `region_block_sensitivity`.
**Evidence:** The wild-cluster Rademacher bootstrap-t multiplies cluster sums by ±1 signs and recomputes the CR1 t-statistic; p = (Σ|t★| ≥ |t_cr1| + 1)/(9999 + 1). This is a valid null-imposed wild-cluster bootstrap-t. The CR3 jackknife uses the standard (G−1)/G delete-one-cluster correction. Methodology is correct.
**Fix:** None.

### F8 — Claim calibration consistent across all required locations (observation, no change needed)
**Location:** abstract, contributions, Section 5.5, Discussion, Conclusion, Table 4, Supplementary Table S6.
**Evidence:** The B4-over-B1 (B1–B4) label is consistently "marginal" and "family-/clustering-dependent" in all required locations. The seeded candidate is framed "by construction" and "post-hoc illustration, not a performance claim". No universal/task-agnostic recommendation is made. Unresolved pairs are labelled unresolved, not equivalent. The deprecated "small and slightly reversed"/"leakage-hardened" framings are superseded by the manuscript-level overlay without changing any number or hashed file.
**Fix:** None.

## Numeric cross-checks (all consistent)

| Claim | Source value | Manuscript | Status |
|---|---|---|---|
| B1–B4 p=0.0109, threshold 0.0125 | JSON 0.010855349147 / 0.0125 | lines 633, 648; Table S1 "reject (0.0109)"; supp line 35 | consistent |
| B1–B4 95% percentile lower bound 0.0023 | ci95=[0.002320044189, 0.020505112323] | line 631–632; Table S1 [0.0023, 0.0205] | consistent |
| B1–B4 Bonferroni 99.5% CI [−0.0012, 0.0243] includes zero | bonferroni_ci=[−0.001188392477, 0.02425368183], excludes_zero=false | line 633 | consistent |
| 7 Holm rejections; 6 Bonferroni intervals exclude zero | n_holm_reject=7, n_bonferroni_exclude_zero=6 | line 633 | consistent |
| B2–B4, B2–B5, B4–B5 unresolved | holm_rejects_zero=false (all three) | lines 636–638, 729–730 | consistent |
| B2–B4 percentile includes zero but unadjusted p=0.049 | ci95=[−0.011786, 0.000222] includes zero; p=0.048519812716 | line 455–456; Table S1 note "disagree near boundary (B2–B4)" | consistent |
| Cluster structure 312/354 singletons, largest 16, G/(G−1)=1.003 | n_singletons=312, n_clusters=354, largest=[16,...], cr1_factor=1.00283286119 | line 446–447 | consistent |
| Region blocks 5°=140 (largest 22), 10°=82 (largest 26) | 5° n_clusters=140 largest=[22,...]; 10° n_clusters=82 largest=[26,...] | line 449–450 | consistent |
| All checks 7 decisions except 10° wild (6, B1–B4 p=0.0130>0.0125) | 10° wild B1–B4 p=0.013; 6 rejected | Table S6 10° wild column=6; line 653–655 | consistent |
| CR3/wild/event-t 7 decisions; B1–B4 p=0.0109, 0.0109, 0.0096, 0.0092 | cr1=0.010855, cr3=0.010891, wild=0.0096, event=0.009219 | line 648–650 | consistent |
| 5°/10° CR1 B1–B4 p=0.0115 both | 5° 0.011455; 10° 0.011463 | line 651–652 | consistent |
| 15-pair seeded family: B1–B4 unresolved, other 9 unchanged | admissible_pair_decisions[B1–B4]=false, other 9=true | line 655–657; Table S6 15-pair column=6 | consistent |
| C_F2 Brier 0.172, AUROC 0.809, log-loss 0.515 | brier=0.172389679459, auroc=0.809276270503, log_loss=0.515321511554 | line 709–710, abstract | consistent |
| C_F2 Holm-supported vs B0,B1,B4 (not B2,B5) | C_F2_holm_supported_against=[B0,B1,B4] | line 715–716; Table 4 | consistent |
| C_F2 vs B5 diff −0.0090 CI [−0.0182, −0.0004] | point=−0.009048738018, ci=[−0.018169763807, −0.000442000101] | line 710 | consistent |
| Baselines B0 0.232, B1 0.198, B2 0.181, B4 0.187, B5 0.181 | holdout_scores match | Table 3; line 599–605; Fig 4 matches | consistent |
| Cohort 7520→2362, 703 severe; 1573+357+430+2=2362; 703=449+102+151+1 | asset_inputs.json | Table 2; line 509–513 | consistent |
| Split contrast Brier −0.0059, AUROC +0.0124, log-loss +0.0069 (all CIs include zero) | split_contrast_paired: −0.005878, 0.012397, 0.006859 | line 578, 805–807; Table S5 | consistent |

## Citation checks (all verified)

| Key | Reference | Ledger | Online | Status |
|---|---|---|---|---|
| holm1979simple | Holm 1979, Scand J Stat 6(2):65–70 | jstor_verified_2026-09-26 | well-known correct | verified |
| diebold1995comparing | Diebold & Mariano 1995, JBES 13(3):253–263, doi 10.1080/07350015.1995.10524599 | crossref_verified_2026-09-26 | well-known correct | verified |
| chandrahas2026evalci | arXiv:2607.04429 (2026) | arxiv_api_verified_2026-09-26 | arXiv 2607.04429v1 exists (Chandrahas, Shreyas K., 2026-07-05); GitHub README bibtex matches; description "paired tests, cluster bootstrap intervals, all-pair Holm correction" accurate | verified |
| cameron2015cluster | Cameron & Miller 2015, J Human Resources 50(2):317–372 | crossref_verified_2026-09-26 | well-known correct | verified |

## Other checks

- **Blinding:** `main.tex` uses "Blinded for Anonymous Peer Review" as author; no identities/affiliations/funding/CRediT in main text. `title_page.tex` carries identities, affiliations, CRediT, and repository URL. Declarations explicitly omit author details for double-anonymous review. No breach.
- **Overlay:** `cbs_interpretation_overlay.json` present, `supersedes_for_this_manuscript=true`, `changes_numeric_results=false`, `leaves_hashed_release_files_unchanged=true`. Deprecated "small and slightly reversed"/"leakage-hardened" framings and `*_inflation_*` / `honest_estimate_scheme` keys superseded without changing any number or hashed file.
- **Release/archive distinction:** `title_page.tex` and `main.tex` (line 776–779) distinguish the frozen scientific release tag (v1.1.1) from a new immutable tag to be deposited on acceptance for the post-hoc Holm/seeded/robustness scripts and records; v1.1.1 left unchanged.
- **No universal/task-agnostic recommendation:** Manuscript states reuse is "a design proposal, not an empirical generalization from DYFI" (line 802–803) and "reuse outside this dataset is untested" (line 872).
- **Formatting:** `main.log` shows only cosmetic Underfull \hbox warnings (no Overfull \box, no clipped content); validation check `compiled_layout_has_no_clipped_or_overfull_content` passes. Figure 4 (`fig_baseline_scores.png`) is a legible forest plot with all values matching `baseline_performance.tex`. Supplement Table S2 (`exclusions_deviations.tex`) is wrapped in `spacing{1.0}` (single-spaced) with `longtable` `endhead` repeated headers.

## Top required changes

1. **(Fixable in this study)** Trim the abstract to ≤200 source tokens (currently 211 per the project validator) without losing the practical output statement.
2. **(Fixable in this study)** Soften the "harness reads feature values by declared name" sentence in Section 5.6 to match the `seeded_candidate_demo.py` implementation (the audit, not the value read, is what blocks substitution).

The remaining items (F3–F6) are limitations that require new data — a second catalogue, a harder endpoint, a more clustered holdout, and a hidden evaluation service — and are already honestly disclosed in Sections 3 and 7. They do not block this round's scientific tree.

## Summary

**Total: 26/30.** No vetoes. The manuscript is a methodologically sound, numerically consistent, and honestly calibrated single-catalogue case study. The two fixable defects (abstract length; one idealised sentence about the seeded harness) are minor and wording-only. The substantive concerns are limitations requiring new data, already disclosed. Default-reject stands on novelty/usefulness grounds bounded by the single-catalogue, magnitude-dominated, post-hoc design — not on any integrity, calibration, citation, blinding, or overclaim dimension.
