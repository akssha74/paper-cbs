# Independent default-reject review — Round 14 (Claude Opus)

**Venue:** Cybernetics and Systems: An International Journal
**Manuscript:** *A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study*
**Verdict:** Major revision. The default-reject stance is not overcome, mainly on novelty.
**Total:** 22 / 30. **Vetoes:** none.

## Artefact integrity

All seven supplied SHA-256 hashes match: `main.pdf`, `main.tex`, `supplement.pdf`, `supplement.tex`, `references.bib`, `build_ledger.json`, and `frozen_inputs/contract_transfer_dbmi.json`. The frozen transfer input is byte-identical to `contract-transfer-dbmi/results/results.json`. I ran `validate_cbs.py` on a scratch copy in `/tmp`, so the committed report was not rewritten, and it returned **57 checks, 0 failed**. `main.pdf` has **32 pages**, and the supplement has 8. `build.sh` was not run.

## Scores

| Criterion | Score |
|---|---|
| cbs_venue_fit | 2 |
| novelty | 1 |
| soundness | 2 |
| numeric_integrity | 3 |
| claim_calibration | 2 |
| editor_page_1 | 2 |
| reproducibility | 2 |
| related_work_citations | 3 |
| formatting_blinding | 3 |
| usefulness | 2 |
| **Total** | **22 / 30** |

**Vetoes:** fabricated_citation no; numeric_mismatch no; blinding_breach no; clearly_out_of_scope no; unsupported_overclaim no.

## Requested checks

1. **Spearman 0.755 on n = 2,185: verified.** `results.json` gives 0.75537 on 2,185 macroseismic events. That count is Mdm 1,985 + MIo 186 + Mpc 13 + Mio 1; the 571 Wmim mixed means are excluded. The instrumental correlation is 0.300 on 382 events. The provenance share checks out: 2,185 + 571 = 2,756, and 2,756 / 3,138 = 87.8%.
2. **Guaranteed 76 < 100 refusal: verified.** The runner chooses the smallest cutoff year Y\* such that the events with year ≥ Y\* number at most 0.2·n. The holdout is a subset of those events, so it can never exceed ⌊0.2·382⌋ = 76, which is below the 100-event floor. The realised holdout was 70 events (cutoff 2005). The main text discloses this in three places. The abstract does not.
3. **Executed versus unreached code: verified, with one minor issue.** In the executed runner (commit `396ef501`), only `leakage_audit`, `decluster`, the local year-cutoff and role glue, the Spearman computation, and the evaluability check ran. `tune_and_fit`, the CR1/CR3/Holm tests, the negative control, and the S1 fit were never reached. The manuscript says exactly this. Separately, `analysis_plan.md` §1 claims reuse of `role_assignment.grouped_cv_folds` and "the CR1 paired test"; in fact `role_assignment` is never imported and CR1 is reimplemented locally. None of that code ran, and the manuscript does not repeat the claim.
4. **Provenance filter and floor are plan-level, not v1 contract fields: mostly verified.** Contribution 6, the Discussion, Table S2, the workflow figure, and the failure-mode table are all consistent. The exception is lines 727–729, which list four local-glue rules and then say "the last two rules are transfer-plan additions". Read literally, that implies the name mapping and the magnitude-type (provenance) filter are v1 fields. All four are plan-level.
5. **"Internally frozen" wording: verified.** Neither "preregistration" nor "preregistered" appears in `main.tex`, `supplement.tex`, or `tables/`. The git order is plan freeze, then runner, then result.
6. **Kaufman, Schelter, and the TFX Evaluator: verified.** The Crossref DOIs resolve to the stated authors, titles, and venues. The TFX Evaluator guide documents `value_threshold`/`change_threshold` blessing, which matches the manuscript's description. evalci (arXiv 2607.04429) exists, and nine further DOIs resolve correctly. The one blemish is cosmetic: the key `tfma2026` carries year 2025.
7. **32 pages and 57/57: verified.**

## Independent arithmetic

- **Holm step-down:** the ordered p-values give seven rejections. B1–B5 (p = 0.0031) passes its 0.010 threshold, B1–B4 (0.0109) passes 0.0125, and B4–B5 (0.0350) fails 0.0167, which stops the procedure.
- **Bonferroni intervals:** six of the 99.5% intervals exclude zero.
- **Oracle-constant gap:** a constant equal to holdout prevalence scores Brier 0.228, and the construction-prevalence constant scores 0.232, a difference of 0.004.
- **Cohort accounting:** 1,573 + 357 + 430 + 2 = 2,362 events, and 449 + 102 + 151 + 1 = 703 severe events.
- **Seeded candidate C_F2:** its scores, paired intervals, and 15-pair Holm pattern match `seeded_candidate_demo.json`.
- **Robustness values:** the Monte Carlo SE of 0.0004 and the 86-cluster p = 0.0138 match `robustness_post_hoc.json`.
- **Transfer cohort:** the sizes, sequence counts, and class counts all match `results.json`.

## Major findings

**F1 (novelty, major): the contribution is incremental.** The authors themselves say the parts "are established separately" and that the released contribution is their combination. The only reversal, rejecting C_F2 despite its best scores, "holds by construction". Fail-closed quality gates already exist (NeMo Evaluator, TFX blessing), and so do paired cluster tests and Holm corrections.
*Required:* show a pre-specified case, not fixed by construction, where the combination changes a decision that an existing gate would make. Otherwise reposition the paper as a case-study or resource note.

**F2 (soundness, major): the decision layer is post hoc on a public holdout, and the second catalogue never exercises it.** The Holm family, the variance estimators, and the seeded candidates all postdate opening the holdout. The frozen protocol's primary result was demoted after the fact. The cluster correction barely matters: 312 of 354 holdout sequences are singletons, and G/(G−1) = 1.003. The Italian plan could not reach an evaluable holdout at n = 382.
*Required:* run the paired Holm layer on at least one evaluable, pre-specified dataset. Otherwise label every Holm result as a post-hoc illustration in the abstract and conclusion.

## Moderate and minor findings

- **F3 (claim calibration):** the abstract says the transfer "refused a 70-event holdout" but not that the plan's own cutoffs guaranteed the refusal. Contribution 6 lists the refusal as a contribution. Both should present the 87.8% provenance audit as the result.
- **F4 (claim calibration):** change "The last two rules …" to "All four are transfer-plan additions; none is a version-1 contract field."
- **F5 (reproducibility):** after the run, commit `db556891` edited `run_transfer.py` and replaced `hash_manifest.json`. The executed runner has hash `c7237009…`, and the original manifest recorded exactly that. The current manifest instead records the edited file (`bdb7294b…`). The edited code writes the note "written on the non-evaluable exit", but the committed manifest's note says the original run returned before writing any manifest. `RESULTS.md` still says the only pre-run change was the import-path fix and does not mention the post-run edit.
  *Required:* restore the executed hash, or record both hashes with the diff. Disclose the edit in `RESULTS.md` and Table S2, and ship the executed runner in the anonymized archive.
- **F6 (reproducibility):** the manuscript-level Holm, seeded-candidate, and robustness scripts will be tagged only on acceptance. Mint the tag before submission.
- **F7 (editor page 1):** the abstract is dense with the pairwise Holm pattern and disclaimers. Replace that detail with the practitioner rule and the pain point.
- **F8 (venue fit):** the systems and cybernetics framing is thin. Present the contract as a lifecycle gating and feedback component, and engage the journal's decision-support and verification work.
- **F9 (usefulness):** the two-field allowlist limits reuse. Ship the provenance rule as a tested audit component and show it rejecting the 2,756 CPTI rows under a name-level mapping.
- **F10 (cosmetic):** the 3,138 denominator also requires numeric magnitude, coordinates, and year, not just a DBMI15 intensity.

## Strengths

- Every number I checked reconciles with the frozen inputs.
- The disclosure of post-hoc status and the protocol chronology is unusually candid.
- The citations are accurate.
- Blinding is clean.
- The CPTI15 provenance finding is a concrete, reusable warning: 87.8% of labelled magnitudes are intensity-derived or mixed but would pass under an admissible name.

## Top required change for each sub-3 criterion

| Criterion | Required change |
|---|---|
| cbs_venue_fit | Present the contract as a lifecycle gating/feedback component and cite the journal's decision-support or verification literature. |
| novelty | Show a pre-specified, non-by-construction decision change relative to TFX/NeMo-style gates, or reposition the paper as a case-study. |
| soundness | Run the Holm layer on an evaluable, pre-specified dataset, or label all Holm results post-hoc illustrations throughout. |
| claim_calibration | Say in the abstract and Contribution 6 that the refusal was fixed by the plan; change "last two rules" to "all four". |
| editor_page_1 | Replace the pairwise-Holm detail in the abstract with the practitioner rule. |
| reproducibility | Restore or dual-record the executed runner hash, disclose the post-run edit, and mint the tag before submission. |
| usefulness | Release the provenance rule as a tested audit component and demonstrate it on CPTI. |
