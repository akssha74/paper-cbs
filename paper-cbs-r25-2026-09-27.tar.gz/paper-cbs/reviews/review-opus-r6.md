# Independent default-reject review, round 6 (Claude Opus 5.5)

**Venue:** Cybernetics and Systems
**Manuscript:** A Fail-Closed Qualification Contract for Machine-Learning Classifier Comparison, Demonstrated on a Versioned Seismic Felt-Intensity Catalogue
**Recommendation:** Reject (major revision at best). **Total: 19/30.** **Vetoes:** none.

## Integrity checks

- **Hashes.** main.pdf (`50b01d3b…e406`) and main.tex (`a7617360…c9fce`) match the claimed values and `build_ledger.json`. supplement.pdf (`b74a7a3e…c9c69c`) matches the ledger.
- **Reproduction.** Using the pinned environment, I ran `family_wise_sensitivity.py` and `seeded_candidate_demo.py`. Both passed the prediction-digest gate and the frozen-interval gate, and both produced JSON byte-identical to the committed records. I backed up the committed files beforehand, restored them afterwards, and reset their modification times.
- **Numbers.** Every value I checked matches `asset_inputs.json`, `family_wise_sensitivity.json` or `seeded_candidate_demo.json`. This covers the cohort counts, prevalences, threshold probe, per-baseline metrics, recall, calibration, the split diagnostic, all ten pairwise rows, the Bonferroni intervals, the Holm decisions, the seeded-candidate scores and intervals, and the temporal slices.
- **Blinding.** Clean. There are no identities, handles or URLs in either PDF or TeX source, and no `/Author` metadata.

## Scores

| Criterion | Score |
|---|---|
| 1 Scope and venue fit | 2 |
| 2 Novelty and contribution | 1 |
| 3 Significance and demonstrated usefulness | 1 |
| 4 Methodological soundness | 2 |
| 5 Numeric accuracy and traceability | 2 |
| 6 Claims–evidence alignment | 2 |
| 7 Protocol adherence and disclosure | 2 |
| 8 Statistical reporting | 2 |
| 9 Reproducibility and provenance | 3 |
| 10 Presentation, format and blinding | 2 |
| **Total** | **19/30** |

## Specific checks

**Holm decision rule and label consistency.** The rule is now fully specified (Section 4.4): Holm step-down at family α = 0.05 over ten pairs, using two-sided bootstrap p-values and Bonferroni 99.5% intervals. I re-derived it: B1–B4 (p = 0.018 against a threshold of 0.0125) and B4–B5 (p = 0.035 against 0.0167) are not rejected, and the other six pairs are. The labels are consistent across the abstract, Section 1.1, Table 6, Figure 1, Section 5.5, the Discussion and the Conclusion.

However, the ten-pair family includes three learned-versus-learned pairs that are not reference decisions. I applied Holm to the seven candidate-versus-reference pairs using the same p-values, and B1–B4 is rejected (0.018 ≤ 0.05 at the last step). So the single label that Holm "changes" (line 362) depends on a family chosen after the holdout was opened. Two smaller inconsistencies remain:

- The supplement lead paragraph still names only B2–B4 and B2–B5 as unresolved.
- Table 6 prints unadjusted intervals beside Holm decisions. For example, B4 versus B1 is printed as [−0.0205, −0.0023] but labelled unresolved.

**Seeded-contamination candidate.** This is a genuine end-to-end run. C_F2 is best on Brier (0.172), AUROC (0.809) and log-loss (0.515), and the audit rejects `num_responses` as family F2. Its post-hoc status is disclosed in the abstract, in Table 6, in Section 5.6, in Supplementary Table S2, in the Limitations and in the JSON record.

Its value as evidence is limited. A two-field allowlist rejects any third field by construction, and the chosen field is already named as forbidden. The unreported fact that would strengthen the paper is that, without the gate, C_F2 would be Holm-supported against B1 and B4 even in a 15-pair family (p ≈ 0.001).

Line 377 says the audit rejects the candidate "before any score is read". The script does compute scores after the audit, but it fits the model and predicts on the holdout before the audit runs.

**Diagnostic random forest.** The characterisation is mostly correct. The no-skill log-loss is 0.598, well below the random forest's 0.92–0.97. Two corrections are needed:

- The sequence-grouped Brier is 0.00503 below no-skill, so "within 0.005" is marginally false at full precision.
- The random-event Brier (0.2048) is worse than the constant-prevalence score (0.2040). This should be stated explicitly.

**B0 construction-prevalence note.** Correct. The B0 Brier is 0.232160, the oracle constant scores 0.227850, and the offset is (p − q)² = 0.0043.

**Machine-readable contradictions.** The new overlay supersedes the four named strings and declares its precedence, but four inconsistencies remain:

- The frozen `pairwise_matrix` still records B1–B4 and B4–B5 as `resolved_directional`. The overlay does not state that the Holm decisions take precedence over these fields.
- `honest_estimate_scheme: sequence_grouped` remains.
- The `*_inflation_*` key names remain.
- `probe_baseline: B4_random_forest` remains, although the manuscript says the diagnostic is distinct from B4.

**Claim ledger.** Every printed 4-dp value is covered. Several `appears_in` entries are wrong:

- L1 (−0.006) and L2 (0.012) are claimed in the prose, table and figure but are not printed anywhere.
- The event-grouped 4-dp values are claimed in the prose but appear only in the table.
- The 3-dp log-loss entries and L_random_event_brier (0.205) are claimed in Table 4, which prints 4 dp.
- The H_* entries are claimed in the prose, but only two of the Bonferroni intervals appear there.

These printed values have no ledger entry: 0.228, 0.004, 0.005, recall 0.25/0.29/0.37, 0.965, 0.387, 1.26, and the 0.70–0.71 and 0.92–0.97 ranges.

**References [1] and [2].** Both are consistent and match Crossref: volume 57(1), 2026, published online in November 2025.

**Table 1.** Wrapping is not fixed. Justified p-columns still produce hyphenated breaks and stretched spacing ("popula-tion", "vi-olation", "Sequence     crosses", "con-trol", "recon-struction").

**BetterBench and Knap et al. 2026.** Both are cited accurately, which I verified against arXiv and the Crossref abstract. Each gets only one sentence, and the discussion omits Knap et al.'s repeated-seed validation, which addresses the training variance this paper excludes from its intervals.

## Major issues

1. **Novelty (M1).** The contribution is a combination of established pieces on one magnitude-dominated corpus with a two-field allowlist. The authors acknowledge this (lines 141–144), and reuse on other data is untested.
2. **The seeded demonstration is close to tautological (M2).** An allowlist rejecting a field that is not on the list shows neither detection power nor practical usefulness.
3. **The Holm family is post hoc and the label change depends on it (M3).** The B4 versus B1 label reverses under a family restricted to reference comparisons.
4. **Usefulness is asserted rather than demonstrated (M4).** No external candidate, second catalogue or user case is evaluated.

## Top required changes

1. Add a second dataset, or a battery of seeded contaminations that includes proxies passing the name-matching families and a legitimately outcome-blind field. Report which ones the contract catches, and report Holm labels for C_F2 in the extended family.
2. Justify the ten-pair Holm family, or report labels under a reference-only family and state that the B4 versus B1 change depends on the family choice. Print the p-values and Holm thresholds in S1, and relabel its Holm column as reject/not rejected.
3. Overlay the remaining machine-readable fields: the pairwise status fields for B1–B4 and B4–B5, `honest_estimate_scheme`, the inflation key names and `probe_baseline`.
4. Fix the claim-ledger `appears_in` errors and add ledger entries for every printed value.
5. Fix the Table 1 wrapping and show the decision-bearing intervals in Table 6. Correct the random-forest "within 0.005" statement and add the random-event-worse-than-no-skill fact. Reorder the seeded script, or reword line 377. Expand the engagement with Knap et al. and BetterBench.
