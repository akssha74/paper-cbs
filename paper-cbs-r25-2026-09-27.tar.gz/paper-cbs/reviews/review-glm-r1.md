# Peer Review — review-glm-r1

**Reviewer model:** GLM-5.2
**Target venue:** *Cybernetics and Systems: An International Journal* (Taylor & Francis)
**Manuscript:** "Reliable Comparison of Severe Felt-Intensity Classifiers with Versioned and Dependent Event Data: A USGS DYFI Benchmark"
**Verdict:** MAJOR REVISION
**Total score:** 26 / 30
**Vetoes:** none

---

## 1. Summary

The manuscript releases a version-frozen USGS DYFI benchmark and an executable "qualification contract" for comparing severe felt-intensity (event-max CDI ≥ 6) classifiers: a six-family leakage audit, outcome-independent sequence-grouped roles with a 2023+ temporal holdout, a fixed baseline suite (no-skill, magnitude-only logistic, source-only logistic, expanded-metadata logistic, random forest, XGBoost), Brier score with sequence-cluster bootstrap intervals, and paired Brier-difference ranking. The worked conclusion is calibrated and largely null: all four learned baselines beat no-skill, B3 is excluded for using event year (a temporal-axis proxy), and the two lowest-Brier models (B2, B5) cannot be ranked. A random-vs-sequence split diagnostic is small and slightly reversed and is reported descriptively because no paired interval was retained.

The paper is unusually well calibrated, fully reproducible against frozen assets, double-anonymous clean, and citation-accurate. Its weaknesses are scientific impact and one methodological gap, not integrity: the "headline" split diagnostic lacks the uncertainty interval the protocol required, the task is magnitude-dominated, the contribution is an incremental combination of established components, and the substantive result is null. These warrant major, not minor, revision at this venue.

## 2. Rubric scores (0–3)

| # | Criterion | Score |
|---|-----------|-------|
| 1 | Venue scope fit for CBS | 2 |
| 2 | Contribution / novelty clarity | 2 |
| 3 | Methodological soundness | 2 |
| 4 | Numeric / evidence integrity | 3 |
| 5 | Claim calibration | 3 |
| 6 | Editor readiness (goal + usefulness on page 1) | 3 |
| 7 | Reproducibility / artifact | 3 |
| 8 | Related work & citation accuracy incl. CBS parity | 3 |
| 9 | Formatting & double-anonymous compliance | 3 |
| 10 | Usefulness / decision impact for applied-AI practitioners | 2 |
| **Total** | | **26 / 30** |

## 3. Detailed assessment

### Venue scope fit for CBS (2)
CBS publishes applied AI/ML with baseline comparisons (praveena2025retail; sag2025optimization; gao2026msbnet) and environmental decision-support systems (hossack2004dst; gomolka2000environmental). The manuscript's framing as "benchmark and evaluation reliability in applied intelligent systems" / decision-support harness fits the stated scope, and the five CBS precedents are correctly engaged. The risk is that the data, task, baselines, and worked example are all seismology-specific, so a skeptical editor could desk-reject as "this is a seismology benchmark." The accepted_precedents binding lesson already says the work must be presented as a decision-support problem for applied ML model selection rather than a seismology paper; that generalization is not surfaced in the main text.

### Contribution / novelty clarity (2)
The authors are explicit that "no individual component is claimed as new; the contribution is the auditable model-comparison contract." Nearest prior work is close: kumar2025dyfiindia (naive-split DYFI regression), li2025llmworldmodels (DYFI-grounded MMI benchmark with an identifier-leakage test), and stockman2026earthquakenpp (leakage-aware seismological benchmark for forecasting). The delta is the specific combination (version-pinning + leakage audit + sequence-grouped roles + temporal holdout + paired uncertainty + qualification contract) for this task. Clarity is high; novelty is incremental-but-defensible.

### Methodological soundness (2)
Proper scoring (Brier), sequence-cluster bootstrap, paired intervals, temporal holdout, leakage audit, one-shot protected evaluation, and bit-for-bit reconstruction are all sound. The one substantive gap: the "headline quantity" (split-sensitivity contrast) lacks the paired uncertainty interval the protocol required; it is honestly disclosed as a deviation, but a headline result with no interval sits awkwardly beside every other comparison being intervalled. The task is also magnitude-dominated (B1 magnitude-only AUROC 0.719; B2 magnitude+depth AUROC 0.786), which limits the ML interest.

### Numeric / evidence integrity (3)
Every result-bearing number I checked matches `frozen_inputs/asset_inputs.json` and the generated tables exactly. Partition sums, prevalences, baseline Brier/AUROC/CIs, the split diagnostic, the endpoint probe, the full pairwise matrix, the joint ordering probabilities, the temporal/geographic slices, and the fit-count provenance all reconcile. `python3 validate_cbs.py` reports 42 checks, 0 failed. See verified_numbers.

### Claim calibration (3)
Exemplary. No winning model is claimed; the split contrast is explicitly descriptive with no equivalence/zero-effect/leakage inference; the threshold probe is explicitly not a robustness claim; non-use boundaries (not real-time, not causal, not confirmatory, not geographic generalization) are stated. This is a model of calibrated writing.

### Editor readiness (3)
Goal, intended users, the decision enabled, and the non-use boundary are all clear in the abstract and on page 1. The independent 30-second editor test passes. Contribution identity ("benchmark and evaluation reliability in applied intelligent systems") is unambiguous.

### Reproducibility / artifact (3)
Frozen snapshot with SHA-256, pinned scientific-Python environment, one-shot protected evaluation with two verification replays, reconstruction hash, public release (link withheld for blinding), manifests, claim/citation ledgers, and `validate_cbs.py`. Excellent.

### Related work & citation accuracy incl. CBS parity (3)
All five CBS citations (DOIs 10.1080/01969722.2025.2583968, .2588199, 10.1080/01969722.2026.2723278, 10.1080/01969720490451878, 10.1080/01969720050046001) resolve on Crossref and their abstracts on OpenAlex match the manuscript's characterizations, including the verbatim "2.15-percentage-point Dice gain" for gao2026msbnet. Four further citations (kumar2025dyfiindia, li2025llmworldmodels, patelli2026macroseismic, mori2025explainable) were also verified. No mischaracterizations. CBS parity is demonstrated through the five precedents.

### Formatting & double-anonymous compliance (3)
`main.tex`/`main.pdf` and `supplement.tex`/`supplement.pdf` contain no author names, affiliations, repository URL, or self-identifying phrasing; the only URLs are the public-domain USGS data DOIs. Identities are correctly isolated on the separate `title_page.tex`. Single column, double-spaced, line-numbered. One caveat: the 29-page internal target has not been checked against the CBS length limit.

### Usefulness / decision impact for applied-AI practitioners (2)
The qualification contract is a genuinely useful decision-support harness and the worked example shows it changes two decisions (B3 excluded; B2/B5 unresolved). But the release is domain-specific (DYFI seismology), the substantive result is null, and the transferable lessons are not articulated, so the usefulness to a general CBS applied-AI reader is moderate rather than high.

## 4. Required changes (concrete and actionable)

1. **Split-contrast uncertainty.** Abstract lines 56–60 ("this comparison is descriptive because no interval was retained") and Section 5.3 / Table 3 ("The resource's headline quantity is the optimism of naive random splitting..."). The headline contrast has no interval while every other comparison does. **Fix:** either (a) compute a paired sequence-cluster bootstrap interval for the Brier and AUROC split-contrast (the infrastructure already exists — the pairwise bootstrap resamples the same 354 holdout sequences with n=2000), or (b) downgrade the contrast from "headline quantity" to "secondary descriptive diagnostic" in Section 5.3, the Abstract, and the Conclusion.

2. **Magnitude-dominated endpoint.** Abstract (47–66) and Section 1 (86–95); Limitations (638–640) already states "The endpoint is magnitude-dominated." B1 magnitude-only AUROC 0.719 and B2 magnitude+depth AUROC 0.786 show the task is close to a magnitude-thresholding proxy. **Fix:** add one sentence to the Abstract or Introduction acknowledging that magnitude is the dominant predictor and the task is by construction a magnitude-thresholding proxy, so the contribution is the comparison contract, not a hard new classification problem.

3. **Venue-fit framing for CBS.** Section 1.2 (144–160) and Section 2 (194–216). The data/task/baselines/examples are all seismology-specific, creating desk-reject risk. **Fix:** add 2–3 sentences positioning the qualification contract as a reusable, task-agnostic applied-AI model-comparison template (version-pinning, feature/axis audit, outcome-independent roles, paired uncertainty) of which DYFI is one instantiation. Surface the binding lesson already in `accepted_precedents.json`.

4. **Threshold-probe presentation.** Section 5.2 / Table 2 (endpoint_threshold_sensitivity). The 5.5/6.5 rows relabel and rescore fixed 6.0-fitted B2 probabilities without refitting, yet the monotonic AUROC increase (0.734→0.786→0.815) reads as endpoint robustness. **Fix:** either rename the column headers to "Brier (6.0-fitted, relabeled)" and "AUROC (6.0-fitted, relabeled)," or add a bolded one-line caveat above the table: "These rows are not fair performance estimates at 5.5/6.5; they are relabelings of the 6.0-fitted B2 model and do not establish endpoint robustness."

5. **Transferable lessons for a null result.** Conclusion (670–685) and Section 5.7 (560–577). The substantive findings are null (no winner; B2–B5 and B2–B4 unresolved; split diagnostic inconclusive). **Fix:** add a short "Transferable lessons" paragraph listing 2–3 generalizable takeaways that hold regardless of the DYFI null result (version-pin any model-selection benchmark; report a paired interval for every superiority claim; audit feature provenance against the evaluation axis before scoring).

6. **Verify CBS length limit.** `cbs_validation_report.json` reports "29 (internal target; venue limit not verified)." **Fix:** confirm the CBS word/page/figure limit from the current Taylor & Francis author instructions and trim or restructure (e.g., move more tables to the supplement) to comply before submission.

## 5. Optional suggestions

- The "110 unit tests across four suites" claim (Section 4.1, line 319) is not in `claim_ledger.jsonl` or `asset_inputs.json`; release the test suite or a test-count manifest so it is auditable like the other results.
- The B4–B5 lower CI endpoint (0.0003) is near the Monte Carlo boundary; consider increasing bootstrap draws (e.g., 10,000) for that specific near-zero comparison to stabilize the "excludes 0" verdict.
- `references.bib` lists gomolka2000environmental as "Gomołka, Zdzisław and Orłowski, Cezary," but Crossref returns only Orlowski and OpenAlex concatenates the names; verify against the publisher PDF and consider an ASCII author fallback note.
- The provenance narrative (preliminary count 7,575 → 7,576; 56-record difference) is not independently checkable from frozen assets; ensure the acquisition log is in the public release bundle.
- The geographic subgroup summary (82 cells, per-cell Brier 0.002–0.825, median 0.151) supports no claim; consider moving Fig. 5b to the supplement to tighten the main story.

## 6. Vetoes

None. No fabricated or mis-characterized citation (all 9 spot-checked citations verified). No numeric mismatch with frozen assets (all checked numbers reconcile). No blinding breach in `main.tex`/`main.pdf`/`supplement.tex`/`supplement.pdf`. Not clearly out of scope for CBS (defensible decision-support framing with five engaged CBS precedents). No unsupported overclaim (calibration is exemplary).

## 7. Recommendation

Major revision. The integrity, calibration, reproducibility, and citation accuracy are above bar for CBS; the headline-diagnostic interval gap, the magnitude-dominated task, the seismology-specific framing, and the null substantive result need to be addressed before the paper is competitive at this venue. With those revisions, a score in the 28–29 range and an accept-with-minor-revisions outcome is plausible.
