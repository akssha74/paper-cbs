# Independent R2 review for Cybernetics and Systems

Reviewer model: GPT-5.6  
Recommendation: **REJECT**  
Score: **23/30**  
Vetoes: **numeric mismatch; unsupported overclaim**

This is a review of the current working-tree manuscript. I extracted the current `main.pdf` with `pdftotext -layout`, checked the source, supplement, title page, generated tables, frozen asset input, bibliography, rendered figures, build logs, and public release. The numerical analysis is mostly careful and the submission is clearly within the journal's broad applied-AI and decision-systems scope. The rejection follows from two explicit vetoes in central result language, plus an incremental contribution that remains demonstrated on only one magnitude-dominated task.

## Scores

- CBS venue fit: **3/3**
- Novelty: **1/3**
- Soundness: **2/3**
- Numeric integrity: **2/3**
- Claim calibration: **2/3**
- Editor page 1: **3/3**
- Reproducibility: **3/3**
- Related work/citations: **3/3**
- Formatting/blinding: **2/3**
- Usefulness: **2/3**

Total: **23/30**

## Goal, usefulness, and abstract story

The study asks whether a classifier comparison remains admissible and statistically supportable after fixing catalogue version, feature eligibility, dependence-aware roles, temporal evaluation, paired uncertainty, and reconstruction.

The intended users are applied-ML engineers, benchmark maintainers, and reviewers. They use the harness to decide whether a candidate belongs to the declared comparison contract and whether a Brier improvement over a reference is supported. The substantive case-study result is that all four learned models improve over no-skill, B2/B4/B5 improve over magnitude-only B1, B3 is outside the SOURCE_ONLY schema, and B2 versus B5 remains unresolved.

- `goal_understood`: true
- `usefulness_understood`: true
- `abstract_story_pass`: true
- Contribution identity: executable benchmark/evaluation contract with a seismic case study
- Novelty class: **incremental**

The first page states the pain point, goal, approach, principal result, user decision, and non-use boundary. Its story is clear despite the result-count error identified below.

## Veto findings

### 1. The abstract and conclusion miscount the B1 improvements

The abstract states: “All four learned models improved on both the no-skill reference and the magnitude-only comparator.” The conclusion similarly says “four learned candidates improve over no-skill and over magnitude-only B1,” and the Contributions section says all admissible learned candidates improve over B1.

The frozen pairwise matrix supports four learned-model improvements over B0, but only three comparisons against B1: B2−B1, B4−B1, and B5−B1. B1 cannot improve over itself. The correct statement is:

> All four learned models improve over B0; B2, B4, and B5 improve over B1.

This mismatch appears in the abstract, contribution summary, conclusion, and title-page abstract. It is a numeric/result veto even though the underlying table is correct.

### 2. “False winner” is not established

Table 6 and the conclusion say that the contract prevents a “false winner declaration.” The B2−B5 interval `[-0.0078, 0.0068]` shows that superiority is unresolved. It does not show that either candidate cannot truly be better.

Replace “false winner declaration” with “unsupported winner declaration.” The abstract already uses the calibrated wording.

## Major required changes

### 3. The demonstrated novelty remains an integration of established controls

The manuscript correctly concedes that no individual component is new. Its delta is an executable integration of version pinning, a two-feature allowlist, role audits, grouped/temporal evaluation, proper scoring, and paired bootstrap comparison. The nearest methodological work already supplies the statistical-comparison, leakage-audit, blocked-validation, and temporal-validation primitives.

The case study does show a useful decision change, but only on one magnitude-dominated endpoint, with generality explicitly untested. The secondary split diagnostic is inconclusive. To clear a research-article novelty bar, demonstrate the contract on a second event dataset or independently supplied candidate set, or conduct a controlled audit showing several concrete decisions that conventional evaluation gets wrong. Otherwise, this remains a strong task-specific reproducibility resource rather than a beyond-incremental systems contribution.

### 4. Align B1 claims with the stated inferential hierarchy

The manuscript labels B2/B4/B5 improvements over B1 as “supported,” while also stating that B2 versus B0 is the only primary comparison and that all remaining pairwise intervals are exploratory and unadjusted.

Either prospectively designate and multiplicity-control the B1 qualification comparisons, or label them exploratory everywhere, including the abstract and conclusion. An exploratory interval should not become an unqualified adoption decision.

## Numeric verification

The frozen numerical surface is otherwise internally consistent:

- Cohort: `1573 + 357 + 430 + 2 = 2362`; role-assigned total `= 2360`.
- Severe events: `449 + 102 + 151 + 1 = 703`; role-assigned severe total `= 702`.
- Prevalence: `703/2362 = 0.297629`, `551/1930 = 0.285492`, and `151/430 = 0.351163`.
- Threshold probe at 5.5/6.0/6.5: prevalence `0.458/0.351/0.260`, Brier `0.240/0.181/0.143`, AUROC `0.734/0.786/0.815`.
- Split diagnostic: sequence-minus-random Brier `-0.005878207034`; AUROC `+0.012396868243`.
- Recomputed recalls: B1 `0.2450`, B2 `0.3179`, B4 `0.2914`, B5 `0.3709`.
- All ten pairwise Brier differences and intervals match the frozen matrix.
- Temporal counts sum to `250 + 180 = 430`; the 82 geographic cells also sum to 430.
- Geographic cell Brier min/median/max are `0.002441/0.150983/0.824898`.

The current local `frozen_inputs/asset_inputs.json` is byte-identical to the public `v1.1.1` asset input, SHA-256 `b7f7dea60c7421b0b75870d45421c094e3cd4b5e325702c94b498ebc7926ace9`. The current PDF/source hashes match `build_ledger.json`.

## Citations and venue fit

The official [Cybernetics and Systems scope](https://www.tandfonline.com/journals/ucbs20/about-this-journal) includes applied AI/ML, intelligent systems, decision making, and cybernetics in environmental systems. The paper is therefore in scope.

Crossref metadata and OpenAlex records/abstracts independently verify all five CBS citations:

- [Hossain and Sağ](https://doi.org/10.1080/01969722.2025.2588199): ten benchmark datasets and Wilcoxon/Friedman testing are confirmed.
- [Praveena and Prasanna Devi](https://doi.org/10.1080/01969722.2025.2583968): the stacked ensemble and point accuracy/precision/recall characterization are confirmed.
- [Gao et al.](https://doi.org/10.1080/01969722.2026.2723278): KiTS23/KiPA22 and the 2.15-point Dice gain are confirmed.
- [Hossack et al.](https://doi.org/10.1080/01969720490451878): the GIS/web environmental decision-support characterization is confirmed.
- [Gomołka and Orłowski](https://doi.org/10.1080/01969720050046001): fuzzy logic, rule creation, and expert membership-function verification are confirmed.

No fabricated CBS citation was found. The USGS dataset DOI `10.5066/P143CZ3R`, which a Crossref-only availability check marked unregistered, is valid in DataCite and resolves to the USGS ScienceBase record; it is not a fabricated citation.

## Reproducibility

The release and manuscript package are unusually well pinned. The public tag resolves, the exact frozen asset input matches the local copy, the scientific environment is versioned, and the manuscript distinguishes fixed-holdout sampling uncertainty from training, tuning, sequence-definition, and future-catalogue uncertainty.

This does not turn the internally frozen protocol into an external preregistration, repair the absent split-diagnostic interval, or establish generality. The manuscript discloses those boundaries.

## Formatting and blinding

The explicit blinding checks pass. `main.tex`, `main.pdf`, `supplement.tex`, and `supplement.pdf` contain no GitHub URL, no project name “DYFI Benchmark Reliability,” no `v1.1.1`, and no author name, affiliation, or email. PDF metadata has no author field. Identifying details are confined to the separate title page.

All five figures are legible and consistent with their captions. The main PDF is single-column, double-spaced, line-numbered, and synchronized with source. The build log nevertheless records overfull boxes of 8.67 pt and 14.16 pt; Table 6 visibly wraps `SOURCE_ONLY` awkwardly near the right margin. Reflow Tables 3 and 6 before submission.

## Final assessment

Strengths are the transparent non-use boundaries, exact artifact pinning, correct conditional-bootstrap interpretation, explicit B1 comparator, calibrated treatment of B3 as schema policy, and unusually complete citation positioning.

The present version is not acceptable because its abstract and conclusion make a false count claim, its “false winner” wording exceeds what the interval proves, and the core contribution remains an incremental one-dataset integration. After correcting the two vetoes, the remaining editorial decision turns on whether the journal accepts the task-specific reproducibility contribution or requires a cross-dataset/system demonstration.
