# Review — GLM Round 12 (independent, default-reject)

**Manuscript:** *A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study* (Cybernetics and Systems, double-anonymous).

**Scope of this round.** I reviewed `main.tex`/`main.pdf`, `supplement.tex`/`supplement.pdf`, `references.bib`, `build_ledger.json`, `cbs_validation_report.json`, and the three post-hoc scripts. Per instructions I did **not** read review files from earlier rounds, did **not** edit the manuscript, scripts, frozen inputs, or other studies, and did **not** open `title_page.tex` (the only file permitted to carry identities).

## 1. SHA-256 verification

All six required hashes match byte-for-byte:

| File | Expected SHA-256 | Verified |
|---|---|---|
| `main.pdf` | `3fbc88381bcb0e587940f1225ff060e2091453022499f3c1d6380c152ec33541` | ✓ |
| `main.tex` | `cc7d1a3931a322656ec28a9c6eb0116bdf08e8f25c44d15c310e529f4a7fa928` | ✓ |
| `supplement.pdf` | `77cb18c162298fdd6fa29c0d91c6e79e0c250c24f40ca57a86f564fe72af4a3a` | ✓ |
| `supplement.tex` | `0f2b5efe4b257ad8889cdb60bc421076b81be18a0e02ac1bbea8e91ac87be395` | ✓ |
| `references.bib` | `5aedb90ed724a2dc17b364e33e6076ecb40ec42717438344dbf5801e2e9e8efd` | ✓ |
| `build_ledger.json` | `268cbafc52886370762c1c9f9c1d6901d830326cbb283d3ef3456821ef735399` | ✓ |

## 2. Page counts (pdfinfo, not invented)

- `main.pdf`: **32 pages** (letter) — matches the stated 32-page main.
- `supplement.pdf`: **8 pages** (letter).

## 3. Validator

`python3 validate_cbs.py` → **56 checks, 0 failed → PASS** (`cbs_validation_report.json` `n_checks=56`).

## 4. Optional reproduction (`/tmp/dyfi-analytics-venv/bin/python`, Python 3.11.15)

I backed up the three post-hoc frozen-input JSON files, re-ran all three scripts, compared SHA-256, restored the backups, re-hashed every scientific file, and re-ran the validator.

| Script | Frozen output | Pre/post SHA-256 | Byte-identical |
|---|---|---|---|
| `family_wise_sensitivity.py` | `frozen_inputs/family_wise_sensitivity.json` | `af7c931a…f61397` | ✓ |
| `seeded_candidate_demo.py` | `frozen_inputs/seeded_candidate_demo.json` | `73781a20…3a21c1` | ✓ |
| `robustness_post_hoc.py` | `frozen_inputs/robustness_post_hoc.json` | `af5fdfc2…ae3ef0b` | ✓ |

Spot-checks reproduced against the manuscript:

- B1–B4 CR1 p = `0.010855349147` (ms p=0.0109, threshold 0.0125) ✓
- B4–B5 CR1 p = `0.034959417716` (ms p=0.0350, unresolved) ✓
- B2–B4 CR1 p = `0.048519812716` (ms p=0.0485, unresolved) ✓
- C_F2 scores: Brier `0.172389679459`, AUROC `0.809276270503`, log-loss `0.515321511554` (ms 0.172 / 0.809 / 0.515) ✓
- Synthetic 86-cluster: CR1 p = `0.013763249604`, n_holm = 6 (ms "raises B1–B4 CR1 p to 0.0138, six Holm decisions") ✓
- Seven Holm rejections reproduced across CR1, CR3 jackknife, wild-cluster, event-level, and 5°/10° regional cells ✓

All six scientific-file SHA-256 values were identical before and after the runs; the validator re-passed 56/56 after restore. No scientific file was modified.

## 5. Required round-12 checks

| Check | Status | Evidence |
|---|---|---|
| Harness/admission wording | **pass** | Abstract "admit/reject decision"; §1.3 "decision-support test harness"; §2.1 "admission audit"; seeded § "harness-extracted allowlisted columns", "read by the harness from the frozen rows". |
| Log-loss in abstract | **pass** | Abstract: "Brier (0.172), AUROC (0.809), and log-loss (0.515)". |
| Matplotlib pin in `build_ledger.json` | **pass** | `utility_figure_matplotlib_pin`: `3.11.1`; §4.4 "Matplotlib~3.11.1". |
| TFX / Breck / NeMo / Dror / Bouthillier | **pass** | All five present in `references.bib` (`baylor2017tfx`, `breck2019datavalidation`, `nvidia2026nemoevaluator`, `dror2018hitchhiker`, `bouthillier2021variance`) and cited in §2. |
| Synthetic 86 clusters | **pass** | §5.4 "A disclosed random 86-cluster partition … raises B1–B4 CR1 p to 0.0138 (six Holm decisions)"; reproduced. |
| Holm 7 | **pass** | §5.4 "Seven of the ten pairwise differences are rejected under Holm"; reproduced. |
| 56/56 | **pass** | `validate_cbs.py`: 56 checks, 0 failed; `cbs_validation_report.json` `n_checks=56`. |
| 32-page main | **pass** | `pdfinfo main.pdf`: Pages = 32. |

## 6. Criterion scores (0–3 each, total /30)

| # | Criterion | Score | Rationale |
|---|---|---|---|
| 1 | Significance | 2/3 | Real applied-AI reliability problem the journal has shown interest in, but single retrospective catalogue, magnitude-dominated task near thresholding, framed as decision-support not an adoption certificate. |
| 2 | Novelty | 1/3 | Authors state the constituent pieces are established separately; the contribution is their fail-closed combination on one frozen corpus; reuse untested. Engineering recombination, not new methodology. |
| 3 | Soundness | 2/3 | Methods correctly applied; post-hoc status disclosed. Caveats: all inferential labels are post-hoc (not confirmatory); the cluster-robust correction is barely exercised (312/354 singletons, G/(G−1)=1.003); the headline B1–B4 label is marginal/family-dependent (unresolved in the 15-pair seeded family; 10° wild-cluster p=0.0124 vs 0.0125). |
| 4 | Usefulness | 2/3 | Intended users and the two decisions are clearly stated and demonstrated end-to-end, including a seeded post-outcome candidate. But one retrospective catalogue, not operational, confirmatory use needs a fresh hidden holdout; the seeded demo is a by-construction policy illustration, not detection. |
| 5 | Reproducibility | 3/3 | SHA-256 versioning, digest-verified reconstruction, single-use token + two replays, pinned env, build ledger, matplotlib pin. Independent byte-identical reproduction of all three post-hoc scripts confirmed here. |
| 6 | Numeric integrity | 3/3 | All spot-checks cross-check; cohort reconciles (7520→2362→2360+2; 1573+357+430+2=2362); 56/56 validator; no hand-edited cells. |
| 7 | Clarity | 2/3 | Well-organized with clear contributions and honest limitations, but dense: §4.3 packs many metrics/uncertainty procedures into one passage; §5.9 overlay/corrections/metadata-supersession machinery is hard to follow on first reading. |
| 8 | Venue fit & formatting | 3/3 | CBS journal is a reasonable home; double-anonymous; 32p main, 8p supp, letter, 1in, doublespaced, line numbers; abstract 202 words; declarations present. |
| 9 | Related work / positioning | 3/3 | Thorough, honest positioning with an explicit delta vs TFX/Breck/NeMo/Dror/Bouthillier/BetterBench/Knap/Demsar/Benavoli/Kapoor; no overclaim of primacy. |
| 10 | Limitations & honesty | 3/3 | Exceptionally candid: post-hoc disclosed, no winning model, no invented equivalence margin, held-out semantics not "untouched"/"confirmatory", reuse untested, not operational, no causal/real-time benefit claimed. |

**Total: 24 / 30 (0.80).**

## 7. Vetoes

**None triggered.**

- No data fabrication or falsification — byte-identical reproduction of all three post-hoc scripts.
- No plagiarism — citations resolve; positioning is honest and credits prior work.
- No miscalibration of headline claims — every inferential label is disclosed as post-hoc, not confirmatory.
- No blinding breach — identities appear only on `title_page.tex`, which I did not open.
- No reproducibility failure — 56/56 validator, SHA-256 chain intact, scientific files unchanged after reproduction.
- No page-limit or abstract-limit violation (32-page main; 202-word abstract).

## 8. Fixed defects credited (default-reject, but credit where due)

- SHA-256 chain intact for all six required files; `main.pdf` is the stated 32 pages.
- Validator **56/56 PASS**.
- Byte-identical independent reproduction of all three post-hoc scripts.
- Abstract reports log-loss (0.515) alongside Brier and AUROC; 202 words, within limit.
- Matplotlib pinned (3.11.1) in `build_ledger.json` and §4.4.
- Required citations present and resolved: TFX, Breck, NeMo, Dror, Bouthillier.
- Harness/admission wording consistent across abstract, §1.2, §1.3, §2.1, and the seeded-candidate section.
- Holm seven-rejection count and synthetic 86-cluster (p=0.0138, six Holm decisions) reproduced exactly.
- Honest scoping throughout: post-hoc disclosed, no winning model, no equivalence claim invented, not confirmatory, not operational, reuse untested.

## 9. Required changes

**F1 (major, clarity) — Simplify the §5.9 overlay/metadata-supersession machinery.** Two overlays (corrections overlay, manuscript-level interpretation overlay), three deprecated legacy field names (`*_inflation_*`, `honest_estimate_scheme`), and the unadjusted B1–B4/B4–B5 direction corrections are described in a single dense paragraph. A reader cannot easily reconstruct what the public v1.1.1 tag contains versus what the review-archive additions carry. Add a compact table (tag → contents → SHA-256 status → postdates v1.1.1?) or a short enumerated list.

**F2 (major, soundness) — Elevate the marginal/family-dependent status of the B1–B4 headline.** B1–B4 (p=0.0109 vs threshold 0.0125) is unresolved in the 15-pair seeded family and borderline under 10° wild-cluster inference (p=0.0124 vs 0.0125, Monte Carlo SE 0.0004). This is disclosed in §5.4 and Supplementary Table S6 but is not reflected in the abstract or conclusion, which list "B2, B4, and B5 also improve over magnitude-only B1" with only a parenthetical. State the fragility of the B4-over-B1 label upfront in the abstract and conclusion so the headline matches the sensitivity evidence.

**F3 (major, soundness) — Acknowledge that the cluster-robust correction is barely exercised on this catalogue.** 312/354 holdout sequences are singletons and G/(G−1)=1.003, so the cluster-robust SE differs little from an event-level paired t test. The manuscript notes this but then relies on cluster-robust Holm as the decision rule. Make explicit that on this catalogue the cluster-robust machinery is largely a formality (the regional-cell re-clustering is the only configuration that meaningfully exercises dependence), and clarify why the default-sequence decision is still reported as primary.

**F4 (minor, clarity) — Split the metrics/uncertainty subsection.** §4.3 covers Brier, log-loss, AUROC, calibration, the sequence-cluster bootstrap, the CR1 SE, Holm, Bonferroni, the percentile-vs-test distinction, and the legacy bootstrap in one long passage. Split into labelled short paragraphs (primary score; secondary scores; uncertainty; multiplicity) for reviewer navigability.

**F5 (minor, novelty) — Soften any implied generalizability of the contract.** Reuse on other catalogues is untested (stated in Limitations). Ensure the abstract and intro do not imply the contract generalizes beyond this DYFI task; the abstract currently reads as a general "contract" rather than a one-corpus demonstration. A single qualifying clause would suffice.

## 10. Non-fixable concerns (design-inherent, acknowledged)

- Single retrospective catalogue; confirmatory use requires a fresh hidden holdout or independent evaluation service.
- Magnitude-dominated endpoint (magnitude-only AUROC 0.719) means the task is close to thresholding; the contribution is the contract, not a hard classification problem.
- Mostly-singleton holdout clustering limits how much the cluster-robust method can be stress-tested on this corpus.

## 11. Summary and recommendation

**Recommendation: major revision.**

Default-reject stance applied. The integrity layer is impeccable — SHA-256 chain intact for all six files, 56/56 validator checks pass, independent byte-identical reproduction of all three post-hoc scripts, calibrated and honestly scoped claims, blinding intact, 32-page main, 202-word abstract, and all required citations (TFX, Breck, NeMo, Dror, Bouthillier) and round-12 checks (harness/admission wording, log-loss in abstract, matplotlib pin, synthetic 86 clusters, Holm 7, 56/56, 32-page main) verified. No veto is triggered.

The remaining deductions are substantive, not integrity-related: modest single-corpus **novelty** (1/3) — the paper itself frames the contribution as a fail-closed recombination of established pieces on one frozen corpus with reuse untested; **soundness** (2/3) — every inferential label is post-hoc, the cluster-robust correction is barely exercised by mostly-singleton sequences, and the headline B1–B4 label is marginal and family-dependent; and **usefulness** (2/3) — demonstrated on one retrospective, non-operational catalogue. The fixable items (F1–F5) are clarity and framing; the core limitations are design-inherent and would require a second corpus or a fresh hidden holdout to address, which is beyond a revision.

This is a defensible-but-modest contribution: methodologically sound, numerically clean, honestly scoped, and in venue, but not one I would inflate to a strong accept. Acceptance should be contingent on F1–F3 being resolved; F4–F5 are desirable polish.
