# Independent default-reject review — GPT-5.6, round 11

## Verdict

**Minor revision / accept after minor revision: 25/30.**

No veto is triggered. I found no result-level error, numeric mismatch, fabricated citation, blinding breach, unsupported overclaim, or scope failure. The remaining changes are one minor citation-precision issue, one claim-ledger self-description/coverage issue, and one figure-legibility issue.

## Criterion scores

- **cbs_venue_fit: 3/3.** The contribution is an applied AI/ML decision system that produces candidate admit/reject and claim supported/unresolved decisions. This matches the journal’s stated applied AI/ML and decision-making scope, and the paper engages five papers from the target journal.
- **novelty: 2/3.** The advance is a defensible, practice-relevant integration, not a new statistical primitive. The residual delta over the nearest work is pre-score schema/role admission, event-sequence clustering, version pinning, and the worked DYFI case.
- **soundness: 2/3.** The frozen-fit conditional analysis is coherent and stress-tested. The ceiling is limited by post-hoc Holm/robustness choices and the exclusion of training-run and hyperparameter-search variance. These limits are disclosed.
- **numeric_integrity: 3/3.** Independent arithmetic, pointer resolution, script reproduction, and validator checks passed; no numeric mismatch was found.
- **claim_calibration: 3/3.** The manuscript does not claim equivalence, a winner, general leakage detection, geographic transport, operational utility, causality, or confirmation.
- **editor_page_1: 3/3.** The rendered 188-word abstract is fully on page 1 and includes the pain point, practical outputs, marginal B1–B4 result, seeded rejection, unresolved comparisons, post-hoc status, and fresh-hidden-data boundary.
- **reproducibility: 2/3.** Pins, environment, reconstruction gates, scripts, immutable inputs, and reviewer archive are strong. Claim-ledger coverage is not as exhaustive as its generator claims.
- **related_work_citations: 2/3.** The nearest neighbors exist and are relevant. One sentence should separate Dror et al.’s test-selection contribution from Bouthillier et al.’s training/HPO variance analysis.
- **formatting_blinding: 2/3.** The package is blinded and generally clean. Figure 3 panel (a) retains crowded/overlapping annotations.
- **usefulness: 3/3.** Users, decisions, prevented errors, and non-use boundaries are explicit. The seeded C_F2 case demonstrates why admission and score-based support are distinct.

## Vetoes

- fabricated_citation: **false**
- numeric_mismatch: **false**
- blinding_breach: **false**
- clearly_out_of_scope: **false**
- unsupported_overclaim: **false**

## Goal, use, and substantive result

The study asks whether classifier-superiority claims on an evolving, dependent-event catalogue remain supportable after candidate admission, version pinning, temporal evaluation, clustered paired inference, and multiplicity control.

The intended users are applied ML engineers, benchmark maintainers, and reviewers. They can reject an inadmissible candidate before scoring and label declared pairwise gains as Holm-supported or unresolved.

The worked result is clear: all admissible learned candidates are supported over B0; B2, B4, and B5 are supported over B1 in the post-hoc ten-pair family, with B1–B4 explicitly marginal and family-dependent; B2–B4, B2–B5, and B4–B5 remain unresolved. C_F2 is rejected at admission despite favorable scores and support against B0, B1, and B4 in the 15-pair family.

`goal_understood: true`  
`usefulness_understood: true`  
`abstract_story_pass: true`

## Novelty assessment

**Class: defensible-beyond-incremental.**

The sceptical reduction is “established leakage checks, version pinning, clustered paired inference, and Holm correction combined on one DYFI task.” The paper survives that reduction narrowly because the pre-score schema/role gate and the explicit separation between admission and statistical support provide a concrete workflow not supplied by the nearest cited tools.

Verified nearest neighbors:

- **NVIDIA NeMo Evaluator quality gates** already match paired per-item scores, form 95% confidence intervals, apply policy thresholds, and return fail-closed GO/NO-GO/INCONCLUSIVE verdicts. Its documented gate does not audit candidate feature availability or role isolation.
- **evalci** already provides paired tests, cluster bootstrap intervals, and every-pair Holm correction for language-model evaluation.
- **Dror et al. (2018)** provides a significance-test-selection protocol and documents misuse of significance testing.
- **Bouthillier et al. (2021)** directly studies variance from data sampling, initialization, and hyperparameter choice.
- **BetterBench** assesses 46 lifecycle practices across 24 benchmarks and reports weak significance/reproducibility practice; it audits benchmarks rather than admitting candidates.
- **Knap et al. (2026)** provides a two-dataset leakage-safe bearing benchmark with six fixed scenarios and repeated-seed follow-up; it does not couple feature-schema admission to a family-wise candidate decision.

The manuscript appropriately claims the combination and case study, not priority over these primitives.

## Verification results

All supplied SHA-256 pins match:

- `main.pdf`: `5785bb7cf92fa7c2191cf9e536e1507dc0ed8a613c5906496572bdc33ba6e7d2`
- `main.tex`: `80c055635e3d666faa412f5a17c8db68aff997a7ea00dd1c0bd4ecb67aacaaba`
- `supplement.pdf`: `77cb18c162298fdd6fa29c0d91c6e79e0c250c24f40ca57a86f564fe72af4a3a`
- `supplement.tex`: `0f2b5efe4b257ad8889cdb60bc421076b81be18a0e02ac1bbea8e91ac87be395`
- `references.bib`: `d73a825d7283ca1f6d7054fceb822ad8922db97e8474fb7d95226df05d64e1c9`
- `build_ledger.json`: `af872ad904d3dd5ac88c112b17605b24f3f9148b4055c5e2ea98475956d4b9e3`

The main PDF has 31 pages; the supplement has 8. Fonts are embedded. Rendered pages and the three specified PNG figures were inspected.

Reproduction:

- `family_wise_sensitivity.py`: PASS
- `seeded_candidate_demo.py`: PASS
- `robustness_post_hoc.py`: PASS
- `validate_cbs.py`: **56/56 PASS**
- Scientific tree after restoring backed-up frozen outputs: **byte-identical**
- Independently resolved RFC 6901 claim-ledger pointers: **161/161**

Key checks:

- Ten-pair Holm rejections: **7**
- Wild-cluster draws: **99,999**
- Ten-degree B1–B4 wild p-value: **0.01244**, MC SE **0.0003505**, versus threshold **0.0125**
- Synthetic frozen-loss clusters: 86 clusters gives B1–B4 p=**0.013763** and six rejections; 54 and 43 clusters give p=**0.011822** and **0.010661**, each with seven rejections
- The synthetic analysis is explicitly disclosed as **not a physical aftershock model**
- C_F2 is supported against **B0, B1, and B4**, but rejected at admission
- C_F2 “best” language is scoped to admissible baselines B0–B5; no contradictory “every reported score” wording remains
- Candidates receive harness-extracted allowlisted columns; pretrained or externally parameterized artifacts are expressly outside the name-level audit
- The admission-audit sentence occurs once
- No `v1.1.1` literal is hardcoded in `validate_cbs.py`
- Figure 1 renders “F1 to F6,” not a literal `F1--F6`
- Table S1 renders true minus signs
- The reviewer package passed the identity-token scan; identities are confined to the excluded title page

## Findings

### R11-F1 — Minor, self-description: claim-ledger completeness is overstated

Evidence:

- `generate_ledgers.py` says `claim_ledger.jsonl` maps “every load-bearing number in the paper.”
- Supplementary Table S6 prints the 86-cluster B1–B4 p=0.0138 result and states that the 54- and 43-cluster partitions keep seven rejections.
- `claim_ledger.jsonl` has no entry naming `synthetic_larger_cluster_sensitivity`, 0.0138, 99,999, or the 86/54/43-cluster results.
- `validate_cbs.py` proves that existing pointers resolve and that the robustness key exists, but it does not test ledger completeness for these printed values.
- All 161 existing resolvable pointers are valid. This is a coverage defect, not a bad-pointer or numeric defect.

Required change: add ledger records for `/variance_estimator_sensitivity/wild_draws`, the printed B1–B4 variance-estimator row, and `/synthetic_larger_cluster_sensitivity/cells/86_clusters`, `/54_clusters`, and `/43_clusters`, with a completeness check; alternatively narrow the exhaustive-coverage comments.

This is fixable in the current study and requires no new data.

### R11-F2 — Minor, presentation: Figure 3 annotations remain crowded

Evidence:

- In `figures/fig_threshold_slice.png` and rendered main PDF page 16, the 6.0-cutoff Brier label 0.181 and prevalence label 0.351 overlap visually.
- The 6.5-cutoff labels compete with the legend and right plot boundary at manuscript scale.
- The values match Supplementary Table S4, so this is not a numeric error.

Required change: use fixed annotation lanes or offsets, move the legend outside panel (a), and inspect the final PDF at printed scale.

This is fixable in the current study and requires no new data.

### R11-F3 — Minor, evidence: nearest-work attribution should be separated

The manuscript states: “Dror et al. and Bouthillier et al. treat whether a reported gain is real, including training-run variance that this study excludes by freezing fits.”

Dror et al. explicitly contributes a significance-test-selection protocol and survey of misuse. Bouthillier et al. directly studies data, initialization, and hyperparameter variance. The combined wording can attribute training-run variance to both.

Required change: split the sentence, assigning test selection to Dror et al. and training/HPO variance to Bouthillier et al., then state that the present fixed-fit estimand excludes the latter.

Both citations are real and relevant. This is fixable in the current study and requires no new data.

## Limitations requiring new data or experiments

- **Fresh hidden evaluation:** confirmatory use for future candidates requires a fresh hidden holdout or independent evaluation service. This requires new data/evaluation infrastructure and is already disclosed.
- **Cross-catalogue transfer:** evidence beyond this DYFI catalogue requires a second catalogue or study. The current manuscript does not overclaim transfer.
- **Training/HPO variance:** repeated refits would require new experiments, but not new data. The current claims are explicitly conditional on frozen fits, so this is a limitation rather than a correctness defect.
- **Physical aftershock independence:** validating the grouping as physical aftershock structure would require a stronger external catalogue or model. The paper correctly calls the current grouping heuristic and the synthetic clustering non-physical.

## Required changes, ranked

1. Complete the claim ledger for printed robustness values or narrow the exhaustive-coverage assertion.
2. Repair Figure 3 panel (a) annotation collisions at rendered scale.
3. Separate the Dror and Bouthillier attribution sentence.

Finding tally: result **0**, evidence **1**, presentation **1**, self-description **1**.
