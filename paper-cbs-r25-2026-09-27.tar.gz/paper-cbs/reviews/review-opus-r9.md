# Independent default-reject review, round 9 (Claude Opus)

**Manuscript:** *A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study*
**Venue:** Cybernetics and Systems (Taylor & Francis)
**Date:** 2026-09-26. Reviews from earlier rounds were not read.

## Verdict

**Total 21/30. No vetoes. Recommendation: major revision.** Under the default-reject stance, the manuscript is not acceptable as submitted. The statistical and numeric defects checked this round are fixed and reproduce exactly. What remains is (a) a novelty and usefulness ceiling that can only be raised with new data, and (b) a small set of calibration and presentation inconsistencies that can be fixed in this study.

| Criterion | Score |
|---|---|
| cbs_venue_fit | 2 |
| novelty | 1 |
| soundness | 2 |
| numeric_integrity | 3 |
| claim_calibration | 2 |
| editor_page_1 | 2 |
| reproducibility | 3 |
| related_work_citations | 2 |
| formatting_blinding | 2 |
| usefulness | 2 |
| **Total** | **21** |

Vetoes (fabricated_citation, numeric_mismatch, blinding_breach, clearly_out_of_scope, unsupported_overclaim): **none triggered**.

## Integrity and reproduction

- All five SHA-256 hashes match (main.pdf, main.tex, supplement.pdf, supplement.tex, references.bib).
- I backed up `frozen_inputs/*.json`, hashed all 81 non-review files, and ran `family_wise_sensitivity.py`, `seeded_candidate_demo.py` and `robustness_post_hoc.py` with `/tmp/dyfi-analytics-venv/bin/python`. **All three output JSONs were byte-identical to the frozen copies**, and the post-run hash diff of all 81 files was empty.
- Extra probe (in memory only, no file written): I reran the 10° wild-cluster B1–B4 p-value with 20 alternative seeds at 9,999 draws. It ranged from 0.0114 to 0.0154, and 5 of 20 seeds (25%) give p ≤ 0.0125, which would mean rejection.

## Verification of the requested checks

**1. Cluster-robust paired Brier test with Holm control: verified.** The Section 4.4 formula matches `cluster_robust_p` in `robustness_post_hoc.py`: d_ig, θ̂, U_g = Σ_i(d_ig − θ̂), SE = {G/(G−1) Σ U_g²}^{1/2}/N, and a t(G−1) reference. I recomputed the Holm ordering:

- five pairs have p < 1e-4;
- B1–B5: p = 0.00314 against a threshold of 0.01;
- B1–B4: p = 0.010855 against a threshold of 0.0125;
- B4–B5: p = 0.0350 against a threshold of 0.0167, where the procedure stops.

That gives seven rejections. Six Bonferroni 99.5% t intervals exclude zero. The B1–B4 simultaneous interval is [−0.0012, 0.0243]. B2–B4 (0.0485), B2–B5 (0.8269) and B4–B5 (0.0350) remain unresolved. Holm [33] and Diebold–Mariano [34] are cited.

**2. Dependence checks: verified, with one caveat.**
- Cluster structure: 354 clusters, 312 singletons, largest cluster 16, G/(G−1) = 1.00283.
- Default-sequence B1–B4 p-values: CR1 0.010855, CR3 0.010891, wild 0.0096, event-level 0.009219. All four give seven decisions.
- Regional re-clustering: 5° cells give 140 clusters and 10° cells give 82. The CR1 B1–B4 p-value is 0.0115 in both. The 5° wild p-value is 0.0093 (seven decisions). The 10° wild p-value is 0.013, which gives six decisions.
- Sequence windows: 50 km gives 375 clusters and 200 km gives 295, each with seven decisions.

All of these match the text and Table S6. **Caveat (F2):** the one six-decision column rests on a Monte Carlo p-value that changes with the seed.

On whether B1–B4 is described consistently, it is called marginal everywhere. However, the clustering qualifier appears only in Section 5.5, the Table 4 note and the overlay. It is missing from the abstract ("marginal and family-dependent"), the contributions, the conclusion ("marginally and family-dependently") and the Table 4 row ("(B1 marginal, family-dependent)") (F3).

**3. Supplementary tables: mostly verified.**
- Table S6 matches the JSON: B1–B4 is rejected in 11 of 13 columns, and the column totals are 7, except 6 for the 10° wild column and the 15-pair column.
- The Table S1 note defines P(A better) as "the descriptive share of bootstrap replicates … not a p-value". It also explains why the B2–B4 percentile interval and the test disagree.
- Table S1 p-values use 4 decimals, but Section 4.4 prints "unadjusted p = 0.049" (F4).

**4. Textual fixes: verified.**
- Table 1 now reads "Cluster-robust paired test + Holm control".
- The Discussion's "four decisions differ" list now covers CF2, B3, B2–B5 and B4–B5.
- The Demšar/Benavoli sentence now describes the cluster-robust test under Holm.
- The duplicated venue description has been removed from the Introduction.
- evalci is engaged accurately. I checked the preprint: it packages paired tests, `cluster_ci` and `multi_compare(correction="holm")`. The manuscript states the remaining difference without strengthening its novelty claim.

**5. Seeded family: verified.**
- CF2 scores: Brier 0.172390, AUROC 0.809276, log-loss 0.515322.
- In the 15-pair family, CF2 is Holm-supported only against B0, B1 and B4, and B1–B4 becomes unresolved.
- The demonstration is framed "by construction". The version-bump procedure is explicitly "not evaluated here".

**6. Abstract: passes, but the length is borderline.** It states the admit/reject output and the supported/unresolved labels, says the analysis is post hoc and single-catalogue, and fits entirely on page 1. The word count is about 195 from the rendered text, but the project's own validator reports 211 (F6).

**7. Formatting: mostly clean.**
- `main.log` has no Overfull boxes.
- Table S1 is no longer shrunk by `resizebox`.
- In Figure 4 the labels sit outside the axes, clear of the B0 line.
- Table S2 is single-spaced and repeats its header.
- Remaining issues: justified narrow cells in Table 1 leave stretched gaps between words, Table 4 uses ASCII hyphens for negative numbers, and the Table S2 caption is narrower than the table (F7).

**8. Other checks.**
- Cohort arithmetic, prevalences, B0 and oracle Brier scores, the construction no-skill score and the split-contrast intervals all recompute correctly.
- Holm (JSTOR 4615733), Diebold–Mariano (Crossref) and evalci (arXiv 2607.04429) exist and are cited accurately.
- The manuscript PDFs, including their metadata, are blinded.
- The overlay supersedes the legacy wording and keys without changing any number.
- The distinction between release tag v1.1.1 and the review archive is clear.
- There is no universal or task-agnostic recommendation.

## Findings

**F1 (major; needs new data): novelty and usefulness ceiling.** The paper itself says "Those pieces are established separately … Reuse on other catalogues is untested." evalci already packages paired tests, cluster intervals and all-pair Holm correction. The endpoint is essentially magnitude thresholding (magnitude-only AUROC 0.719), and the demonstration that the contract reverses a score-based conclusion holds by construction. Raising this ceiling needs a second, non-seismic dependent-event dataset or a prospective hidden-holdout run.

**F2 (minor; fixable): Monte Carlo fragility of the 10° wild-cluster decision.** The recorded p is 0.013 from 9,999 draws, with a Monte Carlo standard error of about 0.0011. Across 20 alternative seeds, 25% reject. The text presents "p = 0.0130 … leaving six decisions" as a fixed result. Report the Monte Carlo standard error or use at least 99,999 draws, and call this column borderline.

**F3 (minor; fixable): the B1–B4 qualifier differs by location.** Adopt one phrase everywhere: the abstract, contributions, the Table 4 row and the conclusion.

**F4 (minor; fixable):** Change "p = 0.049" to 0.0485 in Section 4.4 (main.tex line 456).

**F5 (minor; fixable):** Section 5.5 lists four p-values after naming three methods; the first is the default CR1 value. Label each one.

**F6 (minor; fixable):** The abstract is 211 words by the project's validator. Trim 15–20 words so every counting method gives ≤ 200.

**F7 (minor; fixable):** Typography: make the Table 1 columns ragged-right, use proper minus signs in Table 4, and match the Table S2 caption width to the table.

**F8 (minor; fixable):** References [38] and [39] print without DOIs, even though `references.bib` and the Declarations contain them. Add `url` fields or change the bibliography style.

**F9 (minor; fixable blinding risk):** `build_ledger.json` contains the GitHub handle. Keep it, and the `title_page.*` files, out of the anonymized review archive.

**F10 (minor; fixable):** Table 4 says "best on every score" and the contributions say "wins on every holdout score", but only Brier, AUROC and log-loss were computed for CF2. Say "best Brier, AUROC and log-loss".

## Top required changes

1. Harmonize the B1–B4 qualifier across the abstract, contributions, Table 4 row and conclusion.
2. Report Monte Carlo uncertainty for the 10° wild-cluster p-value (or increase the draws) and describe that column as borderline.
3. Print p = 0.0485 in Section 4.4 and label the four p-values in Section 5.5.
4. Trim the abstract to ≤ 200 words by every counting method.
5. Make the typography fixes, add the DOIs for [38] and [39], and exclude `build_ledger.json` from the anonymized archive.

## Limitations that need new data (cannot be fixed by editing)

- Generalization beyond one magnitude-dominated seismic corpus.
- Confirmatory, pre-specified inference on a fresh hidden holdout.
- Empirical evaluation of the schema-extension workflow, and of any value beyond a by-construction allowlist.
