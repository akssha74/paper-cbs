# Independent default-reject review, round 8 (Claude Opus 5.5)

**Venue:** Cybernetics and Systems (Taylor & Francis)
**Manuscript:** "A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study"
**Verdict:** Major revision. On a default-reject stance it is not acceptable as submitted, but no veto is triggered.
**Total:** 21 / 30

## Integrity checks

- **Hashes.** SHA-256 matches for `main.pdf` (36d4dd33…), `main.tex` (485f0bd0…), and `supplement.pdf` (bbecffb6…). `supplement.tex` and `references.bib` match `build_ledger.json`.
- **Reproduction.** I ran `family_wise_sensitivity.py`, `seeded_candidate_demo.py`, and `robustness_post_hoc.py` with `/tmp/dyfi-analytics-venv/bin/python` and `PYTHONDONTWRITEBYTECODE=1`, after backing up the outputs. All three regenerated JSONs are byte-identical to `frozen_inputs/`, so no scientific file was changed.
- **Independent inference check.** I recomputed the tests myself: G = 354, of which 312 clusters are singletons and the largest has 16 events.

| Pair | CR1 t(353) p | Jackknife (CR3) p | Wild-cluster bootstrap-t p | Largest single-cluster share of ΣU² |
|---|---|---|---|---|
| B1–B4 | 0.01086 | 0.01089 | 0.0102 | 0.071 |
| B4–B5 | 0.03496 | 0.0352 | 0.035 | 0.077 |
| B2–B4 | 0.04852 | 0.0488 | 0.0468 | 0.103 |

  The large-G approximation is not driving any decision.
- **Claim ledger.** All 159 entries reconcile with the PDF text; the only unmatched values are non-printing flags.
- **Blinding.** There are no author, institution, or repository strings in `main.tex`, `supplement.tex`, the tables, the PDF text, or the PDF metadata.

## Scores

| Criterion | Score |
|---|---|
| cbs_venue_fit | 2 |
| novelty | 1 |
| soundness | 2 |
| numeric_integrity | 3 |
| claim_calibration | 2 |
| editor_page_1 | 2 |
| reproducibility | 3 |
| related_work_citations | 2 |
| formatting_blinding | 2 |
| usefulness | 2 |
| **Total** | **21 / 30** |

**Vetoes:** fabricated_citation no; numeric_mismatch no; blinding_breach no; clearly_out_of_scope no; unsupported_overclaim no.

## Requested checks

1. **Cluster-robust paired Brier inference: pass, and the prior concern is resolved.**
   - The formula in Section 4.4 matches `cluster_robust_paired_brier()` exactly: d_ig, U_g = Σ_i(d_ig − θ̂), SE = {G/(G−1) Σ U_g²}^{1/2}/N, t(G−1), G = 354. The assumptions (independent sequences, large G) are stated and cited to Cameron and Miller.
   - Holm rejects seven pairs. The four B0 pairs and B1–B2 all have p < 1e−5, B1–B5 has p = 0.00314 against a threshold of 0.01, and B1–B4 has p = 0.010855 against 0.0125. The procedure stops at B4–B5 (p = 0.03496 against 0.01667).
   - Six Bonferroni 99.5% t intervals exclude zero; the B1–B4 interval [−0.0012, 0.0243] does not.
   - B2–B4 (p = 0.049), B2–B5 (p = 0.827), and B4–B5 remain unresolved.
   - The legacy tail fraction is kept only as `bootstrap_tail_area_p_descriptive`, and the text says explicitly that it is not a null distribution.

2. **Descriptive status of the bootstrap outputs: partial.**
   - The percentile intervals are labelled descriptive in Table 4 and Table S1.
   - The Table S1 column **P(A better)** is never defined. For B4–B5 it prints 0.017 beside a cluster-robust p of 0.035, so readers could mistake it for a p-value (F4).

3. **Robustness families: pass.** The 50 km/15 d (375 clusters), 100 km/30 d (354), and 200 km/60 d (295) windows, the seven-pair reference family, the log-loss family, and the AUROC family all reject the same seven pairs. AUROC is labelled exploratory and null-centred in the code, the main text, and Table S2.

4. **Seeded family: pass, with a minor issue.**
   - In the 15-pair family, C_F2 is Holm-supported only against B0, B1, and B4, and B1–B4 becomes unresolved; the other nine admissible decisions are unchanged.
   - The text frames this as a fixed-allowlist policy illustration that holds by construction.
   - Table 4 mixes the two families without saying so (F3).

5. **Schema-extension workflow: pass.** The steps are concrete, and the Limitations say the procedure "was not evaluated here".

6. **Abstract: pass, with a minor issue.**
   - It sits fully on page 1 with the keywords, is 217 words by the validator's count, and says explicitly that the analysis is post hoc and single-corpus.
   - It states B4 over B1 without flagging that the result is marginal and family-dependent (F1).
   - "every learned candidate" should read "every admissible learned candidate", since B3 was never scored.

7. **Supplement: pass, with cosmetic issues.**
   - The Table S2 longtable repeats its header on pages 3 and 4, and all 12 rows are present.
   - The Table S5 note now agrees with Section 5.3.
   - Table S1 prints the Bonferroni t intervals and the cluster-robust p-values.
   - There are no overfull boxes. Table S1 is shrunk by `\resizebox`, and in Fig. 4 the value labels sit on the dashed B0 line (F8).

8. **Specific wording and provenance items: pass.**
   - **Knap et al.:** the article PDF says "three seeds, {41, 42, 43}" and "mean ± standard deviation over three seeds", so the manuscript's description is accurate.
   - **Event-grouped difference:** the manuscript's −0.0040 [−0.0097, 0.0023] matches −0.003959 [−0.009724, 0.002289] in the JSON.
   - **Release versus archive:** the manuscript and the title page are consistent.
   - **Patelli correction:** it resolves on nature.com (Sci Rep 16, 9208).
   - **Interpretation overlay:** it supersedes all stale strings without changing any number.
   - **Arithmetic:** the spot checks reproduce B0 Brier 0.232, the oracle constant 0.228, construction no-skill 0.204, 1.26 events per sequence, and 1,885 sequences.

9. **No universal or task-agnostic recommendation: pass.** Section 6 calls reuse on other tasks "a design proposal, not an empirical generalization".

## Findings (all minor and fixable in this study)

- **F1 — B4 over B1 is overstated.** The abstract, Section 1.1, and the Conclusion state it with the same weight as the robust labels. It is marginal (p = 0.0109 against a threshold of 0.0125; the Bonferroni interval includes zero) and lost in the 15-pair family. Qualify it, and write "admissible learned".
- **F2 — the Discussion's "four decisions differ" list is wrong in one item.** Its fourth item compares two Holm families rather than comparing the contract with point-score or unadjusted reporting. Replace it with B4–B5, which flips from supported to unresolved (Section 5.5, line 393).
- **F3 — Table 4 mixes the ten-pair and 15-pair families.** Add a note: "Admissible decisions use the ten-pair family; in the 15-pair seeded family B1–B4 is unresolved."
- **F4 — P(A better) is undefined in Table S1.** Define it as the descriptive share of bootstrap replicates in which A has lower Brier, and say it is not a p-value.
- **F5 — the Holm procedure is uncited.** Holm (1979) carries the decision rule but is not in the references. Add it, and optionally Diebold and Mariano (1995) as the paired loss-differential precedent.
- **F6 — a Section 2 sentence predates the new rule.** Lines 129–130 still describe the decision as a "paired sequence-cluster Brier interval". Update it to the cluster-robust paired test under Holm.
- **F7 — the two procedures can disagree near 0.05, and the paper does not say so.** For B2–B4 the percentile interval includes zero while the unadjusted cluster-robust p is 0.0485. Add one sentence: only the test decides, and a label's direction comes from the sign of θ̂.
- **F8 — cosmetic legibility.** Table S1 is shrunk by `\resizebox`, the notes of Table S1 and Table 4 are centred, the Fig. 4 labels overlap the dashed B0 line, and Table S2 is double-spaced over three pages.
- **F9 — the sensitivity families are visible only in JSON.** Add a compact supplementary table with ten pairs against six families, marked reject or not reject.
- **F10 — the abstract is dense.** Check the CBS word limit (I could not confirm it online; many T&F journals use 200 words). Trim one number and state the admit/reject and supported/unresolved output in plain words.
- **F11 — duplicate descriptions.** References [1] and [2] are described in both Section 1 and Section 2; keep one.

## Limitations (not defects of this revision)

- **L1 — needs new data.** One corpus, a magnitude-dominated endpoint, and an illustration that holds by construction keep the novelty incremental. Closing this gap needs a second catalogue or a fresh hidden holdout.
- **L2 — feasible with existing data, but it would add post-hoc refits.** The inference conditions on fixed fits, so the labels do not cover training or seed variability. An optional, disclosed repeated-seed refit of B4 and B5 on the construction data would address this.
- **L3 — partly addressable.** Independence across sequences is assumed. A region-block cluster sensitivity (for example, 10° cells) is feasible with the current data.

## Top required changes

1. Qualify B4 over B1 as marginal and family-dependent in the abstract, contributions, and conclusion, and add the family note to Table 4 (F1, F3).
2. Correct the Discussion's list of decisions that differ (F2).
3. Define P(A better) as descriptive, and state that only the cluster-robust tests decide (F4, F7).
4. Cite Holm (1979), and fix the stale Demšar/Benavoli sentence (F5, F6).
5. Add a sensitivity-family table and fix the table and figure legibility (F8, F9), and check the abstract limit (F10).

**Convergence:** The blocking concern from earlier rounds, the invalid ordinary-bootstrap-tail p-values, is resolved. No new blocking defect was found. Every remaining fixable item is wording, labelling, or citation, and none touches a number.
