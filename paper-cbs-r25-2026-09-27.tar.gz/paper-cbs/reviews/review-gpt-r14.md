# Independent default-reject review — GPT-5.6, round 14

## Verdict

**Reject and resubmit: 27/30; no veto triggered.**

The manuscript is in scope, unusually transparent, numerically consistent, reproducible from the supplied review bundle, well cited, correctly blinded, and easy to understand from page 1. The remaining ceiling is evidentiary: the decision-bearing Holm family was defined after the public holdout was opened, and the Italian transfer stopped at an evaluability refusal before candidate grids, fitting, scoring, or Holm tests. The current evidence supports a careful retrospective case study, but not yet a fully validated transferable qualification contract.

## Scores

- `cbs_venue_fit`: **3/3**
- `novelty`: **2/3**
- `soundness`: **2/3**
- `numeric_integrity`: **3/3**
- `claim_calibration`: **3/3**
- `editor_page_1`: **3/3**
- `reproducibility`: **3/3**
- `related_work_citations`: **3/3**
- `formatting_blinding`: **3/3**
- `usefulness`: **2/3**

**Total: 27/30.**

## Vetoes

- `fabricated_citation`: **false**
- `numeric_mismatch`: **false**
- `blinding_breach`: **false**
- `clearly_out_of_scope`: **false**
- `unsupported_overclaim`: **false**

## Goal and usefulness

The goal is clear: determine whether a fixed-schema candidate should be admitted and whether its apparent gain remains supportable after controlling catalogue version, role assignment, temporal evaluation, dependence, and multiplicity.

The intended users—applied-ML engineers, benchmark maintainers, and reviewers—are stated before the methods. The enabled decisions are also explicit: admit/reject a candidate and label each improvement supported/unresolved. The substantive demonstration is that a response-count candidate leads the admissible baselines on point Brier, AUROC, and log-loss yet is rejected before those scores are used; the closest admissible learned candidates are not declared a unique winner. The non-use boundary is visible: this is not operational, causal, real-time, or confirmatory.

`goal_understood: true`  
`usefulness_understood: true`  
`abstract_story_pass: true`

## Verification summary

All requested SHA-256 values match:

- `main.pdf`: `f1d9be042abfe9204620b8fbc6e41e713abf21823cb98c88ac245f7dc7bd913f`
- `main.tex`: `be7753c8cf316f5e100614f76633c893fe8ebf49d3465bd137fae6974861d3ef`
- `supplement.pdf`: `05dbba6768af9286a114332d81197d2ed1149970194efed518225154013e514e`
- `supplement.tex`: `0f2b5efe4b257ad8889cdb60bc421076b81be18a0e02ac1bbea8e91ac87be395`
- `references.bib`: `3198df70917a445cc6a14d9aa834f21f694b862efc6c61bc490faab745f8558f`
- `build_ledger.json`: `00f54c651ad68f1bb1b99f01e8be1d0772c1217d20ebf4b3a65c6b6716056986`
- `frozen_inputs/contract_transfer_dbmi.json`: `5e76d7b35c09f2efe9dbbff69d1675ffd4f16a7f4783455fcc2d10cc2651a002`

The main PDF has 32 pages; the supplement has eight. All fonts are embedded. All five PNG figures were inspected and are legible, unclipped, consistently labelled, and concordant with their captions and tables. The main manuscript is double-anonymous; the separate title page is not a reviewer-facing identity leak.

`cbs_validation_report.json` records 57/57 checks passing. I inspected the validator but did not rerun it because it writes the frozen report. I did not run `build.sh`.

Independent read-only checks passed:

- \(1573+357+430+2=2362\).
- \(449+102+151+1=703\).
- \(703/2362=0.2976\), reported as 0.298.
- \(151/430=0.3512\), reported as 0.351.
- The holdout-prevalence constant has Brier \(p(1-p)=0.2279\), reported as 0.228.
- \(2756/3138=87.8\%\).
- The purely macroseismic count is \(1985+186+13+1=2185\); the 571 mixed `Wmim` events are correctly excluded from the \(\rho=0.755\) subgroup.
- \(\lfloor0.2\times382\rfloor=76<100\), so the transfer refusal was guaranteed by the observed cohort and the two frozen cutoffs.
- Holm step-down recomputes seven rejections from the ten stored p-values.
- Every stored admissible Brier pair difference equals the corresponding difference of stored baseline Brier scores.
- The frozen transfer copy is byte-identical to `results/results.json`.
- Transfer result, runner, analysis-plan, and frozen-design hashes match `results/hash_manifest.json`.

The transfer execution path is described correctly: unchanged `leakage_audit` and `decluster` ran; candidate grids, fitting, scoring, the B2 self-comparison, threshold rescoring, CR1, and Holm were not reached. The provenance filter and 100-event floor are attributed to the transfer plan and a proposed later contract version, not to version 1. Both the DYFI protocol and transfer are called internally frozen rather than externally preregistered.

The S2 transfer evidence is present: raw `IoDef` is rejected as non-allowlisted, and its declared mapping to `intensity` is rejected as F1.

## Major findings

### F1 — The comparison decisions remain post-hoc on an opened holdout

**Touches:** evidence

The abstract correctly says: “Multiplicity control is post hoc; the study is not operational, and confirmation requires fresh hidden data.” Section 5.5 further states that the Holm family was declared after the holdout was opened and that the labels are post-hoc rather than confirmatory. Supplementary Table S2 records the same chronology.

This disclosure prevents an overclaim veto, but it caps soundness at 2/3. The central supported/unresolved layer has not been prospectively tested on fresh protected outcomes.

**Required action:** predeclare the candidates, primary metric, dependence unit, complete family, and decision rule before opening a fresh hidden holdout; then report the run without outcome-conditioned changes.

### F2 — The second catalogue does not exercise the paired-decision layer

**Touches:** evidence

Section 5.7 says: “Candidate grids and Holm tests were not reached.” The frozen transfer result records 382 instrumental events, a 70-event holdout, and `evaluable=false`. Under the frozen 20% cap, at most 76 events could enter the holdout, below the 100-event floor.

The refusal is valid and useful as a negative case. It verifies field admission, provenance screening, declustering, and the evaluability gate. It does not verify transfer of fitting, scoring, uncertainty, multiplicity control, or final candidate decisions.

**Required action:** preserve this refusal, but run the unchanged end-to-end contract on an independent catalogue large enough to reach the complete ten-pair Holm family.

### F3 — The demonstrated utility is primarily constructed

**Touches:** evidence

The response-count candidate is deliberately outside the two-field allowlist and is scored after rejection. The manuscript correctly says the contrast “holds by construction” and is a policy illustration rather than contamination detection. The independent transfer then refuses before any candidate is qualified.

This is an effective explanation of the mechanism, but it does not yet show that an independent user applying the contract to a realistic new candidate avoids an otherwise credible erroneous adoption decision.

**Required action:** add a non-seeded, independently sourced candidate or historical benchmark claim and run the full admit/reject plus supported/unresolved workflow, including the user decision changed and the error prevented.

## Novelty

**Class: incremental.**

The contribution combines established mechanisms:

- NeMo Evaluator already uses paired per-item deltas, confidence intervals, thresholds, and fail-closed verdicts.
- TFX Evaluator plus TFDV/TFMA already covers schema validation, candidate-versus-baseline thresholds, slices, blessing, and uncertainty options.
- `evalci` already supplies paired tests, cluster bootstrap intervals, and all-pair Holm correction.
- Schelter, Guha, and Grafberger already screen native ML pipelines for train-test leakage using record-level provenance.

The manuscript differentiates these neighbours accurately: none of the cited systems alone implements this exact catalogue-specific field/role admission plus paired dependence-aware Holm contract. However, the present evidence does not yet establish a beyond-incremental capability on an independent end-to-end task. The seeded reversal is constructed, and the second catalogue stops before the comparison layer.

## Citations and availability

The Schelter/Guha/Grafberger citation accurately supports record-level provenance screening of native ML pipelines for train-test leakage. The official TFX Evaluator documentation supports the claim that a candidate is compared with a baseline and blessed when configured absolute and/or relative metric thresholds pass. The descriptions of NeMo Evaluator and `evalci` are also accurate.

Nine plain URLs and 47 DOI strings were probed. All are valid after resolving `10.5066/P143CZ3R` through DataCite and USGS. A Crossref-only fallback incorrectly marked that valid USGS DOI as unregistered; the DOI resolves to the cited 2026 USGS data release with matching title and authors. Fourteen publisher endpoints blocked automated access but were registered, which is not a manuscript defect.

No fabricated citation was found.

## Strengths

- Exact source/PDF/build/transfer pins.
- No numeric mismatch across abstract, prose, tables, figures, ledgers, frozen inputs, and transfer artifacts.
- Correct binding of \(\rho=0.755\) to 2,185 purely macroseismic events rather than 2,756.
- Correct disclosure of the guaranteed 76-event maximum and 70-event realized transfer holdout.
- Correct separation of executed and skipped transfer paths.
- Strong claim calibration: no winner, equivalence, operational, causal, geographic-transfer, or confirmatory claim is made.
- Result-first abstract followed by the post-hoc and non-use caveats.
- Strong engagement with nearest statistical, provenance, quality-gate, benchmark-audit, domain, and target-journal work.
- Clean 32-page blinded manuscript and eight-page supplement with readable figures and embedded fonts.

## Changes required to raise each sub-3 criterion to 3

### `novelty`: 2 → 3

Complete a prospectively frozen, independent end-to-end transfer and compare the resulting decisions directly with NeMo Evaluator, TFX/TFDV/TFMA, `evalci`, and provenance-screening alternatives on the same candidates. A score of 3 requires evidence that the integrated contract changes a defensible decision for a reason the nearest alternatives do not capture. This requires new data or a new study.

### `soundness`: 2 → 3

Run the complete predeclared rule once on fresh hidden outcomes, with the comparison family and dependence unit fixed before scoring. Required evidence is a timestamped plan, immutable candidate/family definitions, an evaluable holdout, and complete CR1/Holm outputs. This requires new hidden data or an independent evaluation service.

### `usefulness`: 2 → 3

Add a realistic, independently sourced candidate that traverses admission, scoring, paired inference, and final decision. Quantify the erroneous adoption/audit decision or wasted evaluation prevented. This requires a new empirical demonstration.

## Finding tally and convergence

- `result`: 0
- `evidence`: 3
- `presentation`: 0
- `self-description`: 0

The review has no open result mismatch and no veto. It has not converged because three evidence limitations remain. Further polishing of the frozen manuscript will not close them; fresh prospective evidence is required.
