# Review GLM-R14 — Independent Default-Reject Review

**Manuscript:** A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study
**Target venue:** *Cybernetics and Systems: An International Journal* (Taylor & Francis)
**Reviewer:** GLM-5.2 (independent default-reject reviewer)
**Round:** 14 · **Date (UTC):** 2026-09-27
**Base:** `studies/dyfi-benchmark-reliability/research/benchmark-resource/manuscript/paper-cbs`

## Instruction compliance

- Did not edit the manuscript or any other study.
- Did not read earlier-round reviews.
- Did not run `build.sh`.
- `title_page.tex` treated as **not** a blinding leak (per instructions); identities are isolated there.
- Reviewed `integrated-studies/contract-transfer-dbmi/` (prereg, code, results).

## SHA-256 verification (all verified)

| File | Claimed | Verified |
|---|---|---|
| `main.pdf` | f1d9be04…913f | ✅ |
| `main.tex` | be7753c8…d3ef | ✅ |
| `supplement.pdf` | 05dbba67…514e | ✅ |
| `supplement.tex` | 0f2b5efe…e395 | ✅ |
| `references.bib` | 3198df70…558f | ✅ |
| `build_ledger.json` | 00f54c65…6986 | ✅ |
| `frozen_inputs/contract_transfer_dbmi.json` | 5e76d7b3…a002 | ✅ |

## Required fact checks

- **Spearman n=2185** ✅ — `contract_transfer_dbmi.json`: `n_macroseismic=2185`, `spearman_mw_imax_macroseismic=0.7554` (paper reports 0.755); instrumental `n=382`, ρ=0.300.
- **Guaranteed refusal 76<100** ✅ — `cohort.evaluable=false`; `n_instrumental_labelled=382`; `floor(0.2×382)=76 < 100`-event floor; holdout realized at 70 events. Refusal was guaranteed by design arithmetic; nothing was fitted, scored, or tested.
- **Executed-path honesty** ✅ — Manuscript explicitly discloses: unexecuted geographic leave-region-out branch; unexecuted aggregation-grid sensitivity; post-hoc (unfulfilled) split-contrast interval; post-hoc B2-vs-B0; post-hoc Holm family declared after the holdout was opened; transfer "nothing was fitted, scored, or tested." Deviations recorded in Supplementary Table S2.
- **Plan-level provenance** ✅ — `integrated-studies/contract-transfer-dbmi/prereg/` contains `analysis_plan.md` and `frozen_design.json`, hashed into `prereg_hashes.json` (`frozen_at 2026-09-26T18:16:51Z`) **before** `run_transfer.py`. `RESULTS.md` confirms a single run under that preregistration; the only pre-run code change was an import-path fix.
- **32 pages** ✅ — `pdfinfo main.pdf` → Pages: 32 (supplement 8, title page 3).
- **57/57** ✅ — `cbs_validation_report.json`: `n_checks=57, n_failed=0, overall_pass=true`.

## Scores (10 criteria, 0–3 each)

| Criterion | Score |
|---|---|
| cbs_venue_fit | 3 |
| novelty | 2 |
| soundness | 2 |
| numeric_integrity | 3 |
| claim_calibration | 3 |
| editor_page_1 | 3 |
| reproducibility | 3 |
| related_work_citations | 3 |
| formatting_blinding | 3 |
| usefulness | 2 |
| **Total** | **27 / 30** |

## Vetoes

| Veto | Triggered | Note |
|---|---|---|
| fabricated_citation | No | All 59 bib entries are cited in `main.tex` (4 only *appeared* uncited because a multi-key `\citep{...}` spans two source lines; direct grep confirms each is cited once). `all_citations_resolve` and `all_bibliography_entries_cited` checks pass. |
| numeric_mismatch | No | Cohort `703=449+102+151+1`; partition `1573+357+430+2=2362`; construction `1930/551/1530`; holdout `430/151/354`; baseline Brier/AUROC/calibration pairs match `tab:baselines`; pairwise deltas and Holm p-values match `tab:pairwise`; transfer `2756=1985+571+200`, `2185=1985+186+13+1`, `87.8%=2756/3138`, `floor(0.2×382)=76`. The two B4–B5 intervals (percentile `[0.0003,0.0099]` vs Bonferroni 99.5% t `[-0.0018,0.0122]`) are explicitly different procedures, both include zero → unresolved; not a mismatch. |
| blinding_breach | No | `main.tex` author block is "Blinded for Anonymous Peer Review"; identities, affiliations, email, GitHub URL, and CRediT roles are isolated on `title_page.tex` (treated as non-leak per instructions). Validation confirms `main_text_blinded`, `title_page_carries_identities`, `reviewer_package_anonymous`. |
| clearly_out_of_scope | No | Applied-AI evaluation reliability / decision-support comparison harness; target is *Cybernetics and Systems* (Applied AI/ML, Decision Making, Cybernetics in Environmental Systems). 5 in-venue precedents engaged. |
| unsupported_overclaim | No | Repeated explicit refusals to overclaim: "no winning model", "not confirmatory", "not operational", "policy illustration, not contamination detection", "design proposal, not empirical generalization", "unresolved is not equivalence." Claims match evidence. |

## Per-criterion rationale

**cbs_venue_fit (3).** Decision-support test harness for retrospective model comparison; explicitly targets *Cybernetics and Systems*; engages 5 in-venue precedents (`praveena2025retail`, `sag2025optimization`, `gao2026msbnet`, `hossack2004dst`, `gomolka2000environmental`) and frames the delta against them. `venue_precedents_complete=5` and `cbs_precedents_engaged` checks pass.

**novelty (2).** Honest but bounded. The paper itself states schema allowlisting and version pinning are standard and that the pieces are established separately; the released delta is the fail-closed combination on one DYFI corpus. The most novel design insight — binding admitted field names to provenance (not just names), so an outcome-derived magnitude is not admitted under an allowlisted name — is empirically motivated by the 87.8% macroseismic-derived finding but is offered as a design proposal for a later contract version, not as a field of the released allowlist. Defensible-beyond-incremental, not clearly novel.

**soundness (2).** Methodologically careful but with two structural caveats that are disclosed but not resolved. (1) The headline multiplicity control (Holm over the 10-pair family) was declared after the holdout was opened, so the supported/unresolved labels are post-hoc, not confirmatory. (2) The sequence-cluster-robust variance is barely exercised: 312/354 holdout sequences are singletons, `G/(G-1)=1.003`, and the default-sequence test differs little from an event-level paired t; the dependence-aware framing is largely defensive on this corpus. The transfer (second-catalogue generalization) refused by design arithmetic, so the paired-decision layer is exercised on exactly one catalogue.

**numeric_integrity (3).** Cross-checked abstract, body, and generated tables; all reconcile. Cohort `703=449+102+151+1`; partition `1573+357+430+2=2362`; construction `1930/551/1530`; holdout `430/151/354`; baseline Brier/AUROC/calibration pairs match `tab:baselines`; pairwise deltas and Holm p-values match `tab:pairwise`; transfer counts `2756=1985+571+200`, `2185=1985+186+13+1`, `87.8%=2756/3138`, `floor(0.2×382)=76<100`. No mismatch found.

**claim_calibration (3).** Exceptionally well-calibrated. Abstract matches body and tables. Repeated explicit refusals to overclaim (no winner; not confirmatory; not operational; policy not detection; proposal not generalization; unresolved not equivalence). Seeded candidate correctly framed as an allowlist-policy illustration, not contamination detection. B4-over-B1 labelled marginal and family-dependent.

**editor_page_1 (3).** Page 1 carries title, a 197-word abstract, keywords, and the opening of the introduction. The abstract states the goal (fail-closed qualification contract), pain point (benchmark gains mislead under version drift, dependence, or unavailable information), contribution (admit/reject + supported/unresolved labels), evidence (DYFI, 430-event holdout, Holm), and the transfer refusal. An editor can grasp goal, contribution, usefulness, evidence, and venue fit within the first page.

**reproducibility (3).** Strong. SHA-256 fingerprint of downloaded bytes defines the resource version; pinned scientific-Python environment; single-use authorization token with two token-free replays reproducing the result fingerprint; bit-for-bit recovery from released rows and frozen best parameters; 110 unit tests; machine-readable fit log (91/120 fits); `build_ledger.json` with engine, binary hash, and ordered steps; `citation_ledger.jsonl`, `claim_ledger.jsonl`, `validate_cbs.py`. Transfer has prereg hashes frozen before `run_transfer.py`.

**related_work_citations (3).** 59 references spanning DYFI/macroseismic data, ML felt-intensity models, decision systems, classifier comparison (Dietterich, Demsar, Benavoli, Diebold–Mariano, Holm, cluster-robust), leakage taxonomies (Kapoor, Kaufman, Schelter), and production evaluators (TFX, NeMo, TFMA, evalci). Related work explicitly states the delta against each. All citations resolve and all bib entries are cited.

**formatting_blinding (3).** Single-column, double-spaced, line-numbered, 32-page main text with 8-page supplement. Main text blinded; identities isolated on `title_page.tex` (treated as non-leak per instructions). 57/57 manuscript validation checks pass, including `main_text_blinded`, `title_page_carries_identities`, `reviewer_package_anonymous`, `single_column_double_spaced_line_numbered`, `concise_abstract`, and `table_titles_at_most_15_words`.

**usefulness (2).** Real but narrow. The executable contract, versioned benchmark, and machine-readable verification record are reusable; the seeded C_F2 candidate (beats every admissible baseline on Brier/AUROC/log-loss yet is rejected at admission) is a compelling illustration, and the Italian provenance gate is a useful design lesson. However, the endpoint is magnitude-dominated (magnitude-only AUROC 0.719 vs source-only 0.786), the dependence-aware variance is barely exercised, and the transfer refused by arithmetic, so the decision-bearing layer is demonstrated on one near-tied catalogue.

## Top required changes (only for sub-3 criteria)

### Novelty (2)
1. Implement and exercise the provenance-binding gate as a field of the released contract (not only a design proposal), so the most novel contribution is demonstrated rather than proposed.
2. Demonstrate the fail-closed combination on a second catalogue where paired Holm decisions are actually reached; the Italian transfer refused by design arithmetic (20% cap + 100-event floor), so it does not test the paired-decision layer on independent data.
3. Sharpen the explicit, tested delta against the closest prior tooling — `evalci` (paired tests + cluster intervals + all-pair Holm) and NeMo Evaluator (per-item pairing + CI + policy threshold + fail-closed verdict). State precisely what "admission gate coupled to a family-wise decision" adds that those lack, with evidence.

### Soundness (2)
1. Re-run the contract with the Holm family pre-declared in a frozen protocol on a fresh hidden holdout (or independent evaluation service), so the supported/unresolved labels move from post-hoc to confirmatory. The paper's central artifact is a decision rule, so the multiplicity layer should not be post-hoc.
2. Report the effective dependence signal on this corpus (fraction of non-singleton sequences, effective cluster size, and how much the cluster-robust SE differs from the event-level SE) and clarify whether the sequence-cluster-robust framing is load-bearing or defensive given 312/354 singletons and `G/(G-1)=1.003`.
3. Pre-register and execute at least one currently unexecuted branch (geographic leave-region-out or aggregation-grid sensitivity) so a stated protocol-required analysis is not merely a disclosed deviation.

### Usefulness (2)
1. Demonstrate the contract on a task where the candidate field set moves performance substantively beyond the magnitude-only baseline, so the admission gate and Holm decisions are decision-bearing rather than near-tied (current source-only AUROC 0.786 vs magnitude-only 0.719).
2. Either relax one transfer cutoff (pre-declared in `frozen_design.json`) so the paired decisions are actually exercised on the Italian catalogue, or reframe the transfer explicitly as a provenance-gate demonstration rather than a generalization test, so the usefulness claim matches what was run.
3. Add a short worked example of a maintainer performing the version-bump procedure (Section 2.1) end-to-end on a new outcome-blind field, so the reuse pathway is demonstrated rather than only described.

## Verdict

**Weak accept / major revisions.** The paper is methodologically careful, numerically clean, exceptionally well-calibrated, and strong on reproducibility, formatting/blinding, venue fit, and page-1 clarity. The blockers are scope: the headline multiplicity control is post-hoc, the dependence-aware variance is barely exercised on a magnitude-dominated single-catalogue endpoint, and the second-catalogue transfer refused by design arithmetic. Addressing the novelty/soundness/usefulness changes above would move this from a defensible single-corpus case study to a generalizable comparison contract.

**Total: 27 / 30 · Vetoes: 0 triggered.**
