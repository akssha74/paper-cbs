# Independent Review (Round R4) — GLM-5.2

**Submission:** *A Fail-Closed Qualification Contract for Comparing Machine-Learning Classifiers on Versioned Event Data: A Seismic Felt-Intensity Case Study*
**Target venue:** Cybernetics and Systems (Taylor & Francis)
**Stance:** Independent default-reject reviewer. No prior-round scores consulted; this review is grounded only in the manuscript, frozen inputs, ledgers, validation report, and bibliography.

---

## Verdict: **Reject** (25 / 30)

| # | Criterion | Score (0–3) |
|---|---|---:|
| 1 | CBS venue fit | 2 |
| 2 | Novelty | 1 |
| 3 | Soundness | 2 |
| 4 | Numeric integrity | 3 |
| 5 | Claim calibration | 3 |
| 6 | Editor / page-1 clarity | 3 |
| 7 | Reproducibility | 3 |
| 8 | Related work / citations | 3 |
| 9 | Formatting / blinding | 3 |
| 10 | Usefulness | 2 |
| | **Total** | **25 / 30** |

The execution is genuinely strong — top marks for numeric integrity, claim calibration, reproducibility, blinding, citations, and page-1 clarity. The rejection rests on **contribution-level** grounds, not execution defects.

---

## Hash verification (observed vs. claimed)

- `main.pdf` — claimed `28f5c57c…c3803b`, observed `28f5c57c…c3803b` ✓
- `main.tex` — claimed `cce6009c…1fffd`, observed `cce6009c…1fffd` ✓
- `supplement.pdf` — observed `53883e61…8268`, matches `build_ledger.json` ✓
- `build_ledger.json` `main_tex_sha256` / `main_pdf_sha256` both match the files above ✓

## Blinding check (main.pdf, not title_page)

I extracted the text of `main.pdf` and scanned for author names, affiliations, emails, and repository handles. **No identifying terms found.** Terms tested: `Akshay`, `Sharma`, `Prasad`, `SAGE`, `Indore`, `akssha`, `akssha74`, `github`, `akssha74@gmail`, `Lalji` — all zero hits. The author block reads "Blinded for Anonymous Peer Review." Identities (Akshay Sharma; Lalji Prasad, SAGE University, Indore) are correctly confined to `title_page.tex`/`title_page.pdf`, which is separate from the blinded main PDF. **Blinding is clean.**

## CBS validation report

`cbs_validation_report.json` reports **43 checks, 0 failed, overall_pass = true** (meets the 42+ requirement). Notable passing checks: `main_text_blinded`, `title_page_carries_identities`, `all_citations_resolve`, `all_bibliography_entries_cited`, `cbs_precedents_engaged` (5 precedents), `qualification_b0/b2/b5_exact`, `r4_wording_residuals_absent`, `build_ledger_main_current`, `build_ledger_pdf_current_or_source_only`, `ai_use_disclosed`, `declarations_complete`, `null_and_no_winner_preserved`, `threshold_probe_not_robustness_claim`. The page-target check notes "31 (internal target; venue limit not verified)" — the venue page limit was not confirmed against the journal guidelines.

## Bibliography spot-check (sag2025optimization, praveena2025retail)

- **`sag2025optimization`** — Hossain & Sağ, *Cybernetics and Systems* **57(1):44–83**, year 2025, note "Online 2025; print 2026", DOI `10.1080/01969722.2025.2588199`. Citation-ledger verification: `crossref_and_openalex_abstract_verified_2026-09-26`. Year and note are internally consistent; in-text usage ("clustering optimizer with Wilcoxon and Friedman tests across ten datasets") matches the title. *Minor:* the cite key derives from the second author (Sağ) while the first author is Hossain — cosmetic only.
- **`praveena2025retail`** — Praveena & Prasanna Devi, *Cybernetics and Systems* **57(1):1–43**, year 2025, note "Online 2025; print 2026", DOI `10.1080/01969722.2025.2583968`. Citation-ledger verification: `crossref_and_openalex_abstract_verified_2026-09-26`. Year and note consistent; in-text usage ("stacked ensemble by point accuracy, precision, and recall") matches.

Both are legitimate in-venue precedents and are correctly dated/annotated.

## Numeric integrity — cross-check vs `frozen_inputs/asset_inputs.json`

Every result-bearing number I checked matches the frozen assets **exactly**. No mismatches found.

- **Cohort:** 7,520 frozen records; 2,362 eligible (703 severe, prevalence 0.298); train 1,573 / dev 357 / holdout 430 with 449/102/151 severe; 2 temporal-straddle (1 severe); 1,885 / 1,530 / 354 sequences; reconciliation 449+102+151+1 = 703 ✓; construction prevalence 0.285, holdout prevalence 0.351 ✓.
- **Baselines (Brier / AUROC / 95% CI):** B0 0.232 / 0.500 [0.212,0.253]; B1 0.198 / 0.719 [0.177,0.219]; B2 0.181 / 0.786 [0.160,0.202]; B4 0.187 / 0.777 [0.168,0.206]; B5 0.181 / 0.783 [0.161,0.202] ✓.
- **Calibration (intercept/slope):** B1 0.32/1.02, B2 0.64/1.29, B4 0.74/1.48, B5 0.42/1.07 ✓.
- **Recall @ 0.5:** B1 0.25, B2 0.32, B4 0.29, B5 0.37 ✓ (range 0.25–0.37 as stated).
- **Threshold sensitivity (Brier/AUROC/prevalence):** 5.5 → 0.240/0.734/0.458; 6.0 → 0.181/0.786/0.351; 6.5 → 0.143/0.815/0.260 ✓. Near-threshold fraction 0.164; no-skill Brier floor 0.204 ✓.
- **Split diagnostic:** random 0.2048/0.6952/0.9640; event-grouped 0.2009/0.7058/0.9223; sequence-grouped 0.1990/0.7076/0.9709 ✓. Brier gap (seq−random) −0.0059; AUROC gap (seq−random) 0.0124; event-grouped Brier gap vs random 0.0039 ✓.
- **Pairwise (10 pairs):** all point-diffs and CIs match, including B2–B5 −0.0008 [−0.0078, 0.0068], B1–B4 lower endpoint 0.0023, B4–B5 lower endpoint 0.0003 ✓. Joint ordering: B2 prob-best 0.613, B5 0.387 ✓.
- **Slices:** 2023 n=250 Brier 0.185 AUROC 0.797; 2024 n=180 Brier 0.174 AUROC 0.777; geographic 82 cells, Brier 0.002–0.825, median 0.151 ✓.
- **Reproducibility counts:** fit_count 91 of 120 cap; n_verification_checks 87; unit tests 110 (24+35+31+20) ✓.

## R4 fixes confirmed (booleans)

- Blinding clean in main.pdf: **true**
- Hashes match claims: **true**
- `r4_wording_residuals_absent`: **true**
- Numeric claims match assets: **true**
- Bib years/notes correct for `sag` and `praveena`: **true**
- Validation report 42+ checks passing: **true** (43/43)
- AI use disclosed: **true**
- Deviations disclosed in Supplement Table S2: **true**
- No-winner claim preserved: **true**
- Threshold probe not framed as robustness: **true**
- B3 scope-exclusion (not leakage) claim: **true**

---

## Vetoes (blocking)

**V1 — Insufficient novelty for a selective venue.** Section 2.3 ("Evaluation-method delta") and the Contributions list explicitly state *"No component is claimed as new"* and that the submission is *"a task-specific reproducibility and benchmark resource for this DYFI classification task, not a general evaluation-method contribution."* The endpoint is magnitude-dominated (magnitude-only AUROC 0.719; adding depth lifts it to 0.786), so the worked task is close to magnitude thresholding. The contribution is the packaged combination on one dataset, which is incremental relative to Kapoor & Narayanan (leakage taxonomy + model information sheets), Demšar / Benavoli (Bayesian comparison), and Roberts (blocked CV). Honest scoping does not by itself clear a selectivity bar that requires a new method or a new finding.

**V2 — Single-dataset evaluation; "task-agnostic" claim untested.** The abstract and Section 1.3 state the controls are *"task-agnostic in form"* and DYFI is *"one instantiation."* Yet no second, non-seismic dataset is evaluated (acknowledged in Section 6.1). Reusability on other event catalogues is untested, so the generality claim rests on assertion rather than evidence.

## Veto (non-blocking, major)

**V3 — Protocol-required analyses not executed.** Supplement Table S2 and Sections 5.2/5.8 disclose that the geographic leave-region-out evaluation, the aggregation-grid sensitivity, and the split-contrast paired interval were required by the frozen internal protocol but not executed. The split contrast is downgraded to descriptive point estimates; the geographic result is only temporal-holdout subgroups. Disclosure is honest, but it leaves the resource's robustness under-demonstrated.

## Required changes

1. **Demonstrate a transferable methodological contribution beyond packaging:** either instantiate the contract on at least one second, non-seismic event catalogue and show the admit/reject and supported/unresolved decisions change meaningfully, **or** reframe the contribution as a benchmark-resource paper and target a venue whose scope explicitly includes benchmark resources.
2. **Complete or convincingly de-scope the unexecuted protocol branches:** execute the geographic leave-region-out evaluation and the aggregation-grid sensitivity, or remove them from the protocol and replace the "task-agnostic" framing with a narrower, evidence-supported scope statement.
3. **Split-contrast handling:** either retain a paired sequence-cluster interval (the protocol required uncertainty) or state in the main text — not only the supplement — that the contrast is descriptive and cannot support any sign or equivalence claim; reconcile the protocol/manifest mismatch.
4. **Strengthen venue-fit argumentation:** five *Cybernetics & Systems* precedents are cited, but the manuscript's core is ML evaluation methodology plus seismology data, so the page-1 framing should explicitly position the work within the journal's Applied AI / Decision Systems focus rather than as a seismology resource.
5. **Cohort-table display:** the "Severe rate" column shows "--" for the 2-event temporal-straddle row while `asset_inputs.json` records prevalence 0.5 for that stratum; either report it or add a footnote explaining the suppression for n=2.

## Minor issues

- Cite key `sag2025optimization` is derived from the second author (Sağ) while the first author is Hossain; a key like `hossain2025siberian` would be more discoverable.
- Main PDF is 31 pages; the validation report flags the venue page limit as "not verified." Confirm against *Cybernetics & Systems* author guidelines before submission.
- The abstract reports AUROC 0.786 for "magnitude plus depth" (B2); a reader could briefly conflate this with B5 (0.783). Consider labeling the model in the abstract.

## Overall note

This is among the best-executed reproducibility/resource submissions I have reviewed: every result number cross-checked matches the frozen assets exactly; hashes match; `main.pdf` is properly blinded; the validation report passes 43/43 checks; and the two flagged bibliography entries are internally consistent and independently verified in the citation ledger. The rejection rests on **novelty, single-dataset generality, and unexecuted protocol branches** — not on execution defects. If the authors either (a) demonstrate the contract on a second dataset, or (b) retarget to a venue that explicitly welcomes benchmark/resource papers, the score could move into the accept range.
