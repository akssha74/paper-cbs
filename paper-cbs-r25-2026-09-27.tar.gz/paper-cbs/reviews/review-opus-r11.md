# Independent default-reject review — round 11 (Claude Opus)

**Manuscript:** A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study
**Venue:** Cybernetics and Systems (Taylor & Francis)
**Earlier-round reviews read:** none

## Verdict

**Total: 21/30. No veto is triggered. Recommendation: major revision; not acceptable in its current form.**

The numbers are exact and reproducible, and the claims are carefully calibrated. What holds the score down:

- **Novelty.** The paper claims a schema gate as part of its remaining delta, but uncited production-ML prior art (TFX/TFDV with TFMA blessing) already chains schema validation with candidate-versus-baseline gating.
- **Evidence base.** The contract's value is shown only by construction, on one magnitude-dominated catalogue.
- **Fixable defects.**
  - Figure 3(a) has colliding and clipped labels.
  - The claim ledger has four entries that the validator silently skips.
  - The AI-use disclosure does not match the package artefacts.

| Criterion | Score |
|---|---|
| cbs_venue_fit | 2 |
| novelty | 1 |
| soundness | 2 |
| numeric_integrity | 3 |
| claim_calibration | 3 |
| editor_page_1 | 2 |
| reproducibility | 2 |
| related_work_citations | 2 |
| formatting_blinding | 2 |
| usefulness | 2 |
| **Total** | **21/30** |

**Vetoes:**

| Veto | Triggered? | Reason |
|---|---|---|
| fabricated_citation | No | Spot-checked through Crossref, arXiv and vendor documentation. |
| numeric_mismatch | No | |
| blinding_breach | No | |
| clearly_out_of_scope | No | |
| unsupported_overclaim | No | |

## Package integrity and reproduction

- **Checksums.** All six SHA-256 hashes match the stated values. main.pdf has 31 pages; supplement.pdf has 8.
- **Post-hoc scripts.** I re-ran `family_wise_sensitivity.py`, `seeded_candidate_demo.py` and `robustness_post_hoc.py` (99,999 wild draws) with `/tmp/dyfi-analytics-venv/bin/python`. All three outputs are **byte-identical** to the frozen JSON files.
- **Validator.** `validate_cbs.py` reports 56 checks with 0 failures.
- **Table formatter.** Run on its own, `format_cbs_tables.py` is **not idempotent** (see F6).
- **Restoration.** I backed up and then restored every file I touched. A SHA-256 manifest of all non-review files is identical before and after.

## Requested checks

1. **C_F2 "best" scoping: pass, with a wording defect.**
   - No "every reported score" remains anywhere.
   - Section 5.6 and Table 4 still say "Among the admissible baselines it has the best…" and "best among admissible baselines". Grammatically, that puts the rejected C_F2 inside the admissible set.
   - The values themselves are correct: C_F2 scores 0.172 / 0.809 / 0.515 on Brier / AUROC / log-loss, against the best admissible 0.181 / 0.786 / 0.536.
2. **Figures: Figure 1 passes; Figure 3 fails.**
   - Figure 1 reads "F1 to F6", and every label fits inside its box (PDF page 6).
   - In Figure 3(a), on PDF page 16 and in the PNG, several labels collide:
     - At cutoff 6.0, the "0.351" and "0.181" labels overprint each other.
     - At 6.5, the "0.143" and "0.260" labels sit under the legend and are clipped.
     - The "0.786" label is crossed by the dotted cutoff line.
     - The "0.734" label runs into the y-axis.
3. **Table S1: pass.** It has true `$-$` minus signs and a left-aligned note. The notes of main Table 3, Table S4 and Table S5 still render centred.
4. **Validator identity tokens: pass.**
   - Tokens are derived by regex from `title_page.tex`, and there are no hardcoded `v1.1.1` or "DYFI Benchmark Reliability" literals.
   - The scan reads `pdfinfo` output and the raw PDF/PNG header bytes.
   - My own independent scan found no identity hits in any listed reviewer file. It covered full `pdftotext` output, XMP metadata and PNG tEXt chunks.
   - Limitation: the validator reads neither the XMP stream nor the extracted PDF text.
5. **Claim-ledger pointers: partial fail.**
   - What passes: the ten Holm claims point to `/pairs/0` through `/pairs/9`, and they resolve. Overall, 161 of 165 claims resolve.
   - `B0_oracle_constant` has the pointer `"derived: /endpoint/holdout_prevalence, /per_baseline/B0_no_skill/brier"`. That is a **comma-separated multi-pointer on a single claim**.
   - `L_event_gap_4dp` and `P_recount_lag_s` use "derived: … minus …" text instead of a pointer, and `P_unit_tests` has a null pointer.
   - `validate_cbs.py` skips all four (L563–565). Its PASS therefore does not cover them.
   - I recomputed all three derived values and they are correct.
6. **Harness precondition, Dror/Bouthillier, Knap: pass.**
   - The harness precondition is stated once (L679–682).
   - Dror et al. and Bouthillier et al. are cited with the training-variance delta (L239–241).
   - Knap et al. is described as a "repeated-seed deep-learning follow-up". The citation ledger records three seeds, and Crossref confirms the DOI.
7. **NeMo Evaluator, 86-cluster partition, abstract order: pass.**
   - The NeMo Evaluator comparison is present, and the vendor page confirms the description.
   - The synthetic 86-cluster partition is disclosed in the main text and the Table S6 note (p = 0.0138, six Holm rejections).
   - The abstract states random-forest marginality before the supported statement.
8. **Numbers: pass.**
   - 99,999 wild-cluster draws; seven Holm rejections.
   - 10° B1–B4 wild p = 0.01244 with Monte Carlo SE 0.00035, against a threshold of 0.0125.
   - 312 of 354 holdout clusters are singletons.
   - Validator: 56/56 checks pass. Main PDF: 31 pages.
   - I recomputed the Holm step-down: B1–B4 is at rank 7 (threshold 0.0125); B4–B5 fails at rank 8 (0.0350 > 0.0167).

## Findings

### F1 — Major, fixable: uncited production-ML prior art weakens the stated novelty delta
- **What the paper claims.** L243–248 names the remaining delta over NeMo as the "pre-score schema/role gate, event-sequence clustering, version pinning, and the worked seismic case".
- **The prior art.** TFX already combines:
  - TFDV schema validation;
  - an Evaluator that accepts a `baseline_model` and a `schema`;
  - TFMA `change_threshold`, which "gate[s] the candidate model by checking whether the corresponding metric is larger/smaller than that of a baseline model";
  - a `ModelBlessing` output that gates deployment.
- **Missing citations.** `references.bib` contains none of TFX, TFDV, Breck et al. 2019 ("Data Validation for ML"), the ML Test Score, or Deequ.
- **Required change.** Cite this literature. Restate the delta as paired, dependence-aware, multiplicity-controlled gating plus the sequence-role audit; TFX gates on point thresholds. Stop presenting the allowlist itself as novel.

### F2 — Major, needs new data: the contract's value is demonstrated only by construction
- L714–717 concedes that the C_F2 rejection "holds by construction".
- Only one catalogue is used, and the endpoint is magnitude-dominated.
- With 312 of 354 holdout clusters being singletons, the cluster correction is "only lightly exercised" (L437–440).
- The Holm family and all sensitivity analyses are post hoc.
- This study already scopes these limits honestly. Closing them needs a second domain and a fresh hidden holdout scored under a pre-declared family.

### F3 — Moderate, fixable: Figure 3(a) label and legend collisions
Described under requested check 2. Fix it by offsetting or dropping the point labels (Table S4 carries the values), moving the legend, and regenerating the figure with an updated manifest hash.

### F4 — Moderate, fixable: four claim-ledger entries are not machine-validated
- The four entries are those listed under requested check 5.
- Replace the pointer text with a `json_pointers` array plus a machine-evaluable `derivation` field.
- Point the unit-test claim at a test-run log.
- Make the validator resolve every pointer and recompute every derived value, instead of skipping.

### F5 — Moderate, fixable: AI-use disclosure is inconsistent with the package
- **Manuscript:** L484–486 names only ChatGPT.
- **Package artefacts:** `goal_usefulness.json` and `cbs_validation_report.json` record the reviewer as "Multi-agent panel (GPT-5.6, Claude Opus, GLM-5.2)".
- **Required change.** Name every generative-AI tool used, as the Taylor & Francis policy requires. Otherwise, remove the tool names from reviewer-facing artefacts.

### F6 — Minor, fixable: `format_cbs_tables.py` is not idempotent
- **What happened when I ran it on its own:**
  - It appended the straddle sentence a second time to the Table 2 note.
  - It re-inserted five rows and a second `\endfirsthead`/`\endhead` block into Table S2.
- **Why the committed tables are still fine.** `build.sh` runs `format_tables.py` first, so the tables produced by the documented pipeline are consistent.
- **Required change.** Guard each patch so it is applied only once, and add an idempotence test to the validator.

### F7 — Minor, fixable: two wording problems
- **C_F2 "best":** "best among admissible baselines" should read "better than every admissible baseline".
- **Abstract:** "Comparisons among those three" has an ambiguous referent, because the preceding sentence names only two models. Name all three.

### F8 — Minor, fixable: table-note alignment and supplement whitespace
- The notes of Table 3, Table S4 and Table S5 render centred.
- Supplement pages 5–6 are mostly blank, because `[t]` floats are followed by `\FloatBarrier`.
- The Table S3 note is wider than its table.

### F9 — Minor, fixable: identity-bearing folder next to the anonymized package
`submission/` holds the prior venue's upload files (JEAS main.pdf, cover letter, pre-submission inquiry), which carry author identities. It sits inside `paper-cbs/`. It is not part of the listed reviewer package and the validator excludes it, so this is **not** a blinding breach. It becomes one if the directory is archived wholesale. Move it out, or build an allowlisted archive.

### F10 — Minor, fixable: page 1 is hard going for a broad readership
- The abstract front-loads statistical terminology.
- It never states in plain words the practitioner decision the contract supports: adopting or refusing a claimed classifier upgrade.

## Limitations that need new data, versus defects fixable in this study

**Only new data can resolve these:**
- A second catalogue or domain.
- A fresh hidden holdout scored under a pre-declared Holm family.
- Data with real within-cluster dependence.

**Fixable in this study:**
- F1 and F3–F10.
- Optionally, repeated-seed refits of B2, B4 and B5 on the existing construction data. This would quantify the training variance the paper explicitly excludes, without any new data.

## What each criterion needs to reach 3

| Criterion | Path to 3 |
|---|---|
| cbs_venue_fit | Present the contract in plain language as a reusable decision component: its inputs, outputs and failure states. |
| novelty | Position against TFX/TFDV/TFMA and narrow the claimed delta. A real 3 needs a second domain or a prospective run (new data). |
| soundness | A pre-declared Holm family scored on fresh hidden data (new data); repeated-seed refits (no new data needed). |
| numeric_integrity | Already 3. Close F4 to keep it. |
| claim_calibration | Already 3. Apply F7 and F5. |
| editor_page_1 | Fix F10. |
| reproducibility | Fix F4, F6 and F9. |
| related_work_citations | Add TFX, TFDV/Breck 2019, the ML Test Score, Deequ, and Nadeau & Bengio 2003. |
| formatting_blinding | Fix F3, F8 and F5. |
| usefulness | Show a decision the contract changes relative to a TFMA or NeMo threshold gate on the same data. |

## Top required changes

1. **F1:** Cite TFX/TFDV/TFMA blessing and Breck et al., and narrow the novelty delta.
2. **F3:** Regenerate Figure 3(a).
3. **F4:** Remove the comma-separated multi-pointer and the other non-pointer ledger entries; make the validator resolve every pointer.
4. **F5:** Reconcile the AI disclosure with the package artefacts.
5. **F6–F8:**
   - Make the table formatter idempotent.
   - Fix the C_F2 "best" and abstract "those three" wording.
   - Left-align the remaining table notes.
