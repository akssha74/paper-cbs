# Independent Default-Reject Review (GLM) — Round r11

Manuscript: A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study
Venue: Cybernetics and Systems (Taylor and Francis) — Applied AI/ML and Decision Systems
Reviewer: GLM (independent, default-reject)
Date: 2026-09-26

Files reviewed: `main.pdf` (31 pp), `supplement.pdf` (8 pp), `main.tex`, `supplement.tex`, `tables/*.tex`, the three named figures, `family_wise_sensitivity.py`, `seeded_candidate_demo.py`, `robustness_post_hoc.py`, `format_cbs_tables.py`, `validate_cbs.py`, `generate_ledgers.py`, `frozen_inputs/*.json`, `claim_ledger.jsonl`, `citation_ledger.jsonl`, `cbs_validation_report.json`, `references.bib`, `build_ledger.json`. `title_page.tex` was inspected only to confirm it is the sole identity-bearing file (editor-only).

## 0. Package integrity

| File | Expected SHA-256 | Verified |
|---|---|---|
| main.pdf | 5785bb7c...3ba6e7d2 | yes |
| main.tex | 80c05563...aacaaba | yes |
| supplement.pdf | 77cb18c1...72af4a3a | yes |
| supplement.tex | 0f2b5efe...87be395 | yes |
| references.bib | d73a825d...64e1c9 | yes |
| build_ledger.json | af872ad9...4b9e3 | yes |

- `pdfinfo main.pdf` -> **Pages: 31** (internal target <= 32; no invented 33-page count). Letter, single column.
- `pdfinfo supplement.pdf` -> 8 pp.
- `cbs_validation_report.json`: **56/56 checks PASS**, `overall_pass: true`.
- Blinding scan: no author/affiliation/URL token (akssha74, akshay, sharma, prasad, sage university, indore, github.com, v1.1.1) appears in any reviewer-facing file. Identities appear **only** in `title_page.tex` (2 authors, 1 handle). OK.
- Optional reproduction (`/tmp/dyfi-analytics-venv/bin/python`): backed up the three post-hoc frozen-input JSON files, re-ran all three scripts, confirmed **byte-identical SHA-256** for each, then restored. No scientific file was modified (pre/post SHA-256 of main.pdf, main.tex, supplement.pdf, supplement.tex, references.bib, build_ledger.json all unchanged). The three frozen-input outputs were also unchanged post-run.

## 1. Specific checks requested

1. **Page count.** `pdfinfo` -> 31 pages. Within the <=32 internal target. OK.
2. **Abstract.** 188 rendered words (validator `concise_abstract`), <=200. OK. Ordering: 'The random-forest gain over magnitude-only is marginal and family-dependent. Otherwise, post-hoc Holm analysis supports every admissible learned candidate over no-skill and the source-only logistic and XGBoost over magnitude-only.' — B1-B4 marginality is stated **before** the remaining supported Holm claims. OK. Page 1 carries 'an admit/reject decision for each candidate and a supported/unresolved label for each pairwise improvement claim.' OK.
3. **Harness sentence vs C_F2_ren.** `seeded_candidate_demo.py` reads feature values from the frozen rows via the harness (`baselines.extract_features` + per-candidate `_col`), so a declared name cannot carry substituted values. `C_F2_ren` declares `n_reports`, carries the **same `num_responses` values** as `C_F2`, and is rejected as `F0_unknown_non_allowlisted` (allowlist decides), **not** because a family label matched. The manuscript states this exactly: 'the named families label rejections, and the allowlist decides them.' OK. The precondition that candidates receive only harness-extracted allowlisted columns is enforced (admission audit on declared names runs first; fit/score only after rejection, for illustration). OK.
4. **Wild-cluster and synthetic partition.** `robustness_post_hoc.json`: `wild_draws = 99999`. 10deg-cell B1-B4 `wild_cluster_rademacher_p = 0.01244` (paper: 0.0124), `wild_cluster_mc_se = 0.0003505` (paper: 0.0004), Holm rank-specific threshold 0.0125 — borderline within MC precision, flagged R^b. Default cluster structure: `n_clusters=354`, `n_singletons=312` (paper: 312/354). OK. Synthetic 86-cluster partition of the same 430 losses: `cr1_p = 0.0137632` (paper: 0.0138), `n_holm_reject = 6` (paper: six decisions); `definition` field states 'Not a physical aftershock model.' OK.
5. **Cluster-robust Holm.** `family_wise_sensitivity.json`: `n_holm_reject = 7`; B1-B4 `cluster_robust_p_two_sided = 0.010855349147` vs `holm_threshold = 0.0125` (reject); B2-B4 (p=0.0485), B2-B5 (p=0.8269), B4-B5 (p=0.0350) all unresolved. OK. `seeded_candidate_demo.json`: C_F2 Brier 0.172389679459, AUROC 0.809276270503, log-loss 0.515321511554 — best among admissible baselines on all three; scoped as post-hoc illustration rejected at admission. OK.
6. **Citations verified real.** Web-confirmed: `evalci` (arXiv:2607.04429, Chandrahas; PyPI/GitHub Shreyaskc/evalci); NVIDIA NeMo Evaluator 'Implementing Quality Gates' (docs.nvidia.com/nemo/evaluator/tutorials/quality-gate; `nel gate` pairs per-item scores, builds CIs, applies policy thresholds, returns GO/NO-GO/INCONCLUSIVE). Dror 2018 (ACL, doi:10.18653/v1/P18-1128); Bouthillier 2021 (MLSys 2021); Holm 1979 (Scand. J. Statist. 6:65-70); Diebold-Mariano 1995 (JBES 13(3):253-263, doi:10.1080/07350015.1995.10524599). No fabricated citation.
7. **Anonymity / validator / no universal recommendation / release vs review-archive.** Reviewer package anonymous (validator `reviewer_package_anonymous` PASS, no identity hits). 56/56 PASS. No universal recommendation: Discussion says reuse 'is a design proposal, not an empirical generalization from DYFI'; Limitations: 'reuse on other event catalogues is untested.' Release-vs-review-archive distinction (github akssha74/dyfi-benchmark-reliability, tag v1.1.1) appears **only** on `title_page.tex`. OK.

## 2. Numeric cross-check (prose vs tables vs frozen JSON)

All ten pairwise Brier differences, Holm p-values, Bonferroni 99.5% CIs, and Holm decisions in `tables/pairwise_matrix.tex` and `tables/candidate_qualification.tex` match `family_wise_sensitivity.json` to printed precision (e.g., B1-B4 point 0.0115, p=0.0109, Bonferroni CI [-0.0012, 0.0243]; B4-B5 p=0.0350, Bonferroni [-0.0018, 0.0122]; B2-B5 p=0.8269). Cohort accounting reconciles: 703 = 449+102+151+1; 2,360 role-assigned events contain 702 severe; 1,573+357+430+2 = 2,362. Split-contrast post-hoc intervals (sequence-random Brier -0.0059 [-0.0119, 0.0005]; AUROC +0.0124 [-0.0019, 0.0266]; log-loss +0.0069 [-0.127, 0.148]; event-grouped Brier -0.0040 [-0.0097, 0.0023]) match `robustness_post_hoc.json`. C_F2 vs B5 (-0.0090 [-0.0182, -0.0004]) and vs B2 (-0.0083 [-0.0181, 0.0005], prob 0.965) match `seeded_candidate_demo.json`. No numeric mismatch found.

## 3. Findings

### Defects fixable in this study (no new data needed)

- **F1 (minor, clarity) — Harness sentence is dense and slightly self-contradictory.** Sec 5.6: 'Candidates are model specifications that receive only harness-extracted allowlisted columns; pretrained or externally parameterised artefacts are outside this name-level audit.' A reader could misread 'receive only ... allowlisted columns' as contradicting the seeded candidates that add non-allowlisted fields. The intended meaning (admission audit on declared names runs first; values are harness-extracted from frozen rows so a clean name cannot launder them; the allowlist decides) is correct and recoverable from surrounding sentences and `seeded_candidate_demo.py`, but the sentence should be reworded to state the precondition crisply: *the admission audit on declared names runs before any scoring; feature values are read by the harness from the frozen rows; a declared name not on the two-field allowlist is rejected before its values are used.*
- **F2 (minor) — Abstract omits log-loss for C_F2 while the body reports all three.** Abstract: 'beats every admissible baseline on Brier (0.172) and AUROC (0.809)'; body/conclusion: 'Brier, AUROC, and log-loss.' Both are internally accurate; the abstract is concise by design. Optional: add '(... and log-loss 0.515)' or leave as-is. Not a correctness defect.
- **F3 (minor) — Figure regeneration environment not installed in the review host.** `cbs_validation_report.json` records 'host matplotlib=not-installed; pinned=3.11.1; hashes verified without regeneration'. Vector figures were hash-verified, not regenerated. Numeric reproduction (the scientific core) is byte-identical; figure regen is a secondary reproducibility item. Fixable by noting the hash-only verification explicitly in the build ledger environment block.

### Limitations requiring new data (not defects)

- L1. Single-catalogue, retrospective, magnitude-dominated endpoint; not operational. Disclosed (Abstract, Sec 6, Sec 7).
- L2. No second non-seismic dataset; reuse on other catalogues untested. Disclosed (Sec 6, Sec 7).
- L3. Protocol-defined geographic transport evaluation and aggregation-grid sensitivity not executed; only temporal-holdout subgroups and a relabelled threshold probe reported. Disclosed (Sec 5.2, Sec 5.7, Supp. Table S2).
- L4. 312/354 singleton sequences => cluster-robust correction only lightly exercised on the default catalogue; addressed with 5deg/10deg regional clustering, CR3 jackknife, wild-cluster bootstrap, and a disclosed synthetic 86-cluster partition. Disclosed (Sec 4.4, Sec 5.4, Supp. Table S6).
- L5. Holm family, B2-vs-B0, split-contrast intervals, seeded candidates, and all sensitivity analyses specified after the holdout was opened => post-hoc, not confirmatory. Disclosed (Sec 4.4, Sec 5.6, Sec 6, Supp. Table S2).
- L6. Internal freeze (2026-09-01) first publicly timestamped 2026-09-19 => 'internally frozen protocol, not an externally registered preregistration.' Disclosed (Sec 3).

### Strengths

- Honest, well-calibrated claims: no winner declared; B1-B4 explicitly 'marginal and family-dependent'; seeded candidate labelled post-hoc illustration, not a performance claim; no equivalence margin invented; no universal recommendation; 'not operational,' 'not confirmatory,' 'reuse untested.'
- Executable, hash-locked artefact chain with claim ledger, citation ledger, build ledger; validator 56/56 PASS; independent byte-identical reproduction of all three post-hoc scripts.
- Page-1 editor readability: goal, pain point, contribution identity, admit/reject + supported/unresolved outputs, and venue fit are all on page 1.
- In scope for Cybernetics and Systems (5 venue precedents engaged: Sag 2025, Praveena 2025, Gao 2026, Hossack 2004, Gomolka 2000).

## 4. Vetoes

| Veto | Triggered | Basis |
|---|---|---|
| fabricated_citation | No | evalci and NeMo Evaluator web-verified; Dror 2018, Bouthillier 2021, Holm 1979, Diebold-Mariano 1995 all real and correctly attributed |
| numeric_mismatch | No | prose vs tables vs frozen JSON all match; reproduction byte-identical; cohort reconciles |
| blinding_breach | No | reviewer package anonymous; identities only on title_page.tex (editor-only) |
| clearly_out_of_scope | No | applied AI/ML decision-support evaluation contract; 5 venue precedents cited |
| unsupported_overclaim | No | no winner, no operational/causal/real-time benefit, no universal recommendation, no contamination-detection claim; B1-B4 flagged marginal |

**No vetoes.**

## 5. Scores (0-3 each, total /30)

| Criterion | Score | Rationale |
|---|---|---|
| cbs_venue_fit | 3 | Applied AI/ML decision-support evaluation contract; 5 venue precedents engaged; clearly in scope. |
| novelty | 1 | Fail-closed combination (allowlist + role audit + version pinning + cluster-robust Holm) on one frozen corpus; each component established (Holm, Diebold-Mariano, cluster-robust variance, leakage allowlists, evalci, NeMo Evaluator); paper itself frames it as packaging, not a new method; single-corpus, no second dataset. Defensible-beyond-incremental but modest. |
| soundness | 2 | Methods correctly applied and clearly described; estimand defined; assumptions stated; B1-B4 marginality and lightly-exercised clustering honestly disclosed with appropriate post-hoc checks. Held to 2 because all inferential analyses are post-hoc (not confirmatory) and the cluster structure is mostly singletons. |
| numeric_integrity | 3 | All numbers cross-check; cohort reconciles; byte-identical reproduction of all three post-hoc scripts; 56/56 validator PASS. |
| claim_calibration | 3 | No winner; B1-B4 flagged marginal/family-dependent; seeded candidate labelled illustration; no equivalence margin invented; no universal recommendation; admit/reject + supported/unresolved on page 1; abstract ordering correct. |
| editor_page_1 | 3 | Goal, pain point, contribution identity, usefulness, evidence, and venue fit all on page 1; abstract 188 words. |
| reproducibility | 3 | SHA-256-locked artefacts, pinned environment, single-use token + two token-free replays, bit-for-bit reconstruction, claim/citation/build ledgers; independent byte-identical reproduction of the three post-hoc scripts. Minor: figure regen environment not installed in review host (hash-verified only). |
| related_work_citations | 3 | Real, verified citations; venue precedents and evaluation-method lineage (Demsar, Benavoli, Dror, Bouthillier, evalci, NeMo, BetterBench, Knap) engaged; ledger covers bibliography; all entries cited and resolve. |
| formatting_blinding | 3 | Single column, double-spaced, line-numbered; 31 pp <= 32; four main figures captioned with titles outside artwork; split figure in supplement; reviewer package anonymous; identities only on title page. |
| usefulness | 2 | Decision-support contract with a worked seeded-candidate demonstration that the gate prevents a would-be winner; reusable practices proposed. Held to 2 because usefulness is demonstrated on a single retrospective catalogue with a magnitude-dominated endpoint and no operational deployment or second-domain demonstration. |
| **total_score** | **22 / 30** | |

## 6. Top required changes (feasible, no new data)

1. **Reword the Sec 5.6 harness sentence (F1).** State explicitly: the admission audit on declared names runs before any scoring; feature values are read by the harness from the frozen rows; a declared name not on the two-field allowlist is rejected before its values are used — so a clean name (e.g., `n_reports`) cannot launder `num_responses` values. This removes the only self-contradictory reading in the paper.
2. **Close the figure-regeneration reproducibility gap (F3).** Note in the build ledger environment block that vector figures were hash-verified (matplotlib 3.11.1 not installed in the review host) and record the matplotlib pin so a future reviewer can regenerate.
3. **Optional: harmonize the C_F2 abstract with the body (F2).** Either add log-loss 0.515 to the abstract or leave the abstract concise; both are accurate as written.

## 7. Overall assessment

Default-reject stance applied; defects that prior rounds appear to have fixed are credited (validator 56/56 PASS, byte-identical reproduction, calibrated claims, blinding intact, page count within target, abstract within word limit and correctly ordered, citations verified real). No veto triggered. The remaining deductions are for modest single-corpus novelty (1/3), post-hoc-only inference with mostly-singleton clustering (soundness 2/3), and usefulness demonstrated on one retrospective catalogue (2/3). The work is methodologically sound, numerically clean, honestly scoped, and in venue; it is a defensible-but-modest contribution that I would not inflate to a strong accept. Recommendation: minor revision on the three fixable items above; acceptance contingent on F1 (clarity) being resolved, since it concerns the central mechanism the paper is contributing.

