# Review GLM-r6 (Independent Default-Reject, GLM-5.2)

**Manuscript:** A Fail-Closed Qualification Contract for Machine-Learning Classifier Comparison, Demonstrated on a Versioned Seismic Felt-Intensity Catalogue
**Venue:** Cybernetics and Systems (Taylor & Francis) — broad applied AI/ML, decision systems
**Base directory:** `studies/dyfi-benchmark-reliability/research/benchmark-resource/manuscript/paper-cbs`

## Hash verification
- `main.pdf` sha256 `50b01d3b9b8162e1bd64abded703d5b77f8e04e6cb5d27fe61b156622801e406` — matches claimed and `build_ledger.json`.
- `main.tex` sha256 `a7617360a5c9fce017ab1e15d9c8109a5025d5465b15e84dfc6995aad6fa9c59` — matches.
- `supplement.pdf` sha256 `b74a7a3eaa6fc0ad012ef1180780769cac9fe4f246d1a3cc461f076e83c9c69c` — matches `build_ledger.json`.
- `references.bib` sha256 `b232fc4fd6cbeb0d58a49078d5e57602e94c4377961304eb9c9cb97d4782e270` — matches.
- PDF matches source. No later one-line wording fix displaced the current pair.

## Scores (0–3 each, total /30)

| Criterion | Score |
|---|---|
| 1_cbs_venue_fit | 2 |
| 2_novelty | 1 |
| 3_soundness | 2 |
| 4_numeric_integrity | 2 |
| 5_claim_calibration | 2 |
| 6_editor_page_1 | 2 |
| 7_reproducibility | 3 |
| 8_related_work_citations | 2 |
| 9_formatting_blinding | 2 |
| 10_usefulness | 2 |
| **total** | **20** |

## Vetoes

| Veto | Severity | Blocks acceptance? |
|---|---|---|
| novelty | moderate | No — defensible-beyond-incremental combination of established pieces, honestly scoped (not occupied, not overclaim). Low score, not a hard block. |
| single-dataset generality | high | No — only the DYFI snapshot is instantiated; no second corpus. Does not hard-block only because the paper never claims generality. Major scope cap on novelty/usefulness. |
| protocol-required analyses not executed | high | No — geographic transport, aggregation-grid sensitivity, intervals for every metric, and the split-contrast paired interval were not executed. Honestly de-scoped in Table S2 and downgraded to a descriptive diagnostic, so not a hard block, but the protocol's *primary* quantitative result was not delivered as an inferential comparison. |
| fabricated citation | none | No — `reuel2024betterbench` verified via arXiv export API; `knap2026leakagesafe` verified via Crossref. No fabricated citations. |
| numeric mismatch | moderate | No — frozen data match the assets, but the verbal claim "Holm control changes one label (B4 unresolved against B1)" (Sec 5.5 and Table S2) contradicts the paper's own pairwise-results section ("B4–B5 and B1–B4 become unresolved and the other six decisions are unchanged"). Two labels change, not one. The pairwise table itself is correct. |
| blinding breach | none | No — `main.pdf`/`main.tex` contain no names, affiliations, email, or identifying repo URL; identities live only in the separate `title_page.tex`. |
| overclaim | none | No — no winner is claimed; all post-hoc analyses are disclosed; unexecuted branches are de-scoped; the split contrast is labelled descriptive point estimates only. |

**No hard veto blocks.** The combination of low novelty, single-corpus scope, unexecuted protocol primaries, and the Holm-count inconsistency keeps the paper below the acceptance bar.

## Specific checks

### Seeded response-count candidate = demonstrated decision-changing use?
**Yes, but narrow.** `C_F2` (B2 pipeline + log response count) wins every holdout score — Brier 0.172 (vs B2/B5 0.181), AUROC 0.809 (vs B2 0.786), log-loss 0.515 (vs B2 0.536) — and its paired Brier CI excludes zero against B0, B1, B4, and B5. A score-ranking workflow would declare it the winner; the admission audit rejects it pre-scoring on family F2 (`num_responses` outside the two-field allowlist). That is a genuine decision-changing demonstration. Caveat: it is a single post-hoc seeded field on one corpus, fit on construction rows with frozen regularization, and the paper honestly labels it an illustration, not an estimate of how often published comparisons contain such fields. The admissible-candidate comparisons change only one qualification label under Holm (B4 vs B1), so the demonstrated decision change is narrow.

### Holm-controlled labels vs `family_wise_sensitivity.json` and Supplementary Table S1
- 6 of 10 pairs rejected under Holm; 4 unresolved: B1–B4, B2–B4, B2–B5, B4–B5. Matches `family_wise_sensitivity.json` (`n_holm_reject = 6`) and `tables/pairwise_matrix.tex` (Table S1).
- Relative to unadjusted 95% intervals (8 exclude zero, 2 include zero), **two** pairs move to unresolved under Holm: **B1–B4** (unadjusted [0.0023, 0.0205] excludes 0 → Bonferroni 99.5% [-0.0020, 0.0235] includes 0) and **B4–B5** (unadjusted [0.0003, 0.0099] excludes 0 → Bonferroni 99.5% [-0.0015, 0.0113] includes 0).
- **Inconsistency:** the pairwise-results section correctly says "B4–B5 and B1–B4 become unresolved and the other six decisions are unchanged," but Sec 5.5 and the Table S2 row "Family-wise error control" say "changes one label (B4 unresolved against B1)." The verbal count is wrong in two places; the table data are correct.

### Post-hoc disclosure
Honest and thorough. Disclosed: Holm family-wise control declared after the holdout was opened; B2-vs-B0 not in the frozen protocol; seeded F2 candidate is post-hoc; split contrast has point estimates only (no paired interval retained); geographic transport not executed; aggregation-grid sensitivity not executed; equivalence margin never specified; split diagnostic reclassified post-protocol. All in the abstract, Table S2, and Limitations.

### BetterBench and Knap et al. 2026 engagement / stated delta
Accurate. BetterBench is correctly described as scoring benchmarks against 46 lifecycle practices and finding most omit statistical significance (ledger: applied to 24 benchmarks; the 46-practice figure matches). Knap et al. 2026 is correctly described as recording-level splits with common ML/DL baselines on two bearing datasets, broader than the single DYFI corpus. The stated delta — a candidate-level admission gate coupled to a family-wise-controlled paired decision, shown to reject a post-outcome candidate that wins every holdout score — is accurate relative to both.

### Unexecuted protocol branches de-scoped honestly?
Yes. Geographic transport ("not executed"), aggregation-grid sensitivity ("not executed"), uncertainty coverage ("partial deviation"), and the split-contrast interval (none retained) are all in Table S2 with rationale. No result is omitted because of its observed outcome.

### Applied-AI / decision-systems framing on page 1
Present. The abstract and Section 1 frame an applied-ML adoption/selection decision; Section 1.2 "Decision-system significance and intended use" positions the work as a decision-support test harness; keywords include "applied artificial intelligence" and "decision systems"; five Cybernetics and Systems precedents are engaged.

### All numbers vs frozen assets
Match, with one verbal discrepancy. Spot checks passed: cohort 7520/2362/430/2 with 703 = 449+102+151+1 and 702 severe in 2360; B0 Brier 0.232 [0.212,0.253], B1 0.198, B2 0.181, B4 0.187, B5 0.181; B1 AUROC 0.719, B2 AUROC 0.786; threshold sensitivity 5.5/6.0/6.5 Brier 0.240/0.181/0.143 and AUROC 0.734/0.786/0.815 with prevalence 0.458/0.351/0.260; near-threshold fraction 0.164; no-skill floor 0.204; seeded `C_F2` Brier 0.172, AUROC 0.809, log-loss 0.515, vs B2 -0.0083 [-0.0181, 0.0005] p_better 0.965, vs B5 -0.0090 [-0.0182, -0.0004]; temporal slices 2023 n=250 Brier 0.185 AUROC 0.797, 2024 n=180 Brier 0.174 AUROC 0.777; geographic 82 cells, median 0.151, range 0.002–0.825; split diagnostic Brier 0.1990/0.2048, AUROC 0.7076/0.6952, log-loss 0.9709/0.9640. Discrepancy: the "changes one label" verbal count (should be two) in Sec 5.5 and Table S2.

### Blinding
Intact. No author names, affiliations, email, or identifying repository URL in `main.pdf`/`main.tex`. Title page is separate.

### Formatting
Single-column, double-spaced, line-numbered, 1-inch margins, generic `article` class (not the T&F template, acceptable for double-anonymous review). Table captions ≤ 15 words. Five figures captioned with separate vector copies. Validation report passes 47/47.

## Top required changes

1. **Fix the Holm label-change count.** State that Holm control changes **two** labels relative to unadjusted 95% intervals (B1–B4 and B4–B5 both move from "excludes 0" to "includes 0"), and reconcile Sec 5.5, the Table S2 row "Family-wise error control," and the pairwise-results section so they all agree. The "changes one label (B4 unresolved against B1)" wording in two places is wrong.
2. **Address single-dataset generality head-on.** Either run a second (even small, non-seismic) corpus under the same contract, or explicitly position the paper as a single-corpus case study on page 1 and justify why a broad applied-AI venue should accept a one-corpus benchmark/method paper. Honest scoping is necessary but not sufficient.
3. **Reconcile the protocol's primary-result promise with what was delivered.** The frozen protocol named the split contrast the primary quantitative result, but no paired interval was retained. Either (a) compute and report a paired sequence-cluster interval for the split contrast now (clearly labelled post-hoc), or (b) reframe the protocol promise prominently on page 1 so the editor does not expect a delivered primary inferential result that is absent.
4. **Calibrate the usefulness claim to the evidence.** The only demonstrated decision-changing use is the single post-hoc seeded F2 candidate; the admissible-candidate comparisons change only one qualification label under Holm (B4 vs B1). Add a sentence quantifying how narrow the demonstrated decision change is.
5. **Make B4 vs B5 explicit in the qualification narrative.** The unadjusted B4–B5 lower endpoint (0.0003) sits at the 1/2000 bootstrap resolution boundary and the Holm/Bonferroni interval includes zero; the qualification narrative should state that B4 vs B5 is unresolved, not only B2 vs B5.

## Verdict
**Major revision (borderline).** Carefully executed, honestly disclosed, and reproducible, but the contribution is a fail-closed combination of established pieces on a single dataset with post-hoc headline analyses and one verbal label-count error. No hard veto blocks (no fabricated citation, no blinding breach, no overclaim, honest de-scoping), but low novelty, single-corpus scope, unexecuted protocol primaries, and the Holm-count inconsistency keep this below the acceptance bar for a broad applied-AI venue. **Total 20/30.**
