# Review (GLM-5.2, Round r8) — Independent Default-Reject

**Manuscript:** *A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study*
**Venue:** Cybernetics and Systems (Taylor & Francis) — applied AI/ML and decision systems
**Verdict:** **default-reject**
**Total score:** **25 / 30**

## SHA-256 verification (passed)

| File | Expected | Computed |
|---|---|---|
| `main.pdf` | `36d4dd33…cd606` | match |
| `main.tex` | `485f0bd0…484ee` | match |
| `supplement.pdf` | `bbecffb6…287da` | match |

## Criterion scores (0–3)

| Criterion | Score |
|---|---|
| cbs_venue_fit | 2 |
| novelty | 1 |
| soundness | 2 |
| numeric_integrity | 3 |
| claim_calibration | 3 |
| editor_page_1 | 3 |
| reproducibility | 3 |
| related_work_citations | 3 |
| formatting_blinding | 3 |
| usefulness | 2 |
| **Total** | **25 / 30** |

## Vetoes

None triggered.

- `fabricated_citation`: **no** — gao2026msbnet (Cybernetics and Systems, DOI 10.1080/01969722.2026.2723278, "2.15 percentage points" confirmed) and knap2026leakagesafe (PHM Society European Conference 9(1):1–8, 2026, DOI 10.36001/phme.2026.v9i1.4924, three repeated seeds confirmed) both web-verified as real; 46 bib entries = 46 citation-ledger entries, all resolve.
- `numeric_mismatch`: **no** — every checked number reproduces the frozen JSON (see §"Numeric checks").
- `blinding_breach`: **no** — main text is blinded ("Blinded for Anonymous Peer Review"); author identities, affiliation, email, and repository URL appear only on the separate `title_page.tex`; `build_ledger.json` is build metadata, not part of the manuscript PDF. `cbs_validation_report.json`: `main_text_blinded=true`, `title_page_carries_identities=true`.
- `clearly_out_of_scope`: **no** — the paper targets applied AI/ML and decision systems and engages five Cybernetics and Systems precedents.
- `unsupported_overclaim`: **no** — claims are carefully hedged; no winner, no equivalence, no leakage-detection, no operational, no universal-recommendation claim.

## Verdict rationale

The execution is unusually careful: impeccable numeric integrity, excellent reproducibility and claim calibration, a page-1 abstract that is technically accurate and explicitly post-hoc/single-corpus, correct blinding, and verified citations. The new paired Brier-loss cluster-robust inference (d_ig, U_g, CR1 G/(G−1), t(G−1), G=354, Holm step-down over ten p-values) **does resolve the prior invalid ordinary-bootstrap-tail p-value concern** by demoting the uncentred bootstrap tail to a descriptive legacy sensitivity and adopting a proper cluster-robust paired t-test as primary.

The reject rests on **novelty and empirical contribution**, not on a defect:

1. **Incremental novelty.** The authors state plainly that the constituent pieces (hashed versioning, two-field allowlist, sequence-grouped roles, temporal holdout, fixed baselines, cluster-robust paired Brier intervals, Holm) are established separately; the contribution is their fail-closed *combination* on one frozen corpus (main.tex lines 240–258). No new classifier, no new statistical method, no new dataset beyond a single frozen DYFI snapshot.
2. **All inference is post-hoc.** The Holm family, robustness families, seeded candidates, and split-contrast intervals were all specified after the holdout was opened (main.tex lines 636–640, 818–822). The family-wise error control is therefore illustrative, not confirmatory.
3. **Magnitude-dominated endpoint with no admissible-winner reversal.** B1 (magnitude-only) AUROC 0.719 vs B2 (source-only) 0.786; the top admissible models B2/B4/B5 are mutually unresolved (B2–B4 p=0.0485, B2–B5 p=0.827, B4–B5 p=0.0350; all not rejected under Holm). The only conclusion the contract reverses is the by-construction rejection of the seeded candidate, which an allowlist blocks by definition.
4. **Cluster-robust framing is over-sold for this corpus.** With ~1.2 events/sequence (430 events / 354 sequences; 1930 / 1530 in construction), the CR1 G/(G−1) correction is 354/353 ≈ 1.003 — near-negligible — so the test is effectively a paired t-test on 354 nearly-independent events, and the independent-sequence assumption is largely unexercised.

## Numeric checks (all passed)

- **Seven Holm rejections** over the ten-pair family (`family_wise_sensitivity.json` `n_holm_reject=7`): B0–B1, B0–B2, B0–B4, B0–B5, B1–B2, B1–B4, B1–B5. Main text line 369–370 matches.
- **Six Bonferroni 99.5% t intervals exclude zero** (`n_bonferroni_exclude_zero=6`): B0–B1, B0–B2, B0–B4, B0–B5, B1–B2, B1–B5. Main text line 370 matches.
- **B1–B4**: `cluster_robust_p_two_sided=0.010855349147`, `holm_threshold=0.0125`, `holm_rejects_zero=true`; Bonferroni CI `[−0.001188392477, 0.02425368183]` includes zero. Main text "p=0.0109, rank-specific threshold 0.0125 ... simultaneous interval (−0.0012 to 0.0243) includes zero" matches.
- **B4–B5 unresolved**: p=0.034959417716, Bonferroni CI `[−0.00175282309, 0.012238101404]`, not rejected (threshold 0.01667). Main text "p=0.0350; −0.0018 to 0.0122" matches.
- **B2–B4 / B2–B5 unresolved**: p=0.048519812716 (threshold 0.025) and p=0.826880333639 (threshold 0.05), both not rejected. Matches main text.
- **C_F2** (seeded): Brier 0.172389679459, AUROC 0.809276270503, log-loss 0.515321511554; paired Brier intervals exclude zero vs B0/B1/B4/B5 and include zero only vs B2 (prob better 0.965). Extended 15-pair Holm family supports C_F2 vs B0/B1/B4 only and makes admissible B1–B4 unresolved. Matches main text lines 681–693.
- **Robustness**: 50/100/200 km Brier families, seven-pair reference family, and log-loss family all give the same seven labels; AUROC family explicitly `null-centered paired sequence-cluster bootstrap (exploratory)` with seven rejections (`robustness_post_hoc.json`). Matches main text lines 376–381.
- **Split contrast**: sequence−random Brier −0.005878207034 (CI `[−0.0119, 0.0005]`), AUROC +0.012396868243 (`[−0.0019, 0.0266]`), log-loss +0.006858981987 (`[−0.127, 0.148]`); event-grouped−random Brier −0.003959156831 (`[−0.0097, 0.0023]`). All include zero. Matches main text lines 559–566.
- **Cohort**: 7520 → 2362 eligible (703 severe) → 1573/357/430 + 2 straddle; 702 severe role-assigned. Matches `asset_inputs.json` and `cohort_roles.tex`.
- `cbs_validation_report.json`: 53/53 checks pass, `overall_pass=true`.

## Required changes fixable in this study

1. **Standardize B1–B4 p precision** across main text (0.0109), Table S1 (0.011), and overlay (0.010855) to one rounding to avoid the appearance of inconsistency.
2. **Soften the cluster-robust framing**: state that with ~1.2 events/sequence the CR1 correction is near-negligible and the test is effectively a paired t-test on 354 nearly-independent events; report max cluster size and effective sample size so the independent-sequence assumption is quantified, not just asserted.
3. **Clarify "B4 versus B1 lower endpoint 0.0023"** to "the B1–B4 95% interval lower bound is 0.0023" to avoid misreading as a near-zero equivalence margin.
4. **Add a one-line note** that the seeded-candidate reversal is by construction (an allowlist rejects every undeclared field), so the demonstration validates gate *operation*, not detection power against unknown contamination.
5. **Address the 6 underfull hboxes** in the abstract region if a camera-ready is prepared (cosmetic only; no overfull/clipped content).

## Limitations requiring new data (not fixable in this study)

- A **second, non-seismic dependent-event corpus** to test generalization beyond DYFI (currently "reuse on other catalogues is untested").
- A **preregistered (prospective) replication** so the Holm/cluster-robust p-values become confirmatory rather than post-hoc.
- A **non-magnitude-dominated task** where the contract could change a real model-adoption decision among admissible candidates.
- A **fresh hidden holdout or independent evaluation service** for any confirmatory superiority claim (public labels permit tuning to this release).
- A **re-declustered benchmark** (not just re-clustering bootstrap units) to support any aftershock-isolation robustness claim.

## Positive aspects (acknowledged)

- The new cluster-robust paired Brier inference correctly resolves the prior invalid ordinary-bootstrap-tail p-value concern; the bootstrap tail is retained only as a descriptive legacy sensitivity.
- Bootstrap percentile intervals and P(A better) are clearly labelled descriptive, not null p-values.
- Robustness families (50/100/200 km, reference-only, log-loss) give the same seven labels; AUROC is explicitly exploratory/null-centred.
- The 15-pair seeded family supports C_F2 only vs B0/B1/B4 and makes B1–B4 unresolved; seeded results are framed as a by-construction allowlist-policy illustration, not contamination detection.
- The prospective versioned schema-extension workflow is operationally clear and not claimed to have been evaluated.
- Abstract is technically accurate, concise (217 words), fully on page 1, and explicitly post-hoc/single-corpus.
- Supplement Table S2 is complete across pages with repeated headers; Table S5 no longer contradicts the main text; Table S1 prints simultaneous Bonferroni 99.5% t intervals and cluster-robust p-values; no clipped/overfull content.
- Knap repeated-seed wording, signed −0.0040 event-group difference, release/archive distinction, and Patelli correction are all present and correct.
- No universal/task-agnostic recommendation remains.
- Blinding is correct; identities and repository URL live only on the separate title page.

## Top required changes (summary)

1. Strengthen novelty/generalization with at least one second corpus or a genuinely new methodological component; otherwise the paper is an incremental combination on a single frozen corpus.
2. Make the primary inferential analysis confirmatory via a preregistered replication (the current Holm/robustness/seeded/split-contrast analyses are all post-hoc).
3. Demonstrate the contract on a non-magnitude-dominated task where it changes a real admissible-model adoption decision (the current top models are mutually unresolved).
4. Quantify the cluster-robust correction's effect (max cluster size, effective sample size) and temper the "cluster-robust" framing given ~1.2 events/sequence.
5. Minor: standardize B1–B4 p rounding and clarify the "lower endpoint 0.0023" wording.
