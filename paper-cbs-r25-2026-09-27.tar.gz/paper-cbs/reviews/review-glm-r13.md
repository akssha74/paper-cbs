# Independent Review — `review-glm-r13`

**Reviewer:** GLM-5.2 (independent, default-reject posture)
**Venue:** Cybernetics and Systems (Taylor & Francis), double-anonymous
**Manuscript:** *A Fail-Closed Qualification Contract for Fixed-Schema Classifier Comparison: A Versioned Seismic-Catalogue Case Study*
**Date:** 2026-09-27 | **Round:** r13

---

## 1. Verification performed

**SHA-256 (all targets verified bit-for-bit):** `main.pdf` 51e2734…0e68; `main.tex` 0589c91…fa2b; `supplement.pdf` 77cb18c…4a3a; `supplement.tex` 0f2b5ef…e395; `references.bib` a2e1f75…05ad; `build_ledger.json` cc8dbb1…ab62; `frozen_inputs/contract_transfer_dbmi.json` 5e76d7b…a002; `contract-transfer-dbmi/prereg/analysis_plan.md` dbc2b6a…bfe. All match.

**Validator:** re-ran `validate_cbs.py` with `/tmp/dyfi-analytics-venv/bin/python` → **57 checks, 0 failed, PASS.**

**Transfer preregistration chronology (git log):**
- `c5136429` 2026-09-26 23:46:51 — freeze preregistration before scoring (FIRST)
- `e187ddf7` 2026-09-26 23:47:59 — one-shot runner (pre-execution)
- `ffc6065e` 2026-09-26 23:48:10 — fix import path (pre-execution)
- `396ef501` 2026-09-26 23:48:58 — one-shot result, fail-closed (LAST)

Preregistration committed **before** the runner and the result. `run_transfer.py` (lines 162-163) refuses to overwrite existing results; (lines 243-250) writes results and returns early when the holdout is below the evaluability floor, fitting/scoring/testing nothing. Matches the manuscript's fail-closed claim exactly.

---

## 2. Section 5.7 transfer — text vs `results.json`

| Claim in text | `results.json` | Match |
|---|---|---|
| 382 instrumental-provenance events (1905–2020) | `n_instrumental_labelled=382`, range 1905–2020 | yes |
| Cutoff Y\* = 2005 | `cutoff_year=2005` | yes |
| 312 construction / 218 sequences (44 multi-event, largest 14) | `construction.n_events=312, n_sequences=218, n_multi_event_sequences=44, largest=14` | yes |
| 70-event holdout / 62 sequences (55 singletons, largest 3) | `holdout.n_events=70, n_sequences=62, n_singletons=55, largest=3` | yes |
| 21 severe, 49 not severe; no straddles | `holdout_positives=21, holdout_negatives=49, straddle_events=0` | yes |
| 2,756 of 3,138 (87.8%) macroseismic/mixed magnitude | `n_non_instrumental_with_label=2756`; 2756/3138=0.878 | yes |
| 1,985 intensity points; 571 weighted inst.–macroseismic; 200 epicentral/other | `Mdm=1985, Wmim=571, MIo=186+Mpc=13+Mio=1=200` | yes |
| Spearman 0.755 (macroseismic) vs 0.300 (instrumental) | `spearman_mw_imax_macroseismic=0.7554, spearman_mw_imax_instrumental=0.3000` | yes |
| Holdout below 100-event floor → nothing fitted/scored/tested | `cohort.evaluable=false` (70 < 100) | yes |

**Fail-closed evaluability refusal:** honestly reported; no qualification decision issued. **Prior-exposure disclosure:** the analysis plan (§2) discloses the earlier descriptive `transfer-dbmi` arm (random 70/30, all eras, `ImaxNum>=7`, B1/B2 only) and confirms no temporal-holdout/instrumental/`ImaxNum>=6`/tree/paired/seeded result had been computed; correctly framed as a preregistered transfer on public data, not a hidden-holdout confirmation. **Provenance-binding lesson:** supported and not overclaimed (87.8% + 0.755-vs-0.300 empirically justify binding provenance to name). One attribution nuance — see F1.

---

## 3. Other reviewer-priority checks

- **Related-work delta (TFX/Breck/TFMA):** cleanly separated — TFX point-metric blessing (Baylor 2017), schema/data validation (Breck 2019), TFMA Poisson-bootstrap/jackknife intervals (tfma2026); text states none applies a paired dependence-aware family-wise test or binds an admitted field to provenance.
- **Figure 3 (`fig_threshold_slice`) caption:** explains the prevalence series ("severe-class prevalence (dashed grey)") and the dotted 6.0 line ("dotted vertical line marks the primary cutoff 6.0"); figure values match text (2023 n=250 Brier 0.185/AUROC 0.797; 2024 n=180 Brier 0.174/AUROC 0.777).
- **Abstract:** 200 rendered words (validator), at the ≤200 limit; conveys goal, pain point, contribution, evidence, venue framing; independent abstract-story gate passed.
- **32-page main:** confirmed (`kMDItemNumberOfPages = 32`); single-column, double-spaced, line-numbered.
- **57/57 validator:** confirmed by re-run.
- **Blinding:** main text fully blinded; identities only on `title_page.tex` (excluded per review instructions). No reviewer-facing leak.
- **Cohort reconciliation:** 703 = 449 (train) + 102 (dev) + 151 (holdout) + 1 (straddle); 2,360 role-assigned events contain 702 severe.
- **Citations:** 57 bib entries; all resolve and all are cited; `citation_ledger.jsonl` records per-entry verification (Crossref/OpenAlex/DOI/ACM/MLSys/source-file) dated 2026-09-26. No fabricated citation.
- **Reconstruction gate:** `family_wise_sensitivity.py`, `seeded_candidate_demo.py`, `robustness_post_hoc.py` each verify the prediction digest and reproduce frozen 95% intervals before emitting.

---

## 4. Scores (0–3 each, /30)

| Criterion | Score | Notes |
|---|---|---|
| `cbs_venue_fit` | 3 | Decision-support evaluation contract for applied ML; cites in-venue precedents (SAG, praveena, gao2026msbnet). |
| `novelty` | 2 | Fail-closed combination of established pieces; provenance-bound admission is the most novel element. Defensible but incremental. |
| `soundness` | 2 | Appropriate machinery (CR1 paired Brier, Holm, CR3, wild-cluster) with honest limitations; cluster correction lightly exercised on primary corpus; paired layer single-catalogue. |
| `numeric_integrity` | 3 | Every number traces to a frozen artifact and cross-checks; 57/57 validator; transfer matches `results.json`. |
| `claim_calibration` | 2 | Carefully hedged throughout; one attribution gap (F1: Spearman 0.755 on 2,185 attributed to "those events" = 2,756). |
| `editor_page_1` | 3 | 200-word abstract, story gate passed, goal/users visible before methods. |
| `reproducibility` | 3 | Hash-pinned inputs, build ledger, pinned env, digest-gated scripts, transfer prereg+hash manifest, clean git chronology. |
| `related_work_citations` | 3 | Delta clear; TFX/Breck/TFMA separated; 57 entries verified, all cited. |
| `formatting_blinding` | 3 | 32 pp, single-column double-spaced line-numbered, blinded main, 4 captioned main figures, vector figures, ≤15-word table titles. |
| `usefulness` | 2 | Real decision-support harness with a prevented-conclusion demonstration; bounded by non-operational scope and single-catalogue paired layer. |
| **Total** | **26/30** | |

---

## 5. Vetoes

| Veto | Triggered | Reason |
|---|---|---|
| `fabricated_citation` | No | All 57 entries verified in `citation_ledger.jsonl`. |
| `numeric_mismatch` | No | All numbers trace and cross-check; F1 is an attribution/wording gap, not a numeric mismatch (0.755 is correct). |
| `blinding_breach` | No | Main text blinded; `title_page.tex` excluded per instructions. |
| `clearly_out_of_scope` | No | In scope for Cybernetics and Systems. |
| `unsupported_overclaim` | No | Claims hedged as post-hoc, non-operational, non-confirmatory, single-catalogue, marginal/family-dependent where applicable. |

**No veto triggered.**

---

## 6. Findings

**F1 — Spearman attribution (minor, claim_calibration).** §5.7 Admission (~lines 740-748). Text: 2,756 (87.8%) have macroseismic/mixed magnitude, then "For those events, magnitude tracks the label (Spearman 0.755…)". But `results.json` computes `spearman_mw_imax_macroseismic=0.755` on `n_macroseismic=2,185`, **excluding** the 571 `Wmim` mixed events. The 0.755 is for a strict subset (2,185) of "those events" (2,756); the `n` and exclusion are not disclosed. Direction is conservative, so the lesson holds — but attribution is loose. **Fix:** state 0.755 is on the 2,185 purely-macroseismic events (excluding 571 mixed), give `n`, or report a separate mixed-group correlation.

**F2 — Cluster-robust correction lightly exercised (minor, soundness).** §4.4 (lines 449-453), Limitations. 312/354 holdout sequences are singletons, `G/(G-1)=1.003`, so CR1 ≈ event-level paired `t`. Mitigated by CR3, wild-cluster bootstrap, 5°/10° regional re-clustering, but primary dependence-aware claim rests on a corpus with minimal within-sequence dependence. Honestly disclosed. **Fix:** frame the dependence-aware layer as demonstrated mainly via regional re-clustering and the transfer catalogue (44 multi-event construction sequences, largest 14).

**F3 — Paired-decision layer is single-catalogue (minor, soundness/usefulness).** §5.7, Limitations (lines 851-853). Transfer tested admission/evaluability only; 70-event holdout < 100 floor, so paired Holm layer exercised on exactly one catalogue. Fail-closed refusal is honest, but central statistical contribution is single-catalogue. **Fix:** (a) a prospective third-catalogue transfer with a larger instrumental holdout, or (b) make the headline claim match the Limitations boundary.

**F4 — Novelty is incremental (minor, novelty).** §2 (lines 219-265). Contribution is a fail-closed combination of established pieces (schema allowlisting, version pinning, cluster-robust paired tests, Holm). Provenance-bound admission is the most genuinely novel element. **Fix:** lead the novelty claim with the provenance-bound admission rule as the primary new artifact, empirically motivated by 87.8% / 0.755-vs-0.300.

**F5 — Abstract B4 marginality implicit only (trivial, claim_calibration).** Abstract omits B4 from the "supported over magnitude-only" list and describes it above as "marginal and family-dependent"; accurate but B4 is not named as the marginal case in the abstract. **Fix:** optional clause; current wording is not wrong.

**F6 — B2–B4 boundary disagreement (trivial, numeric_integrity).** §4.4, `pairwise_matrix.tex`. B2–B4 percentile interval includes zero `[-0.0118, 0.0002]` while CR1 `p=0.0485`; manuscript flags this and states "only the tests decide." Correctly handled. **Fix:** none needed.

---

## 7. Top required changes to raise each sub-3 criterion to 3

- **novelty (2→3):** Reposition the provenance-bound admission rule (allowlist must bind field provenance, not just name) as the primary novel artifact — the one element not already in TFX/TFDV/TFMA or prior leakage/paired-comparison work, empirically motivated by 87.8% intensity-derived/mixed magnitudes and the 0.755-vs-0.300 Spearman contrast.
- **soundness (2→3):** (a) Reframe the dependence-aware layer as demonstrated mainly via regional re-clustering (larger clusters) and the transfer catalogue (44 multi-event construction sequences), since the default 354-sequence holdout is 88% singletons; (b) add a prospective third-catalogue transfer with a larger instrumental holdout so the paired Holm decision layer is exercised on a second, dependence-rich corpus.
- **claim_calibration (2→3):** Fix the Spearman attribution in §5.7 — state that 0.755 is computed on the 2,185 purely-macroseismic events (excluding the 571 `Wmim` mixed), give the `n`, and tighten the referent of "those events" (or report a separate mixed-group correlation).
- **usefulness (2→3):** Demonstrate the paired-decision layer on a second catalogue with an evaluable holdout (the Italian transfer was correctly refused but leaves the headline method single-catalogue), and add a worked example of a maintainer extending the schema via the prospective version-bump procedure (described but not executed) to show the reuse pathway concretely.

---

## 8. Recommendation

**Minor revisions.** The default-reject posture is cleared: no veto, all SHA-256 targets verified, 57/57 validator passes, transfer preregistration precedes results in git history, and Section 5.7 matches `results.json` exactly (including the honest fail-closed evaluability refusal). The residual issues (F1–F4) are scoping and calibration, not integrity. F1 (Spearman subset attribution) is the one concrete text fix; F2–F4 are framing/scope improvements that would lift soundness, novelty, and usefulness to 3.
