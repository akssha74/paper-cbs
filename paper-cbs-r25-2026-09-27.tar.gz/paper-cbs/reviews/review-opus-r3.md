# Independent default-reject review, R3: Cybernetics and Systems

**Manuscript:** *A Fail-Closed Qualification Contract for Comparing Machine-Learning Classifiers on Versioned, Dependent Event Data: A Seismic Felt-Intensity Case Study*
**Reviewed:** current `main.pdf` (31 pp., built 20:22) + `supplement.pdf`. Text was re-extracted from the PDF because `main.txt` is stale. Earlier-round scores were ignored and no manuscript files were edited.

**Total: 18 / 30. Verdict: MAJOR REVISION. The default-reject stands for this round.**

## Summary

The paper releases a frozen USGS DYFI benchmark (7,520 records → 2,362 eligible events → 430-event 2023–2024 holdout) and a "qualification contract". A candidate is admitted only under a two-field magnitude+depth allowlist with outcome-independent sequence-grouped roles, and an improvement is supported only when a paired sequence-cluster Brier interval excludes zero. The numbers are accurate and the provenance is exemplary. Most of the R3 fixes landed. However, the split-diagnostic fix was not carried into the Discussion and Conclusion. Also, the manuscript silently reverses the frozen protocol's designation of the primary result. The contribution is also thin for a selective venue: no component is new, and the "dependent data" capability in the title is not shown to change any decision.

## Veto check

| Veto | Triggered | Basis |
|---|---|---|
| Fabricated citation | No | 42 ledger entries with DOI/URL verification; no fabricated item found (not all re-fetched this round). |
| Numeric mismatch | No | Every value checked against `frozen_inputs/asset_inputs.json` matches (see below). |
| Blinding breach | No | Author field says "Blinded"; no Author field in the PDF or figure metadata; no names, paths, or repository URLs in the text; identities appear only in `title_page.tex`. |
| Out of scope | No | Fits the journal's "Applied AI/ML" and "Decision Making" areas. |
| **Unsupported overclaim** | **Yes (narrow, fixable)** | Discussion p.22 l.404–406: "small and slightly reversed … the naive random split did not inflate the diagnostic score". Conclusion p.24 l.450–451: "small and reversed … supplies no evidence of random-split optimism". Section 5.3 l.306–307 says no sign claim, *including "slightly reversed"*, is supported. Table 4 log-loss favours the random split (0.9640 vs 0.9709), so "did not inflate" is contradicted by the paper's own data. |

## R3 fix verification

| Requested fix | Status |
|---|---|
| B1 not claimed to beat itself | PASS. The abstract parenthetical "(B1 cannot improve on itself)" is awkward. |
| Four learned models beat B0 | PASS. All four intervals exclude 0. |
| Only B2/B4/B5 beat B1 | PASS: [0.0101, 0.0249], [0.0023, 0.0205], [0.0055, 0.0273]. |
| "Unsupported winner", not "false winner" | PARTIAL. Table 1 still says "False model-superiority claim". |
| B1 comparisons labelled exploratory/unadjusted | PASS. Discussion l.395 "beat B1" is unlabeled. |
| Leakage audit demoted to two-field allowlist | PARTIAL. Contribution 2 is fixed. Section 4.1 is still titled "six-category leakage audit" and says it "enforces six leakage families"; Table 1 still lists "Label leakage/Proxy leakage" controls. |
| Split diagnostic has no sign inference | **FAIL**. Section 5.3 prose is fixed, but l.316 "indicates fold-allocation noise", Discussion l.404–405 and Conclusion l.450–451 still make sign or inferential statements. |
| Log-loss 0.9709 vs 0.9640 disclosed | PASS. |
| Event-grouped is a second allocation, not a control | PARTIAL. The prose is fixed, but the Table 4 row is still labelled "(control)" and the sequence-grouped row "(primary)". |
| Intercept not treated as calibration-in-the-large | PASS, but the stated reason is wrong: a joint-fit intercept is never CITL, whatever the slope. |
| Two (not three) changed decisions | PASS. |
| Provenance numbers in `claim_ledger.jsonl` | PASS. P_* entries match `source_locator_manifest.json`, and 110 tests were recounted as 35+20+24+31. |

## Scores

| # | Item | Score | Reason |
|---|---|---|---|
| 1 | Scope / venue fit | 2 | Applied-AI decision harness; thin systems/cybernetics content. |
| 2 | Novelty / contribution | 1 | "No component is claimed as new." Of the two changed decisions, B3's ineligibility follows tautologically from the allowlist, and "B2 vs B5 unresolved" is standard paired-bootstrap practice. |
| 3 | Significance / demonstrated usefulness | 1 | The dependence control is in the title but not shown to matter (1.26 events/sequence; split diagnostic null and mixed across metrics). Single dataset with a magnitude-dominated endpoint. |
| 4 | Methodological soundness | 2 | Sound design, clearly stated conditional estimand. Weaknesses: post-hoc primary comparison, no multiplicity adjustment, a single sequence definition. |
| 5 | Numeric accuracy / traceability | 3 | All values match. |
| 6 | Claims–evidence alignment | 1 | Sign inferences in the Discussion and Conclusion contradict Section 5.3 and the log-loss result. The "fold-allocation noise" claim has no interval. |
| 7 | Protocol adherence / disclosure | 1 | The primary result was switched without disclosure (see below). Other deviations are disclosed well. |
| 8 | Statistical reporting | 2 | Good Monte Carlo caution and no equivalence claims. The calibration reasoning is incorrect. |
| 9 | Reproducibility / provenance | 3 | Hash pinning, fit ledger 91/120, bit-for-bit reconstruction, corrections overlay. |
| 10 | Presentation / format / blinding | 2 | Blinding is clean. Wording from before R3 remains in Table 1, Section 4.1 and Table 4. The abstract is dense (~262 words). |

## Major issues

1. **Split-diagnostic sign inference persists (R3 fix incomplete).** Section 5.3 correctly says that without a paired interval no sign claim is supported. The Discussion and Conclusion then state "slightly reversed", "reversed", "did not inflate the diagnostic score" and "no evidence of random-split optimism". Log-loss moves the other way (random 0.9640 is better than sequence 0.9709). Section 5.3 also asserts that the 0.0039 event-vs-random Brier gap "indicates fold-allocation noise", which is an inference with no interval.
2. **Undisclosed primary-result switch.** `preregistration/frozen_preregistration.json` → `leakage_inflation_headline.status` reads: "this is the resource's primary quantitative result". The preregistration markdown §8 is headed "Leakage-inflation headline (primary quantitative result)". The manuscript calls it "a secondary split-assignment diagnostic … not as a headline result" (abstract; Contribution 6; Section 5.3). It also promotes "B2 versus B0" to "the primary learned-versus-reference comparison" (abstract; Sections 4.4 and 5.5), which the protocol never designated. Table S2 does not list either change, yet its note claims "These decisions were recorded before, or disclosed with, the analysis." For a paper whose thesis is fail-closed, pre-declared comparison, this must be disclosed.
3. **Residual over-framing of the leakage audit.** Contribution 2 correctly demotes the audit to a two-field allowlist. Section 4.1's title, the "six leakage families" text, Section 3's "enforced by the leakage audit (family F2)", and Table 1's "Label leakage / Proxy leakage" rows still present it as a general leakage detector.
4. **Limited demonstrated value for the venue.** The usefulness evidence is two decision changes, one tautological. The dependence handling promised in the title is untested in any regime where it could matter.

## Minor issues

- Table 1: "False model-superiority claim" → "Unsupported model-superiority claim".
- Table 4: "Event-grouped (control)" → "(second allocation)". Drop "(primary)" from the sequence-grouped row, or explain it.
- Section 5.4 l.326–327: change the reason. A joint intercept is not CITL for any model. If under-prediction is to be discussed, report CITL (slope fixed at 1) or the observed/expected ratio.
- Abstract: replace "(B1 cannot improve on itself)" with a positive statement, and verify the journal's abstract limit.
- Section 5.5 l.337: say "supports improvement of B2, B4 and B5 over B0 and over B1".
- Section 5.5 l.343: list the versus-B1 intervals as exploratory, consistent with Section 4.4.
- Discussion l.395: label "beat B1" as exploratory and unadjusted.
- Optional: add a Holm or simultaneous sensitivity analysis for the 10 pairs. B4–B5 (lower endpoint 0.0003) and B1–B4 (0.0023) are fragile.

## Numbers verified against `asset_inputs.json`

- Cohort and roles: 7520, 2362, 703, 0.298, 1885 sequences, 1573/357/430/2, 449/102/151/1, 1530/354 sequences.
- Table 5: all per-baseline values. Recall 0.25–0.37.
- Tables 6 and S1: all pairwise deltas, intervals and P(A better). Joint-ordering values 0.613 and 0.387.
- Table 3.
- Table 4 and its gaps (0.0059, 0.0124, 0.0039).
- Table S3: temporal and geographic slices (82 cells, 0.002–0.825, median 0.151).
- Fit budget 91/120.
- Provenance values: 7575→7576, 7520, 50 s, 56.
- 110 unit tests.

No mismatches.

## Top required changes

1. Remove the split-diagnostic sign and inference language from the Discussion, the Conclusion and Section 5.3 l.316. Report the three metrics' point estimates and note that they disagree in direction.
2. Disclose the primary-result reclassification in Table S2 and Section 5.8. Either drop "primary" for B2 vs B0 or label it as a post-hoc designation.
3. Finish the wording fixes in Table 1, Table 4 and Section 4.1 (allowlist, not a six-family leakage detector).
4. Correct the calibration-intercept reasoning.
5. Demonstrate that the dependence control changes a decision in at least one setting (a seeded or second corpus), or narrow the title and claims.
