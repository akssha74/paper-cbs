# Independent Review (Round R5) — GLM-5.2

**Submission:** *A Fail-Closed Qualification Contract for Comparing Machine-Learning Classifiers on Versioned Event Data: A Seismic Felt-Intensity Case Study*
**Target venue:** Cybernetics and Systems (Taylor & Francis)
**Stance:** Independent default-reject reviewer. No prior-round review JSON consulted for scores; this review is grounded only in the manuscript (`main.pdf` extracted text), `frozen_inputs/asset_inputs.json`, `cbs_validation_report.json`, `references.bib`, and `build_ledger.json`.

---

## Verdict: **Reject** (25 / 30)

| # | Criterion | Score (0–3) |
|---|---|---:|
| 1 | CBS venue fit | 2 |
| 2 | Novelty | 1 |
| 3 | Soundness | 2 |
| 4 | Numeric integrity | 3 |
| 5 | Claim calibration | 3 |
| 6 | Editor / page-1 clarity | 3 |
| 7 | Reproducibility | 3 |
| 8 | Related work / citations | 3 |
| 9 | Formatting / blinding | 3 |
| 10 | Usefulness | 2 |
| | **Total** | **25 / 30** |

Execution is genuinely strong — top marks for numeric integrity, claim calibration, reproducibility, blinding, citations, and page-1 clarity. The rejection rests on **contribution-level** grounds, not execution defects. Two r4 calibration defects are fixed in this revision (see below), but the substantive novelty and single-dataset limitations are unchanged.

---

## Hash verification (observed vs. claimed)

- `main.pdf` — claimed `d76c4793…6e507`, observed `d76c4793…6e507` ✓
- `main.tex` — claimed `6eb516ae…89f2d`, observed `6eb516ae…89f2d` ✓
- `supplement.pdf` — observed `53883e61…8268`, matches `build_ledger.json` ✓
- `build_ledger.json` `main_tex_sha256` / `main_pdf_sha256` both match the files above ✓

## Blinding check (main.pdf, not title_page)

I extracted the text of `main.pdf` (1,209 lines, 32 pages) and scanned for author names, affiliations, emails, and repository handles. **No identifying terms found.** Terms tested: `Akshay`, `Sharma`, `Prasad`, `SAGE`, `Indore`, `akssha`, `akssha74`, `github`, `akssha74@gmail`, `Lalji` — all zero hits. The author block reads "Blinded for Anonymous Peer Review." Identities are correctly confined to `title_page.tex`/`title_page.pdf`, which is a separate build absent from the blinded main PDF. **Blinding is clean.**

## CBS validation report

`cbs_validation_report.json` reports **43 checks, 0 failed, overall_pass = true** (meets the 42+ requirement). Notable passing checks: `main_text_blinded`, `title_page_carries_identities`, `title_page_abstract_matches_main`, `all_citations_resolve`, `all_bibliography_entries_cited`, `cbs_precedents_engaged` (5 precedents), `no_stale_venue_keys`, `qualification_b0/b2/b5_exact`, `qualification_unresolved_pair_exact`, `b3_scope_exclusion_demonstrated`, `r4_wording_residuals_absent`, `build_ledger_main_current`, `build_ledger_pdf_current_or_source_only`, `ai_use_disclosed`, `declarations_complete`, `non_use_boundaries_preserved`, `threshold_probe_not_robustness_claim`, `ascertainment_boundary_honest`, `null_and_no_winner_preserved`, `five_figures_captioned`, `separate_vector_figures_present`. The page-target check notes "32 (internal target; venue limit not verified)" — the venue page limit was not confirmed against the journal guidelines.

## r4 → r5 changes verified

Two r4 blocking/major calibration defects are fixed in this revision:

- **No task-agnostic claim (fixed).** The phrase "task-agnostic" no longer appears anywhere in `main.pdf`. The abstract now reads *"The seismic catalogue below is the only instantiation; generality beyond this dataset is untested,"* and Section 7 states *"No second, non-seismic dataset was evaluated, so reuse on other event catalogues is untested."* The prior overclaim is replaced by an honest, evidence-supported scope statement. ✓
- **Contribution framed as an executable contract, not "nothing is new" (fixed).** The phrase "No component is claimed as new" / "nothing is new" is absent. Section 2 now frames the contribution as *"their fail-closed combination as a reconstructable decision rule for this DYFI classification task,"* and the Conclusion frames it as *"an executable comparison-decision contract on this frozen DYFI task."* The contribution is now stated positively as an executable contract rather than as "nothing is new." ✓
- **Exploratory-supported labeling (present).** Used consistently in abstract, Sections 4.4, 5.5, 5.6, and the Discussion for unadjusted, non-multiplicity-controlled intervals. ✓
- **Split-diagnostic unskilled disclosure (present, in main text).** Lines 326, 429, 475: *"The diagnostic random forest is essentially unskilled on this construction sample"* / *"does not validate dependence handling"* / *"neither demonstrates leakage nor supports a win."* Disclosed in the main text, not only the supplement. ✓
- **Alvarez 2012 (present).** Reference [18] (`alvarez2012mmi`), DOI `10.1007/s10950-012-9291-x`, used in Section 2 to contrast prior DYFI-linked MMI prediction from PGA/PGV/magnitude/distance with the present event-level source-only classification. ✓

## Bibliography spot-check (sag2025optimization, praveena2025retail, alvarez2012mmi)

- **`sag2025optimization`** — Hossain & Sağ, *Cybernetics and Systems* **57(1):44–83**, 2025, note "Online 2025; print 2026", DOI `10.1080/01969722.2025.2588199`. Year and note internally consistent; in-text usage ("clustering optimizer with Wilcoxon and Friedman tests across ten datasets") matches the title. In-venue precedent [1]. *Minor:* the cite key derives from the second author (Sağ) while the first author is Hossain — cosmetic only.
- **`praveena2025retail`** — Praveena & Prasanna Devi, *Cybernetics and Systems* **57(1):1–43**, 2025, note "Online 2025; print 2026", DOI `10.1080/01969722.2025.2583968`. Year and note consistent; in-text usage ("stacked ensemble by point accuracy, precision, and recall") matches. In-venue precedent [2].
- **`alvarez2012mmi`** — Alvarez, Hurtado, Bedoya-Ruíz, *Journal of Seismology* **16(3):489–511**, 2012, DOI `10.1007/s10950-012-9291-x`. Year consistent; in-text usage (prior DYFI-linked MMI prediction from PGA/PGV/magnitude/distance with nonlinear algorithms) matches. Reference [18].

Five *Cybernetics & Systems* in-venue precedents are cited: [1] sag2025, [2] praveena2025, [23] gao2026, [24] hossack2004, [25] gomolka2000. `all_citations_resolve` and `all_bibliography_entries_cited` both pass with no failures.

## Numeric integrity — cross-check vs `frozen_inputs/asset_inputs.json`

Every result-bearing number I checked matches the frozen assets **exactly**. No mismatches found.

- **Cohort:** 7,520 frozen records; 2,362 eligible (703 severe, prevalence 0.2976); train 1,573 / dev 357 / holdout 430 with 449/102/151 severe; 2 temporal-straddle (1 severe); 1,885 / 1,530 / 354 sequences; reconciliation 449+102+151+1 = 703 ✓; construction prevalence 0.2855, holdout prevalence 0.3512 ✓.
- **Baselines (Brier / AUROC / 95% CI):** B0 0.232 / 0.500 [0.212,0.253]; B1 0.198 / 0.719 [0.177,0.219]; B2 0.181 / 0.786 [0.160,0.202]; B4 0.187 / 0.777 [0.168,0.206]; B5 0.181 / 0.783 [0.161,0.202] ✓.
- **Calibration (intercept/slope):** B1 0.32/1.02, B2 0.64/1.29, B4 0.74/1.48, B5 0.42/1.07 ✓.
- **Recall @ 0.5:** B1 0.25, B2 0.32, B4 0.29, B5 0.37 ✓ (range 0.25–0.37 as stated).
- **Threshold sensitivity (Brier/AUROC/prevalence):** 5.5 → 0.240/0.734/0.458; 6.0 → 0.181/0.786/0.351; 6.5 → 0.143/0.815/0.260 ✓. Near-threshold fraction 0.164; no-skill Brier floor 0.204 ✓.
- **Split diagnostic:** random 0.2048/0.6952/0.9640; event-grouped 0.2009/0.7058/0.9223; sequence-grouped 0.1990/0.7076/0.9709 ✓. Brier gap (seq−random) −0.0059; AUROC gap 0.0124; event-grouped Brier gap magnitude 0.0040 ✓ (the sign of the event-grouped gap is unstated in the text; the magnitude matches).
- **Pairwise (10 pairs):** all point-diffs and CIs match, including B2–B5 −0.0008 [−0.0078, 0.0068], B1–B4 lower endpoint 0.0023, B4–B5 lower endpoint 0.0003 ✓. Joint ordering: B2 prob-best 0.613, B5 0.387 ✓.
- **Slices:** 2023 n=250 Brier 0.185 AUROC 0.797; 2024 n=180 Brier 0.174 AUROC 0.777; geographic 82 cells, Brier 0.002–0.825, median 0.151 ✓.
- **Reproducibility counts:** fit_count 91 of 120 cap; n_verification_checks 87; unit tests 110 ✓.

## Confirmed booleans

- Blinding clean in main.pdf: **true**
- Hashes match claims: **true**
- `r4_wording_residuals_absent`: **true**
- Numeric claims match assets: **true**
- Bib years/notes correct for `sag`, `praveena`, `alvarez`: **true**
- Validation report 42+ checks passing: **true** (43/43)
- AI use disclosed: **true**
- Deviations disclosed in Supplement Table S2: **true**
- No-winner claim preserved: **true**
- Threshold probe not framed as robustness: **true**
- B3 scope-exclusion (not leakage) claim: **true**
- Task-agnostic overclaim removed (r5): **true**
- "Nothing is new" framing removed; executable-contract framing present (r5): **true**
- Alvarez 2012 cited: **true**
- Split-diagnostic unskilled caveat in main text: **true**

---

## Vetoes

**V1 — Insufficient novelty for a selective venue (blocking).** Section 2 and the Conclusion frame the contribution as *"their fail-closed combination as a reconstructable decision rule"* / *"an executable comparison-decision contract on this frozen DYFI task."* The framing is now an executable contract rather than "nothing is new" (an r4 fix), but substantively the pieces are established separately — Kapoor & Narayanan (leakage taxonomy + model information sheets), Demšar / Benavoli (Bayesian comparison), Roberts (blocked CV), Field & Welsh (clustered bootstrap) — and the release is their combination on one corpus. The endpoint is magnitude-dominated (magnitude-only AUROC 0.719; adding depth lifts it to 0.786), so the worked task is close to magnitude thresholding, and no winning model is claimed. Honest scoping does not by itself clear a selectivity bar that requires a new method or a new finding.

**V2 — Single-dataset evaluation; generality untested (major, non-blocking).** The r4 "task-agnostic" overclaim is removed; the abstract and Section 7 now state generality is untested and no second, non-seismic dataset was evaluated. This resolves the calibration defect but not the underlying limitation: the contract is demonstrated only on one DYFI corpus, so transferability rests on assertion rather than evidence. Downgraded from blocking (r4) to major because the overclaim is gone.

**V3 — Protocol-required analyses not executed (major, non-blocking).** Supplement Table S2 and Sections 5.2/5.8 disclose that the geographic leave-region-out evaluation, the aggregation-grid sensitivity, and the split-contrast paired interval were required by the frozen internal protocol but not executed. The split contrast is downgraded to descriptive point estimates (with the unskilled-diagnostic caveat now stated in the main text — an r5 improvement); the geographic result is only temporal-holdout subgroups. Disclosure is honest, but robustness remains under-demonstrated.

## Required changes

1. **Demonstrate a transferable methodological contribution beyond packaging:** either instantiate the contract on at least one second, non-seismic event catalogue and show the admit/reject and exploratory-supported/unresolved decisions change meaningfully, **or** reframe the contribution as a benchmark-resource paper and target a venue whose scope explicitly includes benchmark resources.
2. **Complete or convincingly de-scope the unexecuted protocol branches:** execute the geographic leave-region-out evaluation and the aggregation-grid sensitivity, or remove them from the protocol and replace the broader framing with a narrower, evidence-supported scope statement.
3. **Split-contrast handling:** either retain a paired sequence-cluster interval (the protocol required uncertainty) or keep the main-text statement that the contrast is descriptive and cannot support any sign or equivalence claim (already partly done in r5; ensure the protocol/manifest mismatch is fully reconciled).
4. **Strengthen venue-fit argumentation:** five *Cybernetics & Systems* precedents are cited, but the manuscript's core is ML evaluation methodology plus seismology data, so the page-1 framing should explicitly position the work within the journal's Applied AI / Decision Systems focus rather than as a seismology resource.
5. **Cohort-table display:** the "Severe rate" column shows "--" for the 2-event temporal-straddle row while `asset_inputs.json` records prevalence 0.5 for that stratum; either report it or add a footnote explaining the suppression for n=2.

## Minor issues

- Cite key `sag2025optimization` is derived from the second author (Sağ) while the first author is Hossain; a key like `hossain2025siberian` would be more discoverable.
- Main PDF is 32 pages; the validation report flags the venue page limit as "not verified." Confirm against *Cybernetics & Systems* author guidelines before submission.
- The event-grouped Brier "gap versus random-event assignment is 0.0040" is reported without a sign; the magnitude matches assets but the sign convention is unstated, which could mislead a reader about direction.
- The abstract reports AUROC 0.786 for B2 (source-only = magnitude+depth); a reader could briefly conflate it with B5 (0.783). Consider labeling the model in the abstract.

## Overall note

This is among the best-executed reproducibility/resource submissions I have reviewed: every result number I cross-checked (cohort, baselines, calibration, recall, threshold sensitivity, split diagnostic, all 10 pairwise comparisons, joint ordering, slices, reproducibility counts) matches `asset_inputs.json` exactly; both claimed hashes match; `main.pdf` is properly blinded; the validation report passes 43/43 checks; Alvarez 2012 is correctly cited; and the r4 "task-agnostic" and "nothing is new" defects are fixed, with the split-diagnostic unskilled caveat now disclosed in the main text. The rejection rests on **novelty, single-dataset generality, and unexecuted protocol branches** — not on execution defects. If the authors either (a) demonstrate the contract on a second dataset, or (b) retarget to a venue that explicitly welcomes benchmark/resource papers, the score could move into the accept range.
