# Independent default-reject review — GPT-5.6, round 8

## Recommendation

**Minor revision; 26/30. No veto is triggered.**

The new sequence-cluster-robust paired Brier analysis resolves the earlier statistical problem posed by treating an uncentred ordinary-bootstrap distribution as a null distribution. I found no numeric mismatch, fabricated citation, blinding breach, clear scope failure, unsupported universal claim, or result-changing defect. Three minor actions remain: correct one imprecise Table 1 label, engage the closest concurrent statistical-comparison work, and publish the current review-archive additions under the promised immutable release before publication.

## Version pin and independence

- Reviewer: GPT-5.6, independent default-reject review.
- Earlier-round review files were not read.
- The scientific tree was treated as frozen.
- Repository HEAD: `b3fcc66f77139194d9185eeb7f9db88039f27bd0`.
- The reviewed package is untracked at that repository HEAD, so this review is pinned to the supplied working-tree files and hashes.
- `main.pdf`: expected and observed SHA-256 `36d4dd33bbf44cfd982681e9f2896b42b89be30ec8f6bf9a3f897c10757cd606`.
- `main.tex`: expected and observed SHA-256 `485f0bd0aa6c86d85dbd5e7b4fca3058123b8e9d3503a5b16f1eeee7616484ee`.
- `supplement.pdf`: expected and observed SHA-256 `bbecffb622ad9b24a258a29308f25b4219b867b59cd89f00c2ec71f125a287da`.

## Scores

- `cbs_venue_fit`: **3/3**
- `novelty`: **2/3**
- `soundness`: **2/3**
- `numeric_integrity`: **3/3**
- `claim_calibration`: **3/3**
- `editor_page_1`: **3/3**
- `reproducibility`: **3/3**
- `related_work_citations`: **2/3**
- `formatting_blinding`: **3/3**
- `usefulness`: **2/3**
- **Total: 26/30**

The venue-fit score reflects the journal’s stated coverage of applied AI/ML, decision making, and environmental systems. Novelty is **defensible-beyond-incremental**, not a new statistical method: the established pieces are coupled into an executable, candidate-level admission and comparison contract, and the seeded example demonstrates a decision that score ranking would reverse. Soundness and usefulness remain below ceiling because the inference is post hoc and conditional on fixed fits and a heuristic independence unit, while the workflow has been demonstrated on one corpus only.

## Vetoes

- `fabricated_citation`: **false**
- `numeric_mismatch`: **false**
- `blinding_breach`: **false**
- `clearly_out_of_scope`: **false**
- `unsupported_overclaim`: **false**

## Goal and usefulness

The paper asks whether a fixed-schema classifier candidate is admissible and whether its paired Brier improvement is supported on one frozen, dependent-event temporal holdout. The contribution identity is a **protocol and benchmark case study**. Its intended users—applied-ML engineers, benchmark maintainers, and reviewers—receive two concrete outputs: admit/reject and Holm-supported/unresolved.

The substantive result is clear: all four admissible learned baselines are supported over B0; B2, B4, and B5 are supported over B1; B2–B4, B2–B5, and B4–B5 remain unresolved; and the best-scoring seeded response-count candidate is rejected before its score is used. The goal, intended use, error prevented, result, and non-use boundary are understandable from page 1 and the first two Introduction pages.

`goal_understood: true`  
`usefulness_understood: true`  
`abstract_story_pass: true`

## Statistical and numeric audit

### Paired Brier-loss inference

This check passes.

The manuscript defines

> “For pair \(a,b\), let \(d_{ig}=(y_{ig}-p_{a,ig})^2-(y_{ig}-p_{b,ig})^2\), \(\hat\theta=N^{-1}\sum_{g,i}d_{ig}\), and \(U_g=\sum_i(d_{ig}-\hat\theta)\).”

It then uses

> “\(\{G/(G-1)\sum_g U_g^2\}^{1/2}/N\)” and “\(t=\hat\theta/\mathrm{SE}\) against \(t_{G-1}\)”

with \(G=354\), independent sequences, arbitrary within-sequence dependence, and a large-\(G\) approximation. For an intercept-only event-weighted mean with fixed observed \(N\), this is the standard one-way CR1 score form. Holm step-down remains valid under dependence among the ten tests provided the marginal cluster-robust p-values are valid.

I independently recomputed the Holm order and thresholds from the stored p-values:

1. B0–B4: \(p=3.101\times10^{-9}\), threshold 0.005, reject.
2. B0–B2: \(p=7.985\times10^{-9}\), threshold 0.005556, reject.
3. B0–B5: \(p=1.13623\times10^{-7}\), threshold 0.00625, reject.
4. B1–B2: \(p=6.741252\times10^{-6}\), threshold 0.007143, reject.
5. B0–B1: \(p=0.000085537483\), threshold 0.008333, reject.
6. B1–B5: \(p=0.00313501731\), threshold 0.01, reject.
7. B1–B4: \(p=0.010855349147\), threshold 0.0125, reject.
8. B4–B5: \(p=0.034959417716\), threshold 0.016667, stop/not rejected.
9. B2–B4: \(p=0.048519812716\), not rejected.
10. B2–B5: \(p=0.826880333639\), not rejected.

Thus:

- seven Holm rejections are correct;
- six Bonferroni 99.5% \(t\) intervals exclude zero;
- B1–B4 has exact \(p=0.010855349147\) and passes its rank-specific 0.0125 threshold even though its simultaneous interval \([-0.0011884,0.0242537]\) includes zero;
- B2–B4, B2–B5, and B4–B5 are correctly unresolved.

I also independently reconstructed every 99.5% interval from the reported point estimate, CR1 standard error, and \(t_{353}\) critical value. All matched the JSON values within rounding.

### Does this resolve the ordinary-bootstrap-tail concern?

**Yes.** Superiority labels now use a null-referenced cluster-robust \(t\) statistic. `family_wise_sensitivity.py` retains the old ordinary-bootstrap tail fraction only under the key `bootstrap_tail_area_p_descriptive`; main.tex says:

> “an uncentred empirical bootstrap distribution is not a null distribution.”

The 95% percentile intervals and \(P(A\ \mathrm{better})\) are clearly separated from the cluster-robust Holm p-values in Supplementary Table S1 and are described as descriptive. They are not used as null p-values.

The remaining boundary is appropriately disclosed: this is post-hoc inference conditional on fixed fits and the heuristic sequence partition. It excludes training-sample, tuning, and future-catalogue uncertainty.

### Robustness and seeded-family checks

`robustness_post_hoc.json` confirms the same seven rejected labels for:

- 50 km/15 day clustering, 375 holdout clusters;
- 100 km/30 day clustering, 354 clusters;
- 200 km/60 day clustering, 295 clusters;
- the seven-pair reference-only family;
- the log-loss family; and
- the AUROC family.

The AUROC analysis is explicitly exploratory and uses a null-centred paired sequence-cluster bootstrap. The manuscript does not promote it to primary evidence.

The 15-pair seeded family is also reported correctly:

- C_F2 is Holm-supported only against B0, B1, and B4;
- C_F2 remains unresolved against B2 and B5;
- adding the five seeded comparisons makes admissible B1–B4 unresolved;
- the manuscript calls this multiplicity sensitivity, not evidence that one family is uniquely correct.

The seeded result is accurately framed as a fixed-allowlist policy illustration. The manuscript states:

> “That contrast holds by construction: an allowlist blocks every undeclared field, whether contaminated (C_F2) or outcome-blind (C_geo). It illustrates policy operation, not contamination detection.”

This is the necessary calibration.

### Other arithmetic

- \(1573+357+430+2=2362\).
- \(449+102+151+1=703\).
- The holdout-prevalence oracle Brier score is \((151/430)(1-151/430)=0.2278475\), which rounds to 0.228.
- Its gap to B0 is \(0.2321601-0.2278475=0.0043126\), which supports “about 0.004.”
- Event-grouped minus random-event Brier is \(0.200874490602-0.204833647433=-0.003959156831\), correctly printed as \(-0.0040\).
- The Patelli correction is real and correctly identified as *Scientific Reports* 16, 9208 (2026), DOI `10.1038/s41598-026-44475-8`.
- Knap et al. explicitly use deep-learning seeds 41, 42, and 43 and report repeated-seed follow-up as mean ± standard deviation; the manuscript’s contrast is accurate.

## Abstract, claims, and workflow

The 217-word abstract is technically accurate and fully contained on PDF page 1 with the keywords. It reports the principal positive, negative, and unresolved outcomes; explicitly calls the multiplicity rule, sensitivity checks, and seeded illustration post hoc; limits reuse beyond the single catalogue; and states that this is retrospective rather than operational.

The versioned schema-extension workflow is operationally clear. Before protected evaluation, a maintainer must document each field’s source, availability time, transform, units, and relationship to the outcome and evaluation axis; add it to a newly hashed ordered allowlist; rerun the audit tests; develop only on construction data; and use a fresh hidden holdout or independent service for confirmation. The Limitations section correctly states:

> “Section 4.1 defines a prospective version-bump procedure for extending the schema, but that procedure was not evaluated here.”

No universal or task-agnostic empirical recommendation remains. The only cross-task wording is explicitly scoped as:

> “Their reuse on other tasks is a design proposal, not an empirical generalization from DYFI.”

## Reproducibility

Using `/tmp/dyfi-analytics-venv/bin/python`, I ran:

- `family_wise_sensitivity.py`;
- `seeded_candidate_demo.py`; and
- `robustness_post_hoc.py`.

Each regenerated output was byte-identical by SHA-256 to its frozen JSON. Backups were restored, and the post-restoration hashes matched the pre-run hashes. The runs independently reproduced the seven/six rejection counts, the exact B1–B4 p-value, all seeded scores and 15-pair labels, all split intervals, and every alternative-family label.

The release/archive distinction is internally consistent. The review archive contains the current scripts and records; public tag `v1.1.1` does not. The title page says these files postdate that tag and promises a new immutable tag on acceptance. That promise must be completed before publication; it is not a blinding breach or a current numeric mismatch.

## Citations and novelty

All 46 bibliography entries have ledger entries and citation sites. External resolution located every printed work. The automated availability check could not register `10.5066/P143CZ3R` in Crossref, but the independent USGS record resolves that DOI to the cited 2026 *Macroseismic Intensity Dataset in Western North America*; this is a registry-specific false alarm, not a fabricated citation.

The paper’s novelty wording is restrained:

> “Those pieces are established separately; what is released is their fail-closed combination as a reconstructable decision rule for this DYFI classification task.”

The nearest published work is Knap et al. (2026), which is broader in datasets and repeated-seed evaluation but does not couple fixed-schema admission to the manuscript’s family-wise paired candidate decision. BetterBench audits benchmark lifecycle practices rather than individual candidates. This supports a **defensible-beyond-incremental** integration claim.

However, the recent `evalci` preprint (arXiv:2607.04429) already provides per-item paired null-shifted bootstrap testing and Holm correction over every model pair. It does not occupy the schema/role gate, clustered-event dependence, catalogue pinning, or seismic demonstration, but it narrows the statistical part of the delta and should be engaged directly.

## Formatting and blinding

- Main PDF: 31 letter-size pages; supplement: 7.
- All fonts are embedded.
- No overfull boxes were reported. Six underfull-box warnings in the main build do not produce clipping.
- Visual inspection found no clipped, overlapping, or unreadable content in the main tables and figures.
- Supplementary Table S2 continues cleanly across pages 2–4 and repeats its headers.
- Supplementary Table S5 reports random/event/sequence Brier 0.2048/0.2009/0.1990, AUROC 0.6952/0.7058/0.7076, and log-loss 0.9640/0.9223/0.9709, matching the main text.
- Supplementary Table S1 includes all ten comparisons, descriptive 95% intervals and \(P(A\ \mathrm{better})\), Bonferroni 99.5% \(t\) intervals, and cluster-robust Holm p-values.
- The anonymous main and supplement contain no author, institution, email, or identifying repository path. The separate title page correctly contains identities and the repository.

## Required current-study fixes

### R8-F1 — Minor presentation: Table 1 conflates Holm testing with an interval

**Exact evidence:** Table 1 calls the control “Paired interval under Holm control.” The implemented decision is instead a cluster-robust paired test under Holm, with a separate Bonferroni simultaneous interval.

**Required change:** Replace that cell with “Paired cluster-robust test + Holm control” or “Holm-tested paired difference; Bonferroni simultaneous interval.”

This is feasible now, requires no new data, and changes no result.

### R8-F2 — Minor evidence: engage the closest concurrent statistical comparator

**Exact evidence:** The manuscript concedes that the pieces are established separately but does not discuss `evalci` (arXiv:2607.04429), which already combines paired benchmark inference with all-pair Holm correction.

**Required change:** Add one concise Related Work sentence that names this concurrent comparator and narrows the manuscript’s delta to schema admission, event clustering, version pinning, and the worked seismic decision. Do not strengthen the novelty adjective.

This is feasible now, requires no new data, and changes no result.

### R8-F3 — Minor evidence: publish the current immutable release before publication

**Exact evidence:** `title_page.tex` states that the current interpretation overlay and three post-hoc scripts/records “postdate tag v1.1.1” and “will be deposited under a new immutable tag on acceptance.”

**Required change:** Before final publication, mint that tag, map each current manuscript-level file to it, and update the title-page URL/version. Preserve `v1.1.1` unchanged.

This is feasible in the current study and changes no result.

## Limitations requiring new data or a new study—not defects fixable by prose

1. **Confirmatory inference.** The Holm family and seeded/robustness analyses were specified after holdout access. Confirmation requires a fresh hidden benchmark version or independent service with schema and comparison family frozen in advance.
2. **Independence-unit validation.** The 100 km/30 day sequence rule is a disclosed heuristic; true aftershocks can remain in separate clusters. Stronger independence evidence requires an authoritative or independently validated sequence membership and prospective analysis at that evidenced unit.
3. **Transport and schema-extension utility.** No second corpus, leave-region-out branch, or prospective schema extension was evaluated. Those claims require a new catalogue or hidden-service study.

These limitations lower the soundness and usefulness ceilings but do not contradict the manuscript because the paper states them explicitly and does not claim confirmation, physical aftershock completeness, external transport, or universal reuse.

## Finding tally and bottom line

- `result`: 0
- `evidence`: 2 minor
- `presentation`: 1 minor
- `self-description`: 0
- major/blocking: 0

The paper’s decision-bearing statistics now use a valid null-referenced cluster-robust test rather than an uncentred bootstrap tail fraction. Its seven Holm labels, six simultaneous intervals, seeded-family consequences, robustness labels, arithmetic, citations, layout, and blinding check out. I recommend minor revision limited to the three feasible actions above; fresh data are required only to lift the manuscript’s explicitly stated confirmatory and transport limitations.
