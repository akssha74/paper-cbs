# Independent default-reject review, round 4 (Claude Opus 5.5)

**Venue:** Cybernetics and Systems (Taylor & Francis), double-anonymous
**Object:** `paper-cbs/main.pdf` (31 pp.; text extracted independently with `pdftotext -layout`), plus `supplement.pdf`, `main.tex`, `tables/`, `frozen_inputs/*.json`, `claim_ledger.jsonl`, `cbs_validation_report.json`, `references.bib`, `title_page.tex`. Prior-round reviews were not consulted.

## Hash verification

| File | Claimed | Observed | Match |
|---|---|---|---|
| main.pdf | 28f5c57c…3803b | 28f5c57c9b80d8a2384d345933f883b230ce46d710477066c166a3bb42c3803b | yes |
| main.tex | cce6009c…1fffd | cce6009c39435f43f75de1b74e806c1017aae81cb70517b466c6349554e1fffd | yes |
| supplement.pdf | — | 53883e61b85eae5eb10b869156be413e4e88fa89e59e1d5d6fbb19bb281d8268 | matches validation report |

## Verdict: **REJECT**, 15/30

| Category | Score |
|---|---|
| 1 Scope / venue fit | 1 |
| 2 Novelty / contribution | 1 |
| 3 Significance / demonstrated usefulness | 1 |
| 4 Methodological soundness | 1 |
| 5 Numeric accuracy / traceability | 2 |
| 6 Claims–evidence alignment | 2 |
| 7 Protocol adherence / disclosure | 1 |
| 8 Statistical reporting | 2 |
| 9 Reproducibility / provenance | 2 |
| 10 Presentation / format / blinding | 2 |
| **Total** | **15** |

**Rationale.** The numbers are almost fully traceable and disclosure is careful. However, by the authors' own statement the contribution is a task-specific resource: "No component is claimed as new". It uses one dataset whose endpoint is "close to magnitude thresholding". The paper says of its two decision changes, "Those are the only decision changes demonstrated". One is a self-imposed schema policy (B3). The other is a tie that a point-score reader already sees: "would treat B2 and B5 as tied lowest-Brier models (both 0.181)". The frozen protocol's named primary result has no inference ("No paired interval was retained"), and the only interval-bearing headline, B2 vs B0, is post hoc. The decision rule issues "Supported" labels from ten unadjusted intervals. Venue fit is marginal.

## Vetoes

| Veto | Triggered | Evidence |
|---|---|---|
| fabricated_citation | **false** | All 36 DOIs resolve with matching metadata: 33 via Crossref and 3 USGS DOIs via DataCite. The EarthquakeNPP OpenReview URL responds. There is one *miscitation* (not a fabrication): [18], "Deep learning based earthquake and vehicle detection algorithm", is cited under "Felt-intensity models have used random forests or boosting … [7, 8, 16–18]". |
| numeric_mismatch | **false** | Nothing load-bearing. The only discrepancy is that the event-grouped gap is reported as 0.0039, while unrounded 0.204834 − 0.200874 = 0.00396 rounds to 0.0040 (minor fix). |
| blinding_breach | **false** | Searching main/supplement text, main.tex and references.bib for `akssha|sharma|github|orcid` returned nothing, and the PDF has no Author metadata. Identity appears only in `title_page.tex` (l.17, l.64). |
| clearly_out_of_scope | **false** | The fit is marginal but not clearly out of scope; five verified Cybernetics and Systems papers [1, 2, 22, 23, 24] are engaged. |
| unsupported_overclaim | **false** | Headline claims are caveated ("generality beyond this dataset is untested", "no winning model"). The remaining wording tensions (listed below) are required changes. **This veto should trip next round if they persist.** |

## Key findings (evidence-anchored)

1. **Demonstrated usefulness is thin.** The paper itself says: "A conventional point-score reading of the same table would treat B2 and B5 as tied lowest-Brier models (both 0.181) and could name B2 uniquely best from the 0.613 joint-ordering probability." The counterfactual reader who would name B2 uniquely best is a strawman. The B3 exclusion is "a schema policy, not a leakage finding", so the contract only enforces its own rule. No candidate is shown whose point-score win the contract correctly overturns.
2. **Novelty is incremental.** The paper says: "No component is claimed as new. The submission is a task-specific reproducibility and benchmark resource …" and "No second, non-seismic dataset was evaluated". The feature gate is a two-field whitelist, so "reject[ing] seeded contamination cases" is guaranteed by construction.
3. **The decision rule has no multiplicity control.** Ten unadjusted 95% intervals drive "Supported". My normal-approximation Bonferroni (99.5%, z = 2.807, SE = CI width/3.92) check gives B1−B4 ≈ [−0.0015, 0.0245] and B4−B5 ≈ [−0.0017, 0.0121], so both would include zero. Section 5.5 nevertheless says, unqualified, "The contract therefore supports improvement of B2, B4, and B5 over B0 and over B1."
4. **The split diagnostic model has no skill, and the paper does not say so.** Construction no-skill log-loss is −(0.2855 ln 0.2855 + 0.7145 ln 0.7145) = 0.598, while the diagnostic RF log-loss is 0.9223–0.9709. The random-event diagnostic Brier of 0.2048 exceeds construction no-skill Brier 0.204 (`/endpoint/no_skill_brier_floor_construction` = 0.20399). A no-skill, overconfident model cannot inform whether random splitting inflates scores. The Discussion attributes the null to data structure instead ("remains useful for datasets containing more multi-event sequences").
5. **Grouping barely binds.** The corpus has 1930/1530 = 1.26 events per sequence, and there is no sensitivity analysis on the 100 km/30 day rule ("no alternative … was tested").
6. **Protocol adherence is poor, though well disclosed.** The frozen primary lost its interval, the geographic and aggregation-grid branches were "not executed", non-Brier intervals were dropped, and B2 vs B0 is "post-hoc". The protocol was frozen internally and "first publicly timestamped on 2026-09-19", 18 days after data access.
7. **Residual sign language.** Section 5.3 says "no sign claim—including 'slightly reversed'—is inferentially supported". Yet the Discussion (main.tex l.685) says "small and reversed; the log-loss point estimates point in opposite directions", and the Conclusion (l.747) says "Brier and AUROC are small and reversed". The frozen `/exclusions_and_deviations/F3_split_contrast_framing` still says "small and slightly reversed".
8. **"Prevents" overreaches.** "This workflow prevents a practitioner or reviewer from declaring superiority from … a contaminated split" conflicts with "unlinked true aftershocks may therefore remain in different roles".

## Numeric checks performed (all against `frozen_inputs/asset_inputs.json` unless noted)

| Item | Reported | Source / arithmetic | Result |
|---|---|---|---|
| Preliminary counts | 7,575 → 7,576 | source_locator `/drift_receipt/observations` = 7575, 7576 | match |
| Final snapshot and count | 7,520; count "50 seconds later" = 7,520 | access 06:33:30Z, count 06:34:20Z (Δ 50 s); costamped_count 7520; count_delta 0 | match |
| 56-record gap | 56 | 7576 − 7520 = 56 | match |
| Eligible | 2362; 703 severe; 0.298 | `/cohort_flow` 2362, 703, 0.29763 | match |
| Partition | 1573+357+430+2 = 2362 | arithmetic | match |
| Severe reconciliation | 703 = 449+102+151+1 | `/cohort_flow/roles/*/positive` | match |
| Role-assigned | 2360 / 702 | `/cohort_flow/n_role_assigned*` | match |
| Sequences | 1885 = 1530+354+1 | `/cohort_flow/sequences` | match |
| Prevalences | 0.285 / 0.286 / 0.351 | 0.28544 / 0.28571 / 0.35116 | match |
| Events per sequence | 1.26 | 1930/1530 = 1.2614 | match |
| Table 3 | 0.458/0.240/0.734; 0.351/0.181/0.786; 0.260/0.143/0.815 | `/endpoint/threshold_sensitivity` | match |
| Near-threshold; no-skill | 0.164; 0.204 | 0.16373; 0.20399 | match |
| Table 4 | 0.2048/0.6952/0.9640; 0.2009/0.7058/0.9223; 0.1990/0.7076/0.9709 | `/leakage_inflation_headline/per_scheme` | match |
| Split gaps | 0.0059 Brier; 0.0124 AUROC | 0.005878; 0.012397 | match |
| Event-grouped gap | 0.0039 | 0.003959 → 0.0040 | **minor mismatch** |
| Log-loss direction | 0.9709 vs 0.9640 | seq > random, opposite sign to Brier/AUROC | disclosed |
| Diagnostic vs no-skill | — | no-skill log-loss 0.598 vs 0.92–0.97; Brier 0.2048 > 0.2040 | **undisclosed** |
| Table 5 Brier/CI | B0 0.232 [0.212,0.253] … B5 0.181 [0.161,0.202] | `/per_baseline/*` | match |
| B0 recomputed | 0.232; log-loss 0.658 | 0.3512·0.7145² + 0.6488·0.2855² = 0.23216; 0.65831 | match |
| Log-loss / AUROC | 0.658/0.583/0.536/0.553/0.541; 0.500/0.719/0.786/0.777/0.783 | `/per_baseline/*` | match |
| Calibration | 0.32/1.02, 0.64/1.29, 0.74/1.48, 0.42/1.07; B0 INFEASIBLE | `/per_baseline/*/calibration_*` | match |
| Accuracy | 0.65/0.70/0.73/0.73/0.74 | 0.6488/0.7047/0.7279/0.7279/0.7419 | match |
| Recall (abstract 0.25–0.37) | 0.25/0.32/0.29/0.37 | 37/151, 48/151, 44/151, 56/151 | match |
| Abstract AUROC | 0.719 / 0.786 | 0.71896 / 0.78575 | match |
| Table S1 / Table 6 (10 pairs) | e.g. B1−B4 0.0115 [0.0023,0.0205]; B2−B5 −0.0008 [−0.0078,0.0068]; B4−B5 0.0052 [0.0003,0.0099] | `/pairwise_ranking_stability/pairwise_matrix` | all 10 match |
| P(A better) | 0.009, 0.970, 0.613, 0.017 … | 0.0085, 0.9695, 0.613, 0.017 | match |
| Joint ordering | 0.613 / 0.387 | `/tie_aware_joint_ordering/prob_best` | match |
| vs-B0 deltas | −0.0339, −0.0515, −0.0455, −0.0507 | `/ranking_vs_reference` | match |
| Temporal slices | 250: 0.185/0.797; 180: 0.174/0.777 | `/slices/temporal` | match |
| Geographic | 82 cells; 0.002–0.825; median 0.151 | `/slices/geographic_summary` (sum_n 430) | match |
| Fits / token | 91 of 120; single use | fit_count 91, fit_cap 120, run_token_consumed_count 1 | match |
| 110 tests | 110 across four suites | claim_ledger P_unit_tests: 24+35+31+20 = 110; json_pointer null | arithmetic matches; **not verifiable from frozen JSON** |
| Multiplicity (reviewer) | — | Bonferroni: B1−B4 [−0.0015, 0.0245]; B4−B5 [−0.0017, 0.0121] | not robust |

## R4 fix verification

| Item | Status | Evidence |
|---|---|---|
| No residual sign inference on split diagnostic (Discussion/Conclusion); disclose opposite log-loss | **partial** | Log-loss is disclosed in Section 5.3, the Discussion and the Conclusion. But the Discussion and Conclusion still say "small and reversed", the language Section 5.3 itself calls unsupported. The log-loss sentence is garbled ("point in opposite directions"), and the frozen F3 framing string still says "slightly reversed". |
| Table 4 not calling event-grouped a control | **pass** | "Event-grouped (second allocation)"; text: "not a distinct control". |
| Table 1 not saying False model-superiority | **pass** | "Unsupported model-superiority claim". |
| 4.1 not titled six-category leakage audit | **pass** | "4.1 Feature sets, the two-field allowlist, and split-axis checks". |
| Table S2 discloses the frozen primary, the reclassification to secondary, and B2 vs B0 as post hoc | **pass** | Table S2 row "Headline-result designation / Post-protocol disclosure"; repeated in Sections 4.4, 5.5 and 5.8. |
| CITL sentence does not claim the joint intercept is CITL | **pass** | "is not calibration-in-the-large for any model". An actual CITL value is still not reported. |
| Contribution framed as task-specific benchmark/resource | **partial** | Section 2 and the Conclusion pass. The title ("for Comparing Machine-Learning Classifiers on Versioned Event Data"), the abstract and Section 1.2 ("task-agnostic") still lead with generic framing. |
| B1 self-beat absent; four vs B0; B2/B4/B5 vs B1 exploratory | **partial** | B1 self-beat is absent, and "All four learned models improved on the no-skill reference" is correct. However, Section 5.5 says, unqualified, "The contract therefore supports improvement of B2, B4, and B5 over B0 and over B1", and the Table 6 Decision column says "Supported" without an exploratory label. |

## Top required changes

1. Demonstrate usefulness with a non-trivial case: a leaked covariate that wins on point Brier, a version shift that flips a ranking, or a second dataset. The current decision changes are a self-imposed policy and a visible tie.
2. Add multiplicity control to the decision rule, or relabel the vs-B1 and pairwise outcomes as "exploratory directional" in Table 6 and Section 5.5.
3. Replace or drop the no-skill split diagnostic (log-loss 0.92–0.97 vs no-skill 0.598; Brier ≈ no-skill). If it is kept, use a skilful, calibrated model and a paired interval.
4. Remove the "small and reversed" language from the Discussion and Conclusion, fix the garbled log-loss sentence, and correct or overlay the frozen F3 string.
5. Align the title, abstract and Section 1.2 with the task-specific claim, or demonstrate task-agnosticism on a second catalogue.
6. Develop a genuine systems or cybernetic contribution (for example properties or error rates of the admit/support gate), or retarget to a data/benchmark or seismology venue.
7. State in the abstract that no pre-specified, interval-bearing primary result exists.

## Minor changes

- Report the event-grouped gap as 0.0040, or state that it is computed from rounded values.
- Fix the [18] miscitation: it is an earthquake-and-vehicle detection deep-learning paper, not an RF or boosting felt-intensity model.
- Report CITL or mean predicted probability against the 0.351 holdout prevalence.
- Provide a verifiable pointer for the 110 tests, and attribute them to "schema and split audits" as the claim ledger does.
- Explain the release lineage: original_build_ledger v1.0.27 (PDF sha 6ce8b8d8…) versus title-page v1.1.1.
- Fix typesetting in Tables 1 and 6 ("Unsupported          model-", "lo- gistic") and the fragmentary Fig. 2 caption opener.
- Add DOIs for [32] and [33] in the reference list.
- Shorten the 31 pages by moving disclosure bookkeeping to the supplement.

**Novelty class:** incremental.
**Convergence note:** Numeric traceability and disclosure have converged, and of the r4 wording items five pass and three are partial. The remaining blockers are substantive (usefulness, novelty, multiplicity, the no-skill diagnostic, venue fit), and more wording revision cannot resolve them.
