# Independent review for Cybernetics and Systems

Reviewer model: GPT-5.6  
Recommendation: **MAJOR REVISION**  
Score: **23/30**  
Vetoes: **None**

The manuscript is numerically careful, unusually transparent about deviations and non-use boundaries, and formally within the journal's applied-AI, decision-system, and environmental-systems scope. I would not desk-reject it as merely seismology. I would not accept it in the present form, however. Its contribution is an incremental integration of established evaluation controls for one DYFI task, while the split-sensitivity result called the headline quantity has no retained uncertainty interval and no sequence-definition sensitivity. The applied-AI decision benefit is plausible but not yet demonstrated beyond this worked candidate set.

## Scores

- Venue scope fit for CBS: **2/3**
- Contribution/novelty clarity: **1/3**
- Methodological soundness: **2/3**
- Numeric/evidence integrity: **3/3**
- Claim calibration: **3/3**
- Editor readiness (goal and usefulness on page 1): **3/3**
- Reproducibility/artifact: **3/3**
- Related work and citation accuracy, including CBS parity: **2/3**
- Formatting and double-anonymous compliance: **2/3**
- Usefulness/decision impact for applied-AI practitioners: **2/3**

## Goal and usefulness

One-sentence goal: determine whether severe felt-intensity classifier comparisons remain admissible and statistically supportable after fixing catalogue version, feature rules, dependent-event grouping, temporal evaluation, paired uncertainty, and reconstruction.

The intended users are applied-ML engineers, benchmark maintainers, and reviewers. The enabled decisions are whether a candidate belongs to the declared comparison estimand and whether its Brier improvement over a reference is supported. The worked substantive result is that four evaluated learned candidates improve over no-skill, B2 and B5 cannot be distinguished directly, B3 is outside the SOURCE_ONLY schema, and the random-versus-sequence point contrast is small and reversed.

- `goal_understood`: true
- `usefulness_understood`: true
- `abstract_story_pass`: true
- Contribution identity: benchmark/evaluation protocol with an executable decision-support harness
- Novelty classification: **incremental**

The abstract communicates the pain point, exact goal, approach, principal positive and unresolved results, user decision, and non-use boundary. The first page is editor-ready.

## Venue fit and novelty

The official CBS scope expressly includes applied AI/ML, decision making, intelligent systems, and cybernetics in environmental systems. The paper also substantively engages five CBS articles. Three recent precedents propose applied ML systems and compare them with baselines; two older precedents concern environmental decision-support and fuzzy knowledge systems. This establishes scope, but not parity.

The nearest-work reduction is: established leakage auditing, grouped validation, temporal holdout, proper scoring, paired bootstrap comparison, and reproducibility controls packaged for an event-level DYFI classification task. The concrete delta over Kumar et al. is the event-level severe-classification contract with sequence grouping, temporal evaluation, paired uncertainty, and a frozen release; the delta over Li et al. is a source-metadata classifier qualification task rather than per-location LLM MMI simulation; the delta over EarthquakeNPP is a different endpoint and comparison contract. That delta survives as useful engineering integration, but the current single-dataset worked example and negative/inconclusive split diagnostic do not establish a beyond-incremental systems contribution comparable to the recent CBS model papers.

## Required changes

### 1. Resolve the unsupported status of the headline split diagnostic

Location: Abstract, lines 56-59; Results Section 5.3; Contribution 6.

Quote: “For a fixed random-forest diagnostic, the observed differences between sequence-grouped and random folds were small (Brier −0.006; area under the receiver-operating-characteristic curve [AUROC] +0.012); this comparison is descriptive because no interval was retained.”

The manuscript calls split sensitivity the resource's headline quantity and a contribution, but the registered uncertainty analysis was not retained and no sensitivity to the fixed 100-km/30-day grouping rule was run. The result cannot establish harmful random-split optimism, equivalence, or a negligible effect.

Exact fix: either add a clearly labelled post-freeze exploratory paired uncertainty analysis and sensitivity over defensible sequence definitions, or demote this result from the abstract, contribution list, and “headline quantity” language. If demoted, use: “In this sample, sequence-grouped folds yielded Brier 0.0059 lower and AUROC 0.0124 higher than random folds; without a retained uncertainty interval or grouping-parameter sensitivity, this diagnostic does not establish the direction or practical size of a split effect.”

### 2. Demonstrate decision value or narrow the novelty claim

Location: Related work, lines 210-217; Conclusion, lines 680-683.

Quote: “No individual component is claimed as new; the contribution is the auditable model-comparison contract, implemented as an executable decision system, and its worked decision example.”

Exact fix: add a contract-versus-conventional-evaluation comparison enumerating every changed decision on the same candidates, including the exact point-score decision and its contract replacement. Then either demonstrate portability on a second event dataset or an independently supplied candidate, or narrow the title, abstract, and conclusion from a reusable applied-AI benchmark to a DYFI case study.

### 3. State the inferential target and address multiplicity

Location: Worked qualification, lines 550-557; Pairwise ranking, lines 563-579.

Quote: “B1, B2, B4, and B5 pass the audit and each has a paired Brier interval below the no-skill B0 reference. The contract therefore supports their improvement over B0.”

The bootstrap resamples fixed holdout predictions; it does not include training-sample, tuning, grouping-definition, or temporal-period uncertainty. Four comparisons against B0 and ten pairwise comparisons are interpreted without a familywise plan.

Exact fix: define the estimand as conditional performance of fixed fitted candidates on the sampled 2023-2024 sequence population and list excluded uncertainty sources. For the four B0 claims, designate one primary comparison and mark the others exploratory, or report Holm-adjusted decisions or simultaneous paired-bootstrap intervals.

### 4. Separate schema eligibility from leakage

Location: Feature sets, lines 300-315; Table S2; Worked qualification.

Quote: “Event year is known at prediction time and is not intrinsically label leakage, but it is excluded by the declared source-only temporal-holdout contract.”

Exact fix: use “ineligible for this SOURCE_ONLY estimand” instead of “inadmissible” or “invalid” for B3. Replace the Table S2 rationale with: “Origin year is available at prediction time but is outside the prespecified SOURCE_ONLY feature schema; no label-leakage claim is made.” Visually separate this policy branch from F1-F6 leakage failures.

### 5. Remove a citation-supported frequency overgeneralization

Location: Introduction, lines 79-83.

Quote: “whereas stacked tree-based and neural ensembles for demand forecasting are still commonly summarized by point accuracy, precision, and recall.”

The cited StackRetailNet abstract reports those metrics, but one article does not support “commonly.”

Exact fix: write: “whereas the cited StackRetailNet demand-forecasting study reports point accuracy, precision, and recall.”

### 6. Make the quantitative claim census complete

Location: Contributions and leakage audit; `claim_ledger.jsonl`.

Quote: “It is exercised by 110 unit tests across four suites, all passing.”

I independently reproduced this claim: release v1.1.1 contains suites of 24, 35, 31, and 20 tests, and all 110 pass in the pinned environment. It and several provenance/protocol numbers are nevertheless absent from the supplied claim ledger.

Exact fix: add ledger entries for the test count/suites, preliminary count drift, 50-second recheck, two deterministic replays, protocol constants, and software/artwork versions, each pointing to a hashed authoritative release file. Add a validator that fails on any unledgered quantitative prose or caption claim.

## Numeric and artifact audit

I found no numeric-mismatch veto.

- Fifty-one independent arithmetic checks passed with zero failures.
- Partition: 1,573 + 357 + 430 + 2 = 2,362; role-assigned total = 2,360.
- Severe accounting: 449 + 102 + 151 + 1 = 703; role-assigned severe total = 702.
- Prevalences recompute to 0.298 eligible, 0.285 construction, and 0.351 holdout after rounding.
- Construction no-skill Brier recomputes as p(1-p) = 0.203986; holdout B0 recomputes as 0.232160 using construction prevalence.
- Split differences recompute as Brier −0.005878 and AUROC +0.012397 for sequence minus random.
- All baseline scores, intervals, log-loss, AUROC, calibration entries, and accuracies match frozen inputs.
- Every confusion matrix sums to 430, and recomputed accuracy/precision/recall match.
- All ten pairwise point differences equal the corresponding exact Brier differences; the two reported unresolved intervals include zero.
- Temporal slice counts sum to 430. The 82 geographic cells also sum to 430; min/median/max cell Brier independently recompute to 0.002441/0.150983/0.824898.
- The package asset input is byte-identical to release v1.1.1 (`b7f7dea...ace9`).
- The tagged release resolves anonymously. In a clean clone and pinned Python 3.11.15 environment, all 110 tests passed.

## Citation audit

Crossref metadata and OpenAlex `abstract_inverted_index` were checked for all five required CBS papers plus Roberts et al. and Atkinson-Wald.

- `10.1080/01969722.2025.2583968`: StackRetailNet components and accuracy/precision/recall match; “commonly” is broader than this one abstract supports.
- `10.1080/01969722.2025.2588199`: ten datasets and Wilcoxon/Friedman p < 0.05 match.
- `10.1080/01969722.2026.2723278`: KiTS23/KiPA22 and the 2.15-point Dice gain match.
- `10.1080/01969720490451878`: GIS/web urban-soil decision support and transparent decision making match.
- `10.1080/01969720050046001`: fuzzy logic, rule creation, and membership-function verification match.
- `10.1111/ecog.02881`: dependence-aware blocked cross-validation characterization matches.
- `10.1785/gssrl.78.3.362`: DYFI ground-motion/regional characterization matches; the IPE exclusion is correctly presented as this study's design decision.

No fabricated citation or material citation-mischaracterization veto was found.

## Double-anonymous and formatting audit

`main.tex`, `main.pdf`, `supplement.tex`, and `supplement.pdf` contain no author names, affiliation, email, ORCID, identifying repository URL, or self-citation language. PDF metadata has no author field or identifier tokens. The unblinded names and repository URL occur only on the separate title page. Formal blinding therefore passes, although the distinctive public project name and release tag make the authors discoverable; an editor-mediated anonymous artifact would reduce that risk.

The compiled main PDF is synchronized with source, 29 pages, single-column, double-spaced, and line-numbered. All five figures are legible and consistent with captions and frozen values. There are no overfull boxes, unresolved references, or supplement layout warnings. Nine underfull boxes are non-blocking. The two USGS data-release DOIs appear in the availability statement but not in the rendered bibliography entries.

## Reproducibility

The artifact is a strength. Release v1.1.1 resolves, the source snapshot and result files are hash-pinned, package and release asset inputs are identical, exact dependency versions are provided, and the complete 110-test suite passes in the pinned environment. The release is sufficient to verify the fixed numeric result surface. This does not repair the missing planned uncertainty for the split contrast or convert the internally frozen protocol into an externally preregistered one; the manuscript already discloses both boundaries correctly.

## Finding tally and conclusion

- Result findings: 0
- Evidence findings: 4
- Presentation findings: 1
- Self-description findings: 1

This first review has not converged because evidence findings remain. The paper is in scope and numerically reliable, but acceptance requires a stronger, explicitly demonstrated decision-system contribution and a defensible treatment or demotion of the central split diagnostic. Recommendation: **MAJOR REVISION**.
