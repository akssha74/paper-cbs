# Review R2: Cybernetics and Systems (double-anonymous)

**Manuscript:** A Fail-Closed Qualification Contract for Comparing Machine-Learning Classifiers on Versioned, Dependent Event Data: A Seismic Felt-Intensity Case Study
**Reviewer model:** Claude Opus 5.5 (independent, default-reject)
**Total:** 18 / 30
**Verdict:** Reject, resubmission encouraged
**Vetoes:** unsupported claim in the abstract that contradicts the paper's own evidence (1). No fabricated citations, no numeric mismatch in any table or figure, no blinding breach, not out of scope.

## Summary of the submission

The paper proposes a retrospective "qualification contract" for claims that one classifier improves over another. A candidate must use an allowlisted two-feature schema (magnitude, depth), is scored on a frozen 2023–2024 temporal holdout (430 events, 354 sequences) of a hashed USGS DYFI M≥5 snapshot, and is credited with improvement only when a paired sequence-cluster bootstrap Brier interval excludes zero. In the worked example:

- all learned models beat no-skill B0;
- B2, B4 and B5 beat magnitude-only B1;
- B2 versus B5 is unresolved;
- B3 (which uses event year) is ruled ineligible.

A random-versus-sequence split diagnostic is reported descriptively.

**Goal understood:** yes. **Usefulness understood:** yes, but the demonstrated practical value is modest. **Abstract story pass:** no, because of the veto sentence.

## What R2 fixed

- The paper is retitled and reframed as a contract plus case study.
- The project name was removed from the main text.
- The singleton misstatement was removed.
- Dietterich, Demšar, Benavoli, Kapoor–Narayanan and Bergmeir were added.
- B1 is used as the domain-simple comparator in Table 6.
- Calibration intercepts and recall are reported.
- B3 is framed as a schema-policy exclusion rather than a leakage finding.
- The bootstrap estimand is stated explicitly (conditional on the fitted models, 354 holdout sequences).

These are real improvements.

## Scores

| Item | Score |
|---|---|
| 1. CBS venue fit | 2 |
| 2. Novelty | 1 |
| 3. Soundness | 2 |
| 4. Numeric integrity | 2 |
| 5. Claim calibration | 2 |
| 6. Editor page 1 | 2 |
| 7. Reproducibility | 2 |
| 8. Related work and citations | 2 |
| 9. Formatting and blinding | 2 |
| 10. Usefulness | 1 |

**Venue fit.** The decision-support framing plausibly fits the journal's applied AI and decision-making scope, but the cybernetic or systems content is thin.

**Novelty.** The authors say "No component is claimed as new." The contribution is a packaged set of standard evaluation practices applied to one dataset with a two-field allowlist.

**Soundness.** The work is careful and transparent. However, the allowlist makes the leakage-audit families vacuous, the "Supported" calls rest on unadjusted intervals, the calibration intercept is misread, and the event-grouped "control" is identical in design to random assignment.

**Numeric integrity.** Every table and figure value matches the frozen assets. The score is capped by the logically false "four models beat B1" sentence and by the "three decisions" versus "only [two] decision changes" inconsistency.

**Claim calibration.** The paper is generally conservative (it makes no winner claim and states its non-use boundaries), apart from the veto sentence and the heavy "fail-closed contract" framing for a two-feature allowlist.

**Editor page 1.** The problem, users and limits are all visible on page 1, but the false four-model claim also appears there.

**Reproducibility.** Hashes, a fit ledger and a corrections overlay are all provided. However, the provenance and test counts cannot be traced in the review package, and the archive is not included.

**Related work and citations.** Every checked citation resolves and is characterized correctly. The ML evaluation-reliability and hidden-test literature is still missing.

**Formatting and blinding.** Blinding is clean. There are minor reference-style gaps and a duplicated "For example" at the start of the introduction.

**Usefulness.** The contract changes two decisions in the worked example. A standard paired test gives one of them; the other follows from a schema policy the authors define. Generality is untested.

## Veto (blocking)

**The claim in the abstract, Sec. 1.1 and Sec. 8 contradicts the evidence.**

- Abstract: "All four learned models improved on both the no-skill reference and the magnitude-only comparator".
- Sec. 1.1: "all admissible learned candidates improve over no-skill and over the magnitude-only comparator".
- Sec. 8: "four learned candidates improve over no-skill and over magnitude-only B1".

The four learned models are B1, B2, B4 and B5, and B1 *is* the magnitude-only comparator. Table 6 and Table S1 support improvement over B1 only for B2 (+0.0176 [0.0101, 0.0249]), B4 (+0.0115 [0.0023, 0.0205]) and B5 (+0.0168 [0.0055, 0.0273]). Sec. 6 gets this right. R1 flagged the same wording (R8); only Table 6 was fixed.

**Fix:** "All four learned models improved on no-skill; B2, B4 and B5 also improved on magnitude-only B1."

## Required changes

1. **C1 (blocking).** Correct the four-model claim in all three places, as described in the veto.
2. **C2 (major): the paper disagrees with itself on how many decisions change.** Sec. 5.5 says two decisions change ("Those are the only decision changes demonstrated"), while Sec. 6 says "The worked example changes three decisions". A point-score reading would already rank B2, B4 and B5 above B1, so that is a confirmation, not a changed decision. Make Sec. 6 agree with Sec. 5.5.
3. **C3 (major): novelty and usefulness need evidence.** Show a case where the contract changes a conclusion that a practitioner running a standard paired or corrected resampled test would not have changed. There are two good options:
   - apply the contract retrospectively to published felt-intensity comparisons ([7], [8], [19]) and report how many of their claims would be rejected or left unresolved;
   - add a second, non-seismic instantiation.

   Without one of these, "task-agnostic in form" is only asserted.
4. **C4 (major): the audit reduces to an allowlist.** With an exact two-field allowlist, families F1–F4 cannot fail for any candidate that uses only the allowlist. "110 unit tests reject every contaminated case" therefore tests the allowlist, not leakage detection. Either make F1–F4 act on field provenance metadata and demonstrate one admitted and one rejected new covariate, or describe the contribution as schema allowlisting.
5. **C5 (moderate): calibration is misread.** The claim "positive calibration intercept ... consistent with under-prediction" comes from a joint intercept/slope fit with slopes of 1.29 and 1.48. Report calibration-in-the-large (slope fixed at 1, or mean predicted probability versus the observed 0.351), and consider adding a reliability diagram.
6. **C6 (moderate): multiplicity is not controlled.** "Supported" decisions are made from unadjusted 95% intervals, with two endpoints near zero (B1–B4 lower endpoint 0.0023; B4–B5 lower endpoint 0.0003). A contract meant to prevent false superiority claims should control family-wise error over its decision-bearing comparisons (e.g., Holm across the three versus-B1 tests) and report whether the decisions survive.
7. **C7 (moderate): some numbers cannot be traced.** The counts 7,575 → 7,576, the 7,520 count taken 50 s later, the access instant and the "110 unit tests / four suites" are not in `asset_inputs.json` or `claim_ledger.jsonl`. Add them to the ledger. The anonymized archive promised to the editor is not in the review package; make it available to reviewers.
8. **C8 (moderate): the split diagnostic is misdescribed in two ways.** First, the "event-grouped (control)" is, by the authors' own note, the same design as random assignment with a different allocation. Relabel it as an indicator of fold-allocation noise (the two differ by 0.0039 Brier) or drop it. Second, sequence-grouped log-loss (0.9709) is worse than random (0.9640), so "scores marginally better" holds only for Brier and AUROC.
9. **C9 (minor).** Two consecutive sentences in Sec. 1, paragraph 1 open with "For example". Rewrite them as a contrast.
10. **C10 (minor): add missing related work.** Nadeau & Bengio (2003) on corrected resampled t-tests; Bouthillier et al. (2021) on variance in ML benchmarks; REFORMS (Kapoor et al. 2024); Dynabench or evaluation-server designs (Kiela et al. 2021), since Sec. 1.2 relies on a "hidden evaluation service" for confirmatory use.
11. **C11 (minor): reference formatting.** [1] and [2] are Cybernetics and Systems 57(1), published online in 2025; annotate them as done for [12] and [18]. Add the DOIs to [32] (10.5066/F7J101C8) and [33] (10.5066/F7MS3QZH) in the reference list.
12. **C12 (minor): "magnitude-dominated" understates depth.** Adding depth raises AUROC by 0.067 and lowers Brier by 0.0176, with an interval that excludes zero. Rephrase or quantify.

## Verification performed

**Numbers.** I checked every value in Tables 2–6, S1 and S3, Figs. 2–5 and the prose against `frozen_inputs/asset_inputs.json`, and all match at the stated rounding. This covers:

- cohort counts and the reconciliation 703 = 449 + 102 + 151 + 1;
- sequence counts and prevalences;
- the threshold probe;
- split-diagnostic scores and gaps;
- per-baseline Brier, CI, log-loss, AUROC, calibration, accuracy and recall;
- all 10 paired differences, CIs and P(A better);
- the joint-ordering probabilities 0.613 and 0.387;
- the temporal slices and the 82-cell geographic summary;
- the 91 of 120 fit count;
- the self-referential records and the three-entry corrections overlay.

I also recomputed B0's holdout Brier independently: 0.351 × 0.649 + (0.351 − 0.2855)² = 0.2322. The provenance counts and the test count could not be traced (C7).

**Citations.** I resolved 20 references via Crossref, OpenAlex or DataCite.

- The metadata of the five Cybernetics and Systems references ([1], [2], [22], [23], [24]) match.
- The descriptions of [1], [2] and [22] match their abstracts: ten datasets with Wilcoxon/Friedman tests; point accuracy, precision and recall; and +2.15 percentage points Dice over the strongest baseline.
- EarthquakeNPP was found; its TMLR venue was not independently confirmed.
- No fabricated citations.

**Blinding.** I searched `main.tex`, `supplement.tex`, both PDFs (text and metadata), `tables/` and the figure PDF metadata for GitHub, the author handle, the author names, the institution, `v1.1.1` and "DYFI Benchmark Reliability". No hits. The title page carries identities, as it should. Residual hint: "tagged public release" in Sec. 5.8; consider "archived release".

## Bottom line

The package is unusually honest and numerically clean, and R2 fixed most of the R1 problems. The blocking issue is small but lands on page 1: the abstract says the magnitude-only model beats itself. Even after that fix, the paper evaluates one benchmark carefully rather than contributing a reusable decision system. The contract has not been shown to change a conclusion that standard paired-comparison practice would not already change, and its "leakage audit" is a two-field allowlist. The paper needs C3 and C4 to clear the novelty and usefulness bar for acceptance.
