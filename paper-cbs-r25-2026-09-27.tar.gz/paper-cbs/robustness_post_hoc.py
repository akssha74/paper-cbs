"""Post-hoc robustness checks (no refit of any reported holdout model).

(a) Split-contrast paired interval. Recomputes the frozen split-diagnostic
    out-of-fold predictions on the construction rows, gates on exact
    reproduction of the frozen per-scheme Brier, AUROC and log-loss, then runs a
    paired sequence-cluster bootstrap of (sequence-grouped minus random-event)
    and (event-grouped minus random-event) differences.
(b) Sequence-definition sensitivity of the Holm decisions. Re-links the
    eligible events with alternative space-time windows, keeps roles and frozen
    holdout predictions fixed, and re-runs the ten-pair Holm family with the
    alternative clusters as bootstrap units.
(c) Secondary-metric Holm families. Paired sequence-cluster bootstrap of
    log-loss and AUROC differences for the same ten pairs.
(d) Variance-estimator sensitivity. CR1, CR3 jackknife, null-imposed wild
    cluster bootstrap-t and an event-level independence t for the Brier family.
(e) Region-block sensitivity. Re-clusters the holdout by 5 and 10 degree
    latitude-longitude cells to allow cross-sequence regional dependence.

Output: frozen_inputs/robustness_post_hoc.json
"""
from __future__ import annotations

import itertools
import json
import math
import os
import sys
from collections import Counter

import numpy as np
from scipy.stats import t as student_t

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "code"))

import asset_common as ac  # noqa: E402
import baselines  # noqa: E402
import decluster  # noqa: E402
import metrics  # noqa: E402
import report  # noqa: E402

OUT = os.path.join(HERE, "frozen_inputs", "robustness_post_hoc.json")
ALPHA = 0.05
WINDOWS = [(50.0, 15.0), (100.0, 30.0), (200.0, 60.0)]
LOWER_BETTER = {"brier": True, "log_loss": True, "auroc": False}
WILD_DRAWS = 99999
WILD_CHUNK = 10000
REGION_CELLS_DEG = (5.0, 10.0)


def cluster_index(groups):
    g = np.asarray(groups, dtype=object)
    uniq = np.array(sorted({v for v in g.tolist()}, key=lambda v: str(v)), dtype=object)
    return uniq, {u: np.where(g == u)[0] for u in uniq}


def paired_diffs(y, pa, pb, groups, metric, n_boot=ac.BOOTSTRAP_DRAWS, seed=ac.BOOTSTRAP_SEED):
    uniq, idx_by = cluster_index(groups)
    rng = np.random.default_rng(seed)
    out = []
    for _ in range(n_boot):
        chosen = rng.integers(0, uniq.shape[0], size=uniq.shape[0])
        idx = np.concatenate([idx_by[uniq[c]] for c in chosen])
        va = metrics._metric_scalar(metric, y[idx], pa[idx])
        vb = metrics._metric_scalar(metric, y[idx], pb[idx])
        if va is None or vb is None or not (math.isfinite(va) and math.isfinite(vb)):
            continue
        out.append(va - vb)
    return np.sort(np.asarray(out, dtype=np.float64))


def summarize(arr, point):
    n = arr.size
    p = min(1.0, 2.0 * min((np.sum(arr <= 0) + 1) / (n + 1), (np.sum(arr >= 0) + 1) / (n + 1)))
    lo, hi = (float(np.quantile(arr, q, method="linear")) for q in (0.025, 0.975))
    return {"point": ac._round12(point), "ci95": [ac._round12(lo), ac._round12(hi)],
            "excludes_zero": bool(lo > 0 or hi < 0),
            "bootstrap_tail_area_p_descriptive": ac._round12(p), "n_valid": int(n)}


def additive_losses(y, p, metric):
    y = np.asarray(y, dtype=np.float64)
    p = np.asarray(p, dtype=np.float64)
    if metric == "brier":
        return (y - p) ** 2
    if metric == "log_loss":
        p = np.clip(p, 1e-15, 1.0 - 1e-15)
        return -(y * np.log(p) + (1.0 - y) * np.log(1.0 - p))
    raise ValueError(f"{metric} is not additive")


def cluster_robust_p(y, pa, pb, groups, metric):
    d = additive_losses(y, pa, metric) - additive_losses(y, pb, metric)
    point = float(np.mean(d))
    g = np.asarray(groups, dtype=object)
    uniq = np.array(sorted({v for v in g.tolist()}, key=lambda v: str(v)), dtype=object)
    influence = np.asarray([np.sum(d[g == u] - point) for u in uniq], dtype=np.float64)
    se = float(np.sqrt(uniq.size / (uniq.size - 1.0) * np.sum(influence ** 2)) / d.size)
    statistic = point / se
    return {
        "cluster_robust_se": ac._round12(se),
        "cluster_robust_t": ac._round12(statistic),
        "cluster_robust_df": int(uniq.size - 1),
        "p_two_sided": ac._round12(2.0 * student_t.sf(abs(statistic), df=uniq.size - 1)),
        "p_two_sided_method": "sequence-cluster-robust t",
    }


def cluster_losses(y, pa, pb, groups):
    d = additive_losses(y, pa, "brier") - additive_losses(y, pb, "brier")
    g = np.asarray(groups, dtype=object)
    uniq = np.array(sorted({v for v in g.tolist()}, key=lambda v: str(v)), dtype=object)
    sums = np.asarray([np.sum(d[g == u]) for u in uniq], dtype=np.float64)
    sizes = np.asarray([np.sum(g == u) for u in uniq], dtype=np.float64)
    return d, sums, sizes


def cr1_t(sums, sizes):
    n, G = sizes.sum(), sums.size
    point = sums.sum() / n
    se = math.sqrt(G / (G - 1.0) * np.sum((sums - point * sizes) ** 2)) / n
    return point, point / se


def variance_estimator_p(y, pa, pb, groups, n_wild=WILD_DRAWS, seed=ac.BOOTSTRAP_SEED):
    d, sums, sizes = cluster_losses(y, pa, pb, groups)
    n, G = sizes.sum(), sums.size
    point, t_cr1 = cr1_t(sums, sizes)
    loo = (sums.sum() - sums) / (n - sizes)
    se_cr3 = math.sqrt((G - 1.0) / G * np.sum((loo - loo.mean()) ** 2))
    rng = np.random.default_rng(seed)
    exceed, done = 0, 0
    while done < n_wild:
        b = min(WILD_CHUNK, n_wild - done)
        s = rng.choice((-1.0, 1.0), size=(b, G)) * sums
        pt = s.sum(axis=1) / n
        se = np.sqrt(G / (G - 1.0) * np.sum((s - pt[:, None] * sizes) ** 2, axis=1)) / n
        exceed += int(np.sum(np.abs(pt / se) >= abs(t_cr1)))
        done += b
    p_wild = (exceed + 1) / (n_wild + 1)
    se_iid = float(np.std(d, ddof=1) / math.sqrt(d.size))
    return {
        "point": ac._round12(point),
        "cr1_p": ac._round12(2.0 * student_t.sf(abs(t_cr1), df=G - 1)),
        "cr3_jackknife_p": ac._round12(2.0 * student_t.sf(abs(point / se_cr3), df=G - 1)),
        "wild_cluster_rademacher_p": ac._round12(p_wild),
        "wild_cluster_mc_se": ac._round12(math.sqrt(p_wild * (1.0 - p_wild) / n_wild)),
        "event_level_iid_p": ac._round12(2.0 * student_t.sf(abs(point / se_iid), df=d.size - 1)),
    }


def holm_on(rows, key):
    m = len(rows)
    order = sorted(range(m), key=lambda i: rows[i][key])
    stop, rejected = False, []
    for rank, i in enumerate(order):
        ok = (not stop) and rows[i][key] <= ALPHA / (m - rank)
        if ok:
            rejected.append(f"{rows[i]['a'][:2]}-{rows[i]['b'][:2]}")
        stop = stop or not ok
    return sorted(rejected)


def cluster_structure(groups):
    sizes = sorted(Counter(groups).values(), reverse=True)
    G, n = len(sizes), sum(sizes)
    return {"n_events": n, "n_clusters": G, "n_singletons": sum(s == 1 for s in sizes),
            "largest_cluster_sizes": sizes[:5], "mean_cluster_size": ac._round12(n / G),
            "cr1_small_sample_factor": ac._round12(G / (G - 1.0))}


def holm(rows):
    m = len(rows)
    order = sorted(range(m), key=lambda i: rows[i]["p_two_sided"])
    stop = False
    for rank, i in enumerate(order):
        ok = (not stop) and rows[i]["p_two_sided"] <= ALPHA / (m - rank)
        rows[i]["holm_reject"] = bool(ok)
        stop = stop or not ok
    return rows


def family(y, preds, groups, metric):
    rows = []
    for a, b in itertools.combinations(sorted(preds), 2):
        arr = paired_diffs(y, preds[a], preds[b], groups, metric)
        point = metrics._metric_scalar(metric, y, preds[a]) - metrics._metric_scalar(metric, y, preds[b])
        summary = summarize(arr, point)
        if metric in ("brier", "log_loss"):
            inference = cluster_robust_p(y, preds[a], preds[b], groups, metric)
        else:
            centered_p = (np.sum(np.abs(arr - point) >= abs(point)) + 1) / (arr.size + 1)
            inference = {
                "p_two_sided": ac._round12(centered_p),
                "p_two_sided_method": "null-centered paired sequence-cluster bootstrap (exploratory)",
            }
        rows.append({"a": a, "b": b, **summary, **inference})
    return holm(rows)


def split_contrast(construction):
    spec = report._leakage_probe_spec()
    X = baselines.extract_features(construction, spec.schema)
    y = baselines.extract_labels(construction)
    ev = [str(r["event_id"]) for r in construction]
    sq = [str(r["sequence_id"]) for r in construction]
    folds = {
        "random_event": report._random_folds(len(construction), report.DEFAULT_N_FOLDS, report.DEFAULT_SEED),
        "event_grouped": report._key_folds(ev, report.DEFAULT_N_FOLDS),
        "sequence_grouped": report._key_folds(sq, report.DEFAULT_N_FOLDS),
    }
    oof = {k: report._oof_predictions(X, y, f, spec.build, report.LEAKAGE_PROBE_PARAMS) for k, f in folds.items()}
    frozen = ac.load_run_result()["result_core"]["report"]["leakage_inflation_headline"]["per_scheme"]
    for k, p in oof.items():
        for m in ("brier", "auroc", "log_loss"):
            v = ac._round12(metrics._metric_scalar(m, y, p))
            if abs(v - frozen[k][m]) > 1e-12:
                raise SystemExit(f"split diagnostic {k} {m} does not reproduce: {v} vs {frozen[k][m]}")
    res = {}
    for other in ("sequence_grouped", "event_grouped"):
        for m in ("brier", "auroc", "log_loss"):
            arr = paired_diffs(y, oof[other], oof["random_event"], sq, m)
            point = metrics._metric_scalar(m, y, oof[other]) - metrics._metric_scalar(m, y, oof["random_event"])
            res[f"{other}_minus_random_{m}"] = summarize(arr, point)
    return res


def main() -> None:
    recon = ac.reconstruct_frozen_predictions()
    ver = ac.verify_reconstruction(recon)
    if not ver["all_match"] or recon["predictions_digest"] != recon["recorded_predictions_digest"]:
        raise SystemExit("reconstruction verification failed; refusing to emit")
    y = np.asarray(recon["y_hold"], dtype=np.float64)
    preds = {b: np.asarray(v, dtype=np.float64) for b, v in recon["predictions"].items()}
    construction, holdout = recon["construction"], recon["holdout"]

    out = {"record_type": "post_hoc_robustness_checks",
           "status": "post-hoc; not pre-specified; no reported holdout model refit",
           "bootstrap": {"n_boot": ac.BOOTSTRAP_DRAWS, "seed": ac.BOOTSTRAP_SEED,
                         "kind": "paired cluster percentile intervals (descriptive)"},
           "family_inference": "cluster-robust t for additive Brier/log-loss; null-centered paired cluster bootstrap for exploratory AUROC"}

    out["split_contrast_paired"] = split_contrast(construction)

    base_groups = recon["groups"]
    sens = {}
    all_rows = list(construction) + list(holdout)
    hold_ids = [str(r["event_id"]) for r in holdout]
    for km, days in WINDOWS:
        relinked = decluster.assign_sequences(all_rows, space_km=km, time_days=days)
        seq_of = {str(r["event_id"]): r["sequence_id"] for r in relinked}
        groups = [seq_of[e] for e in hold_ids]
        if (km, days) == (100.0, 30.0) and groups != [str(g) for g in base_groups]:
            raise SystemExit("default window does not reproduce the frozen holdout sequence ids")
        fam = family(y, preds, groups, "brier")
        sens[f"{int(km)}km_{int(days)}d"] = {
            "n_holdout_clusters": len(set(groups)),
            "holm_rejected_pairs": [f"{r['a'][:2]}-{r['b'][:2]}" for r in fam if r["holm_reject"]],
            "n_holm_reject": sum(r["holm_reject"] for r in fam),
            "pairs": fam,
        }
    out["sequence_definition_sensitivity"] = sens

    ref_rows = [r for r in family(y, preds, base_groups, "brier")
                if r["a"] in ("B0_no_skill", "B1_magnitude_only_logit")]
    out["reference_only_family"] = {
        "definition": "each learned candidate against B0 and against B1 (seven pairs)",
        "pairs": holm([{k: v for k, v in r.items() if k != "holm_reject"} for r in ref_rows]),
    }
    out["reference_only_family"]["holm_rejected_pairs"] = [
        f"{r['a'][:2]}-{r['b'][:2]}" for r in out["reference_only_family"]["pairs"] if r["holm_reject"]]
    out["secondary_metric_holm"] = {m: family(y, preds, base_groups, m) for m in ("log_loss", "auroc")}
    for m, fam in out["secondary_metric_holm"].items():
        out[f"n_holm_reject_{m}"] = sum(r["holm_reject"] for r in fam)

    base = [str(g) for g in base_groups]
    out["cluster_structure"] = cluster_structure(base)
    pairs = list(itertools.combinations(sorted(preds), 2))
    ve_rows = [{"a": a, "b": b, **variance_estimator_p(y, preds[a], preds[b], base)} for a, b in pairs]
    out["variance_estimator_sensitivity"] = {
        "definition": "Brier family on the default sequences: CR1 t(G-1), leave-one-cluster-out CR3 jackknife t(G-1), "
                      "null-imposed wild cluster Rademacher bootstrap-t, and an event-level independence t for contrast",
        "wild_draws": WILD_DRAWS, "wild_seed": ac.BOOTSTRAP_SEED,
        "pairs": ve_rows,
        "holm_rejected_pairs": {k: holm_on(ve_rows, k) for k in
                                ("cr1_p", "cr3_jackknife_p", "wild_cluster_rademacher_p", "event_level_iid_p")},
    }
    region = {}
    for cell in REGION_CELLS_DEG:
        groups = [f"{math.floor(float(r['latitude']) / cell)}:{math.floor(float(r['longitude']) / cell)}"
                  for r in holdout]
        rows = [{"a": a, "b": b, **variance_estimator_p(y, preds[a], preds[b], groups)} for a, b in pairs]
        region[f"{int(cell)}deg_cells"] = {
            "cluster_structure": cluster_structure(groups),
            "pairs": rows,
            "holm_rejected_pairs": {k: holm_on(rows, k) for k in ("cr1_p", "cr3_jackknife_p", "wild_cluster_rademacher_p")},
        }
    out["region_block_sensitivity"] = {
        "definition": "holdout events clustered by latitude-longitude grid cell instead of sequence; roles and fits fixed",
        "cells": region,
    }

    def balanced_groups(n, n_clusters, seed):
        rng = np.random.default_rng(seed)
        idx = rng.permutation(n)
        g = np.empty(n, dtype=object)
        for i, k in enumerate(idx):
            g[k] = f"synth{i % n_clusters}"
        return g.tolist()

    synth = {}
    n = y.size
    b1, b4 = "B1_magnitude_only_logit", "B4_random_forest"
    for n_clusters in (86, 54, 43):
        groups = balanced_groups(n, n_clusters, ac.BOOTSTRAP_SEED)
        rows = []
        for a, b in pairs:
            rec = cluster_robust_p(y, preds[a], preds[b], groups, "brier")
            d = additive_losses(y, preds[a], "brier") - additive_losses(y, preds[b], "brier")
            se_iid = float(np.std(d, ddof=1) / math.sqrt(d.size))
            rec["event_level_iid_p"] = ac._round12(2.0 * student_t.sf(abs(rec["cluster_robust_t"] * rec["cluster_robust_se"] / se_iid), df=d.size - 1))
            rec["se_ratio_cr1_over_iid"] = ac._round12(rec["cluster_robust_se"] / se_iid)
            rec["a"], rec["b"] = a, b
            rec["p_two_sided"] = rec["p_two_sided"]
            rows.append(rec)
        holm(rows)
        b14 = next(r for r in rows if {r["a"], r["b"]} == {b1, b4})
        synth[f"{n_clusters}_clusters"] = {
            "cluster_structure": cluster_structure(groups),
            "n_holm_reject": sum(r["holm_reject"] for r in rows),
            "B1_B4": {"cr1_p": b14["p_two_sided"], "event_level_iid_p": b14["event_level_iid_p"],
                      "se_ratio_cr1_over_iid": b14["se_ratio_cr1_over_iid"]},
        }
    out["synthetic_larger_cluster_sensitivity"] = {
        "definition": "post-hoc illustration: freeze holdout Brier losses and randomly partition the same 430 events into fewer, larger clusters (seed 20260901). Not a physical aftershock model; it shows how CR1 compares with an event-level t when mean cluster size is 5, 8, or 10 rather than 1.22.",
        "cells": synth,
    }

    with open(OUT, "w") as fh:
        json.dump(out, fh, indent=2, sort_keys=True)
        fh.write("\n")
    for k, v in out["split_contrast_paired"].items():
        print(k, v["point"], v["ci95"], v["excludes_zero"])
    for k, v in sens.items():
        print(k, v["n_holdout_clusters"], v["n_holm_reject"], v["holm_rejected_pairs"])
    print("reference-only family:", out["reference_only_family"]["holm_rejected_pairs"])
    for m, fam in out["secondary_metric_holm"].items():
        print(m, [(r["a"][:2], r["b"][:2], r["point"], r["ci95"], r["holm_reject"]) for r in fam])
    print("cluster structure:", out["cluster_structure"])
    print("variance estimators:", out["variance_estimator_sensitivity"]["holm_rejected_pairs"])
    for k, v in region.items():
        print(k, v["cluster_structure"], v["holm_rejected_pairs"])
    print("synthetic clusters:", {k: v["B1_B4"] | {"n_holm": v["n_holm_reject"]} for k, v in synth.items()})


if __name__ == "__main__":
    main()
