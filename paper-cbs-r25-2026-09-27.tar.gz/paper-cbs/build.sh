#!/usr/bin/env bash
# Deterministic, self-contained build of the Cybernetics and Systems (double-anonymous) manuscript.
#
# Steps (all scripted, no hand-editing):
#   1. Generate decision-support assets from frozen inputs.
#   2. Regenerate the venue-formatted table inputs from the canonical, validated
#      generated tables under manuscript/tables/ (layout-only transform).
#   3. Fit wide generated tables to the single-column review layout.
#   4. Copy the deterministic figures (byte-identical to the validated assets).
#   5. Compile main.tex -> main.pdf with tectonic (auto reruns bibtex + passes).
#   6. Compile supplement.tex -> supplement.pdf and title_page.tex -> title_page.pdf.
#
# Requires: python3, tectonic. No network write, no DOI mint, no submission.
set -euo pipefail
cd "$(dirname "$0")"
export SOURCE_DATE_EPOCH=1262304000

echo "[1/6] generating decision-support assets ..."
mkdir -p frozen_inputs
if [[ -f ../derived/asset_inputs.json ]]; then
  cp -f ../derived/asset_inputs.json frozen_inputs/asset_inputs.json
fi
if [[ -f ../paper/build_ledger.json ]]; then
  python3 - <<'PY'
import json
src = json.load(open("../paper/build_ledger.json"))
withheld = "withheld for double-anonymous review; see separate title page"
for key in list(src):
    if isinstance(src[key], str) and ("github.com" in src[key] or key in ("public_repository", "public_release_tag")):
        src[key] = withheld
with open("frozen_inputs/original_build_ledger.json", "w") as fh:
    json.dump(src, fh, indent=2, sort_keys=True)
    fh.write("\n")
PY
fi
if [[ -f ../../bundle/release/CORRECTIONS_OVERLAY.json ]]; then
  cp -f ../../bundle/release/CORRECTIONS_OVERLAY.json frozen_inputs/corrections_overlay.json
fi
SHAKEMAP_RESULTS="../../../integrated-studies/contract-transfer-shakemap/results"
if [[ -f "$SHAKEMAP_RESULTS/reconstruction_v2.json" ]]; then
  cp -f "$SHAKEMAP_RESULTS/results.json" frozen_inputs/contract_transfer_shakemap_v1.json
  cp -f "$SHAKEMAP_RESULTS/reconstruction_v1.json" frozen_inputs/contract_transfer_shakemap_reconstruction_v1.json
  cp -f "$SHAKEMAP_RESULTS/v1_event_rows.jsonl.gz" frozen_inputs/contract_transfer_shakemap_v1_rows.jsonl.gz
  cp -f "$SHAKEMAP_RESULTS/results_v2.json" frozen_inputs/contract_transfer_shakemap_v2.json
  cp -f "$SHAKEMAP_RESULTS/reconstruction_v2.json" frozen_inputs/contract_transfer_shakemap_reconstruction_v2.json
  cp -f "$SHAKEMAP_RESULTS/v2_event_rows.jsonl.gz" frozen_inputs/contract_transfer_shakemap_v2_rows.jsonl.gz
  cp -f "$SHAKEMAP_RESULTS/hash_manifest_v2.json" frozen_inputs/contract_transfer_shakemap_hash_manifest_v2.json
  cp -f "$SHAKEMAP_RESULTS/../code/reconstruct_v2_release.py" frozen_inputs/contract_transfer_shakemap_reconstruct_v2.py
  cp -f "$SHAKEMAP_RESULTS/../code/reconstruct_v1_release.py" frozen_inputs/contract_transfer_shakemap_reconstruct_v1.py
  cp -f "$SHAKEMAP_RESULTS/../code/verify_v1_release.py" frozen_inputs/contract_transfer_shakemap_verify_v1.py
  cp -f "$SHAKEMAP_RESULTS/../code/verify_v2_release.py" frozen_inputs/contract_transfer_shakemap_verify_v2.py
  cp -f "$SHAKEMAP_RESULTS/verification_environments_v1.json" frozen_inputs/contract_transfer_shakemap_verification_environments_v1.json
fi
PROSPECTIVE="../../../integrated-studies/prospective-dyfi-2025"
if [[ -f "$PROSPECTIVE/results/results.json" ]]; then
  cp -f "$PROSPECTIVE/results/results.json" frozen_inputs/prospective_dyfi_2025.json
  cp -f "$PROSPECTIVE/results/raw_payload.geojson.gz" frozen_inputs/prospective_dyfi_2025_raw_payload.geojson.gz
  cp -f "$PROSPECTIVE/results/holdout_rows.jsonl.gz" frozen_inputs/prospective_dyfi_2025_holdout_rows.jsonl.gz
  cp -f "$PROSPECTIVE/results/hash_manifest.json" frozen_inputs/prospective_dyfi_2025_hash_manifest.json
  cp -f "$PROSPECTIVE/results/verification_environments.json" frozen_inputs/prospective_dyfi_2025_verification_environments.json
  cp -f "$PROSPECTIVE/prereg/frozen_design.json" frozen_inputs/prospective_dyfi_2025_frozen_design.json
  cp -f "$PROSPECTIVE/prereg/analysis_plan.md" frozen_inputs/prospective_dyfi_2025_analysis_plan.md
  cp -f "$PROSPECTIVE/prereg/prereg_hashes.json" frozen_inputs/prospective_dyfi_2025_prereg_hashes.json
  cp -f "$PROSPECTIVE/code/run_prospective.py" frozen_inputs/prospective_dyfi_2025_run.py
  cp -f "$PROSPECTIVE/code/verify_prospective.py" frozen_inputs/prospective_dyfi_2025_verify.py
  cp -f "$SHAKEMAP_RESULTS/verification_environments.json" frozen_inputs/contract_transfer_shakemap_verification_environments.json
  cp -f "$PROSPECTIVE/results/post_hoc_winners.json" frozen_inputs/prospective_dyfi_2025_post_hoc_winners.json
  cp -f "$PROSPECTIVE/code/post_hoc_winners.py" frozen_inputs/prospective_dyfi_2025_post_hoc_winners.py
fi
DIABETES="../../../integrated-studies/contract-transfer-diabetes"
if [[ -f "$DIABETES/results/results.json" ]]; then
  for sub in code prereg results; do
    mkdir -p "frozen_inputs/diabetes_transfer/$sub"
    find "$DIABETES/$sub" -maxdepth 1 -type f -exec cp -f {} "frozen_inputs/diabetes_transfer/$sub/" \;
  done
  rm -rf frozen_inputs/diabetes_transfer/code/__pycache__
fi
UTILITY_PYTHON="${DYFI_FIGURE_PYTHON:-}"
if [[ -z "$UTILITY_PYTHON" && -x ../.venv-fig/bin/python ]]; then
  UTILITY_PYTHON="../.venv-fig/bin/python"
fi
if [[ -z "$UTILITY_PYTHON" ]]; then
  UTILITY_PYTHON="python3"
fi
"$UTILITY_PYTHON" build_utility_assets.py

echo "[2/6] formatting tables from canonical assets ..."
python3 format_tables.py

echo "[3/6] fitting wide tables to review layout ..."
python3 format_cbs_tables.py

echo "[4/6] syncing figures ..."
mkdir -p figures
cp -f ../figures/*.png figures/
cp -f ../figures/*.pdf figures/
rm -f figures/fig_leakage_split.png figures/fig_leakage_split.pdf figures/fig_leakage_split.svg
"$UTILITY_PYTHON" build_utility_assets.py

echo "[5/6] compiling main manuscript with tectonic ..."
tectonic --keep-logs main.tex >/dev/null 2>&1

echo "[6/6] compiling supplementary information ..."
tectonic --keep-logs supplement.tex >/dev/null 2>&1
tectonic --keep-logs title_page.tex >/dev/null 2>&1

pages=$(pdfinfo main.pdf 2>/dev/null | awk '/Pages:/ {print $2}')
supp_pages=$(pdfinfo supplement.pdf 2>/dev/null | awk '/Pages:/ {print $2}')
python3 generate_ledgers.py
pdftotext -layout main.pdf main.txt
echo "OK: main.pdf built (${pages:-?} pages); supplement.pdf (${supp_pages:-?} pages)."
